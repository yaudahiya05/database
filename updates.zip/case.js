// case.js
import fs from 'fs';
import chalk from 'chalk';
import util from 'util';
import path from 'path';
import crypto from 'crypto';
import moment from 'moment-timezone';
import phonenumber from 'awesome-phonenumber';
import * as baileys from '@whiskeysockets/baileys';
import toMs from 'ms';
import yts from 'yt-search';
import axios from 'axios';
import * as cheerio from 'cheerio';
import request from 'request';
import ms from 'parse-ms';
import fetch from 'node-fetch';
import { exec } from 'child_process';
import func from './system/functions.js';
import { fileURLToPath } from 'url';
import {
    createRequire
} from 'module';
const __filename = fileURLToPath(import.meta.url);
const require = createRequire(import.meta.url);
const FormData = require('form-data');

export default async (m, client, ctx) => {
    const { chat, sender, body, budy, prefix, command, cmd, args, text, mtype, reply, expiration, isDevs, isOwner, isPrem, isVIP, isPrefix, isBot, isPc, isGc, isAdmin, isBotAdmin } = m;
    const { cfg, socket, utils, mapping, plugins, commands, events, database, store, users, groups, setting, date, time, packname, author, isBanned, quoted, mime, froms, errorMessage, YT, CASE,lid } = ctx;
    const lulli = client;

    function get(jid) {
        if (jid.endsWith('@g.us')) {
            return global.db.groups[jid]
        } else {
            jid = jid.replace(/\D/g, '') + '@s.whatsapp.net'
            return global.db.users[jid]
        }
    }

    let target;
    if (froms) {
        target = global.db.users[froms];
    }

    // Memblokir command dari baileys
    if (isBot) return

    // Memblokir command yang sudah ada pada plugins
    if (command && commands.includes(command)) return

    const sendAudio = async (media, ptt = false) => {
        if (!media) return false;
        try {
            return await client.sendMessage(m.chat, {
                audio: Buffer.isBuffer(media) ? media : { url: media },
                mimetype: ptt ? 'audio/ogg; codecs=opus' : 'audio/mp4',
                ptt: ptt
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } catch (error) {
            console.error('✗ Gagal mengirim audio:', error);
            return error.message;
        }
    };

    // Feature Versi Case
    switch (command) {
        case 'tes':
            client.sendMessageModify(chat, `Quick Test Done! ${m.pushname}`, m, {
                title: 'Aktif Selama :',
                body: func.runtime(process.uptime()),
                thumbUrl: setting.cover,
                largeThumb: false,
                url: setting.cover,
                expiration
            })
            break
        case 'join': {
            if (m.quoted || text) {
                try {
                    let url = m.quoted ? m.quoted.text : text;
                    if (url.includes('chat.whatsapp.com')) {
                        await client.groupAcceptInvite(url.split('https://chat.whatsapp.com/')[1])
                            .then(json => {
                                let string = String(json);
                                if (!string) {
                                    reply('Mohon untuk menerima bot agar dapat bergabung ke dalam grup.');
                                } else if (string.endsWith('@g.us')) {
                                    reply(string);
                                }
                            })
                    } else reply('Masukkan link grup dengan benar!')
                } catch (error) {
                    console.log('errorAcceptInvite:', error.message);
                    if (error.message.includes('already-exists')) {
                        return reply('Bot sudah pernah melakukan permintaan bergabung sebelumnya.');
                    }
                    return reply('Bot sudah terkick, tidak dapat join.')
                }
            } else reply(`Kirim perintah ${m.cmd} link grup\n_Contoh: ${m.cmd} https://chat.whatsapp.com/BgrnHVRRpRaJKHN7AxGYEa_`)
        }
        break
        case 'sange': {
            if (!m.isGc) return m.reply(cfg.mess.group);
            let target = m.members.map(x => x.id).random();
            await reply(`orang tersange di grup ini adalah @${target.replace(/@.+/, '')}`)
        }
        break
        default:
            // EVAL & EXEC CODE
            if (isDevs && /^(x|xx)$/.test(m.command)) {
                let evalCode;
                let evalCmd;
                if (m.command === 'x') evalCode = text ? text : false;
                else if (m.command === 'xx') evalCode = m.quoted && m.quoted.text ? m.quoted.text : text ? text : false
                if (!evalCode) return false;
                try {
                    evalCmd = /await/i.test(evalCode) ? eval("(async () => { " + evalCode + " })()") : eval(evalCode)
                    let evaled = await evalCmd;
                    if (typeof evaled !== 'string') evaled = util.inspect(evaled)
                    client.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (error) {
                    client.sendMessage(m.chat, {
                        text: error.message
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (isDevs && m.command === '=>' && text) {
                try {
                    let evaled = await eval(`(async () => { return ${text} })()`)
                    client.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (e) {
                    client.sendMessage(m.chat, {
                        text: util.format(e)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (isDevs && m.command === '$' && text) {
                client.sendReact(m.chat, '🕒', m.key)
                exec(text, (err, stdout) => {
                    if (err) return client.sendMessage(m.chat, {
                        text: err.toString()
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                    if (stdout) return client.sendMessage(m.chat, {
                        text: util.format(stdout)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                })
            }
    }
}