const run = async (m, lulli) => {
    if (global.db.blockcmd.length == 0) return m.reply('Empty data.')
    let caption = '乂  *LIST BLOCK COMMANDS*\n\n'
    caption += `Total: *${global.db.blockcmd.length}* commands blocked\n\n`
    caption += global.db.blockcmd.map((v) => `◦  ${m.prefix + v.command}`).join('\n')
    await m.reply(caption)
}

module.exports = {
    run,
    cmd: 'listblockcmd',
    alias: 'listblokcmd',
    type: 'info',
    location: 'plugins/info/listblockcmd.js'
}