const truthQuestions = [
    `apakah {userMention} masih memiliki perasaan kepada mantan?`,
    `apa rahasia yang {userMention} sembunyikan dari orang tua?`,
    `jika kamu terlahir kembali/reinkarnasi, kamu ingin menjadi siapa?`,
    `peristiwa/kejadian paling memalukan di kehidupan {userMention}?`,
    `hal apa yang membuat {userMention} merasa insecure?`,
    `apa kesalahan terburuk yang pernah {userMention} lakukan?`,
    `jika kamu bisa kembali ke masa lalu dan merubah sesuatu, apa yang akan {userMention} rubah?`,
    `apa yang menyebabkan {userMention} tidak percaya diri?`,
    `ketika di rumah tidak ada siapa-siapa, biasanya {userMention} melakukan kegiatan apa?`,
    `pernahkah {userMention} terobsesi sama sesuatu? siapa atau apa itu?`,
    `apa {userMention} pernah pacaran satu jenis?`,
    `apa {userMention} pernah ciuman? entah bersama teman atau pacar.`,
    `apa yang ingin {userMention} katakan kepada orang tua?`,
    `sebutkan 3 film favorit yang tidak bisa {userMention} lupakan!`,
    `apa nama panggilan {userMention} yang paling aneh?`,
    `jika permintaan {userMention} dapat terkabul, maka akan meminta apa?`,
    `apa omongan tersakit yang pernah {userMention} terima dari orang lain?`,
    `apa ketakutan terbesar {userMention} pada saat ini?`,
    `apa penyesalan terbesar {userMention}?`,
    `apa hal terindah yang {userMention} ingat?`,
    `acara tv apa yang paling memuakkan menurut {userMention}? berikan alasannya!`,
    `apa baju yang menurut {userMention} paling jelek yang pernah {userMention} pakai, dan kapan {userMention} memakainya?`,
    `apa binatang patronus yang cocok untuk {userMention}?`,
    `apa hal paling buruk yang pernah {userMention} bilang tentang teman {userMention}?`,
    `apa hal paling memalukan dari {userMention}?`,
    `apa hal paling memalukan dari teman {userMention}?`,
    `apa hal pertama yang {userMention} lihat saat melihat orang lain (beda gender)?`,
    `apa hal pertama yang terlintas di pikiran {userMention} saat melihat cermin?`,
    `apa hal terbodoh yang pernah {userMention} lakukan?`,
    `apa ketakutan terbesar {userMention}?`,
    `apa mimpi terburuk {userMention}?`,
    `apa mimpi terkonyol yang pernah {userMention} ingat?`,
    `apa pekerjaan paling konyol yang pernah {userMention} bayangkan?`,
    `apa sifat terburuk {userMention} menurut {userMention}?`,
    `apa sifat yang ingin {userMention} ubah dari diri {userMention}?`,
    `apa sifat yang ingin {userMention} ubah dari teman {userMention}?`,
    `apa yang akan {userMention} lakukan bila pasangan {userMention} bilang hidung atau jari {userMention} jelek?`,
    `apa yang {userMention} pikirkan sebelum tidur?`,
    `apakah hal yang menurut {userMention} paling menonjol dari diri {userMention}?`,
    `bagian tubuh teman {userMention} mana yang paling {userMention} sukai dan ingin {userMention} punya?`,
    `bagian tubuh {userMention} mana yang paling {userMention} benci?`,
    `dari semua kelas yang ada di sekolah, kelas mana yang paling ingin {userMention} masuki dan hindari?`,
    `deskripsikan teman terdekat {userMention}!`,
    `deskripsikan diri {userMention} dalam satu kata!`,
    `film dan lagu apa yang pernah bikin {userMention} nangis?`,
    `hal apa yang {userMention} rahasiakan sampai sekarang dan nggak ada satu orang pun yang tahu?`,
    `hal paling romantis apa yang seseorang (beda gender) pernah lakukan atau kasih ke {userMention}?`,
    `hal-hal menjijikkan apa yang pernah {userMention} alami?`,
    `jika {userMention} lahir kembali dan harus jadi teman {userMention}, siapa yang akan dipilih?`,
    `jika punya kekuatan super, apa yang ingin {userMention} lakukan?`,
    `jika sebentar lagi kiamat, apa yang akan {userMention} lakukan?`,
    `kalau {userMention} disuruh operasi plastik niru wajah teman, wajah siapa yang akan ditiru?`,
    `apakah {userMention} pernah mencuri sesuatu?`,
    `apakah {userMention} takut mati? kenapa?`,
    `kapan terakhir kali {userMention} menangis dan mengapa?`,
    `kemampuan spesial apa yang {userMention} miliki?`,
    `kok bisa {userMention} suka sama orang yang {userMention} sukai?`,
    `menurut {userMention}, apa sifat baik teman terdekat yang nggak dia sadari?`,
    `orang seperti apa yang ingin {userMention} nikahi suatu saat nanti?`,
    `pekerjaan paling ngenes apa yang menurut {userMention} cocok untuk teman di sebelah kanan?`,
    `pengen tukeran hidup sehari dengan siapa? (teman terdekat) dan mengapa?`,
    `pernahkah {userMention} diam-diam berharap hubungan seseorang dengan pacarnya putus? siapa?`,
    `pilih pacar atau teman? berikan alasannya!`,
    `quote apa yang paling {userMention} ingat dan suka?`,
    `rahasia apa yang belum pernah {userMention} katakan sampai sekarang kepada teman?`,
    `role model (panutan) {userMention} siapa?`,
    `siapa di antara teman {userMention} yang {userMention} pikir matre?`,
    `siapa di antara teman {userMention} yang potongan rambutnya paling nggak banget?`,
    `siapa di antara teman {userMention} yang paling nggak fotogenik?`,
    `siapa mantan terindah {userMention}? dan mengapa kalian putus?`,
    `siapa nama artis yang pernah {userMention} cium fotonya diam-diam?`,
    `siapa nama guru cowok yang pernah {userMention} sukai dulu?`,
    `siapa nama mantan pacar teman yang pernah {userMention} sukai diam-diam?`,
    `siapa nama orang (beda gender) yang menurut {userMention} akan asyik bila dijadikan pacar?`,
    `siapa nama orang yang {userMention} benci, tapi {userMention} rasa orang itu suka sama {userMention}?`,
    `siapa nama orang yang pernah {userMention} ikuti diam-diam?`,
    `siapa orang yang paling sering terlintas di pikiran {userMention}?`,
    `siapa orang yang paling menjengkelkan di antara teman-teman {userMention}? alasannya!`,
    `siapa sebenarnya di antara teman {userMention} yang harus di-make-over?`,
    `siapa yang paling mendekati tipe pasangan ideal {userMention} di sini?`,
    `pernahkah {userMention} bohong sama orang tua demi main keluar?`,
    `siapa orang terakhir yang {userMention} stalk di sosmed?`,
    `apa kebiasaan terburuk yang nggak bisa {userMention} hilangin?`,
    `pernahkah {userMention} naksir pacar temen sendiri?`,
    `apa rahasia terdalam yang belum pernah {userMention} ceritain ke siapa-siapa?`,
    `pernahkah {userMention} pura-pura sakit buat bolos sekolah/kerja?`,
    `siapa mantan yang paling bikin {userMention} susah move on?`,
    `pernahkah {userMention} selingkuh atau diselingkuhin?`,
    `kapan terakhir kali {userMention} ngompol di celana?`,
    `apa chat terakhir yang {userMention} hapus sebelum dibaca orangnya?`
];

const dareQuestions = [
    `sebutkan nama orang terkenal yang mirip dengan {userMention}.`,
    `katakan 'i love you' kepada member ke-4 di grup ini.`,
    `unggah foto random di story whatsapp sekarang juga.`,
    `lakukan 50x push up tanpa henti!`,
    `posting salah satu draf absurd yang ada di tiktok kamu.`,
    `berikan sebagian saldo/uang virtualmu ke member ke-2 di grup ini.`,
    `pakai helm saat makan siang hari ini dan kirim fotonya.`,
    `buatlah karangan singkat tentang betapa hebatnya dirimu.`,
    `cium layar hp-mu dan kirim fotonya ke grup.`,
    `suruh member ke-6 untuk mengirimkan pap wajahnya.`,
    `bikin video random lalu post ke story instagram.`,
    `buat dance tiktok yang absurd dan kirim ke grup.`,
    `buat text story whatsapp, katakan bahwa {userMention} sudah jadian bersama crush.`,
    `kirim pap dengan pose ✌🏻 ke grup ini.`,
    `kirim pap dengan pose jelek/komuk ke grup ini.`,
    `ajak orang yang tidak dikenal untuk selfie berdua lalu upload ke snapgram.`,
    `ambil nomor acak di kontakmu dan chat 'aku hamil anakmu!'.`,
    `ambil minuman terdekat, campur dengan garam, lalu minum sedikit.`,
    `telepon nomor acak di kontakmu, lalu bilang 'aku mencintaimu'.`,
    `berdiri di depan rumah dan berteriak, 'aku jomblo ngenes!'`,
    `beri hormat pada ibumu dan bilang 'hamba siap melayani anda, yang mulia.'`,
    `nyanyikan lagu 'selamat ulang tahun' sambil tepuk tangan di grup (pakai vn).`,
    `bikin hiasan kepala absurd dari tisu, pakai, lalu pap ke grup.`,
    `bilang 'kamu cantik/ganteng banget nggak bohong' pada member ke-5.`,
    `chat mantanmu dan bilang 'aku kangen kamu'.`,
    `buang 1 kertas tak terpakai ke tempat sampah sambil divideoin.`,
    `isi mulutmu dengan air, lalu ada yang melawak. kalau tumpah harus ulangi!`,
    `kirim sms pada orang tua {userMention} 'ma, pa, aku mau nikah besok.'`,
    `makan satu sendok kecap manis campur kecap asin!`,
    `makan sesuatu tanpa menggunakan tangan (seperti hewan).`,
    `marah-marah gajelas di vn dan kirim ke grup.`,
    `pecahkan telur ayam mentah pakai dahi kamu (kalau berani).`,
    `campur minuman dengan makanan, lalu minum sedikit (pastikan aman).`,
    `menari ala blackpink atau bts lalu pap ke grup.`,
    `gombalin admin grup ini sekarang juga!`,
    `tiru gaya bicara/ketikan salah satu member di grup ini seharian.`,
    `nyanyikan lagu 'hai tayo' di vn sambil teriak.`,
    `nyanyi lagu disney di vn dengan suara sekencang mungkin.`,
    `teriak 'woi gw {userMention}, denger nih raungan gw, roaaaar!' (pakai vn).`,
    `jadikan foto profil wa kamu gambar monyet selama 1 jam.`,
    `nyanyikan lagu 'balonku ada lima' pakai huruf o semua di vn.`,
    `telepon nomor acak dan bilang 'halo, pesanan ayam gepreknya udah sampai'.`,
    `buat vn ngomong 'aku cinta banget sama kamu' dan kirim ke grup.`,
    `upload foto aib teman terdekatmu di story wa sekarang juga.`,
    `makan 1 sendok ujung garam/gula sekarang juga.`
];

// sistem memori anti-repeat (disimpan di RAM selama bot hidup)
const tracker = {
    truth: new Set(),
    dare: new Set()
};

const getUniqueQuestion = (type, userMention) => {
    const questions = type === 'truth' ? truthQuestions : dareQuestions;
    const usedSet = tracker[type];

    // kalau pertanyaan udah habis semua, reset dari 0
    if (usedSet.size >= questions.length) {
        usedSet.clear();
    }

    // cari index yang belum pernah kepakai
    const availableIndexes = questions.map((_, i) => i).filter(i => !usedSet.has(i));
    const randomIndex = availableIndexes[Math.floor(Math.random() * availableIndexes.length)];
    
    // tandai index ini udah dipakai
    usedSet.add(randomIndex);

    return questions[randomIndex].replace(/{userMention}/g, userMention).toLowerCase();
};

const run = async (m, client) => {
    try {
        const userMention = `@${m.sender.split('@')[0]}`;
        const commandType = m.command.toLowerCase();

        if (!['truth', 'dare'].includes(commandType)) {
            return m.reply('✗ command tidak valid. ketik truth atau dare ya sayang.');
        }

        const selectedQuestion = getUniqueQuestion(commandType, userMention);

        let caption = `𐙚 .˚ 𝘁𝗿𝘂𝘁𝗵 𝗼𝗿 𝗱𝗮𝗿𝗲 .˚ 𐙚\n`;
        caption += `. . . . . . . . . . . . . 🎀\n\n`;
        caption += `╭ ┈ ┈ ┈ 𐙚\n`;
        caption += `┊ ᰔ tipe : ${commandType}\n`;
        caption += `┊ ᰔ buat : ${userMention}\n`;
        caption += `┊ ᰔ pertanyaan/tantangan :\n`;
        
        // memecah baris agar rapi di dalam box jika teksnya panjang
        const formattedQuestion = selectedQuestion.split('\n').map(line => `┊ ᰔ ${line}`).join('\n');
        caption += formattedQuestion + `\n`;
        
        caption += `╰ ┈ ┈ ┈ 𐙚\n\n`;
        caption += `   ︶︶︶︶︶︶︶︶ 🎀`;

        await client.reply(m.chat, caption, m, {
            mentions: [m.sender]
        });

    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Truth or Dare:', e);
        await m.reply(`✗ duh sayang, ada error nih: ${e.message}`);
    }
};

export default {
    run,
    cmd: ['truth', 'dare'],
    type: 'user',
    limit: true,
    location: 'plugins/user/truth-dare.js'
};