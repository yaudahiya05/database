const FormData = require('form-data');
const axios = require('axios');

const upscale = async (buffer, scale = "2") => {
    try {
        const form = new FormData();
        form.append("image", Buffer.from(buffer), {
            filename: `${Date.now()}.png`,
            contentType: "image/png",
        });
        form.append("scale", scale);

        const {
            data
        } = await axios.post("https://api2.pixelcut.app/image/upscale/v1",
            form, {
                headers: {
                    ...form.getHeaders(),
                    "X-Client-Version": "web",
                    "X-Locale": "id",
                    accept: "application/json",
                },
            },
        );

        return {
            status: true,
            result_url: data.result_url,
        };
    } catch (error) {
        return {
            status: false,
            message: error.message
        }
    }
}

const run = async (m, lulli, {
    func,
    cfg,
    quoted
}) => {
    if (/image\/(jpe?g|png)/.test(quoted.mime)) {
        lulli.sendReact(m.chat, '🕒', m.key)
        let imageBuffer = await quoted.download()
        try {
            // const enhancedImageBuffer = await remini(imageBuffer, m.text ? m.text : 'enhance');
            // if (!Buffer.isBuffer(enhancedImageBuffer)) return m.reply('Result is not buffer.')
            const result = await upscale(imageBuffer, "2");
            if (!result.status) return m.reply(result.message);
            await lulli.sendMessage(m.chat, {
                image: {
                    url: result.result_url
                }
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
            await lulli.sendReact(m.chat, '✅', m.key);
        } catch (error) {
            console.error("Error enhancing image:", error);
            await m.reply('Error enhancing image: ' + error);
        }
    } else m.reply(`Reply gambar dengan caption ${m.cmd}`)
}

module.exports = {
    run,
    cmd: 'remini',
    alias: ['hd', 'upscale'],
    use: 'reply photo',
    type: 'ai',
    premium: true,
    location: 'plugins/ai/remini.js'
}