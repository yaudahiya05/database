const axios = require('axios')
const FormData = require('form-data');

const upscale = async (imageBuffer) => {
    try {
        const form = new FormData();
        form.append("image", imageBuffer, {
            filename: "image.jpg",
            contentType: "image/jpeg",
        });

        const response = await axios.post("https://api2.pixelcut.app/image/upscale/v1", form, {
            headers: {
                ...form.getHeaders(),
                accept: "application/json",
                "x-client-version": "web",
                "x-locale": "en",
            },
            referrer: "https://www.pixelcut.ai/",
        });
        return response.data;
    } catch (err) {
        console.error(err.response?.data || err.message);
        throw err;
    }
}

const cache = new Set();

const run = async (m, lulli, {
    func,
    cfg,
    quoted
}) => {
    if (!quoted.mime) return m.reply(`Kirim/Reply gambar dengan caption *${m.cmd}*`)
    if (!/image\/(jpe?g|png)/.test(quoted.mime)) return m.reply(`Mime *${quoted.mime}* tidak didukung.`)
    if (cache.has(m.sender)) return m.reply('Masih ada proses yang belum diselesaikan.')
    cache.add(m.sender);
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const imageBuffer = await quoted.download()
        if (!imageBuffer || !Buffer.isBuffer(imageBuffer)) return m.reply('Gagal mengunduh atau file tidak valid.')
        const data = await upscale(imageBuffer)

        await lulli.sendMedia(m.chat, data.result_url, m, {
            caption: cfg.mess.ok,
            expiration: m.expiration
        });
        cache.delete(m.sender);
    } catch (e) {
        m.reply(cfg.mess.wrong(e.message));
    } finally {
        cache.delete(m.sender);
    }
}

module.exports = {
    run,
    cmd: 'remini3',
    alias: ['hd3', 'upscale3'],
    use: 'reply photo',
    type: 'ai',
    premium: true,
    location: 'plugins/ai/remini3.js'
}