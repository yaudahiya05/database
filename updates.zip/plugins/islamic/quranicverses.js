const fetch = require('node-fetch');
let cache = null;

const run = async (m, lulli) => {
    if (!cache) {
        cache = await fetch('https://raw.githubusercontent.com/Jabalsurya2105/database/master/data/quranicverses.json')
            .then(response => response.json());
    }

    let result = cache.random();
    await m.reply(resul);
}

module.exports = {
    run,
    cmd: 'quranicverses',
    alias: 'qv',
    type: 'islamic',
    desc: 'menampilkan random ayat dalam Al-Quran',
    location: 'plugins/islamic/quranicverses.js'
}