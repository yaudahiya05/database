async function run(m, lulli, {
    func,
    cfg,
    groups
}) {
    const [action] = m.args;
    if (!m.isBotAdmin && /antihacked|antiporn|antitoxic|antilink|antivirtex|antibot|antiluar|antihidetag|automatically|antigsmm|autokicksider/.test(m.command)) return m.reply(cfg.mess.botAdmin)
    if (!action) return m.reply(`*Current status*: ${groups[m.command] ? 'active' : 'non-active'}\n\n${func.example(m.cmd, 'on / off')}`)
    let option = action.toLowerCase();
    if (!/^(on|off)$/i.test(option)) return m.reply(func.example(m.cmd, 'on / off'))
    let status = option === 'on' ? true : false;
    if (groups[m.command] == status) return m.reply(`${func.ucword(m.command)} feature has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
    groups[m.command] = status;
    m.reply(`${func.ucword(m.command)} feature has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`)
}

module.exports = {
    run,
    cmd: [
        'welcome',
        'goodbye',
        'detect',
        'antigsm',
        'antihacked',
        'autosholat',
        'antiporn',
        'antitoxic',
        'antilink',
        'antivirtex',
        'antibot',
        'antiluar',
        'antihidetag',
        'antidelete',
        'antiedited',
        'autokicksider'
    ],
    use: 'on / off',
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/moderation.js'
}