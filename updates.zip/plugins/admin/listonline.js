async function run(m, lulli, {
    func,
    store,
    lid
}) {
    const [params] = m.args;
    try {
        let id = params && /\d+\-\d+@g.us/.test(params) ? params : m.chat;
        if (typeof store.presences[id] == 'undefined') return m.reply('Tidak ada peserta yang sedang online.');
        let online = [...Object.keys(store.presences[id]).filter(x => x.includes('@')), m.bot];
        if (online.length > 0) {
            await m.reply('Daftar peserta yang sedang online:\n\n' + online.map(jid => '- @' + (lid.isLidUser(jid) ? lid.get(jid) : jid).replace(/@.+/, '')).join('\n'))
        } else {
            await m.reply('Tidak ada peserta yang sedang online.');
        }
    } catch (e) {
        await m.reply(cfg.mess.wrong(e.message));
    }
}

module.exports = {
    run,
    cmd: 'listonline',
    type: 'group',
    group: true,
    admin: true,
    location: 'plugins/admin/listonline.js'
}