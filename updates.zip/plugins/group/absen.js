let run=async(a,e,{cfg:s,date:n,groups:t,socket:r})=>{let i;var u=t.absen,b=[["Absen",a.prefix+"absen"]];switch(a.command){case"mulaiabsen":if(!a.isAdmin&&!a.isOwner)return a.reply(s.mess.admin);if(u.status)return a.reply(`Masih ada absen di grup ini, kirim *${a.prefix}hapusabsen* untuk menghapus absen.`);t.absen={status:!0,alasan:a.text||"-",date:n,peserta:[],key:[]},i=`*ABSEN DI MULAI*

- *Tanggal*: ${t.absen.date}
- *Alasan*: `+t.absen.alasan;var p=(await e.sendbut(a.chat,i.trim(),"klik tombol dibawah untuk absen",b,a,{caption:i+`

kirim *${a.prefix}absen* untuk absen`,expiration:a.expiration})).key;t.absen.key.push({...p,botId:e.user.jid});break;case"absen":if(!u.status)return a.reply("Tidak ada absen di grup ini!");if(u.peserta.some(e=>e.jid===a.sender))return a.reply("Kamu sudah Absen!");if(a.text&&30<a.text.length)return a.reply("Max 30 characters.");if(t.absen.peserta.push({jid:a.sender,text:a.text||""}),i=`乂  *A B S E N*

- *Tanggal*: ${u.date}
- *Alasan*: ${u.alasan}
- *Total*: ${u.peserta.length}
- *Daftar Absen*: `+(u.peserta.length<1?"-":formatAbsen(u.peserta)),0<t.absen.key.length)for(var[l,d]of t.absen.key.entries()){await new Promise(e=>setTimeout(e,500));var o=r.get(d.botId)??e;try{await o.sendMessage(d.remoteJid,{delete:d})}catch(e){console.log("[ABSEN]",e.message)}t.absen.key.splice(l,1)}var p=(await e.sendbut(a.chat,i.trim(),"klik tombol dibawah untuk absen",b,a,{caption:i+`

kirim *${a.prefix}absen* untuk absen`,expiration:a.expiration})).key;t.absen.key.push({...p,botId:e.user.jid});break;case"cekabsen":if(!u.status)return a.reply("Tidak ada absen yang berlangsung!");i=`乂  ${a.groupName}

- *Tanggal*: ${u.date}
- *Alasan*: ${u.alasan}
- *Total*: ${u.peserta.length}
- *Daftar Absen*: ${u.peserta.length<1?"-":formatAbsen(u.peserta)}

kirim *${a.prefix}absen* untuk absen`,await a.reply(i.trim());break;case"hapusabsen":if(!a.isAdmin&&!a.isOwner)return a.reply(s.mess.admin);if(!u.status)return a.reply("Tidak ada absen yang berlangsung!");u.status=!1,u.peserta=[],await a.reply("Absen berhasil dihapus")}};function formatAbsen(e){return Array.isArray(e)?"\n"+e.map((e,a)=>`${a+1}. @${e.jid.split("@")[0]} `+(e.text||"")).join("\n"):"-"}module.exports={run:run,cmd:["mulaiabsen","absen","cekabsen","hapusabsen"],use:"alasan",type:"group",group:!0,location:"plugins/group/absen.js"};