const fs = require('fs').promises;

class MultiDB {
    constructor() {
        this.MongoURL = global.cfg?.mongoUrl;
        this.init = (this.MongoURL && /mongo/.test(this.MongoURL)) ? new(require('./mongodb'))(this.MongoURL) : new(require('./localdb'))();
    }

    initDatabase = async () => {
        let content = {};

        // Coba baca file database.json jika MongoURL tidak ada
        try {
            if (!(this.MongoURL && /mongo/.test(this.MongoURL))) {
                const data = await fs.readFile('./database/database.json', 'utf8');
                content = JSON.parse(data);
            }
        } catch (error) {
            console.error("Error reading database file:", error);
        }

        // Load database
        global.db = {
            users: {},
            groups: {},
            statistic: {},
            sticker: {},
            stickercmd: {},
            setting: {},
            menfes: {},
            tictactoe: {},
            petakbom: {},
            casino: {},
            chess: {},
            metadata: {},
            premium: {},
            sewabot: {},
            server: {},
            panel: {},
            renewpanel: {},
            autodonation: {
                status: false,
                amount: 519,
                lastDay: -1,
                lastTime: '08:36',
                taskDay: false,
                taskPayment: false,
                keyId: null
            },
            jadibot: [],
            owner: [],
            developer: [],
            blockcmd: [],
            paydata: [],
            testi: [],
            error: [],
            limit: {
                max: 10,
                data: []
            },
            ...(await this.init.read() || content)
        };

        // Save database
        try {
            await this.init.save(global.db);
        } catch (error) {
            console.error("Error saving database:", error.message);
        }
    }
};

module.exports = new MultiDB();