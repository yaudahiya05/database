const express = require('express');
const cors = require('cors');
const path = require('path');
const session = require('express-session');
const { minify } = require('html-minifier');
const webpush = require('web-push');
const crypto = require('crypto');
const apiRoutes = require('./script.js');
const mongodb = require('./MongoDB/mongodb.js');
const cookieParser = require('cookie-parser');

const app = express();
const PORT = process.env.PORT || 4000;
const internationalFormatRegex = /^\d{10,15}$/;
const PIN_KODE = '210505';

// 1. FUNGSI NANOID YANG BENAR UNTUK NODE.JS/VERCEL
function nanoid(size = 21) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    const bytes = crypto.randomBytes(size);
    let id = '';
    for (let i = 0; i < size; i++) {
        id += alphabet[bytes[i] & 63];
    }
    return id;
}

// 2. SETTINGS
app.set('port', PORT);
app.set('json spaces', 2);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.enable('trust proxy');

// 3. MIDDLEWARES DASAR
app.use(cookieParser());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'd7434351cb00216b643be0e10c81610a',
    resave: true,
    saveUninitialized: true,
    cookie: {
        maxAge: 24 * 60 * 60 * 1000
    }
}));

// 4. MIDDLEWARE KONEKSI DATABASE (Paling Penting untuk Vercel)
app.use(async (req, res, next) => {
    try {
        await mongodb.connect(); 
        next();
    } catch (err) {
        console.error("Database connection error:", err);
        res.status(500).send("Database Connection Error");
    }
});

// 5. MIDDLEWARE MINIFY HTML
function htmlMinifierMiddleware(req, res, next) {
    const originalSend = res.send;
    res.send = function(body) {
        if (typeof body === 'string' && /^\s*<(?:!DOCTYPE|html)/i.test(body)) {
            try {
                const minifiedBody = minify(body, {
                    collapseWhitespace: true,
                    removeComments: true,
                    minifyCSS: true,
                    minifyJS: true,
                    // removeEmptyAttributes: true,
                    // removeRedundantAttributes: true
                });
                return originalSend.call(this, minifiedBody);
            } catch (error) {
                return originalSend.call(this, body);
            }
        }
        return originalSend.call(this, body);
    };
    next();
}
app.use(htmlMinifierMiddleware);

// Jalur Masuk Utama & Loader
app.get('/', (req, res) => {
    // Jika cookie sudah ada, langsung lempar ke player ID-nya
    if (req.cookies && req.cookies.app_session_id) {
        return res.redirect(`/${req.cookies.app_session_id}`);
    } else {
        const uniqueAppSessionId = crypto.randomUUID();
        const maxAgeSeconds = 600; // 5 menit

        res.cookie('app_session_id', uniqueAppSessionId, {
            maxAge: maxAgeSeconds * 1000,
            httpOnly: true, // Aman dari pencurian script
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'Lax',
            path: '/'
        });
        return res.sendFile(path.join(__dirname, 'public/gate.html'));
    }
});

// Jalur Music Player (Halaman Utama)
app.get('/:uniqueId', (req, res) => {
    const { uniqueId } = req.params;

    // Validasi apakah cookie cocok dengan ID di URL
    if (req.cookies && req.cookies.app_session_id === uniqueId) {
        return res.sendFile(path.join(__dirname, 'public/main.html'));
    } else {
        console.warn(`⚠️ Akses tidak valid ke /${uniqueId}. Redirect ke gate.`);
        res.clearCookie('app_session_id', { path: '/' });
        return res.redirect('/');
    }
});


// 6. KONFIGURASI WEB PUSH
const vapidKeys = {
    publicKey: "BFohXfAeSKzcAZUZDuPDLztTOuZFZZ7vxTVEoSaOXM77PT2dWFYr9LnsjTUi8YjXM5-IJftvfpw_dYeng_Zl0Dc",
    privateKey: "Tf3H5n1mhn-ur7KQM4QvYe9Ifc77VwS8U9lvGemTICg"
};
webpush.setVapidDetails('mailto:suryadev2105@gmail.com', vapidKeys.publicKey, vapidKeys.privateKey);

// --- ROUTES ---
app.use('/', apiRoutes);

// --- BAGIAN BARU: ENDPOINT UNTUK NOTIFIKASI ---

// 1. Endpoint untuk memberikan VAPID public key ke frontend
app.get('/vapidPublicKey', (req, res) => {
    res.send(vapidKeys.publicKey);
});

// 2. Endpoint untuk menerima dan menyimpan langganan notifikasi baru
app.post('/subscribe', async (req, res) => {
    try {
        const {
            subscription,
            number
        } = req.body;

        // 1. Validasi input tetap sama, ini sudah bagus.
        if (!subscription || !number) {
            return res.status(400).json({
                success: false,
                message: 'Data tidak lengkap (subscription dan number diperlukan).'
            });
        }

        const subscriptionsDB = await mongodb.getSubscriptions();

        // 2. Logika yang disempurnakan: Cek apakah sudah ada langganan.
        // Cek apakah key 'number' sudah ada dan array-nya tidak kosong.
        if (subscriptionsDB[number] && subscriptionsDB[number].length > 0) {
            // JANGAN 'return' kosong. Kirim respons yang jelas.
            return res.status(200).json({
                success: true, // Sukses karena tujuannya (terdaftar) sudah tercapai
                message: `Nomor ${number} sudah terdaftar untuk notifikasi.`
            });
        }

        // 3. Jika belum ada, buat langganan baru.
        subscriptionsDB[number] = [subscription]; // Cukup inisialisasi dengan array berisi 1 subscription
        await mongodb.saveSubscriptions(subscriptionsDB);

        console.log(`Langganan notifikasi baru disimpan untuk nomor: ${number}`);

        // 4. Kirim respons sukses pembuatan baru.
        return res.status(201).json({
            success: true,
            message: 'Langganan berhasil disimpan.'
        });

    } catch (error) {
        // 5. Selalu baik untuk memiliki penanganan error
        console.error('Error saat proses subscribe:', error);
        return res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan pada server.'
        });
    }
});

// 3. Endpoint untuk Anda (admin) panggil untuk mengirim notifikasi
app.post('/send-notification', async (req, res) => {
    const {
        number,
        title,
        body
    } = req.body;

    const subscriptionsDB = await mongodb.getSubscriptions()

    const subscriptionsForUser = subscriptionsDB[number];
    if (!subscriptionsForUser || subscriptionsForUser.length === 0) {
        return res.status(404).json({
            message: 'Tidak ada langganan notifikasi untuk nomor ini.'
        });
    }

    const payload = JSON.stringify({
        title: title || "Pesan Baru",
        body: body || "Klik untuk membuka pesan.",
        url: `/${number}` // URL yang akan dibuka saat notifikasi diklik
    });

    console.log(`Mengirim notifikasi ke ${subscriptionsForUser.length} perangkat untuk nomor ${number}...`);

    const promises = subscriptionsForUser.map(sub =>
        webpush.sendNotification(sub, payload)
        .catch(async (err) => {
            // Jika langganan sudah tidak valid (misal: user ganti browser), hapus dari DB.
            if (err.statusCode === 410) {
                subscriptionsDB[number] = subscriptionsDB[number].filter(s => s.endpoint !== sub.endpoint);
                await mongodb.saveSubscriptions(subscriptionsDB);
                res.status(400).json({
                    message: `Langganan kedaluwarsa untuk ${number}, akan dihapus.`
                });
            } else {
                console.error("Gagal mengirim notifikasi, alasan: ", err.stack);
                res.status(400).json({
                    message: `Gagal mengirim notifikasi, alasan: ${err.message}`
                });
            }
        })
    );

    await Promise.all(promises);
    res.status(200).json({
        message: `Notifikasi terkirim.`
    });
});

app.post('/reset-notification', async (req, res) => {
    try {
        const {
            number
        } = req.body;

        // 1. Validasi Input: Pastikan 'number' ada di body request
        if (!number) {
            return res.status(400).json({
                success: false,
                message: 'Nomor tidak boleh kosong.'
            });
        }

        if (!internationalFormatRegex.test(number)) {
            return res.status(400).json({
                error: 'Format nomor tidak valid.'
            });
        }

        const subscriptionsDB = await mongodb.getSubscriptions();

        // 2. Cek apakah nomor terdaftar
        if (subscriptionsDB[number]) {
            // Jika ada, hapus dari database
            delete subscriptionsDB[number];
            await mongodb.saveSubscriptions(subscriptionsDB);

            // 3. Kirim respons sukses
            return res.status(200).json({
                success: true,
                message: `Notifikasi untuk nomor ${number} berhasil direset.`
            });
        } else {
            // 4. Kirim respons jika nomor tidak ditemukan
            return res.status(404).json({
                success: false,
                message: `Nomor ${number} tidak ditemukan dalam langganan.`
            });
        }
    } catch (error) {
        // 5. Tangani error tak terduga (misal: database down)
        console.error('Error saat reset notifikasi:', error);
        return res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan pada server.'
        });
    }
});

const requireAuth = (req, res, next) => {
    if (req.session && req.session.isAuthenticated) {
        return next();
    } else {
        res.redirect('/login');
    }
};

// routes
app.get('/', (req, res) => {
    res.render('home');
});

// Rute untuk file Buyers
app.get('/buyers', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/buyers.html'));
});

app.get('/login', (req, res) => {
    const errorMsg = req.query.error ? '<p style="color:red; text-align:center;">PIN salah, silakan coba lagi.</p>' : '';
    res.send(`<!DOCTYPE html><html lang="id"><head><title>Login</title><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><style>body,html{height:100%;width:100%;overflow:hidden;margin:0;padding:0}body{display:flex;justify-content:center;align-items:center;background-color:#f0f2f5;font-family:sans-serif}.login-card{background:#fff;padding:40px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.1);text-align:center}h1{margin-top:0}input{padding:10px;font-size:18px;width:200px;text-align:center;border:1px solid #ccc;border-radius:4px}button{margin-top:20px;padding:10px 20px;font-size:16px;background-color:#00a884;color:#fff;border:none;border-radius:4px;cursor:pointer}</style></head><body><div class="login-card"><h1>Masukkan PIN</h1><form method="POST" action="/login">${errorMsg}<input type="password" name="pin" inputmode="numeric" pattern="[0-9]*" autofocus autocomplete="off"><br><button type="submit">Login</button></form></div></body></html>`)
});

app.post('/login', (req, res) => {
    const {
        pin
    } = req.body;
    if (pin === PIN_KODE) {
        req.session.isAuthenticated = true;
        res.redirect('/allchats');
    } else {
        res.redirect('/login?error=1');
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/allchats');
        }
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
});

// endpoint /set-alias sekarang menggunakan nomor sebagai KEY
app.post('/set-alias', async (req, res) => {
    const {
        alias,
        number
    } = req.body;
    if (!alias || !number || !/^[a-zA-Z0-9_]+$/.test(alias) || !internationalFormatRegex.test(number)) {
        return res.status(400).send("Input tidak valid.");
    }
    const {
        aliases
    } = await mongodb.getChats();
    aliases[number] = alias;
    await mongodb.saveAliases(aliases);
    res.redirect('/allchats?tab=aliases');
});

/**
 * ENDPOINT MIGRASI (Jalankan Sekali)
 * Fungsi: Menambahkan 'id' unik ke semua pesan lama yang belum memilikinya.
 * Cara menggunakan: Buka http://alamat-server-anda/migrate-ids di browser Anda.
 */
app.get('/migrate-ids', async (req, res) => {
    try {
        console.log('Memulai proses migrasi ID untuk pesan lama...');

        // 1. Ambil semua data chat dari database
        const {
            chats
        } = await mongodb.getChats();

        let updatedMessagesCount = 0;
        let totalMessagesCount = 0;

        // 2. Iterasi melalui setiap nomor telepon dalam data chat
        for (const number in chats) {
            // Dapatkan array pesan untuk nomor tersebut
            const messages = chats[number];

            // 3. Iterasi melalui setiap pesan dalam array
            messages.forEach(message => {
                totalMessagesCount++;
                // 4. Periksa apakah pesan TIDAK memiliki properti 'id'
                if (!message.id) {
                    // Jika tidak ada id, buatkan satu menggunakan nanoid
                    message.id = nanoid();
                    updatedMessagesCount++;
                }
            });
        }

        // 5. Jika ada pesan yang diperbarui, simpan kembali seluruh data chat
        if (updatedMessagesCount > 0) {
            await mongodb.saveChats(chats);
            console.log(`Migrasi sukses! ${updatedMessagesCount} dari ${totalMessagesCount} pesan telah diperbarui dengan ID baru.`);
            res.status(200).json({
                status: 'sukses',
                message: 'Migrasi ID berhasil diselesaikan.',
                updatedMessages: updatedMessagesCount,
                totalMessages: totalMessagesCount
            });
        } else {
            console.log('Tidak ada pesan yang perlu dimigrasi. Semua sudah memiliki ID.');
            res.status(200).json({
                status: 'tidak ada perubahan',
                message: 'Semua pesan sudah memiliki ID. Tidak ada yang perlu diperbarui.',
                totalMessages: totalMessagesCount
            });
        }

    } catch (error) {
        console.error('Gagal melakukan migrasi ID:', error);
        res.status(500).json({
            error: 'Terjadi kesalahan internal saat proses migrasi.'
        });
    }
});

// endpoint /delete-alias sekarang harus mencari nomornya dulu
app.post('/delete-alias', async (req, res) => {
    const {
        number
    } = req.body;
    if (!number) {
        return res.status(400).send("Parameter 'number' diperlukan.");
    }
    const {
        aliases
    } = await mongodb.getChats();
    if (aliases[number]) {
        delete aliases[number];
        await mongodb.saveAliases(aliases);
    }
    res.redirect('/allchats?tab=aliases');
});

app.get('/getchats', async (req, res) => {
    const {
        chats,
        aliases,
        subscriptions
    } = await mongodb.getChats();
    res.json({
        success: true,
        chats,
        aliases,
        subscriptions
    })
})

// ENDPOINT 1: Untuk mengirim pesan (Tidak ada perubahan di sini)
app.get('/send', async (req, res) => {
    const {
        number,
        message
    } = req.query;

    // --- Validasi input (tidak ada yang berubah) ---
    if (!number || !message) {
        return res.status(400).json({
            error: 'Parameter "number" dan "message" diperlukan.'
        });
    }
    if (!internationalFormatRegex.test(number)) {
        return res.status(400).json({
            error: 'Format nomor tidak valid.',
            hint: 'Gunakan format internasional tanpa spasi atau simbol, contoh: 6281234567890'
        });
    }

    // --- Logika penyimpanan pesan (tidak ada yang berubah) ---
    const {
        chats,
        aliases,
        subscriptions
    } = await mongodb.getChats();
    const displayName = aliases[number];
    if (!chats[number]) {
        chats[number] = [];
    }
    const newMessage = {
        id: nanoid(),
        text: message,
        timestamp: new Date().toISOString()
    };
    chats[number].push(newMessage);
    await mongodb.saveChats(chats);

    /*let notificationStatusMessage = 'Notifikasi tidak dicoba.'; // Pesan default

    try {
        const notificationPayload = {
            number: number,
            body: message
        };

        const notificationUrl = `${req.protocol}://${req.get('host')}/send-notification`;
        console.log(`Memicu pengiriman notifikasi ke: ${notificationUrl}`);

        const notificationResponse = await fetch(notificationUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(notificationPayload)
        });

        // Kita ambil respons JSON-nya, baik itu sukses maupun gagal
        const responseData = await notificationResponse.json();

        if (notificationResponse.ok) {
            // Jika fetch berhasil (status 200-299)
            notificationStatusMessage = responseData.message; // Contoh: "Notifikasi terkirim."
        } else {
            // Jika fetch gagal (status 404, dll.)
            notificationStatusMessage = `Gagal: ${responseData.message}`; // Contoh: "Gagal: Tidak ada langganan notifikasi untuk nomor ini."
        }

    } catch (error) {
        // Tangani jika fetch itu sendiri gagal total
        notificationStatusMessage = `Kesalahan Internal: Gagal memicu endpoint notifikasi. (${error.message})`;
        console.error(notificationStatusMessage);
    }*/

    let notificationStatusMessage = ''; // Variabel untuk menampung hasil

    // 1. Cari langganan notifikasi untuk nomor yang diberikan
    const subscriptionsForUser = subscriptions[number];

    // 2. Cek apakah ada perangkat yang terdaftar untuk menerima notifikasi
    if (!subscriptionsForUser || subscriptionsForUser.length === 0) {
        notificationStatusMessage = 'Pesan disimpan, tetapi tidak ada perangkat terdaftar untuk notifikasi.';
    } else {
        // 3. Jika ada, siapkan dan kirim notifikasi
        const payload = JSON.stringify({
            title: "Pesan Baru",
            body: message,
            url: `/${number}`
        });

        console.log(`Mengirim notifikasi langsung ke ${subscriptionsForUser.length} perangkat untuk nomor ${number}...`);

        const promises = subscriptionsForUser.map(sub =>
            webpush.sendNotification(sub, payload)
            .catch(async (err) => {
                // Jika langganan sudah tidak valid (misal: user ganti browser), hapus dari DB.
                if (err.statusCode === 410) {
                    console.log(`Langganan kedaluwarsa untuk ${number}, akan dihapus.`);
                    subscriptions[number] = subscriptions[number].filter(s => s.endpoint !== sub.endpoint);
                    await mongodb.saveSubscriptions(subscriptions);
                } else {
                    console.error("Gagal mengirim notifikasi ke satu perangkat, alasan: ", err.stack);
                }
            })
        );

        // Tunggu semua proses pengiriman selesai
        await Promise.all(promises);
        notificationStatusMessage = 'Pesan disimpan dan notifikasi telah dikirim.';
    }

    // --- Kirim respons akhir yang menyertakan status notifikasi ---
    const chatUrl = `${req.protocol}://${req.get('host')}/${number}`;
    const display = displayName ? `${displayName} (${number})` : `${number}`;
    res.json({
        status: 'sukses',
        message: `Pesan terkirim ke ${display}`,
        url: chatUrl,
        notification_result: notificationStatusMessage
    });
});

app.get('/clear', async (req, res) => {
    const {
        number
    } = req.query;

    if (!number) {
        return res.status(400).json({
            error: 'Parameter "number" diperlukan.'
        });
    }

    if (!internationalFormatRegex.test(number)) {
        return res.status(400).json({
            error: 'Format nomor tidak valid.'
        });
    }

    const {
        chats
    } = await mongodb.getChats();

    if (chats[number]) {
        // Hapus properti nomor dari objek database
        delete chats[number];
        await mongodb.saveChats(chats);
        // Alihkan kembali ke halaman /allchats setelah berhasil menghapus
        res.redirect('/allchats');
    } else {
        // Jika nomor tidak ada, kirim pesan error
        res.status(404).send(`<h1>Error 404</h1><p>Nomor ${number} tidak ditemukan di database.</p><a href="/allchats">Kembali ke Daftar Chat</a>`);
    }
});

/*app.post('/delete-message', async (req, res) => {
    const {
        number,
        messageId
    } = req.body;
    if (!number || !messageId) {
        return res.status(400).send('Parameter tidak lengkap.');
    }
    const {
        chats
    } = await mongodb.getChats();
    if (chats[number]) {
        const updatedMessages = chats[number].filter(msg => msg.id !== messageId);
        chats[number] = updatedMessages;
        await mongodb.saveChats(chats);
    }
    res.redirect(`/${number}`);
});*/

app.get('/allchats', requireAuth, async (req, res) => {
    // app.get('/allchats', async (req, res) => {
    const {
        chats,
        aliases
    } = await mongodb.getChats();
    let chatList = Object.keys(chats).map(number => {
        const messages = chats[number];
        if (messages.length === 0) return null;
        const lastMessage = messages[messages.length - 1];
        return {
            number,
            lastMessageText: lastMessage.text,
            lastMessageTimestamp: lastMessage.timestamp,
            messageCount: messages.length,
            alias: aliases[number] // LOGIKA JADI LEBIH SEDERHANA: Langsung lookup!
        };
    }).filter(chat => chat !== null);

    chatList.sort((a, b) => new Date(b.lastMessageTimestamp) - new Date(a.lastMessageTimestamp));

    const chatListHtml = chatList.map(chat => {
        const displayName = chat.alias ? `<strong>${chat.alias}</strong> <span class="sub-number">${chat.number}</span>` : `<strong>${chat.number}</strong>`;
        const confirmName = chat.alias || chat.number;
        const lastTime = new Date(chat.lastMessageTimestamp).toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            timeZone: 'Asia/Jakarta'
        });
        return `<div class="chat-list-item"><a href="/${chat.number}" class="chat-link"><div class="chat-info"><div class="chat-name">${displayName}</div><div class="last-message">${chat.lastMessageText.replace(/</g, "&lt;")}</div></div><div class="chat-meta"><div class="last-message-time">${lastTime}</div><span class="message-count-badge">${chat.messageCount}</span></div></a><a href="/clear?number=${chat.number}" class="clear-btn" title="Hapus Chat" onclick="return confirm('Anda yakin ingin menghapus SEMUA pesan untuk ${confirmName}?')"><svg class="trash-icon" viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg></a></div>`;
    }).join('') || '<p style="color:#667781; text-align:center; padding: 40px;">Belum ada percakapan.</p>';

    // LOGIKA DIBALIK untuk menampilkan daftar alias
    const aliasesHtml = Object.entries(aliases).map(([number, alias]) => `
        <div class="alias-item">
            <span><strong>@${alias}</strong> ➡️ ${number}</span>
            <form action="/delete-alias" method="POST" style="display:inline;">
                <input type="hidden" name="number" value="${number}">
                <button type="submit" class="delete-alias-btn">✕</button>
            </form>
        </div>
    `).join('') || '<p style="color:#667781; text-align:center;">Belum ada alias.</p>';

    // --- Mengirim response dengan template HTML dari Anda ---
    res.send(`<!DOCTYPE html><html lang="id"><head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>Dasbor Developer</title>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #f0f2f5; margin: 0; }
            .header { display: flex; justify-content: space-between; align-items: center; background-color: #00a884; color: white; padding: 16px; font-size: 20px; font-weight: 500; position: sticky; top: 0; z-index: 100; }
            .header a { color: white; font-size: 14px; text-decoration: none; }
            .main-container { max-width: 800px; margin: 0 auto; padding: 20px; }
            .tabs { display: flex; border-bottom: 1px solid #ddd; margin-bottom: 20px; }
            .tab-button { padding: 10px 20px; cursor: pointer; border: none; background-color: transparent; font-size: 16px; color: #667781; position: relative; bottom: -1px; border-bottom: 3px solid transparent; }
            .tab-button.active { color: #00a884; font-weight: 600; border-bottom-color: #00a884; }
            .tab-panel { display: none; } .tab-panel.active { display: block; }
            .card { background: #fff; border-radius: 8px; box-shadow: 0 1px 2px rgba(0,0,0,0.1); overflow: hidden; }
            .card-header { padding: 12px 16px; border-bottom: 1px solid #f0f2f5; font-size: 18px; font-weight: 600; }
            .card-body { padding: 16px; }
            .form-grid { display: grid; gap: 12px; }
            input[type="text"] { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; box-sizing: border-box; }
            button { background-color: #007bff; color: white; border: none; padding: 9px 15px; border-radius: 4px; cursor: pointer; width: 100%; }
            .alias-list { max-height: 250px; overflow-y: auto; margin-top: 16px; border-top: 1px solid #f0f2f5; padding-top: 10px; }
            .alias-item { display: flex; justify-content: space-between; align-items: center; padding: 6px 0; font-size: 14px; }
            .delete-alias-btn { background: none; border: none; color: #ff3b30; font-size: 16px; cursor: pointer; padding: 0 5px; width: auto; }
            .chat-list-item { display: flex; align-items: center; border-bottom: 1px solid #f0f2f5; } .chat-list-item:last-child { border-bottom: none; }
            .chat-link { flex-grow: 1; display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; text-decoration: none; color: inherit; min-width: 0; }
            .chat-info { overflow: hidden; margin-right: 15px; } .chat-name { font-size: 16px; } .sub-number { color: #667781; font-size: 13px; font-weight: normal; }
            .last-message { font-size: 14px; color: #667781; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding-top: 2px; }
            .chat-meta { text-align: right; flex-shrink: 0; } .last-message-time { font-size: 12px; color: #667781; margin-bottom: 4px; }
            .message-count-badge { background-color: #25d366; color: white; font-size: 12px; font-weight: bold; border-radius: 10px; padding: 2px 8px; display: inline-block; }
            .clear-btn { display: flex; align-items: center; justify-content: center; flex-shrink: 0; padding: 10px; margin-right: 6px; cursor: pointer; border-radius: 50%; width: 36px; height: 36px; box-sizing: border-box; }
            .clear-btn:hover .trash-icon { stroke: #ff3b30; } .trash-icon { stroke: #8696a0; transition: stroke 0.2s; }
        </style>
    </head><body>
        <div class="header"><span>Dasbor Developer</span><a href="/logout">Logout</a></div>
        <div class="main-container">
            <div class="tabs">
                <button class="tab-button active" data-tab="chats">Percakapan</button>
                <button class="tab-button" data-tab="aliases">Alias</button>
            </div>
            <div id="chats" class="tab-panel active">
                <div class="card"><div class="card-body" style="padding:0;">${chatListHtml}</div></div>
            </div>
            <div id="aliases" class="tab-panel">
                <div class="card"><div class="card-header">Atur Alias</div><div class="card-body">
                    <form action="/set-alias" method="POST" class="form-grid"><input type="text" name="alias" placeholder="@nama_alias" required><input type="text" name="number" placeholder="628123..." required><button type="submit">Simpan Alias</button></form>
                    <div class="alias-list">${aliasesHtml}</div>
                </div></div>
            </div>
        </div>
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const tabButtons = document.querySelectorAll('.tab-button');
                const tabPanels = document.querySelectorAll('.tab-panel');
                tabButtons.forEach(button => {
                    button.addEventListener('click', () => {
                        tabButtons.forEach(btn => btn.classList.remove('active'));
                        tabPanels.forEach(panel => panel.classList.remove('active'));
                        button.classList.add('active');
                        document.getElementById(button.getAttribute('data-tab')).classList.add('active');
                    });
                });
                // Bonus: Jika URL berisi ?tab=aliases, otomatis klik tab alias
                const urlParams = new URLSearchParams(window.location.search);
                if (urlParams.get('tab') === 'aliases') {
                    document.querySelector('.tab-button[data-tab="aliases"]').click();
                }
            });
        </script>
    </body></html>`);
});

app.get('/:number', async (req, res) => {
    const { number } = req.params;

    if (!internationalFormatRegex.test(number)) {
        return res.status(400).send(`<h1>Format Nomor Tidak Valid</h1><p>Gunakan format internasional, contoh: 6281234567890</p>`);
    }

    const { chats, aliases, subscriptions } = await mongodb.getChats();

    if (!chats[number]) {
        return res.status(404).send(`<h1>Chat Tidak Ditemukan</h1><p>Tidak ada riwayat percakapan untuk nomor ${number}</p>`);
    }

    const userMessages = chats[number] || [];
    const aliasName = aliases[number] || number;

    const formatSmartDate = (date) => {
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const yesterday = new Date(today); yesterday.setDate(today.getDate() - 1);
        const aWeekAgo = new Date(today); aWeekAgo.setDate(today.getDate() - 7);
        const msgDate = new Date(date); msgDate.setHours(0, 0, 0, 0);
        if (msgDate.getTime() === today.getTime()) return "Hari ini";
        if (msgDate.getTime() === yesterday.getTime()) return "Kemarin";
        if (msgDate > aWeekAgo) return msgDate.toLocaleDateString('id-ID', { weekday: 'long', timeZone: 'Asia/Jakarta' });
        return msgDate.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta' });
    };

    let messagesHtml = '';
    let lastDate = null;
    userMessages.forEach(msg => {
        const msgDate = new Date(msg.timestamp);
        if (!lastDate || msgDate.toDateString() !== lastDate) {
            lastDate = msgDate.toDateString();
            messagesHtml += `<div class="date-separator-anchor" data-date="${msgDate.toISOString()}" data-date-text="${formatSmartDate(msgDate)}"></div>`;
        }
        const sanitizedText = (msg.text || "").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, '<br>');
        const messageTime = msgDate.toLocaleString("id-ID", { day: '2-digit', month: '2-digit', year: 'numeric', hour: "2-digit", minute: "2-digit", timeZone: 'Asia/Jakarta' });
        
        let replyHtml = "";
        if (msg.replyingTo && msg.replyingTo.id && msg.replyingTo.text) {
            const sanitizedReplyText = msg.replyingTo.text.replace(/</g, "&lt;").replace(/>/g, "&gt;");
            replyHtml = `<div class="reply-snippet" data-reply-to-id="${msg.replyingTo.id}"><p class="reply-snippet-text">${sanitizedReplyText}</p></div>`;
        }

        messagesHtml += `
            <div class="message-bubble ${msg.fromMe ? "from-me" : "from-receiver"}" data-message-id="${msg.id}">
                ${replyHtml}
                <p class="message-text">${sanitizedText}</p>
                <div class="message-footer">
                    <div class="actions">
                        <span class="reply-msg-btn" title="Balas">↩</span>
                        <span class="delete-msg-btn" title="Hapus">✕</span>
                    </div>
                    <span class="message-timestamp">${messageTime}</span>
                </div>
            </div>`;
    });

    res.send(`<!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
        <title>Chat dengan ${aliasName}</title>
        <style>
            :root{--my-message-bg:#ffffff;--their-message-bg:#e0f1ff;--primary-blue:#007bff;--window-bg:#ffffff;--text-primary:#333333;--text-secondary:#65676b;--border-color:#e9e9e9;--page-bg:#2b2b2b}html,body{overflow:hidden;height:100%;width:100%;margin:0;padding:0}body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;background-color:var(--page-bg);display:flex;justify-content:center}.chat-window{width:100%;height:100%;max-width:800px;background-color:#f7f7f7;border-radius:0;box-shadow:none;display:flex;flex-direction:column;overflow:hidden;position:relative}.chat-header{display:flex;align-items:center;background-color:var(--window-bg);box-shadow:0 1px 3px rgba(0,0,0,0.04);flex-shrink:0;z-index:10;padding:12px 15px;padding-top:calc(12px + env(safe-area-inset-top));position:relative}.header-main{display:flex;flex-direction:column;align-items:flex-start;flex-grow:1}.header-name{font-size:18px;font-weight:600;color:var(--text-primary)}#audio-visualizer{display:none;height:16px;margin-top:4px;gap:3px;align-items:flex-end}.visualizer-bar{width:3px;background-color:var(--primary-blue);transition:height 0.1s ease-out;border-radius:2px}#sticky-date-header{position:absolute;top:10px;left:50%;transform:translateX(-50%);background-color:rgba(233,234,236,0.95);backdrop-filter:blur(5px);color:var(--text-secondary);padding:5px 12px;border-radius:999px;font-size:12px;font-weight:500;box-shadow:0 1px 2px rgba(0,0,0,0.1);opacity:0;transition:opacity 0.3s ease,top 0.3s ease;z-index:5}#sticky-date-header.visible{opacity:1}#music-toggle-btn{background:none;border:none;cursor:pointer;padding:5px;opacity:0.7;flex-shrink:0;transition:opacity 0.2s;outline:none;-webkit-tap-highlight-color:transparent}#music-toggle-btn:hover{opacity:1}#music-toggle-btn svg{width:24px;height:24px;fill:#54656f}#toast-notification{position:absolute;top:calc(15px + env(safe-area-inset-top));left:50%;transform:translateX(-50%);background-color:rgba(40,167,69,0.9);color:white;padding:6px 14px;border-radius:20px;box-shadow:0 3px 10px rgba(0,0,0,0.2);z-index:100;opacity:0;transition:opacity .4s ease,top .4s ease;pointer-events:none;font-size:13px;font-weight:500;white-space:nowrap;backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}#toast-notification.visible{opacity:1;top:calc(20px + env(safe-area-inset-top))}#toast-notification.error{background-color:rgba(220,53,69,0.9)}.input-area{background-color:var(--window-bg);box-shadow:0 -1px 3px rgba(0,0,0,0.04);flex-shrink:0;z-index:10;padding:5px 12px;padding-bottom:env(safe-area-inset-bottom)}.input-wrapper{max-width:600px;margin:0 auto;width:100%}#reply-context{display:none;padding:8px 12px;margin:0 0 5px 0;border-radius:8px;background:#e9ecef;border-left:4px solid var(--primary-blue)}#reply-context p{margin:0;font-size:14px;color:#54656f;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#reply-context .close-reply{float:right;cursor:pointer;font-weight:bold;color:#999;font-size:22px;line-height:0.8;outline:none;-webkit-tap-highlight-color:transparent}#message-form{display:flex;align-items:flex-end;gap:10px}.message-container{flex-grow:1;overflow-y:auto;scroll-behavior:smooth;padding:10px;min-height:0;background-color:#efeae2;background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAECAYAAACtBE5DAAAAFUlEQVQImWNgYGBgYGJgZ2BgYGSAAF2NAwCR2gW+2tAXUQAAAABJRU5ErkJggg==");display:flex;flex-direction:column;gap:3px}.message-bubble{padding:8px 14px;border-radius:18px;max-width:80%;display:flex;flex-direction:column;user-select:none;position:relative;box-shadow:0 1px 1px rgba(0,0,0,0.08);margin-bottom:8px;cursor:pointer;-webkit-tap-highlight-color:transparent}.message-bubble::after{content:'';position:absolute;top:0;border:10px solid transparent}.from-me{align-self:flex-end;background-color:var(--my-message-bg);border-top-right-radius:6px}.from-me::after{right:-8px;border-left-color:var(--my-message-bg)}.from-receiver{align-self:flex-start;background-color:var(--their-message-bg);border-top-left-radius:6px}.from-receiver::after{left:-8px;border-right-color:var(--their-message-bg)}.copied-feedback{animation:feedback-flash-me 0.7s ease-out}@keyframes feedback-flash-me{0%{background-color:#d4edda}100%{background-color:var(--my-message-bg)}}.from-receiver.copied-feedback{animation-name:feedback-flash-receiver}@keyframes feedback-flash-receiver{0%{background-color:#c3e6cb}100%{background-color:var(--their-message-bg)}}#message-input{flex-grow:1;border:1px solid #ddd;background-color:white;border-radius:20px;padding:10px 18px;font-size:15px;font-family:inherit;outline:none;box-shadow:0 1px 2px rgba(0,0,0,0.05);resize:none;line-height:1.4;max-height:100px}#message-input:focus{border-color:var(--primary-blue)}#message-input{scrollbar-width:none;-ms-overflow-style:none}#message-input::-webkit-scrollbar{display:none}.message-container::-webkit-scrollbar{width:6px}.message-container::-webkit-scrollbar-thumb{background-color:rgba(0,0,0,0.2);border-radius:3px}#scroll-to-bottom{position:absolute;bottom:calc(60px + env(safe-area-inset-bottom));right:25px;width:40px;height:40px;background-color:rgba(255,255,255,0.95);border:1px solid var(--border-color);box-shadow:0 2px 8px rgba(0,0,0,0.15);display:flex;justify-content:center;align-items:center;cursor:pointer;z-index:5;opacity:0;transform:translateY(20px);pointer-events:none;transition:opacity 0.3s ease,transform 0.3s ease;outline:none;-webkit-tap-highlight-color:transparent}#scroll-to-bottom.visible{opacity:1;transform:translateY(0);pointer-events:auto}#scroll-to-bottom svg{width:24px;height:24px;fill:var(--text-secondary)}.date-separator-anchor{text-align:center;margin:10px 0;}.date-separator-anchor:first-child{margin-top:0;}.date-separator-anchor::before{content:attr(data-date-text);background-color:#e9eaec;color:var(--text-secondary);padding:5px 12px;border-radius:999px;font-size:12px;font-weight:500;box-shadow:0 1px 1px rgba(0,0,0,0.08)}.message-text{font-size:15px;margin:0;word-wrap:break-word;color:var(--text-primary)}.message-footer{display:flex;justify-content:flex-end;align-items:center;margin-top:5px;gap:8px}.message-timestamp{font-size:12px;color:var(--text-secondary)}.actions{display:flex;align-items:center;gap:4px;opacity:0;transition:opacity 0.2s}.message-bubble:hover .actions{opacity:1}.reply-msg-btn,.delete-msg-btn{background:none;border:none;font-size:18px;line-height:1;font-weight:bold;color:#b0b9c2;cursor:pointer;padding:2px 4px;outline:none;-webkit-tap-highlight-color:transparent}.reply-msg-btn:hover,.delete-msg-btn:hover{color:var(--primary-blue)}#send-btn{background-color:var(--primary-blue);border:none;border-radius:50%;width:40px;height:40px;cursor:pointer;display:flex;justify-content:center;align-items:center;flex-shrink:0;transition:background-color 0.2s,transform 0.2s,opacity 0.3s;outline:none;-webkit-tap-highlight-color:transparent}#send-btn:hover{background-color:#0056b3;transform:scale(1.05)}#send-btn.disabled{opacity:0.5;cursor:not-allowed;transform:scale(1)}#send-btn svg{width:20px;height:20px;fill:white;margin-left:2px}.reply-snippet{background-color:rgba(0,0,0,0.04);padding:6px 10px;margin:-2px -6px 8px -6px;border-radius:8px;border-left:3px solid var(--primary-blue);cursor:pointer}.from-me .reply-snippet{border-left-color:#5fcf5f}.reply-snippet:hover{background-color:rgba(0,0,0,0.08)}.reply-snippet-text{margin:0;font-size:13px;color:#54656f;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.message-highlighted{animation:highlight-fade 1.5s ease-out}@keyframes highlight-fade{0%,10%{background-color:rgba(0,123,255,0.25)}100%{background-color:var(--my-message-bg)}}.from-receiver.message-highlighted{animation-name:highlight-fade-receiver}@keyframes highlight-fade-receiver{0%,10%{background-color:rgba(0,123,255,0.2)}100%{background-color:var(--their-message-bg)}}.spinner{animation:rotate 2s linear infinite;width:20px;height:20px;margin:0}.spinner .path{stroke:white;stroke-linecap:round;animation:dash 1.5s ease-in-out infinite}@keyframes rotate{100%{transform:rotate(360deg)}}@keyframes dash{0%{stroke-dasharray:1,150;stroke-dashoffset:0}50%{stroke-dasharray:90,150;stroke-dashoffset:-35}100%{stroke-dasharray:90,150;stroke-dashoffset:-124}}
        </style>
    </head>
    <body>
        <div class="chat-window">
            <div class="chat-header">
                <div class="header-main"><span class="header-name">${aliasName}</span><div id="audio-visualizer"></div></div>
                <div id="sticky-date-header"></div>
                <button id="music-toggle-btn" title="Play/Pause Music"></button>
            </div>
            <div id="toast-notification"></div>
            <div class="message-container">${messagesHtml}</div>
            <div id="scroll-to-bottom" title="Scroll ke bawah"><svg viewBox="0 0 24 24"><path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"></path></svg></div>
            <div class="input-area">
                <div class="input-wrapper">
                    <div id="reply-context"><span class="close-reply" title="Batal Balas">×</span><p id="reply-preview-text"></p></div>
                    <form id="message-form" style="width:100%; display:flex; align-items:flex-end; gap:10px;">
                        <textarea id="message-input" placeholder="Ketik pesan..." rows="1"></textarea>
                        <button type="submit" id="send-btn" title="Kirim" class="disabled"><svg viewBox="0 0 24 24"><path d="M2,21L23,12L2,3V10L17,12L2,14V21Z"></path></svg></button>
                    </form>
                </div>
            </div>
        </div>
        <audio id="chat-music" loop src="/sakit-tapi-ku-rindu.mp3"></audio>

        <script>
            document.addEventListener("DOMContentLoaded", () => {
                const chatNumber = "${number}";
                const subscriptionsDB = ${JSON.stringify(subscriptions[number] || [])};
                const allElements = { container: document.querySelector(".message-container"), input: document.getElementById("message-input"), sendBtn: document.getElementById("send-btn"), form: document.getElementById("message-form"), scrollToBottomBtn: document.getElementById("scroll-to-bottom"), musicBtn: document.getElementById('music-toggle-btn'), audio: document.getElementById('chat-music'), replyContext: document.getElementById("reply-context"), replyPreviewText: document.getElementById("reply-preview-text"), closeReplyBtn: document.querySelector(".close-reply"), stickyDateHeader: document.getElementById("sticky-date-header"), visualizer: document.getElementById("audio-visualizer"), toast: document.getElementById('toast-notification') };
                let replyingToMessageId = null; let audioContext, analyser, source, animationFrameId; const NUM_BARS = 16;
                const musicIconPlay = \`<svg viewBox="0 0 24 24"><path d="M8,5.14V19.14L19,12.14L8,5.14Z"></path></svg>\`;
                const musicIconPause = \`<svg viewBox="0 0 24 24"><path d="M14,19H18V5H14M6,19H10V5H6V19Z"></path></svg>\`;
                const sendIcon = \`<svg viewBox="0 0 24 24"><path d="M2,21L23,12L2,3V10L17,12L2,14V21Z"></path></svg>\`;
                const loaderIcon = \`<svg class="spinner" viewBox="0 0 50 50"><circle class="path" cx="25" cy="25" r="20" fill="none" stroke-width="5"></circle></svg>\`;
                allElements.musicBtn.innerHTML = musicIconPlay;

                let toastTimer;
                function showToastNotification(message, type = 'success', duration = 2500) { clearTimeout(toastTimer); allElements.toast.textContent = message; allElements.toast.className = type === 'error' ? 'error' : ''; allElements.toast.classList.add('visible'); toastTimer = setTimeout(() => { allElements.toast.classList.remove('visible'); }, duration); }
                
                // [PERBAIKAN] Logika notifikasi yang bersih dan mandiri
                async function initPushNotifications(currentNumber) {
                    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
                        console.warn('Push messaging tidak didukung oleh browser ini.');
                        return;
                    }
                    try {
                        const swRegistration = await navigator.serviceWorker.register('/sw.js');
                        // Tanyakan ke browser apakah sudah ada langganan
                        let subscription = await swRegistration.pushManager.getSubscription();
                        
                        // Jika sudah ada langganan, hentikan proses.
                        if (subscription) {
                            console.log('Pengguna sudah terdaftar untuk notifikasi.');
                            return;
                        }

                        // Jika tidak ada, mulai proses pendaftaran baru
                        const permission = await Notification.requestPermission();
                        if (permission !== 'granted') {
                            console.log('Izin notifikasi ditolak oleh pengguna.');
                            return;
                        }
                        
                        const response = await fetch('/vapidPublicKey');
                        const vapidPublicKey = await response.text();
                        
                        subscription = await swRegistration.pushManager.subscribe({
                            userVisibleOnly: true,
                            applicationServerKey: vapidPublicKey
                        });
                        
                        await fetch('/subscribe', {
                            method: 'POST',
                            body: JSON.stringify({ subscription: subscription, number: currentNumber }),
                            headers: { 'content-type': 'application/json' }
                        });
                        console.log('Berhasil mendaftarkan pengguna untuk notifikasi.');
                        showToastNotification('Anda akan menerima notifikasi');
                    } catch(err) {
                        console.error('Gagal mendaftar notifikasi push:', err);
                        showToastNotification('Gagal mendaftar notifikasi', 'error');
                    }
                }

                function setupAudioVisualizer() { if (audioContext) return; try { audioContext = new (window.AudioContext || window.webkitAudioContext)(); analyser = audioContext.createAnalyser(); source = audioContext.createMediaElementSource(allElements.audio); source.connect(analyser); analyser.connect(audioContext.destination); analyser.fftSize = 256; allElements.visualizer.innerHTML = ''; for (let i = 0; i < NUM_BARS; i++) { const bar = document.createElement('div'); bar.classList.add('visualizer-bar'); allElements.visualizer.appendChild(bar); } } catch (e) { console.error("Web Audio API tidak bisa diinisialisasi.", e); } }
                function drawVisualizer() { if (!analyser) return; animationFrameId = requestAnimationFrame(drawVisualizer); const dataArray = new Uint8Array(analyser.frequencyBinCount); analyser.getByteFrequencyData(dataArray); const bars = allElements.visualizer.children; const barWidth = Math.floor(dataArray.length / NUM_BARS); for (let i = 0; i < NUM_BARS; i++) { let barHeight = dataArray[i * barWidth]; const height = Math.max(1, (barHeight / 255) * 100); if (bars[i]) { bars[i].style.height = \`\${height}%\`; } } }
                allElements.musicBtn.addEventListener('click', () => { if (allElements.audio.paused) { try { setupAudioVisualizer(); audioContext.resume(); allElements.audio.play().then(() => { allElements.musicBtn.innerHTML = musicIconPause; allElements.visualizer.style.display = 'flex'; drawVisualizer(); }).catch(e => { console.error("Gagal memutar audio:", e); showToastNotification('Gagal memutar audio', 'error');}); } catch(e) { showToastNotification('Gagal memulai audio', 'error'); } } else { allElements.audio.pause(); allElements.musicBtn.innerHTML = musicIconPlay; allElements.visualizer.style.display = 'none'; if (animationFrameId) { cancelAnimationFrame(animationFrameId); } } });
                allElements.input.addEventListener('input', () => { allElements.input.style.height = 'auto'; allElements.input.style.height = \`\${allElements.input.scrollHeight}px\`; const hasText = allElements.input.value.trim().length > 0; allElements.sendBtn.classList.toggle('disabled', !hasText); allElements.sendBtn.disabled = !hasText; });
                
                function initializeBubble(bubble) {
                    bubble.addEventListener('dblclick', (e) => {
                    if (e.target.closest('.actions') || e.target.closest('.reply-snippet')) return;
                    const textToCopy = bubble.querySelector('.message-text').innerText;
                    navigator.clipboard.writeText(textToCopy).then(() => {
                    bubble.classList.add('copied-feedback');
                    // showToastNotification('Tersalin ke papan klip');
                    setTimeout(() => {
                    bubble.classList.remove('copied-feedback');
                    }, 700);
                    });
                    });
                    bubble.querySelector('.delete-msg-btn').addEventListener('click', () => { const messageId = bubble.dataset.messageId; if (confirm("Anda yakin ingin menghapus pesan ini?")) { fetch('/delete-message', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ number: chatNumber, messageId: messageId }) }).then(res => { if(res.ok) { const dateSeparator = bubble.previousElementSibling; const nextElement = bubble.nextElementSibling; const isNextADateSeparator = nextElement && nextElement.classList.contains('date-separator-anchor'); const isPrevADateSeparator = dateSeparator && dateSeparator.classList.contains('date-separator-anchor'); bubble.remove(); if (isPrevADateSeparator && (!nextElement || isNextADateSeparator)) { dateSeparator.remove(); } showToastNotification('Pesan berhasil dihapus'); updateStickyDate(); } else { showToastNotification('Gagal menghapus pesan', 'error'); } }).catch(() => showToastNotification('Gagal terhubung ke server', 'error')); } });
                    bubble.querySelector('.reply-msg-btn').addEventListener('click', () => { replyingToMessageId = bubble.dataset.messageId; const originalMessageText = bubble.querySelector('.message-text').innerText; allElements.replyPreviewText.textContent = originalMessageText.length > 45 ? originalMessageText.substring(0, 45) + "..." : originalMessageText; allElements.replyContext.style.display = "block"; allElements.input.focus(); });
                    const replySnippet = bubble.querySelector('.reply-snippet');
                    if (replySnippet) { replySnippet.addEventListener('click', () => { const originalId = replySnippet.dataset.replyToId; if (!originalId) return; const originalBubble = document.querySelector(\`.message-bubble[data-message-id="\${originalId}"]\`); if (originalBubble) { originalBubble.scrollIntoView({ behavior: 'smooth', block: 'center' }); originalBubble.classList.add('message-highlighted'); setTimeout(() => { originalBubble.classList.remove('message-highlighted'); }, 1500); } else { showToastNotification('Pesan asli tidak ditemukan', 'error'); } }); }
                }

                async function addNewMessage() { const text = allElements.input.value.trim(); if (!text) return; allElements.sendBtn.disabled = true; allElements.sendBtn.innerHTML = loaderIcon; const payload = { number: chatNumber, text: text, replyingTo: replyingToMessageId }; try { const response = await fetch('/reply', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }); if (response.ok) { const newMsg = await response.json(); appendNewMessage(newMsg); allElements.input.value = ""; cancelReply(); allElements.container.scrollTo({ top: allElements.container.scrollHeight, behavior: "smooth" }); } else { showToastNotification('Gagal mengirim pesan', 'error'); } } catch (err) { showToastNotification('Gagal terhubung ke server', 'error'); } finally { allElements.sendBtn.innerHTML = sendIcon; allElements.input.dispatchEvent(new Event("input")); } }
                function appendNewMessage(msg) { if (!msg || !msg.id || !msg.timestamp) { console.error('Menerima objek pesan tidak valid:', msg); showToastNotification('Gagal menampilkan pesan baru', 'error'); return; } const msgDate = new Date(msg.timestamp); const isDateValid = !isNaN(msgDate); const messageTime = isDateValid ? msgDate.toLocaleString("id-ID", { day: '2-digit', month: '2-digit', year: 'numeric', hour: "2-digit", minute: "2-digit", timeZone: 'Asia/Jakarta' }) : '--:--'; const sanitizedText = (msg.text || "").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\\n/g, '<br>'); let replyHtml = ""; if (msg.replyingTo && msg.replyingTo.id && msg.replyingTo.text) { replyHtml = \`<div class="reply-snippet" data-reply-to-id="\${msg.replyingTo.id}"><p class="reply-snippet-text">\${msg.replyingTo.text.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p></div>\`; } const bubble = document.createElement('div'); bubble.className = \`message-bubble \${msg.fromMe ? 'from-me' : 'from-receiver'}\`; bubble.dataset.messageId = msg.id; bubble.innerHTML = \`\${replyHtml}<p class="message-text">\${sanitizedText}</p><div class="message-footer"><div class="actions"><span class="reply-msg-btn" title="Balas">↩</span><span class="delete-msg-btn" title="Hapus">✕</span></div><span class="message-timestamp">\${messageTime}</span></div>\`; allElements.container.appendChild(bubble); initializeBubble(bubble); }
                function cancelReply() { replyingToMessageId = null; allElements.replyContext.style.display = "none"; }
                function updateStickyDate() { const separators = [...allElements.container.querySelectorAll('.date-separator-anchor')]; const containerTop = allElements.container.getBoundingClientRect().top; let currentSeparator = null; for (const separator of separators) { if (separator.getBoundingClientRect().top <= containerTop + 25) { currentSeparator = separator; } else { break; } } if (currentSeparator && allElements.container.scrollTop > 50) { allElements.stickyDateHeader.textContent = currentSeparator.dataset.dateText; allElements.stickyDateHeader.classList.add('visible'); } else { allElements.stickyDateHeader.classList.remove('visible'); } }
                allElements.closeReplyBtn.addEventListener("click", cancelReply);
                allElements.container.addEventListener("scroll", () => { updateStickyDate(); allElements.scrollToBottomBtn.classList.toggle('visible', allElements.container.scrollHeight - allElements.container.clientHeight > allElements.container.scrollTop + 100); });
                allElements.scrollToBottomBtn.addEventListener("click", () => { allElements.container.scrollTo({ top: allElements.container.scrollHeight, behavior: "smooth" }); });
                allElements.form.addEventListener("submit", (e) => { e.preventDefault(); addNewMessage(); });
                
                // Inisialisasi semua fungsi utama
                document.querySelectorAll('.message-bubble').forEach(initializeBubble);
                allElements.sendBtn.disabled = true; 
                allElements.input.dispatchEvent(new Event("input")); 
                updateStickyDate(); 
                allElements.container.scrollTop = allElements.container.scrollHeight;
                
                // [PERBAIKAN] Jalankan inisialisasi notifikasi setelah semua siap
                if (!subscriptionsDB || subscriptionsDB.length === 0) {
                    console.log('Memulai pendaftaran notifikasi...');
                    initPushNotifications(chatNumber);
                }
            });
        </script>
    </body>
    </html>`);
});

// Contoh perbaikan pada endpoint /reply agar menggunakan nanoid yang baru:
app.post('/reply', async (req, res) => {
    const { number, text, replyingTo: replyingToMessageId } = req.body;
    const { chats, aliases, subscriptions } = await mongodb.getChats();

    if (!number || !text || !chats[number]) {
        return res.status(400).json({ error: 'Data tidak valid' });
    }

    const newMessage = {
        id: nanoid(), // Sekarang sudah aman pakai crypto Node.js
        timestamp: new Date().toISOString(),
        text: text,
        fromMe: true,
        replyingTo: replyingToMessageId ? {
            id: replyingToMessageId,
            text: chats[number].find(m => m.id === replyingToMessageId)?.text
        } : null
    };

    chats[number].push(newMessage);
    await mongodb.saveChats(chats);
    // --- MENGIRIM NOTIFIKASI ---
    const payload = JSON.stringify({
        title: `Pesan Baru dari ${aliases[number] || number}`,
        body: text
    });
    const owner = "62895415497664"
    if (subscriptions[owner]) {
        subscriptions[owner].forEach(sub => {
            webpush.sendNotification(sub, payload).catch(error => console.error("Gagal mengirim notifikasi:", error.body));
        });
    }

    // Mengembalikan objek pesan baru ke klien
    res.status(200).json(newMessage);
});

// --- ENDPOINT UNTUK MENGHAPUS PESAN ---
app.post('/delete-message', async (req, res) => {
    const { number, messageId } = req.body;
    const { chats } = await mongodb.getChats();

    if (!number || !messageId || !chats[number]) {
        return res.status(400).json({ error: 'Data tidak valid atau chat tidak ditemukan' });
    }

    const initialLength = chats[number].length;
    const updatedChat = chats[number].filter(m => m.id !== messageId);

    if (updatedChat.length < initialLength) {
        chats[number] = updatedChat;
        await mongodb.saveChats(chats); // Menggunakan pemanggilan yang benar
        res.status(200).json({ success: true, message: 'Pesan berhasil dihapus' });
    } else {
        res.status(404).json({ error: 'Pesan tidak ditemukan' });
    }
});

setInterval(async () => {
    if (mongodb.db) {
        await mongodb.save(mongodb.db);
    }
}, 1000 * 60);

// Jalankan Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});