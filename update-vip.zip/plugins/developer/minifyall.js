import { minify } from 'terser';
import fs from 'node:fs';
import path from 'node:path';
import archiver from 'archiver';
import mapping from '../../system/mapping.js';

function isBase64Encoded(str) {
    if (typeof str !== 'string' || str.length === 0) return false;
    if (str.length % 4 !== 0) return false;
    try { return Buffer.from(str, 'base64').toString('base64') === str; } catch (e) { return false; }
}

function looksLikeEncryptedPlugin(content) {
    return isBase64Encoded(content) && !content.includes("export default") && !content.includes("module.exports") && !content.includes("exports.");
}

const run = async (m, lulli, { plugins }) => {
    // Ambil nomor owner dari mapping agar dinamis
    const ownerJid = mapping.cfg?.owner || "62895415497664@s.whatsapp.net";

    // Ubah jadi Promise agar 'await archiveFolders()' benar-benar menunggu proses selesai
    async function archiveFolders(folderName = 'plugins') {
        return new Promise((resolve, reject) => {
            const backupName = `backup_${folderName}.zip`;
            const output = fs.createWriteStream(backupName);
            const archive = archiver('zip', { zlib: { level: 9 } });

            output.on('close', async () => {
                const totalSizeMB = (archive.pointer() / 1024 / 1024).toFixed(2);
                const caption = `✓ Archive ${folderName} selesai! Total ukuran: ${totalSizeMB} MB.`;

                try {
                    await lulli.sendMessage(ownerJid, {
                        document: fs.readFileSync(backupName), 
                        caption: caption,
                        mimetype: 'application/zip',
                        fileName: backupName
                    }, { quoted: m });
                    
                    fs.unlinkSync(backupName);
                    console.log(`✓ File backup ${backupName} berhasil dikirim dan dihapus.`);
                    resolve(true);
                } catch (sendError) {
                    console.error('✗ Gagal mengirim atau menghapus file backup:', sendError);
                    await m.reply(`✗ Gagal mengirim file backup: ${sendError.message}`);
                    if (fs.existsSync(backupName)) fs.unlinkSync(backupName);
                    resolve(false);
                }
            });

            archive.on('error', (error) => {
                console.error('✗ Terjadi kesalahan saat membuat archive:', error);
                lulli.sendMessage(m.chat, { text: `✗ Terjadi kesalahan saat mengarsipkan: ${error.message}` }, { quoted: m });
                if (fs.existsSync(backupName)) fs.unlinkSync(backupName);
                resolve(false); // Pakai resolve agar script selanjutnya tidak nge-hang
            });

            archive.pipe(output);
            
            // PERBAIKAN 3: Validasi path yang lebih aman
            if (fs.existsSync(path.join(process.cwd(), folderName))) {
                archive.directory(folderName + '/', folderName);
            } else {
                console.warn(`Direktori '${folderName}' tidak ditemukan untuk diarsipkan.`);
            }
            archive.finalize();
        });
    }

    let successCount = 0;

    if (/^plugins/i.test(m.text)) {
        await m.reply(`✧ Memulai backup folder plugins sebelum dipadatkan...`);
        await archiveFolders('plugins'); // Sekarang bot akan menunggu file dikirim
        
        // Ambil list plugin dari parameter handler atau mapping
        const activePlugins = plugins || mapping.plugins;
        const pluginsList = Object.keys(activePlugins);

        for (let filename of pluginsList) {
            const fullPath = path.join(process.cwd(), filename);
            if (!fs.existsSync(fullPath)) continue;

            const inputString = fs.readFileSync(fullPath, 'utf-8');
            if (looksLikeEncryptedPlugin(inputString)) {
                console.log(`Melewatkan file terenkripsi: ${filename}`);
                continue;
            }

            try {
                // TERSER BERSIFAT ASYNC, WAJIB AWAIT
                const result = await minify(inputString, {
                    toplevel: true, // Memperkecil nama variabel global
                    compress: { passes: 2 }, // Kompresi ganda agar lebih padat
                    format: { comments: false } // Menghapus semua komentar
                });

                if (result && result.code) {
                    fs.writeFileSync(fullPath, result.code, 'utf-8');
                    successCount++;
                }
            } catch (err) {
                console.warn(`✗ Gagal meminify file: ${filename}. Error: ${err.message}`);
            }
            await new Promise(resolve => setTimeout(resolve, 50));
        }
        await m.reply(`✓ Berhasil meminify ${successCount} file plugin menggunakan Terser.`);

    } else if (/^system/i.test(m.text)) {
        await m.reply(`✧ Memulai backup folder system sebelum dipadatkan...`);
        await archiveFolders('system');

        const systemFiles = fs.readdirSync('system').filter(file => file.endsWith('.js')).map(filename => path.join('system', filename));
        
        // Menambahkan main.js karena itu file utama yang baru
        const customFiles = ['./handler.js', './index.js', './main.js'].filter(file => fs.existsSync(path.join(process.cwd(), file)));
        const allSystemPaths = [...systemFiles, ...customFiles];

        let captionList = '';

        for (let filePath of allSystemPaths) {
            const fullPath = path.join(process.cwd(), filePath);
            if (!fs.existsSync(fullPath)) continue;

            const inputString = fs.readFileSync(fullPath, 'utf-8');

            try {
                // TERSER BERSIFAT ASYNC
                const isESM = /(?:^|\s)(import\s+.*from|export\s+|await\s+)/i.test(inputString);
                const result = await minify(inputString, {
                    module: isESM,
                    toplevel: true,
                    compress: { passes: 2 }, 
                    format: { comments: false } 
                });

                if (result && result.code) {
                    fs.writeFileSync(fullPath, result.code, 'utf-8');
                    successCount++;
                    captionList += `${successCount}. ${path.basename(filePath)}\n`;
                }
            } catch (err) {
                console.warn(`✗ Gagal meminify file: ${filePath}. Error: ${err.message}`);
            }
            await new Promise(resolve => setTimeout(resolve, 500));
        }

        let caption = `✓ Berhasil meminify ${successCount} file sistem menggunakan Terser.\n\n${captionList}`;
        await m.reply(caption);

    } else {
        await m.reply(`✗ Mohon ketik *${m.cmd} system* atau *${m.cmd} plugins*`);
    }
};

export default {
    run,
    cmd: 'minifyall',
    type: 'developer',
    desc: 'Untuk memperkecil (minify) semua file JavaScript di folder tertentu.',
    devs: true,
    location: 'plugins/developer/minifyall.js'
};
