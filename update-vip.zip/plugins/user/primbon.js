import{Primbon}from"scrape-primbon";let primbon=new Primbon,run=async(e,a,{})=>{a.sendReact(e.chat,"🕒",e.key);var a=e.args.join(" "),i=e.command;let n=a=>String(a||"").replace(/<[^>]*>?/gm,"").replace(/\(adsbygoogle[\s\S]*?\);?/g,"").replace(/\s{2,}/g," ").trim();var s,r,t,m,o,p,g,l,_,h,k,y,$,b,u,c,f,d,j;try{return"arti_nama"===i?a?(s=await primbon.arti_nama(a)).status?e.reply(`A R T I  N A M A

• Nama : ${n(s.message.nama)}
• Arti : ${n(s.message.arti)}
• Catatan : `+n(s.message.catatan)):e.reply("Gagal mendapatkan data arti nama."):e.reply(`Contoh: ${e.prefix}arti_nama yono`):"kecocokan_pasangan"===i?(r=a.split("|")).length<2?e.reply(`Contoh: ${e.prefix}kecocokan_pasangan dika|novia`):(t=await primbon.kecocokan_nama_pasangan(r[0].trim(),r[1].trim())).status?e.reply(`K E C O C O K A N

• Nama Anda : ${n(t.message.nama_anda)}
• Nama Pasangan : ${n(t.message.nama_pasangan)}
• Sisi Positif : ${n(t.message.sisi_positif)}
• Sisi Negatif : `+n(t.message.sisi_negatif)):e.reply(n(t.message)):"nomer_hoki"===i?a?(m=await primbon.nomer_hoki(Number(a))).status?e.reply(`N O M O R  H O K I

• Nomor HP : ${m.message.nomer_hp}
• Angka Shuzi : ${m.message.angka_shuzi}

• Energi Positif :
Kekayaan : ${m.message.energi_positif.kekayaan}
Kesehatan : ${m.message.energi_positif.kesehatan}
Cinta : ${m.message.energi_positif.cinta}
Kestabilan : ${m.message.energi_positif.kestabilan}
Persentase : ${m.message.energi_positif.persentase}

• Energi Negatif :
Perselisihan : ${m.message.energi_negatif.perselisihan}
Kehilangan : ${m.message.energi_negatif.kehilangan}
Malapetaka : ${m.message.energi_negatif.malapetaka}
Kehancuran : ${m.message.energi_negatif.kehancuran}
Persentase : `+m.message.energi_negatif.persentase):e.reply(n(m.message)):e.reply(`Contoh: ${e.prefix}nomer_hoki 0812345678`):"tafsir_mimpi"===i?a?(o=await primbon.tafsir_mimpi(a)).status?e.reply(`• Mimpi : ${n(o.message.mimpi)}
• Arti : ${n(o.message.arti)}
• Solusi : `+n(o.message.solusi)):e.reply(n(o.message)):e.reply(`Contoh: ${e.prefix}tafsir_mimpi belanja`):"ramalan_jodoh"===i?a?(p=a.split(",").map(a=>a.trim())).length<8?e.reply("Format salah."):(g=await primbon.ramalan_jodoh(...p)).status?(l=g.message,e.reply(`• Pihak 1 : ${l.nama_anda.nama}
• Lahir 1 : ${l.nama_anda.tgl_lahir}

• Pihak 2 : ${l.nama_pasangan.nama}
• Lahir 2 : ${l.nama_pasangan.tgl_lahir}

• Hasil : ${l.result}
• Catatan : `+l.catatan)):e.reply(n(g.message)):e.reply(`Contoh: ${e.prefix}ramalan_jodoh Dika,7,7,2005,Novia,16,11,2004`):"ramalan_jodoh_bali"===i?a?(_=a.split(",").map(a=>a.trim())).length<8?e.reply("Format salah."):(h=await primbon.ramalan_jodoh_bali(..._)).status?(k=h.message,e.reply(`• Pihak 1 : ${k.nama_anda.nama}
• Lahir 1 : ${k.nama_anda.tgl_lahir}

• Pihak 2 : ${k.nama_pasangan.nama}
• Lahir 2 : ${k.nama_pasangan.tgl_lahir}

• Hasil : ${k.result}
• Catatan : `+k.catatan)):e.reply(n(h.message)):e.reply(`Contoh: ${e.prefix}ramalan_jodoh_bali Dika,7,7,2005,Novia,16,11,2004`):i in(y={weton:"weton_jawa",rejeki:"rejeki_hoki_weton",pekerjaan:"pekerjaan_weton_lahir",hari_baik:"petung_hari_baik",hari_sangar:"hari_sangar_taliwangke",hari_naas:"primbon_hari_naas",hari_naga:"rahasia_naga_hari",arah_rejeki:"primbon_arah_rejeki",memancing:"primbon_memancing_ikan",nasib:"ramalan_nasib",penyakit:"cek_potensi_penyakit"})?a?($=3!==(f=(f=a).split(",").map(a=>a.trim())).length||([f,d,j]=f,isNaN(f))||isNaN(d)||isNaN(j)?null:[f,d,j])?(b=await primbon[y[i]](...$)).status?(u=Object.entries(b.message).map(([a,e])=>`• ${a.replace(/_/g," ")} : `+n(e)).join("\n"),e.reply(u)):e.reply("Data tidak ditemukan."):e.reply("Format salah! Gunakan: tanggal,bulan,tahun"):e.reply(`Contoh: ${e.prefix}${i} 7,7,2008`):"shio"===i?a?(c=await primbon.shio(a.toLowerCase())).status?e.reply("• Hasil : "+n(c.message)):e.reply(n(c.message)):e.reply(`Contoh: ${e.prefix}shio tikus`):void 0}catch(a){return e.reply("Terjadi kesalahan: "+a.message)}};export default{run:run,cmd:["arti_nama","kecocokan_pasangan","nomer_hoki","tafsir_mimpi","ramalan_jodoh","ramalan_jodoh_bali","weton","rejeki","pekerjaan","hari_baik","hari_sangar","hari_naas","hari_naga","arah_rejeki","memancing","nasib","penyakit","shio"],alias:[],use:"",type:"primbon",limit:!0,location:"plugins/user/primbon.js"};