let cooldown=864e5,rewards={limit:10,exp:12e3,balance:1e4},run=async(a,l,{func:e,users:i})=>{"lastclaim"in i||(i.lastclaim=0);var n,o,r=Date.now();if(r-i.lastclaim<cooldown)return n=cooldown-(r-i.lastclaim),a.reply(`Kamu sudah mengambil daily hari ini!
Tunggu *${e.clockString(n)}* lagi.`);let t="Klaim Daily Berhasil!\n\n";for(o of Object.keys(rewards))o in i||(i[o]=0),i[o]+=rewards[o],t+=`+${rewards[o].toLocaleString()} ${o}
`;i.lastclaim=r,e=t.trim()+`

Total balance sekarang: *${i.balance.toLocaleString()}*`,await l.sendMessage(a.chat,{text:e},{quoted:a,ephemeralExpiration:a.expiration})};export default{run:run,cmd:"daily",alias:["claim"],type:"user",cooldown:cooldown,location:"plugins/user/daily.js"};