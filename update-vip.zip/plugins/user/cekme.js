let getRandomItem=a=>a[Math.floor(Math.random()*a.length)],run=async(a,e,{func:n,cfg:t,froms:i})=>{e.sendReact(a.chat,"🕒",a.key);try{switch(a.command){case"cekme":var r=["Makan","Tidur","Main Game","Sesama Jenis","Binatang",`Seseorang Yang ${a.pushname} Sukai`,"Belajar","Ibadah","Diri Sendiri"],s=()=>Math.floor(100*Math.random())+1,c=getRandomItem(["✓ Cakep","✗ Jelek"]),k=getRandomItem(["Pembohong","Galak","Suka Bantu Orang","Baik","Jahat","Bobrok","Suka BadMood","Setia","Tulus","Beriman","Penyayang Binatang","Baperan"]),o=getRandomItem(r),d=s(),m=s(),g=s(),u=`✦ *CEK PRIBADI KAMU*

`,u=(u+=`~ Nama         : *${a.pushname||"Pengguna"}*
`)+`~ Sifat        : ${a.sender===t.owner?"Setia":k}
`+`~ Keberanian   : ${d}%
`+`~ Ketakutan    : ${g}%
`+`~ Cakep        : ${a.sender===t.owner?"✓ Cakep":c}
`+`~ Kecerdasan   : ${m}%
`+"~ Menyukai     : "+o;await e.sendMessage(a.chat,{text:u},{quoted:a,ephemeralExpiration:a.expiration}),e.sendReact(a.chat,"✅",a.key);break;case"apakah":if(!a.text)return a.reply(`✗ Gunakan dengan cara *${a.cmd} [teks_pertanyaan]*
~ Contoh : *${a.cmd} kamu lonteh*`);await a.reply(`✦ Pertanyaan : apakah *${a.text}*
» Jawaban    : *${getRandomItem(["Iya","Tidak","Bisa Jadi","Betul","Bisa Jadi Tidak"])}*`),e.sendReact(a.chat,"✅",a.key);break;case"bisakah":if(!a.text)return a.reply(`✗ Gunakan dengan cara *${a.cmd} [teks_pertanyaan]*
~ Contoh : *${a.cmd} saya punya cewe*`);await a.reply(`✦ Pertanyaan : bisakah *${a.text}*
» Jawaban    : *${getRandomItem(["Bisa","Tidak Bisa","Tidak Bisa, Astaga!","Tentu, kamu PASTI bisa!","Tentu, kamu TIDAK bisa!"])}*`),e.sendReact(a.chat,"✅",a.key);break;case"kapankah":if(!a.text)return a.reply(`✗ Gunakan dengan cara *${a.cmd} [teks_pertanyaan]*
~ Contoh : *${a.cmd} saya punya cewe*`);var h=["Besok","Lusa","5 Hari Lagi","10 Hari Lagi","15 Hari Lagi","20 Hari Lagi","1 Bulan Lagi","3 Bulan Lagi","6 Bulan Lagi","1 Tahun Lagi","2 Tahun Lagi","3 Tahun Lagi","Tidak Akan Pernah",`Abis ini juga kamu *${a.text}*`];await a.reply(`✦ Pertanyaan : kapankah *${a.text}*
» Jawaban    : *${getRandomItem(h)}*`),e.sendReact(a.chat,"✅",a.key);break;case"bagaimanakah":if(!a.text)return a.reply(`✗ Gunakan dengan cara *${a.cmd} [teks_pertanyaan]*
~ Contoh : *${a.cmd} cara punya cewe*`);await a.reply(`✦ Pertanyaan : bagaimanakah *${a.text}*
» Jawaban    : *${getRandomItem(["Tidak Tahu","Sulit itu","Coba Cari di Google","Maaf, saya tidak bisa menjawab","Astaga, benarkah?","Saya bingung","Oh, begitu","Yang sabar ya","Coba lagi nanti"])}*`),e.sendReact(a.chat,"✅",a.key);break;case"rate":if(!a.text)return a.reply(`✗ Gunakan dengan cara *${a.cmd} [teks_yang_akan_dinilai]*
~ Contoh : *${a.cmd} kebesaran tytydku*`);var l=Math.floor(100*Math.random())+1;await a.reply(`✦ Penilaian : *${a.text}*
» Hasil     : *${l}%*`),e.sendReact(a.chat,"✅",a.key);break;case"gantengcek":case"cantikcek":case"sangecek":case"gaycek":case"lesbicek":if(!i)return a.reply("✗ Mohon mention atau balas pesan target.");var y=Math.floor(100*Math.random())+1;if("gaycek"===a.command)try{var p=global.db.users[i],b=await e.profilePictureUrl(i,"image").catch(()=>"https://files.catbox.moe/39hmb8.jpg"),$=/files\.catbox\.moe/.test(b)?b:await n.tmpfiles(await n.fetchBuffer(b)),w=`https://api.siputzx.my.id/api/canvas/gay?nama=${p?.name||i.split("@")[0]}&avatar=${$}&num=`+y;await e.sendMedia(a.chat,w,a,{expiration:a.expiration,caption:`✦ Hasil Cek Gay:
» @${i.split("@")[0]} : *${y}%* Gay!`})}catch(t){console.error("✗ Error membuat canvas gaycek:",t),await a.reply(`✦ Cek Gay
» @${i.split("@")[0]} : *${y}%* Gay!`)}else await a.reply(`✦ ${n.ucword(a.command.replace("cek"," "))} 
» @${i.split("@")[0]} : *${y}%*`);e.sendReact(a.chat,"✅",a.key)}}catch(t){console.error("✗ Terjadi kesalahan pada Cek Me:",t),e.sendReact(a.chat,"❌",a.key),await a.reply("✗ Terjadi kesalahan: "+t.message)}};export default{run:run,cmd:["cekme","apakah","bisakah","kapankah","bagaimanakah","rate","gantengcek","cantikcek","sangecek","gaycek","lesbicek"],type:"user",limit:!0,location:"plugins/user/cekme.js"};