let run=async(i,t,{cfg:l,setting:n,froms:s})=>{try{let e,a;if(s){e=s;var m=global.db.users[e];if(!m)return i.reply("✗ Data pengguna target tidak ditemukan.");a=m.name}else e=i.sender,a=i.pushname;var o=global.db.users[e]?.premium,u=[l.owner,...global.db.owner||[]].includes(e)||e===t.user.jid,c=[...l.devs,...global.suryadev||[]].includes(e),p=global.db.users[e]?.limit||0,d=global.db.users[e]?.balance||0,b=i.isVIP?"Unlimited":o?n.limit.premium:n.limit.free;let r="";r=c?"Developer":u?"Owner":i.isVIP?"VIP Member":o?"Premium":"Free";var g=e=>"number"!=typeof e?e:new Intl.NumberFormat("en-US",{notation:"compact",compactDisplay:"short",maximumFractionDigits:1}).format(e),y=`*INFO LIMIT AKUN*

`,y=(y=(y=(y=(y+=`⋄ Username: ${a||"@"+e.replace(/@.+/,"")}
`)+`⋄ ID Akun: @${e.replace(/@.+/,"")}
`)+`⋄ Limit: ${g(p)} / ${g(b)}
`)+`⋄ Balance: ${g(d)}
`)+("⋄ Status: "+r);await i.reply(y,{mentions:[e]})}catch(e){console.error("Terjadi kesalahan pada Cek Limit:",e),await i.reply("✗ Terjadi kesalahan: "+e.message)}};export default{run:run,cmd:"limit",alias:["ceklimit","balance"],use:"Mention atau balas pesan target (opsional)",type:"user",location:"plugins/user/limit.js"};