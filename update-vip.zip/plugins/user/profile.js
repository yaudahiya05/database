import fetch from"node-fetch";import ms from"parse-ms";function timeReverse(e){return 0===(e=ms(Date.now()-e)).days&&0===e.hours&&0===e.minutes&&0===e.seconds?"Baru Saja":e.days+` Hari ${e.hours} Jam ${e.minutes} Menit ${e.seconds} Detik`}function countdown(e,a,t){var i=new Date;return(a=new Date(a+` ${e}, ${t} 00:00:00`)).getTime()<i.getTime()&&a.setFullYear(a.getFullYear()+1),(e=a.getTime()-i.getTime())<=0?"Hari ini!":Math.floor(e/864e5)+` Hari ${Math.floor(e%864e5/36e5)} Jam ${Math.floor(e%36e5/6e4)} Menit ${Math.floor(e%6e4/1e3)} Detik Lagi`}let formatTimezone=(e,a="Asia/Jakarta")=>(e=new Date(e),new Intl.DateTimeFormat("id-ID",{timeZone:a,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:!1}).format(e).replace(/\./g,":")),run=async(k,v,{func:A,froms:D})=>{if(v.sendReact(k.chat,"🕒",k.key),!D)return k.reply("✗ Mohon mention atau balas pesan target.");try{var P=global.db.users[D];if(!P)return k.reply("✗ Data pengguna target tidak ditemukan.");let e,a,t,i,{name:r,gender:n,age:o,limit:s,balance:m,premium:l,banned:d,jadibot:u,warning:g,register:c,date:p,pasangan:h,expired:f,level:$,exp:b,role:N,ultah:R}=P,T=(await v.fetchStatus(D).catch(()=>[])||[])?.[0]?.status||{},M=await v.fetchBlocklist().catch(()=>[]),w="Jomblo Abadi",y=(h&&h.id&&(e=global.db.users[h.id],w=e&&e.pasangan&&e.pasangan.id===D?`@${h.id.split("@")[0]} (${timeReverse(h.time)})`:"Sedang digantung oleh @"+h.id.split("@")[0]),"-"),E=o||"-";R&&R.date&&R.status&&([a,t]=R.date.split("/").map(Number),i=(new Date).getFullYear(),y=countdown(a,t,i),E=A.getAgeFromDate(R.date));var j=`乂  *U S E R - P R O F I L E*

◈ *Name* : ${r||v.getName(D)}
◈ *Gender* : ${n||"-"}
◈ *Age* : ${E||0}
◈ *Birthday* : ${y}
◈ *Limit* : ${s||0}
◈ *Balance* : ${A.formatNumber(m)}
◈ *Level* : ${$||0}
◈ *Exp* : ${b||0} / ${10*Math.pow($,2)+50*$+100}
◈ *Role* : ${N}
◈ *Device* : ${A.getDevice(k.key.id)}
◈ *Lovers* : ${w}
◈ *About* : ${T.status} (${formatTimezone(T.setAt)})

乂  *U S E R - S T A T U S*
◈ *Warning* : ${g} / 3
◈ *Blocked* : ${M.includes(k.sender)?"Yes":"No"}
◈ *Banned* : ${d?"Yes ("+("PERMANENT"==f.banned?"PERMANENT":A.timeReverse(f.banned))+")":"No"}
◈ *Premium* : ${l?"Yes ("+("PERMANENT"==f.premium?"PERMANENT":A.timeReverse(f.premium))+")":"No"}
◈ *Jadibot* : ${u?"Yes ("+("PERMANENT"==f.jadibot?"PERMANENT":A.timeReverse(f.jadibot))+")":"No"}
◈ *Register* : `+(c?"Yes ("+p+")":"No"),Y=await v.profilePictureUrl(D,"image").catch(()=>"https://files.catbox.moe/39hmb8.jpg"),x=await fetch(Y).then(e=>e.buffer());await v.sendMessageModify(k.chat,j.trim(),k,{largeThumb:!0,thumbnail:x,expiration:k.expiration,mentions:[D]}),v.sendReact(k.chat,"✅",k.key)}catch(e){console.error("✗ Terjadi kesalahan pada Profil Pengguna:",e),v.sendReact(k.chat,"❌",k.key),await k.reply("✗ Terjadi kesalahan: "+e.message)}};export default{run:run,cmd:"profile",alias:"profil",use:"Mention atau balas pesan target",type:"user",group:!0,location:"plugins/user/profile.js"};