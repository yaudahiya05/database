let cooldown=6048e5,rewards={limit:25,exp:25e3,balance:25e3},run=async(e,l,{func:a,users:n})=>{"lastweekly"in n||(n.lastweekly=0);var o,r,t=Date.now();if(t-n.lastweekly<cooldown)return o=cooldown-(t-n.lastweekly),e.reply(`Kamu sudah mengambil weekly claim minggu ini!
Tunggu *${a.clockString(o)}* lagi.`);let i="Klaim Weekly Berhasil! 🔥\n\n";for(r of Object.keys(rewards))r in n||(n[r]=0),n[r]+=rewards[r],i+=`+${rewards[r].toLocaleString()} ${r}
`;n.lastweekly=t,a=i.trim()+`

Total balance sekarang: *${n.balance.toLocaleString()}*`,await l.sendMessage(e.chat,{text:a},{quoted:e,ephemeralExpiration:e.expiration})};export default{run:run,cmd:"weekly",alias:["weeklyclaim","claimweekly"],type:"user",cooldown:cooldown,location:"plugins/user/weekly.js"};