let hitungKecocokan=(n,e)=>{let i=0;for(let a=0;a<Math.max(n.length,e.length);a++){var t=n.charCodeAt(a)||0,r=e.charCodeAt(a)||0;i+=t^r}return i=(i+n.length*e.length)%100,Math.max(1,i+1)},dapatkanSifatKepribadian=n=>{let a=["Kreatif","Penuh semangat","Setia","Empatis","Petualang","Murah hati","Sabar","Optimis","Berani","Handal","Ceria","Bijaksana","Tegas","Fleksibel","Cerdas","Tenang","Jujur"],e=0;for(let a=0;a<n.length;a++)e=n.charCodeAt(a)+((e<<5)-e);return a[Math.abs(e)%a.length]},run=async(s,m,{func:d,cfg:g})=>{if(m.sendReact(s.chat,"🕒",s.key),!s.text||s.text.split(" ").length<2)return s.reply(d.example(s.cmd,"Surya Lulli"));var l=(o=s.text.split(" "))[0].trim(),o=o[1].trim(),a=a=>2<=a.length&&/^[a-zA-Z]+$/.test(a);if(!a(l)||!a(o))return s.reply("✗ Nama harus berisi huruf (minimal 2 karakter) dan tidak boleh ada angka atau simbol.");try{let a=hitungKecocokan(l,o),n=dapatkanSifatKepribadian(l),e=dapatkanSifatKepribadian(o),i=90<a?"💞 Pasangan yang Sempurna! Hubungan kalian tak terpisahkan dan penuh dengan cinta serta pengertian. Hargai hubungan ini!":70<a?"💕 Pasangan Hebat! Banyak kesamaan yang kuat dan mudah mengatasi perbedaan. Hubungan kalian memiliki pondasi yang kuat untuk tumbuh lebih dalam dan menyenangkan.":50<a?"💘 Pasangan Baik! Ada beberapa perbedaan, namun dengan usaha dan komunikasi, hubungan ini bisa berkembang dengan indah.":30<a?"💓 Pasangan Rata-rata! Kalian memiliki beberapa kesamaan, namun perlu bekerja untuk saling memahami dan menerima perbedaan satu sama lain.":"💔 Kecocokan Rendah. Ada perbedaan yang signifikan yang mungkin memerlukan banyak usaha dan kompromi untuk membuat hubungan ini berhasil.",t,r,u=(r=90<a?(t="Koneksi emosional yang kuat, pemahaman yang mendalam.","Jaga komunikasi dan hindari rasa puas diri."):70<a?(t="Minat bersama, komunikasi yang baik.","Hadapi konflik dengan kesabaran."):50<a?(t="Saling menghormati, siap untuk berunding.","Kerja keras untuk menyelesaikan perbedaan secara konstruktif."):30<a?(t="Potensi untuk pertumbuhan, belajar satu sama lain.","Fokus untuk meningkatkan komunikasi dan pemahaman."):(t="Menantang namun memuaskan jika dikerjakan dengan baik.","Memerlukan usaha yang signifikan dalam komunikasi dan kompromi."),`✦ C U P I D - M E T E R

`),k=(u=(u=(u=(u=(u=(u=(u+=`» *Persentase Kecocokan:*
`)+`  ~ ${l} & ${o}
`+`  ~ ❤️ *${a}%*

`)+`» *Deskripsi:*
${i}

`+`» *Kepribadian:*
`)+`  ~ *${l}* : ${n}
`+`  ~ *${o}* : ${e}

`)+`» *Kekuatan Hubungan:*
${t}

`)+`» *Area untuk Ditingkatkan:*
${r}

`)+`» *Catatan:*
Cupid Meter oleh `+g.botName,await m.sendMessage(s.chat,{text:d.texted("monospace","⚙️ Menghitung kecocokan...")},{quoted:s,ephemeralExpiration:s.expiration}));setTimeout(async()=>{await m.sendMessage(s.chat,{text:u,edit:k.key},{quoted:s,ephemeralExpiration:s.expiration}),m.sendReact(s.chat,"✅",s.key)},2e3)}catch(a){console.error("✗ Terjadi kesalahan saat menghitung kecocokan:",a),m.sendReact(s.chat,"❌",s.key),await s.reply("✗ Terjadi kesalahan saat menghitung kecocokan: "+a.message)}};export default{run:run,cmd:"cupidmeter",alias:"jodohku",type:"user",limit:!0,location:"plugins/user/cupidmeter.js"};