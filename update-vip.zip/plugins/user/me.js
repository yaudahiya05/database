import fetch from"node-fetch";import ms from"parse-ms";function timeReverse(e){return 0===(e=ms(Date.now()-e)).days&&0===e.hours&&0===e.minutes&&0===e.seconds?"Baru Saja":e.days+` Hari ${e.hours} Jam ${e.minutes} Menit ${e.seconds} Detik`}function countdown(e,a,t){var i=new Date;return(a=new Date(a+` ${e}, ${t} 00:00:00`)).getTime()<i.getTime()&&a.setFullYear(a.getFullYear()+1),(e=a.getTime()-i.getTime())<=0?"Hari ini!":Math.floor(e/864e5)+` Hari ${Math.floor(e%864e5/36e5)} Jam ${Math.floor(e%36e5/6e4)} Menit ${Math.floor(e%6e4/1e3)} Detik Lagi`}let formatTimezone=(e,a="Asia/Jakarta")=>(e=new Date(e),new Intl.DateTimeFormat("id-ID",{timeZone:a,year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:!1}).format(e).replace(/\./g,":"));async function run(v,A,{func:k}){A.sendReact(v.chat,"🕒",v.key);try{var D=global.db.users[v.sender];if(!D)return v.reply("✗ User data not found.");let e,a,t,i,{name:r,gender:n,age:s,limit:o,balance:m,premium:d,banned:l,jadibot:u,warning:c,register:g,date:h,pasangan:p,expired:$,level:f,exp:b,role:N,ultah:R}=D,T=(await A.fetchStatus(v.sender).catch(()=>[])||[])?.[0]?.status||{},w=await A.fetchBlocklist().catch(()=>[]),E="Jomblo Abadi",M=(p&&p.id&&(e=global.db.users[p.id],E=e&&e.pasangan&&e.pasangan.id===v.sender?`@${p.id.split("@")[0]} (${timeReverse(p.time)})`:"sedang di gantung @"+p.id.split("@")[0]),"-"),y=s||"-";R&&R.date&&R.status&&([a,t]=R.date.split("/").map(Number),i=(new Date).getFullYear(),M=countdown(a,t,i),y=k.getAgeFromDate(R.date));var P=r||v.pushname||"",j=`乂  *U S E R - P R O F I L E*

◈ *Name* : ${15<P.length?P.slice(0,15)+"...":P}
◈ *Gender* : ${n||"-"}
◈ *Age* : ${y}
◈ *Birthday* : ${M}
◈ *Limit* : ${o||0}
◈ *Balance* : ${k.formatNumber(m)}
◈ *Level* : ${f||0}
◈ *Exp* : ${b||0} / ${10*Math.pow(f,2)+50*f+100}
◈ *Role* : ${N}
◈ *Device* : ${k.getDevice(v.key.id)}
◈ *Lovers* : ${E}
◈ *About* : ${T.status} (${formatTimezone(T.setAt)})

乂  *U S E R - S T A T U S*
◈ *Warning* : ${c} / 3
◈ *Blocked* : ${w.includes(v.sender)?"Yes":"No"}
◈ *Banned* : ${l?"Yes ("+("PERMANENT"==$.banned?"PERMANENT":k.timeReverse($.banned))+")":"No"}
◈ *Premium* : ${d?"Yes ("+("PERMANENT"==$.premium?"PERMANENT":k.timeReverse($.premium))+")":"No"}
◈ *Jadibot* : ${u?"Yes ("+("PERMANENT"==$.jadibot?"PERMANENT":k.timeReverse($.jadibot))+")":"No"}
◈ *Register* : `+(g?"Yes ("+h+")":"No"),Y=await A.profilePictureUrl(v.sender,"image").catch(()=>"https://files.catbox.moe/39hmb8.jpg"),x=await fetch(Y).then(e=>e.buffer());await A.sendMessageModify(v.chat,j.trim(),v,{largeThumb:!0,thumbnail:x,expiration:v.expiration,mentions:[v.sender]}),A.sendReact(v.chat,"✅",v.key)}catch(e){console.error("✗ Terjadi kesalahan pada Cek Profil (Me):",e),A.sendReact(v.chat,"❌",v.key),await v.reply("✗ Terjadi kesalahan: "+e.message)}}export default{run:run,cmd:"me",type:"user",location:"plugins/user/me.js"};