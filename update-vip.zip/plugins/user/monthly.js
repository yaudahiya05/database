let cooldown=2592e6,rewards={limit:50,exp:5e4,balance:5e4},run=async(l,a,{func:n,users:o})=>{"lastmonthly"in o||(o.lastmonthly=0);var t,e,r=Date.now();if(r-o.lastmonthly<cooldown)return t=cooldown-(r-o.lastmonthly),l.reply(`Kamu sudah mengambil monthly claim bulan ini!
Tunggu *${n.clockString(t)}* lagi.`);let i="Klaim Monthly Berhasil! 🎉\n\n";for(e of Object.keys(rewards))e in o||(o[e]=0),o[e]+=rewards[e],i+=`+${rewards[e].toLocaleString()} ${e}
`;o.lastmonthly=r,n=i.trim()+`

Total balance sekarang: *${o.balance.toLocaleString()}*`,await a.sendMessage(l.chat,{text:n},{quoted:l,ephemeralExpiration:l.expiration})};export default{run:run,cmd:"monthly",alias:["monthlyclaim","claimmonthly"],type:"user",cooldown:cooldown,location:"plugins/user/monthly.js"};