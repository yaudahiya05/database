import path from 'node:path';
import fs from 'node:fs';
import sharp from 'sharp';
import { createCanvas, registerFont, loadImage } from 'canvas';
import mapping from '../../system/mapping.js';

const mediaPath = mapping.cfg.path.media;

try {
    const ocrFontPath = path.join(mediaPath, 'fonts/Ocr.ttf');
    const signFontPath = path.join(mediaPath, 'fonts/Sign.ttf');
    const arrialFontPath = path.join(mediaPath, 'fonts/Arrial.ttf');

    if (fs.existsSync(ocrFontPath)) registerFont(ocrFontPath, { family: 'OCR' });
    if (fs.existsSync(signFontPath)) registerFont(signFontPath, { family: 'Sign' });
    if (fs.existsSync(arrialFontPath)) registerFont(arrialFontPath, { family: 'Arrial' });
} catch (error) {
    console.error('✗ Error saat mendaftarkan font:', error);
}

async function generateEKTP(data) {
    try {
        const templatePath = path.join(mediaPath, 'template_ktp.png');
        const templateImg = await loadImage(templatePath);
        
        const canvas = createCanvas(templateImg.width, templateImg.height);
        const ctx = canvas.getContext('2d');
        
        // 1. Gambar background template KTP
        ctx.drawImage(templateImg, 0, 0);

        // 2. Olah foto dengan sharp: Auto-crop proporsional & fokus ke objek utama
        const photoBuffer = await sharp(data.pas_photo_buffer)
            .rotate()
            .resize({
                width: 200,
                height: 250,
                fit: sharp.fit.cover,
                position: sharp.strategy.attention // Biar muka gak kepotong
            })
            .png()
            .toBuffer();

        // 3. Timpa foto pas di atas template
        const photoImg = await loadImage(photoBuffer);
        ctx.drawImage(photoImg, 520, 140, 200, 250);

        // 4. Setup text
        ctx.fillStyle = 'black';

        try {
            ctx.font = '25px Arrial';
            ctx.textAlign = 'center';
            ctx.fillText(`PROVINSI ${data.provinsi.toUpperCase()}`, 380, 65);
            ctx.fillText(`KABUPATEN ${data.kabupaten.toUpperCase()}`, 380, 90);
            ctx.textAlign = 'left';
        } catch (e) { 
            ctx.font = '25px sans-serif'; 
            ctx.textAlign = 'center'; 
            ctx.fillText(`PROVINSI ${data.provinsi.toUpperCase()}`, 380, 65); 
            ctx.fillText(`KABUPATEN ${data.kabupaten.toUpperCase()}`, 380, 90); 
            ctx.textAlign = 'left'; 
        }

        try {
            ctx.font = '32px OCR';
            ctx.fillText(data.nik, 170, 125);
        } catch (e) { 
            ctx.font = '32px monospace'; 
            ctx.fillText(data.nik, 170, 125); 
        }

        try {
            ctx.font = '16px Arrial';
            ctx.fillText(data.nama.toUpperCase(), 190, 155);
            ctx.fillText(data.ttl.toUpperCase(), 190, 178);
            ctx.fillText(data.jenis_kelamin.toUpperCase(), 190, 201);
            ctx.fillText(data.golongan_darah.toUpperCase(), 463, 200);
            ctx.fillText(data.alamat.toUpperCase(), 190, 222);
            ctx.fillText(data.rt_rw.toUpperCase(), 190, 244);
            ctx.fillText(data.kelurahan.toUpperCase(), 190, 267);
            ctx.fillText(data.kecamatan.toUpperCase(), 190, 289);
            ctx.fillText(data.agama.toUpperCase(), 190, 310);
            ctx.fillText(data.status.toUpperCase(), 190, 333);
            ctx.fillText(data.pekerjaan.toUpperCase(), 190, 356);
            ctx.fillText(data.kewarganegaraan.toUpperCase(), 190, 379);
            ctx.fillText(data.masa_berlaku.toUpperCase(), 190, 400);
            ctx.fillText(`${data.kabupaten.toUpperCase()}`, 577, 350);
            ctx.fillText(data.terbuat || new Date().toLocaleDateString('id-ID'), 570, 370);
        } catch (e) { 
            ctx.font = '16px sans-serif'; 
        }

        try {
            if (data.tanda_tangan_path && fs.existsSync(data.tanda_tangan_path)) {
                const signatureImg = await loadImage(data.tanda_tangan_path);
                ctx.drawImage(signatureImg, 540, 385, 120, 50);
            } else {
                const nameParts = data.nama.split(' ');
                ctx.font = '40px Sign';
                ctx.fillText(nameParts[0], 540, 405);
            }
        } catch (e) { 
            const nameParts = data.nama.split(' '); 
            ctx.font = '40px serif'; 
            ctx.fillText(nameParts[0], 540, 405); 
        }

        return canvas.toBuffer('image/png');
    } catch (error) {
        console.error('✗ Error generate E-KTP:', error);
        throw error;
    }
}

const run = async (m, lulli, { func, cfg, quoted }) => {
    if (!quoted || !/image\/(jpe?g|png)/i.test(quoted.mime)) {
        return m.reply(`✗ Mohon kirim/balas foto dengan caption *${m.cmd}*`);
    }
    
    if (!m.text) {
        return m.reply(`✗ Penggunaan:\n*${m.cmd} NIK|Kabupaten|Provinsi|Nama|TTL|JK|GolDarah|Alamat|RT/RW|Kelurahan|Kecamatan|Agama|Status|Pekerjaan|Kewarganegaraan|MasaBerlaku*\n\n✦ Contoh: *${m.cmd} 9999999999|Tokyo|Jawa Tengah|Surya Skylark|Tokyo, 21 Mei 2005|Laki-laki|A|Isekai|003/003|Isekai|Isekai|Islam|Pacaran|Wirausaha|Indonesia|Seumur Hidup*`);
    }
    
    const params = m.text.split('|').map(x => x.trim());
    if (params.length < 16) {
        return m.reply('✗ Data KTP tidak lengkap. Mohon isi semua 16 parameter.');
    }

    const [nik, kabupaten, provinsi, nama, ttl, jenis_kelamin, golongan_darah, alamat, rt_rw, kelurahan, kecamatan, agama, status, pekerjaan, kewarganegaraan, masa_berlaku] = params;
    
    if (!/^(\d{3})\/(\d{3})$/.test(rt_rw)) {
        return m.reply('✗ Format RT/RW salah. Harus dalam format `003/003`.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        // Langsung simpan buffer ke memori, nggak usah di-write ke file lagi
        const pas_photo_buffer = await quoted.download();

        const date = new Date();
        const formattedDate = date.toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '-');

        const ktpData = {
            nik, kabupaten, provinsi, nama, ttl, jenis_kelamin, golongan_darah, alamat, rt_rw, kelurahan, kecamatan, agama, status, pekerjaan, kewarganegaraan, masa_berlaku,
            terbuat: formattedDate,
            pas_photo_buffer // Pass buffer ke fungsi utama
        };

        const resultBuffer = await generateEKTP(ktpData);
        
        await lulli.sendMessage(m.chat, {
            image: resultBuffer,
            caption: '✓ Berikut hasil E-KTP palsu Anda.'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

    } catch (e) {
        console.error('✗ Terjadi kesalahan pada KTP Maker:', e);
        await m.reply(`✗ Terjadi kesalahan saat membuat KTP: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'ktpmaker',
    alias: 'buatktp',
    use: 'NIK|kabupaten|...|masaberlaku (balas foto)',
    type: 'maker',
    premium: true,
    limit: 5,
    location: 'plugins/maker/ktpmaker.js'
};
