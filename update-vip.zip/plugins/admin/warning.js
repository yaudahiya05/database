let run=async(a,r,{func:l,groups:s})=>{var e=`*#WARNING CARD*
──────── ୨୧ ────────
*Violation by* : +tag
*Rule violated* : +reason
*Warning count* : +limit
 
> Consequences for severe violations include blacklist / kick!!`;switch(s.warning=s.warning||{text:e,limit:3},s.member=s.member||[],a.command){case"settextwarn":if(!a.text)return a.reply("✗ Invalid input. Example: "+l.example(a.command,e+`

+tag to tag user
+reason for reason
+limit for warning limit`));s.warning.text=a.text.trim(),a.reply("✓ Warning text successfully updated.");break;case"setlimitwarn":if(!a.args||a.args.length<1)return a.reply("✗ Invalid input. Example: "+l.example(a.command,"3"));var o=parseFloat(a.args[0]);if(isNaN(o)||o<=0)return a.reply("✗ Warning limit must be a positive number.");s.warning.limit=o,r.sendReact(a.chat,"✅",a.key),a.reply(`✓ Warning limit successfully set to ${o}.`);break;case"warn":{let t,e="violating rules";if(a.quoted&&a.quoted.sender)t=a.quoted.sender,e=a.text||e;else{if(!a.text)return a.reply("✗ Invalid input. Example: "+l.example(a.command,"@0,against admin"));var[o,...m]=a.text.split(",").map(e=>e.trim());e=(t=a.mentionedJid&&0<a.mentionedJid.length?a.mentionedJid[0]:l.wa(o),m.join(",")||e)}if(!t||!t.endsWith("@s.whatsapp.net"))return a.reply("✗ Invalid target.");if(!a.members.map(e=>e.id).includes(t))return a.reply("✗ That user is not in this group.");if(t===r.user.jid||a.isAdmin||a.isOwner)return a.reply("✗ Cannot give a warning to the bot, an admin, or the owner.");let n=s.member.find(e=>e.jid===t),i=(n||(n={jid:t,lastseen:Date.now(),toxic:0,chat:0,warn:0},s.member.push(n)),n.warn=(n.warn||0)+1,s.warning.text.replace(/\+tag/g,"@"+t.split("@")[0]).replace(/\+reason/g,e).replace(/\+limit/g,n.warn));n.warn>=s.warning.limit?(i+=`

✗ @${t.split("@")[0]}, you have exceeded the warning limit. Sorry, you will be removed from the group.`,r.reply(a.chat,i,null,{mentions:[t],expiration:a.expiration}),setTimeout(async function(){if(!a.isBotAdmin)return a.reply("✗ Sorry, cannot kick the offender because the bot is not an admin.");await r.groupParticipantsUpdate(a.chat,[t],"remove")},3e3)):await r.reply(a.chat,i,null,{mentions:[t],expiration:a.expiration})}}};export default{run:run,cmd:["warn","setlimitwarn","settextwarn"],use:"parameter (e.g., @user,reason)",type:"admin",group:!0,admin:!0,location:"plugins/admin/warning.js"};