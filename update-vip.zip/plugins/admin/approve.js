function convertMsToDate(e){return new Date(e).toLocaleString("en-US",{timeZone:"Asia/Jakarta",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:!1})}let run=async(e,t,{func:a})=>{let[i]=e.args,r=[],p=`✦ *LIST REQUEST JOIN*
`;var n=await t.groupRequestParticipantsList(e.chat);if(0===n.length)return e.reply("✗ No pending requests.");if(n.forEach((e,t)=>{r.push({index:t+1,jid:e.phone_number,request_method:e.request_method,request_time:e.request_time}),p=(p=(p+=`

${t+1}. @`+e.phone_number.split("@")[0])+`
◦ Request method: `+e.request_method)+`
◦ Time: `+convertMsToDate(1e3*e.request_time)}),p=(p+=`

- ${e.prefix}acc 1 to approve participant 1`)+`
- ${e.prefix}acc all to approve all participants`,i&&/^(all|semua)$/i.test(i)){for(var o of n)await t.groupRequestParticipantsUpdate(e.chat,[o.phone_number],"approve"),await a.delay(1e3);e.reply(`✓ Successfully approved ${n.length} participants.`)}else i&&r.some(e=>e.index===parseInt(i))?(n=r[parseInt(i)-1].jid,await t.groupRequestParticipantsUpdate(e.chat,[n],"approve"),e.reply(`✓ Successfully approved @${n.split("@")[0]}.`,null,{ephemeralExpiration:e.expiration,mentions:[n]})):await e.reply(p,null,{mentions:r.map(e=>e.jid),ephemeralExpiration:e.expiration})};export default{run:run,cmd:"approve",alias:["accept","acc"],use:"all / [participant_number]",type:"admin",group:!0,admin:!0,botAdmin:!0,location:"plugins/admin/approve.js"};