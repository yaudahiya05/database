let run=async(e,t)=>{if(!e.quoted)return e.reply("✗ This command must be used by replying to a customer's message!");try{var r=e.chat,i=new Date,a=i.toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit",second:"2-digit",timeZone:"Asia/Jakarta"}),o=i.toLocaleDateString("en-US",{day:"numeric",month:"long",year:"numeric",timeZone:"Asia/Jakarta"}),n=e.isGc?e.groupName:"Private Chat",s=e.text.trim()||"-",u=e.quoted.sender,c=`
┌─「 *TRANSACTION IN PROCESS* 」
│
├ Time: \`\`\`${a} WIB\`\`\`
├ Date: \`\`\`${o}\`\`\`
├ Location: \`\`\`${n}\`\`\`
├ Note: \`\`\`${s}\`\`\`
│
└─「 Please Wait! 」

Hello @${u.split("@")[0]}, your order is currently being processed! Please wait for further updates.`.trim();await t.sendMessage(r,{text:c,mentions:[u]},{quoted:e,ephemeralExpiration:e.expiration})}catch(r){console.error('Error in "proses" plugin:',r),await t.sendMessage(e.chat,{text:'✗ An error occurred while processing the "in process" notification.'},{quoted:e,ephemeralExpiration:e.expiration})}};export default{run:run,cmd:"proses",use:"(reply message) <note>",type:"admin",admin:!0,location:"plugins/admin/proses.js"};