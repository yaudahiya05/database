function ensureAlarmArray(a){a.alarm&&Array.isArray(a.alarm)||(a.alarm=[]),a.city||(a.city="Semarang")}function isValidTime(a){return/^([01]\d|2[0-3]):([0-5]\d)$/.test(a)}function checkArray(a){return Array.isArray(a)?JSON.stringify(a.sort()):a}function extractNameAndTime(a){var r,a=a.split(" ");return 2<=a.length&&isValidTime(a[a.length-1])?(r=a[a.length-1],{name:a.slice(0,-1).join(" ").trim().toLowerCase(),time:r}):{name:null,time:null}}let run=async(l,a,{func:e,groups:m})=>{ensureAlarmArray(m);var s=`✧ *Format Perintah:*
- Untuk mengatur alarm, gunakan format berikut:
> ${l.prefix}setalarm name|text alarm|HH:mm|--options

✧ *Daftar Opsi:*
- --days 0-6 (Hari, 0=Minggu, 6=Sabtu)
- --timezone Asia/Jakarta
- --tagall (Menandai semua peserta)
- --open (Membuka grup jika grup tertutup)
- --close (Menutup grup)

💡 *TIPS SPESIAL RAMADAN:*
Beri nama alarm dengan *sahur*, *imsak*, atau *maghrib* untuk otomatis menyesuaikan dengan jadwal azan harian kotamu! (Atur kota dengan command *${l.prefix}alarmcity*)`;switch(l.command){case"setalarm":{var u=l.text.split("|").map(a=>a.trim());if(u.length<3)return l.reply(`✗ Format perintah salah.
`+s);let[a,r,e,...t]=u,n=a.toLowerCase();if(!n)return l.reply("✗ Nama alarm tidak boleh kosong.");if(!isValidTime(e))return l.reply("✗ Format waktu salah. Harus dalam format HH:mm (contoh: 07:00).");var o,u=t.join(" ");let i={days:null,timeZone:"Asia/Jakarta",tagAll:!1,announce:null};if(u)for(o of u.split("--").map(a=>a.trim()).filter(Boolean)){var[d,...p]=o.split(" ").map(a=>a.trim()),k=p.join(" ");switch(d){case"days":var y=k.split(",").map(a=>a.trim()),y=[...new Set(y.filter(a=>!isNaN(a)&&0<=parseInt(a)&&parseInt(a)<=6))];if(0===y.length)return l.reply("✗ Opsi --days harus berupa angka antara 0-6, dipisahkan koma.");i.days=y.map(Number).sort();break;case"timezone":y=["Asia/Jakarta","Asia/Makassar","Asia/Jayapura","America/New_York","Europe/Berlin"];if(!y.includes(k))return l.reply("✗ Zona waktu tidak valid! Daftar: "+y.join(", "));i.timeZone=k;break;case"tagall":i.tagAll=!0;break;case"open":i.announce="open";break;case"close":i.announce="close";break;default:return l.reply(`✗ Opsi tidak dikenal: --${d}.`)}}if(m.alarm.some(a=>a.time===e&&checkArray(a.days)===checkArray(i.days)))return l.reply(`✗ Alarm pada waktu ${e} dengan hari yang sama sudah ada. Gunakan waktu lain atau hapus alarm tersebut terlebih dahulu.`);var u={name:n,status:!0,textAlarm:r,time:e,timeZone:i.timeZone,days:i.days,tagAll:i.tagAll,announce:i.announce,createdAt:Date.now()},c=m.alarm.findIndex(a=>a.name===n),h=(-1===c?m.alarm.push(u):m.alarm[c]=u,[]);u.days&&h.push("Hari: "+u.days.join(", ")),u.tagAll&&h.push("Tag All"),u.announce&&h.push("Announce: "+u.announce),await l.reply(`✓ Alarm berhasil ${-1===c?"ditambahkan":"diperbarui"}:
- Nama: ${a}
- Pesan: ${r}
- Waktu: ${e} (${u.timeZone})
- Opsi: `+(0<h.length?h.join(", "):"-"))}break;case"alarmcity":if(ensureAlarmArray(m),!l.text)return l.reply(`✗ Masukkan nama kota untuk menyesuaikan jadwal sholat otomatis!
✧ Contoh: *${l.prefix}alarmcity semarang*`);m.city=l.text.trim(),await l.reply(`✓ Kota alarm grup ini berhasil diatur ke: *${m.city}*

Alarm dengan nama sahur, imsak, dan maghrib akan otomatis mengikuti jadwal kota ini.`);break;case"delalarm":{if(ensureAlarmArray(m),0===m.alarm.length)return l.reply("✗ Tidak ada alarm di grup ini.");if(!l.text)return l.reply("✗ Masukkan nama alarm yang ingin dihapus!");let r=l.text.trim().toLowerCase();c=m.alarm.findIndex(a=>a.name===r);if(-1===c)return l.reply(`✗ Alarm dengan nama “${r}“ tidak ditemukan.`);m.alarm.splice(c,1),await l.reply(`✓ Alarm dengan nama “${r}“ berhasil dihapus.`)}break;case"listalarm":{if(ensureAlarmArray(m),0===m.alarm.length)return l.reply("✗ Tidak ada alarm di grup ini.");let t=`✦ *L I S T - A L A R M*
📍 *Kota Jadwal Sholat:* ${m.city||"Semarang"}
`;m.alarm.forEach((a,r)=>{var e=[];a.tagAll&&e.push("Tag All"),a.announce&&e.push("Announce: "+a.announce),t+=`

${r+1}. Nama: `+a.name+`
- Status: `+(a.status?"Aktif":"Non-aktif")+`
- Pesan: `+a.textAlarm+`
- Waktu: ${a.time} (${a.timeZone})`+`
- Hari: `+(a.days?a.days.map(a=>["Minggu","Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"][a]).join(", "):"Setiap hari")+`
- Opsi: `+(0<e.length?e.join(", "):"-")}),await l.reply(t)}break;case"alarm":if(ensureAlarmArray(m),0===m.alarm.length)return l.reply("✗ Tidak ada alarm di grup ini.");var[u,h]=l.args;if(!u||!h)return l.reply(`✗ Format perintah salah.
✧ Contoh: `+e.example(l.cmd,"1 on/off"));c=parseInt(u)-1;if(isNaN(c)||c<0||c>=m.alarm.length)return l.reply("✗ Indeks alarm tidak valid!");u=h.toLowerCase();if(!/^(on|off)$/.test(u))return l.reply("✗ Mode tidak valid. Gunakan `on` atau `off`.");h=m.alarm[c],c="on"===u;if(h.status===c)return l.reply(`✗ Alarm “${h.name}“ sudah ${"on"===u?"aktif":"tidak aktif"} sebelumnya.`);h.status=c,await l.reply(`✓ Alarm “${h.name}“ berhasil di${"on"===u?"aktifkan":"non-aktifkan"}.`);break;case"setalarmtime":{if(ensureAlarmArray(m),0===m.alarm.length)return l.reply("✗ Tidak ada alarm di grup ini.");let{name:r,time:a}=extractNameAndTime(l.text);if(!r||!a)return l.reply(`✗ Format perintah salah.
✧ Contoh: `+e.example(l.cmd,"pagi time 08:00"));if(!isValidTime(a))return l.reply("✗ Format waktu salah. Harus dalam format HH:mm.");c=m.alarm.find(a=>a.name===r);if(!c)return l.reply(`✗ Alarm dengan nama “${r}“ tidak ditemukan.`);c.time=a,await l.reply(`✓ Berhasil mengubah waktu alarm “${r}“ menjadi ${a}.`)}}};export default{run:run,cmd:["setalarm","alarmcity","delalarm","listalarm","alarm","setalarmtime"],use:"options",type:"admin",group:!0,admin:!0,location:"plugins/admin/alarm.js"};