let run=async(e,o,{func:t,groups:r})=>{r.goodbyeText=r.goodbyeText||"";var a=(o=await o.groupMetadata(e.chat).catch(()=>({}))).subject||"Cool Group",o=o.desc||"Group description.",u=r.goodbyeText||"Goodbye +user from +group.";if(!e.text)return e.reply("✗ Invalid input. Example: "+t.example(e.command,u+`

+user to tag user
+group for group name
+desc for group description`));r.goodbyeText=e.text.trim(),t=e.text.replace(/\+user/g,"@"+e.sender.split("@")[0]).replace(/\+group/g,a).replace(/\+desc/g,o),await e.reply(`✓ Goodbye text successfully changed to :
`+t)};export default{run:run,cmd:"setgoodbye",alias:"setbye",use:"text goodbye",type:"admin",admin:!0,group:!0,location:"plugins/admin/setgoodbye.js"};