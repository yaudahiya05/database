let run=async(e,t)=>{if(!e.quoted)return e.reply("✗ This command must be used by replying to a customer's message!");try{var r=e.chat,a=new Date,i=a.toLocaleTimeString("en-US",{hour:"2-digit",minute:"2-digit",second:"2-digit",timeZone:"Asia/Jakarta"}),n=a.toLocaleDateString("en-US",{day:"numeric",month:"long",year:"numeric",timeZone:"Asia/Jakarta"}),o=e.isGc?e.groupName:"Private Chat",s=e.text.trim()||"-",c=e.quoted.sender,u=`
┌─「 ✓ *TRANSACTION COMPLETED* 」
│
├ Time: \`\`\`${i} WIB\`\`\`
├ Date: \`\`\`${n}\`\`\`
├ Location: \`\`\`${o}\`\`\`
├ Note: \`\`\`${s}\`\`\`
│
└─「 Thank You! 」

Hello @${c.split("@")[0]}, your order has been successfully processed!`.trim();await t.sendMessage(r,{text:u,mentions:[c]},{quoted:e,ephemeralExpiration:e.expiration})}catch(r){console.error('Error in "done" plugin:',r),await t.sendMessage(e.chat,{text:"✗ An error occurred while processing the transaction receipt."},{quoted:e,ephemeralExpiration:e.expiration})}};export default{run:run,cmd:"done",use:"(reply message) <note>",type:"admin",location:"plugins/admin/done.js"};