import os from"node:os";import{performance}from"node:perf_hooks";let formatUptime=e=>{var o=Math.floor(e/86400),t=Math.floor(e%86400/3600),r=Math.floor(e%3600/60),e=Math.floor(e%60);let s="";return 0<o&&(s+=o+"d "),0<t&&(s+=t+"h "),0<r&&(s+=r+"m "),0<e&&(s+=e+"s"),s.trim()||"0s"},run=async(e,o)=>{var t=performance.now(),r=(os.totalmem()/Math.pow(1024,3)).toFixed(2),s=(os.freemem()/Math.pow(1024,3)).toFixed(2),a=(r-s).toFixed(2),i=process.memoryUsage(),p=(i.rss/Math.pow(1024,2)).toFixed(2),i=(i.heapUsed/Math.pow(1024,2)).toFixed(2),m=os.cpus(),n=m[0]?.model.trim()||"Tidak diketahui",d=m[0]?.speed||0,t=(performance.now()-t).toFixed(4),n=`✦ *SERVER INFORMATION*

❖ *S Y S T E M*
\`\`\`» OS: ${os.type()} ${os.release()} (${os.arch()})
» Node.js: ${process.version}
» Sys Uptime: ${formatUptime(os.uptime())}
» Bot Uptime: ${formatUptime(process.uptime())}\`\`\`

❖ *C P U*
\`\`\`» Model: ${n}
» Cores: ${m.length} Core(s)
» Speed: ${d} MHz\`\`\`

❖ *M E M O R Y*
\`\`\`» OS Total: ${r} GB
» OS Used: ${a} GB
» OS Free: ${s} GB
» Bot RSS: ${p} MB
» Bot Heap: ${i} MB\`\`\`

❖ *S P E E D*
\`\`\`» Ping: ${t} ms\`\`\``;await o.sendMessage(e.chat,{text:n.trim()},{quoted:e,ephemeralExpiration:e.expiration})};export default{run:run,cmd:"ping",type:"info",location:"plugins/info/ping.js"};