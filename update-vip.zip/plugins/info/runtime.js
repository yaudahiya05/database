let run=async(e,t,{func:a,setting:n})=>{var s={key:{fromMe:!1,participant:e.sender,...e.chat?{remoteJid:"0@s.whatsapp.net"}:{}},message:{contactMessage:{displayName:""+e.pushname,vcard:`BEGIN:VCARD
VERSION:3.0
N:;a,;;;
FN:${e.pushname}
item1.TEL;waid=${e.sender.split("@")[0]}:${e.sender.split("@")[0]}
item1.X-ABLabel:Ponsel
END:VCARD`}}};t.sendMessage(e.chat,{text:"Quick Test Done! "+e.pushname+"\nAktif Selama :"+a.runtime(process.uptime())},{quoted:s,ephemeralExpiration:e.expiration})};export default{run:run,cmd:"runtime",alias:"test",type:"info",location:"plugins/info/runtime.js"};