import axios from"axios";let LulliAI=async a=>{try{var e=await axios.post("https://chateverywhere.app/api/chat/",{model:{id:"gpt-4",name:"GPT-4",maxLength:32e3,tokenLimit:8e3,completionTokenLimit:5e3,deploymentName:"gpt-4"},messages:[{pluginId:null,content:a,role:"user"}],prompt:`Kamu adalah converter plugin WhatsApp bot Baileys yang sangat patuh pada struktur EXACT yang diminta user.

TUGAS KAMU HANYA: mengubah kode plugin lama menjadi format BARU berikut. Output HANYA kode JavaScript sesuai format di bawah. TIDAK ADA teks lain, tidak ada \`\`\`js, tidak ada penjelasan, tidak ada kata "Berikut", "Hasil", "Kode baru", tidak ada komentar di luar kode.

ADA DUA TIPE PLUGIN UTAMA:

1. PLUGIN BIASA (dengan command) pakai 'run' dan punya 'cmd'

Format WAJIB:
const run = async (m, lulli, { func }) => {
    // SELURUH LOGIKA DI SINI SAJA
};

export default {
    run,
    cmd: 'nama_utama', // string jika 1 command, atau ['cmd1','cmd2'] jika banyak
    alias: 'nama_lain', // string atau ['alias1','alias2'] — hanya nama alternatif, bukan command utama
    type: 'tools', // WAJIB salah satu dari 21 kategori ini: admin, ai, anime, buyer, convert, developer, downloader, editor, event, fun, games, group, info, islamic, jadibot, maker, owner, searching, tools, topup, user
    premium: false, // true jika khusus premium
    limit: false, // true jika pakai limit pemakaian
    group: false, // true jika HARUS di grup
    private: false, // true jika HARUS di private chat
    admin: false, // true jika HARUS admin grup
    botAdmin: false, // true jika bot HARUS jadi admin
    register: false, // true jika user harus register dulu
    owner: false, // true jika khusus owner
    developer: false, // true jika khusus developer
    location: 'plugins/tools/namafile.js' // WAJIB format ini, pilih kategori dari 21 di atas
};

2. PLUGIN EVENT (tanpa command, aktif di setiap pesan) pakai 'main', tidak ada 'cmd' atau 'alias'

Format WAJIB:
const main = async (m, lulli, { func, groups }) => {
    // logika yang berjalan otomatis setiap pesan, biasanya pakai m.budy, anti-link, welcome, dll
};

export default {
    main,
    group: false, // true jika HARUS di grup
    private: false, // true jika HARUS di private chat
    admin: false, // true jika HARUS admin grup
    botAdmin: false, // true jika bot HARUS jadi admin
    register: false, // true jika user harus register dulu
    owner: false, // true jika khusus owner
    developer: false, // true jika khusus developer
    location: 'plugins/event/namafile.js'
};

ATURAN KETAT WAJIB DIKIKUT:
- Jika fitur punya command pakai tipe 1 (run + cmd)
- Jika fitur berjalan otomatis tanpa command (anti-link, welcome, detect kata, dll) pakai tipe 2 (main, tanpa cmd/alias)
- cmd string jika hanya 1, array jika >1
- alias hanya nama lain (bukan command utama), string atau array, boleh kosong/tidak ada jika tidak punya alias
- type WAJIB salah satu dari 21 kategori di atas. Pilih yang paling cocok dengan fungsi plugin.
- location SELALU 'plugins/[kategori]/[nama-file].js' — nama file sebaiknya mengandung command utama atau deskripsi singkat (contoh: convertplugin.js, antilink.js, hidetag.js)
- JANGAN tambahkan field yang tidak disebutkan di atas.
- Gunakan helper serialize: m.reply(), m.text, m.args, m.isOwner, m.isGc, m.isAdmin, m.isBotAdmin, dll.
- JANGAN import baileys atau module lain kecuali benar-benar perlu dan jarang.
- JANGAN pakai client.sendMessage langsung jika bisa pakai m.reply().
- Output HANYA kode JavaScript sesuai salah satu dari dua format di atas.

Sekarang ubah kode plugin lama yang diberikan menjadi format yang benar sesuai aturan di atas.
KELUARKAN HANYA KODE JAVASCRIPT. TIDAK ADA APA PUN SELAIN KODE.`,temperature:.2,max_tokens:1500},{headers:{Accept:"/*/","User-Agent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"}});return e.data?.response||e.data?.text||e.data||""}catch(a){throw new Error(a.message)}},run=async(a,e,{})=>{let i;if(1<=a.args.length?i=a.args.join(" "):a.quoted&&a.quoted.text&&(i=a.quoted.text),!i)return a.reply(`kirim/reply kode plugin lain setelah command.
Contoh:
${a.cmd} const handler = async ... { ... }`);try{e.sendReact(a.chat,"🕒",a.key);var t=(await LulliAI(i)).replace(/^(Here is|Berikut|Ini|Result|Kode|Plugin|Converted|Output):?.*/im,"").replace(/^```(?:js|javascript)?\s*/im,"").replace(/```$/gm,"").replace(/`{1,3}/g,"").replace(/^\s*\/\/.*$/gm,"").replace(/^\s*[\w\s]+[:=].*$/im,"").trim();if(!t||!t.includes("export default"))return a.reply("AI gagal menghasilkan format yang benar. Coba paste ulang kode plugin lamanya.");await e.sendMessage(a.chat,{text:t},{quoted:a,ephemeralExpiration:a.expiration})}catch(e){console.error(e),await a.reply("Gagal konversi: "+e.message)}};export default{run:run,cmd:"cplugin",alias:"pluginai",type:"tools",premium:!0,location:"plugins/ai/pluginai.js"};