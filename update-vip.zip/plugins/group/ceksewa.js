let run=async(e,r,{func:a,groups:s})=>{if(!s.sewa||!s.sewa.status)return e.reply(`✗ This group is not registered in the bot rental list. Type ${e.prefix}listrent for more info.`);var t=`✦ *GROUP RENTAL CHECK*
`,t=(t+=`
✧ Name: `+e.groupName)+`
✧ ID: `+e.chat+`
✧ VIP: `+(s.sewa?.vip?"✅":"❌")+`
✧ Expire: `+(/PERMANENT/.test(s.sewa?.expired)?"PERMANENT":a.expireTime(s.sewa?.expired));await e.reply(t)};export default{run:run,cmd:"ceksewa",alias:"checksewa",type:"group",group:!0,location:"plugins/group/ceksewa.js"};