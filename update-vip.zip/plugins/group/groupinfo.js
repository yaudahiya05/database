import moment from"moment-timezone";import{areJidsSameUser}from"@whiskeysockets/baileys";let statusIndicator=t=>t?"✓":"✗",run=async(t,a,{func:i,groups:e,lid:n})=>{(e=e||{}).sewa=e.sewa||{expired:0};var s=await a.groupMetadata(t.chat),n=(n.convertLidParticipants(s),s.participants.filter(t=>t.admin)),o=await i.fetchBuffer(await a.profilePictureUrl(t.chat,"image").catch(()=>"https://telegra.ph/file/320b066dc81928b782c7b.png")),r=`✧ *GROUP INFO*

`,r=(r+=`Name: ${s.subject}
`)+`ID: ${s.id}
`+`Owner: ${s.ownerPn?"@"+s.ownerPn.split("@")[0]:s.owner?"@"+s.owner.split("@")[0]:t.chat.match("-")?"@"+t.chat.split("-")[0]:"-"}
`+`Addressing Mode: ${s.addressingMode}
`+`Created: ${moment(1e3*s.creation).format("DD/MM/YY HH:mm:ss")}
`+`Member: ${s.participants.length}
`+`Admin: ${n.length}

`+`✧ *GROUP SETTING*

`+statusIndicator(e.welcome)+` Welcome Message
`+statusIndicator(e.goodbye)+` Goodbye Message
`+statusIndicator(e.detect)+` Detect Message
`+statusIndicator(e.antitoxic)+` Anti Toxic
`+statusIndicator(e.antilink)+` Anti Link
`+statusIndicator(e.antivirtex)+` Anti Virtex
`+statusIndicator(e.antibot)+` Anti Bot
`+statusIndicator(e.antiluar)+` Anti Outside
`+statusIndicator(e.antihidetag)+` Anti Hidetag
`+statusIndicator(e.antidelete)+` Anti Deleted
`+statusIndicator(e.antiedited)+` Anti Edited
`+statusIndicator(e.antiporn)+` Anti Porn
`+statusIndicator(e.antihacked)+` Anti Hacked
`+statusIndicator(e.antigsm)+` Anti Group Status Mention
`+statusIndicator(e.autosholat)+` Auto Sholat/Adzan
`+statusIndicator(e.autokicksider)+` Auto Kick Sider

`+`✧ *GROUP STATUS*

`+`Muted: ${statusIndicator(e.mute)}
`+`Send messages: ${s.announce?"Admins only":"All participants"}
`+`Edit group info: ${s.restrict?"Admins only":"All participants"}
`+"Bot Rental Expired: "+(0===e.sewa.expired?"-":i.timeReverse(e.sewa.expired));await a.sendMessageModify(t.chat,r,t,{largeThumb:!0,thumbnail:o,expiration:t.expiration})};export default{run:run,cmd:"groupinfo",alias:["infogroup","gcinfo"],type:"group",group:!0,location:"plugins/group/groupinfo.js"};