import PhoneNumber from"awesome-phonenumber";let getCountryFlag=o=>o?o.toUpperCase().split("").map(o=>String.fromCodePoint(o.charCodeAt(0)-65+127462)).join(""):"🏳️",run=async(o,t,{})=>{var e,n=new Intl.DisplayNames(["en"],{type:"region"}),r={};for(e of l=o.metadata.participants){var a="+"+e.id.split("@")[0];let o="Unknown",t="🏳️";(a=new PhoneNumber(a).getRegionCode())&&(o=n.of(a)||"Unknown",t=getCountryFlag(a)),r[o]||(r[o]={total:0,flag:t}),r[o].total++}var l=l.length,i=Object.keys(r).length,p=Object.entries(r).map(([o,{total:t,flag:e}])=>e+` *${o}*: ${t} members`).join("\n"),u=`✦ *GROUP COUNTRY CHECKER*

`;await o.reply((u+=`✧ Total Members: ${l}
`)+`✧ Total Regions: ${i}

`+`✧ Country List:
`+(p||"No country data found."))};export default{run:run,cmd:"groupcountry",alias:["country","region"],type:"group",group:!0,location:"plugins/group/groupcountry.js"};