let run=async(t,e,{date:a,groups:n,socket:s})=>{let i,r=n.absen;r||(n.absen={status:!1,reason:"-",date:"",participants:[],key:[]},r=n.absen);var o=[["Absen",t.prefix+"absen"]];switch(t.command){case"mulaiabsen":if(!t.isAdmin&&!t.isOwner)return t.reply("✗ You are not authorized to use this command.");if(r.status)return t.reply(`✗ An attendance session is already active in this group. Send *${t.prefix}hapusabsen* to remove it.`);n.absen={status:!0,reason:t.text||"-",date:a,participants:[],key:[]},i=`✦ *ATTENDANCE STARTED*

- Date: ${n.absen.date}
- Reason: `+n.absen.reason;var p=n.absen.participants.map(e=>e.jid),p=(await e.sendbut(t.chat,i.trim(),"click the button below to attend",o,t,{caption:i+`

Send *${t.prefix}absen* to mark attendance`,mentions:p,expiration:t.expiration})).key;n.absen.key.push({...p,botId:e.user.jid});break;case"absen":case"attend":if(!r.status)return t.reply("✗ No attendance session is active in this group!");if(r.participants.some(e=>e.jid===t.sender))return t.reply("✗ You have already marked attendance!");if(t.text&&30<t.text.length)return t.reply("✗ Maximum 30 characters allowed.");if(n.absen.participants.push({jid:t.sender,text:t.text||""}),i=`乂 *A T T E N D A N C E*

- Date: ${r.date}
- Reason: ${r.reason}
- Total: ${r.participants.length}
- Attendance List: `+(r.participants.length<1?"-":formatAbsen(r.participants)),0<n.absen.key.length){for(var d of n.absen.key){var c=s.get(d.botId)||e;try{await c.sendMessage(d.remoteJid,{delete:d})}catch(e){}}n.absen.key=[]}p=n.absen.participants.map(e=>e.jid),p=(await e.sendbut(t.chat,i.trim(),"click the button below to attend",o,t,{caption:i+`

Send *${t.prefix}absen* to mark attendance`,mentions:p,expiration:86400})).key,n.absen.key.push({...p,botId:e.user.jid});break;case"cekabsen":if(!r.status)return t.reply("✗ No attendance session is active!");i=`乂 ${t.groupName}

- Date: ${r.date}
- Reason: ${r.reason}
- Total: ${r.participants.length}
- Attendance List: ${r.participants.length<1?"-":formatAbsen(r.participants)}

Send *${t.prefix}absen* to mark attendance`,await t.reply(i.trim());break;case"hapusabsen":return t.isAdmin||t.isOwner?r.status?(n.absen={status:!1,reason:"-",date:"",participants:[],key:[]},void await t.reply("✓ Attendance session successfully deleted.")):t.reply("✗ No attendance session is active!"):t.reply("✗ You are not authorized to use this command.")}};function formatAbsen(e){return Array.isArray(e)&&0!==e.length?"\n"+e.map((e,t)=>`${t+1}. @${e.jid.split("@")[0]} `+(e.text?`(${e.text})`:"")).join("\n"):"-"}export default{run:run,cmd:["mulaiabsen","absen","cekabsen","hapusabsen"],alias:["attend"],use:"[reason]",type:"group",group:!0,location:"plugins/group/absen.js"};