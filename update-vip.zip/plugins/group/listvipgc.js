let run=async(e,l,{})=>{var t=Object.values(global.db.groups||{}).filter(e=>e.vip);if(!t||0===t.length)return e.reply("✦ No VIP group data found.");let a="✦ *V I P - G R O U P - L I S T*";t.forEach((e,l)=>{a+=`

${l+1}. ${e.name}
✦ ID: `+e.jid}),await e.reply(a)};export default{run:run,cmd:"listvipgc",alias:"listgcvip",use:"Displays a list of all VIP groups registered with the bot.",type:"developer",devs:!0,desc:"Shows a list of all groups that have VIP status.",location:"plugins/special/listvipgc.js"};