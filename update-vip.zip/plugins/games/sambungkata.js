import util from"node:util";let gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/kbbi.json",random=a=>a[Math.floor(Math.random()*a.length)];async function getKbbi(){if(!global.db_kbbi)try{var a=await fetch(gamesUrl);global.db_kbbi=await a.json()}catch(a){return console.error("Gagal mengambil data KBBI",a),[]}return global.db_kbbi}async function genKata(){var a=await getKbbi();let e=random(["a","b","c","d","e","g","h","i","j","k","l","m","n","p","r","s","t","u","w"]);var n=a.filter(a=>a.startsWith(e));let r=random(n);for(;!r||r.length<3;)r=random(n);return r}async function cekKata(a=""){return(await getKbbi()).includes(a.toLowerCase())}function filter(a){if(!/[aiueo][aiueo]([qwrtypsdfghjklzxcvbnm])?$/.test(a)&&2<=a.length){var e=a.substring(a.length-2);if(e.match(/[aiueo]/)&&e.match(/[qwrtypsdfghjklzxcvbnm]/))return e}return a.substring(a.length-1)}global.skata=global.skata||{},global.db_kbbi=global.db_kbbi||null;let run=async(e,n,{func:r,cfg:t})=>{try{var i,l=e.chat;let a=global.skata[l];a||(i=await genKata(),global.skata[l]={owner:e.sender,player:[],status:"wait",basi:[],point:0,chance:0,index:0,current:"",kata:i,timer:40,timeout:null,filter:filter},a=global.skata[l]);var s=(e.args[0]||"").toLowerCase();if(!s)return e.reply(`⋄ Kirim perintah :

⋄ - *${e.cmd} help*
⋄ - *${e.cmd} join*
⋄ - *${e.cmd} start*
⋄ - *${e.cmd} exit*
⋄ - *${e.cmd} delete*
⋄ - *${e.cmd} player*

⋄ Bisa dimainkan Solo (Lawan AI) atau Multiplayer!`);switch(s){case"help":case"rules":case"menu":n.reply(l,`⋄ *S A M B U N G - K A T A - H E L P*

⋄ 1. Bisa dimainkan solo (lawan Bot) atau bersama teman.
⋄ 2. Saat permainan dimulai bot akan memberikan 1 kata
⋄ 3. Kemudian, player harus membuat 1 kata dari suku kata terakhir dari kata sebelumnya
⋄ 4. Contohnya: *Teknologi*, maka jawabannya *Gigih* atau *Girang*
⋄ 5. Permainan sistem eliminasi, yang kehabisan waktu/nyawa akan gugur sampai tersisa 1 pemenang.
⋄ 6. Player baru bebas join kapan saja meskipun game sedang berjalan.
⋄ 7. Tiap pemain diberi waktu 40 detik untuk menjawab
⋄ 8. Tiap pemain diberi 3 kesempatan untuk menjawab
⋄ 9. Kata yang dijawab harus terdaftar dalam KBBI dan belum pernah dijawab
⋄ 10. Apabila kalah/tereliminasi, player akan diberikan denda minus balance.`,e,{expiration:e.expiration});break;case"join":if(r.ceklimit(e.sender,1)&&!e.isPrem&&!e.isVIP)return e.reply("✗ "+t.mess.limit);if(a.player.find(a=>a.id===e.sender))return e.reply("✗ Kamu sudah berada di dalam list pemain.");a.player.push({id:e.sender,chance:3,words:0,sessionPrize:0}),"play"===a.status?e.reply(`✓ Berhasil masuk ke permainan yang sedang berjalan!
⋄ Tunggu giliranmu ya. Total pemain sekarang: `+a.player.length):e.reply(`✓ Berhasil masuk
⋄ Jumlah pemain: `+a.player.length);break;case"exit":if(!a.player.find(a=>a.id===e.sender))return e.reply("✗ Kamu tidak dalam sesi permainan.");if("play"===a.status)return e.reply("✗ Permainan sudah dimulai, kamu tidak bisa keluar secara sepihak. Jawab salah untuk tereliminasi!");var u=a.player.findIndex(a=>a.id===e.sender);a.player.splice(u,1),e.reply(`✓ @${e.sender.split("@")[0]} keluar dari permainan.`);break;case"delete":if(!a)return e.reply("✗ Tidak ada sesi permainan.");if(a.owner!==e.sender&&!e.isDevs)return e.reply(`✗ Hanya @${a.owner.split("@")[0]} yang dapat menghapus sesi permainan ini.`);n.reply(l,"✓ Sesi permainan berhasil dihapus.",e,{expiration:e.expiration}),a.timeout&&clearTimeout(a.timeout),delete global.skata[l];break;case"player":if(!a||0===a.player.length)return e.reply("✗ Sesi permainan belum memiliki player.");var m="⋄ *S A M B U N G - K A T A*\n\n⋄ LIST PLAYER:\n";m+=a.player.map((a,e)=>e+1+". "+("BOT"===a.id?"🤖 AI Bot":"@"+a.id.split("@")[0])).join("\n"),n.reply(l,m.trim(),e,{expiration:e.expiration});break;case"start":if("play"===a.status)return e.reply("✗ Permainan sudah dimulai.");if(0===a.player.length)return e.reply("✗ Kamu belum join sesi permainan. Ketik join terlebih dahulu.");1===a.player.length&&(a.player.push({id:"BOT",chance:3,words:0,sessionPrize:0}),await e.reply("✓ Kamu bermain Solo. Bot akan menjadi lawanmu!")),a.player.forEach(a=>{a.words=0,a.sessionPrize=0,a.chance=3}),a.current=a.player[0].id,a.index=0,a.status="play",a.basi=[],a.point=100*a.kata.length;var o=`⋄ Giliran: ${"BOT"===a.current?"🤖 AI Bot":"@"+a.current.split("@")[0]}
⋄ Kata : *${a.kata}*
⋄ Waktu: ${a.timer}s
⋄ Kesempatan: ${a.player[a.index].chance}

⋄ Carilah kata yang berawalan *${a.filter(a.kata)}*`;return a.chat=await n.reply(l,o.trim(),null,{mentions:[a.current],expiration:e.expiration}),void setNextTimeout(n,a,l,r,e);default:n.reply(l,`✗ Perintah tidak dikenal. Ketik *${e.prefix}sk help* untuk bantuan.`,e,{expiration:e.expiration})}}catch(a){console.error("✗ Error in sambungkata run command:",a),await n.reply(e.chat,"✗ Terjadi kesalahan: "+a.message,e,{expiration:e.expiration})}},main=async(a,e,{func:n})=>{var r=a.chat,t=global.skata[r];if(t&&"play"===t.status&&t.current===a.sender&&!a.isPrefix){var i=(a.budy||"").toLowerCase().trim();if(!i.includes(" ")){i=i.replace(/[^a-z]/g,"");if(i){var l=100*i.length,s=t.filter(t.kata);if(i.startsWith(s)){if(t.basi.includes(i))return s=`✗ *${i}* sudah pernah digunakan.
`,t.player[t.index].chance--,handleSalah(a,e,t,r,n,s,l);if(!await cekKata(i))return s=`✗ *${i}* tidak terdaftar di KBBI.
`,t.player[t.index].chance--,handleSalah(a,e,t,r,n,s,l);clearTimeout(t.timeout),global.db.users[t.current]=global.db.users[t.current]||{balance:0,game:{}},global.db.users[t.current].balance+=l,global.db.users[t.current].game.sambungkata=(global.db.users[t.current].game.sambungkata||0)+1,t.player[t.index].words+=1,t.player[t.index].sessionPrize+=l,t.basi.push(i),t.kata=i,t.index++,t.index>=t.player.length&&(t.index=0),t.current=t.player[t.index].id,t.player[t.index].chance=3;s=`✓ *Jawaban benar!* (+${n.formatNumber(l)} balance)`;"BOT"===t.current?await handleBotTurn(a,e,t,r,n,s):(s+=`

⋄ Giliran: ${"@"+t.current.split("@")[0]}
⋄ Kata: *${t.kata}*
⋄ Waktu: ${t.timer}s
⋄ Kesempatan: ${t.player[t.index].chance}

⋄ Carilah kata yang berawalan *${t.filter(t.kata)}*`,t.chat=await e.reply(r,s,null,{mentions:[t.current],expiration:a.expiration}),setNextTimeout(e,t,r,n,a))}}}}};async function handleBotTurn(r,t,i,l,s,a){a=a?a+`

🤖 Sedang memikirkan kata berawalan *${i.filter(i.kata)}*...`:`🤖 Sedang memikirkan kata berawalan *${i.filter(i.kata)}*...`;await t.reply(l,a,r),setTimeout(async()=>{if(global.skata[l]&&"play"===i.status){var a=await getKbbi();let e=i.filter(i.kata);var n,a=a.filter(a=>a.startsWith(e)&&!i.basi.includes(a)&&3<=a.length);0===a.length?await eliminatePlayer(r,t,i,l,s,`🤖 Bot menyerah! Tidak ada kata yang berawalan *${e}* di KBBI.`,0):(a=random(a),i.basi.push(a),i.kata=a,i.index++,i.index>=i.player.length&&(i.index=0),i.current=i.player[i.index].id,i.player[i.index].chance=3,a=`🤖 AI Bot menjawab: *${a}*

⋄ Giliran: ${"BOT"===i.current?"🤖 AI Bot":"@"+i.current.split("@")[0]}
⋄ Kata: *${i.kata}*
⋄ Waktu: ${i.timer}s
⋄ Kesempatan: ${i.player[i.index].chance}

⋄ Carilah kata yang berawalan *${i.filter(i.kata)}*`,n="BOT"!==i.current?[i.current]:[],i.chat=await t.reply(l,a,null,{mentions:n,expiration:r.expiration}),setNextTimeout(t,i,l,s,r))}},1500)}async function eliminatePlayer(e,n,r,t,i,l,s){var u=r.current,m=r.index,o=r.player[m];if("BOT"!==u&&(global.db.users[u]=global.db.users[u]||{balance:0},global.db.users[u].balance-=s),r.player.splice(m,1),r.timeout&&clearTimeout(r.timeout),1===r.player.length){m=r.player[0];let a="";("BOT"===u||"BOT"===m.id)&&(o="BOT"===m.id?o:m,a=`

🏆 *STATISTIK*
⋄ Kata terjawab: ${o.words||0} kata
⋄ Total perolehan: +${i.formatNumber(o.sessionPrize||0)} balance`);o="BOT"!==u?`
⋄ Denda: -${i.formatNumber(s)} balance`:"",o=l+o+`

`+("BOT"===m.id?"🤖 *AI Bot* memenangkan permainan!":`🎉 Selamat @${m.id.split("@")[0]} memenangkan permainan!`)+a,m=[u,m.id].filter(a=>"BOT"!==a);await n.reply(t,o,e,{mentions:m,expiration:e.expiration}),delete global.skata[t]}else{r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.player[r.index].chance=3;o=l+("BOT"!==u?`
⋄ Denda: -${i.formatNumber(s)} balance`:"")+`

⋄ *Permainan Berlanjut!*`;"BOT"===r.current?await handleBotTurn(e,n,r,t,i,o):(o+=`
⋄ Giliran: ${"@"+r.current.split("@")[0]}
⋄ Kata: *${r.kata}*
⋄ Waktu: ${r.timer}s
⋄ Kesempatan: ${r.player[r.index].chance}

⋄ Carilah kata yang berawalan *${r.filter(r.kata)}*`,m=[u,r.current].filter(a=>"BOT"!==a),r.chat=await n.reply(t,o,e,{mentions:m,expiration:e.expiration}),setNextTimeout(n,r,t,i,e))}}async function handleSalah(a,e,n,r,t,i,l){n.player[n.index].chance<=0?await eliminatePlayer(a,e,n,r,t,`✗ ${i.replace("✗ ","")}Kamu kehabisan kesempatan dan tereliminasi!`,l):await a.reply(i+("⋄ Sisa kesempatan: "+n.player[n.index].chance))}function setNextTimeout(n,r,t,i,l){r.timeout&&clearTimeout(r.timeout),r.timeout=setTimeout(()=>{var a=100*r.kata.length,e="BOT"===r.current?"🤖 Bot":"@"+r.current.split("@")[0];eliminatePlayer(l,n,r,t,i,`✗ Waktu habis, ${e} tereliminasi!`,a).catch(console.error)},1e3*r.timer)}export default{run:run,main:main,cmd:"sambungkata",alias:"sk",use:"options",type:"games",group:!0,location:"plugins/games/sambungkata.js"};export{run,main};