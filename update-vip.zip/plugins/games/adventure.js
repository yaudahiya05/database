import axios from"axios";let LulliAI=async a=>{try{var e=await axios.post("https://chateverywhere.app/api/chat/",{model:{id:"gpt-4",name:"GPT-4",maxLength:32e3,tokenLimit:8e3,completionTokenLimit:5e3,deploymentName:"gpt-4"},messages:[{pluginId:null,content:a,role:"user"}],prompt:`Kamu adalah converter plugin WhatsApp bot Baileys yang SANGAT PATUH dan TIDAK BOLEH MENYIMPANG dari struktur EXACT yang diminta.

TUGAS KAMU: Ubah kode plugin lama menjadi format BARU ini. Output HANYA kode JavaScript sesuai format di bawah. 
TIDAK ADA teks lain sama sekali, tidak ada \`\`\`js, tidak ada backtick, tidak ada "Berikut hasilnya", tidak ada penjelasan, tidak ada komentar di luar kode, tidak ada kata pengantar apa pun.

ADA DUA TIPE PLUGIN:

1. PLUGIN DENGAN COMMAND (paling umum) → pakai 'run'

Format WAJIB:
const run = async (m, lulli, { func }) => {
    // SELURUH LOGIKA PLUGIN DI SINI SAJA
};

export default {
    run,
    cmd: 'nama_utama',               // WAJIB: string jika 1 command, atau array ['cmd1', 'cmd2'] jika banyak
    alias: 'nama_lain',              // OPSIONAL: string atau array ['alias1', 'alias2'] — hanya jika ada alias
    type: 'games',                   // WAJIB: salah satu dari 21 kategori ini: admin, ai, anime, buyer, convert, developer, downloader, editor, event, fun, games, group, info, islamic, jadibot, maker, owner, searching, tools, topup, user
    location: 'plugins/games/adventure.js',   // WAJIB: format plugins/[kategori]/[nama-file].js — nama file pakai command utama atau deskripsi singkat
    // HANYA tambahkan field berikut JIKA bernilai TRUE:
    // premium: true,
    // limit: true,
    // group: true,
    // private: true,
    // admin: true,
    // botAdmin: true,
    // register: true,
    // owner: true,
    // developer: true
    // JANGAN pernah tambahkan field yang false! Jika false, HAPUS barisnya sama sekali.
};

2. PLUGIN EVENT (tanpa command, aktif otomatis setiap pesan) → pakai 'main'

Format WAJIB:
const main = async (m, lulli, { func, groups }) => {
    // logika otomatis, biasanya cek m.budy, anti-link, welcome, dll
};

export default {
    main,
    // HANYA field yang TRUE atau diperlukan:
    // group: true,
    // botAdmin: true,
    // dll (sama seperti di atas)
    location: 'plugins/event/antilink.js'   // WAJIB plugins/event/...
};

ATURAN MUTLAK (JIKA DILANGGAR = HASIL SALAH TOTAL):
- cmd WAJIB ADA dan tidak boleh kosong (minimal string atau array dengan 1 item)
- alias OPSIONAL, hanya muncul jika benar-benar ada nama lain
- type WAJIB salah satu dari 21 kategori yang disebutkan
- location SELALU dimulai dengan 'plugins/' + salah satu 21 kategori + '/' + nama-file.js
- HANYA field yang bernilai TRUE yang ditulis di export default. Jika false atau tidak relevan → HAPUS baris tersebut sepenuhnya.
- JANGAN tambahkan field lain di luar daftar di atas (misal desc, onlyPrem, dll — dilarang!)
- Gunakan helper serialize: m.download(), m.quoted.download(), m.reply(), m.mtype, m.mimetype, m.budy, m.text, m.args, m.prefix, m.command, m.isOwner, m.isDevs, m.isPc, m.isGc, m.isAdmin, dll.
- Jika plugin lama pakai client.sendMessage → ubah ke m.reply() atau lulli.reply() jika memungkinkan
- JANGAN import module baru kecuali benar-benar diperlukan dan sudah ada di bot (misal axios jika dipakai)
- Output KODE SAJA. Tidak ada apapun selain kode JavaScript lengkap.

Sekarang ubah kode plugin lama yang diberikan menjadi format persis di atas.
KELUARKAN HANYA KODE JAVASCRIPT. TIDAK ADA TEKS LAIN APA PUN DI LUAR KODE.`,temperature:.2,max_tokens:1500},{headers:{Accept:"/*/","User-Agent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"}});return e.data?.response||e.data?.text||e.data||""}catch(a){throw new Error(a.message)}},run=async(a,e,{})=>{let i;if(1<=a.args.length?i=a.args.join(" "):a.quoted&&a.quoted.text&&(i=a.quoted.text),!i)return a.reply(`kirim/reply kode plugin lain setelah command.
Contoh:
${a.cmd} const handler = async ... { ... }`);try{e.sendReact(a.chat,"🕒",a.key);var t=(await LulliAI(i)).replace(/^(Here is|Berikut|Ini|Result|Kode|Plugin|Converted|Output):?.*/im,"").replace(/^```(?:js|javascript)?\s*/im,"").replace(/```$/gm,"").replace(/`{1,3}/g,"").replace(/^\s*\/\/.*$/gm,"").replace(/^\s*[\w\s]+[:=].*$/im,"").trim();if(!t||!t.includes("export default"))return a.reply("AI gagal menghasilkan format yang benar. Coba paste ulang kode plugin lamanya.");await e.sendMessage(a.chat,{text:t},{quoted:a,ephemeralExpiration:a.expiration})}catch(e){console.error(e),await a.reply("Gagal konversi: "+e.message)}};export default{run:run,cmd:"cplugin",alias:"pluginai",type:"tools",premium:!0,location:"plugins/ai/pluginai.js"};