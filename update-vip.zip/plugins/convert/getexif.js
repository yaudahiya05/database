import webpmux from"node-webpmux";let run=async(e,t)=>{if(!e.quoted)return e.reply("✗ Reply stikernya!");if(!/sticker/.test(e.quoted.mtype))return e.reply("✗ Pesan yang di-reply bukan stiker.");try{var r=await e.quoted.download(),a=new webpmux.Image,i=(await a.load(r),JSON.parse(a.exif.toString("utf-8").slice(22))),s=`✦ *EXIF STICKER INFORMATION*

`,s=(s+=`- Sticker-pack-id: ${i["sticker-pack-id"]??"-"}
`)+`- Sticker-pack-name: ${i["sticker-pack-name"]??"-"}
`+`- Sticker-pack-publisher: ${i["sticker-pack-publisher"]??"-"}
`+"- Is-avatar-sticker: "+(0!==i["is-avatar-sticker"]?"Yes":"No");await e.reply(s)}catch(t){console.error("✗ Error getting EXIF data from sticker:",t),await e.reply("✗ Gagal membaca EXIF data stiker: "+t.message)}};export default{run:run,cmd:"getexif",alias:"getwm",use:"reply sticker",type:"convert",limit:!0,location:"plugins/convert/getexif.js"};export{run};