const moment = require('moment-timezone'),
    fetch = require('node-fetch');

const run = async (m, lulli, {
    func,
    setting
}) => {
    let blockList = await lulli.fetchBlocklist().catch((_) => []);
    let groupList = async () => Object.entries(await lulli.groupFetchAllParticipating()).slice(0).map(entry => entry[1])
    class Hit extends Array {
        total(key) {
            return this.reduce((a, b) => a + (b[key] || 0), 0)
        }
    }
    let sum = new Hit(...Object.values(global.db.statistic))
    const stats = {
        users: Object.keys(global.db.users).length,
        groups: await (await groupList()).map(v => v.id).length,
        banned: Object.values(global.db.users).filter(v => v.banned).length,
        premium: Object.values(global.db.users).filter(v => v.premium).length,
        blocked: blockList.length,
        hitstat: sum.total('hit') != 0 ? sum.total('hit') : 0,
        uptime: func.runtime(process.uptime())
    }
    const statistic = (stats) => {
        return `乂  *B O T S T A T*

◦  *${func.formatNumber(stats.groups)}* Groups Joined
◦  *${func.formatNumber(stats.users)}* Users In Database
◦  *${func.formatNumber(stats.banned)}* Users Banned
◦  *${func.formatNumber(stats.blocked)}* Users Blocked
◦  *${func.formatNumber(stats.premium)}* Premium Users
◦  *${func.formatNumber(stats.hitstat)}* Commands Hit
◦  Memory Used : *${func.fileSize(process.memoryUsage().rss)} / ${(process.env.SERVER_MEMORY != undefined && process.env.SERVER_MEMORY != 0) ? process.env.SERVER_MEMORY + ' MB' : '∞'}*
◦  Platform : *${process.platform + ' ' + process.arch}*
◦  Runtime : *${stats.uptime}*
◦  Hostname : *${process.env.HOSTNAME ?? '-'}*

乂  *S Y S T E M*

◦  *${statusIndicator(setting.online)}* Always Online
◦  *${statusIndicator(setting.autodownload)}* Auto Download
◦  *${statusIndicator(setting.autoblockcmd)}* Auto Blockcmd 
◦  *${statusIndicator(setting.antispam)}* Anti Spam
◦  *${statusIndicator(setting.anticall)}* Anti Call
◦  *${statusIndicator(setting.groupmode)}* Group Mode
◦  *${statusIndicator(setting.maintenance)}* Maintenance Mode
◦  *${statusIndicator(setting.self)}* Self Mode
◦  Prefix : *( ${m.prefix} )*
◦  Reset At : ${moment(setting.lastreset).format('DD/MM/YYYY HH:mm')}`
    }
    await m.reply(statistic(stats));
}

function statusIndicator(boolean) {
    return boolean ? '✅' : '❌'
}

module.exports = {
    run,
    cmd: 'botstat',
    type: 'info',
    location: 'plugins/info/botstat.js'
}