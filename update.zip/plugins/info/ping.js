const {
    performance
} = require('perf_hooks');
const os = require('os');

const run = async (m, lulli, {
    func
}) => {
    const old = performance.now();
    const ram = (os.totalmem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const free_ram = (os.freemem() / Math.pow(1024, 3)).toFixed(2) + " GB";
    const serverInfo = `Server Information

- ${os.cpus().length} CPU: ${os.cpus()[0]?.model ?? 'Tidak diketahui'}

- Uptime: ${Math.floor(os.uptime() / 86400)} days
- Ram: ${free_ram}/${ram}
- Speed: ${(performance.now() - old).toFixed(5)} ms`
    await m.reply(func.texted('monospace', serverInfo));
}

module.exports = {
    run,
    cmd: 'ping',
    type: 'info',
    location: 'plugins/info/ping.js'
}