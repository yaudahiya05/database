const moment = require('moment-timezone');

const run = async (m, lulli, {
    func,
    setting,
    lid
}) => {
    let set = global.db.groups[m.chat];
    let metadata = await (await lulli.groupMetadata(m.chat))
    lid.convertLidParticipants(metadata);
    let admin = metadata.participants.filter(v => v.admin)
    let pic = await func.fetchBuffer(await lulli.profilePictureUrl(m.chat, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b782c7b.png'))
    let caption = `乂  *G R O U P - I N F O*

	◦  *Name* : ${metadata.subject}
	◦  *ID* : ${metadata.id}
	◦  *Owner* : ${metadata.ownerPn ? '@' + metadata.ownerPn.split('@')[0] : metadata.owner ? '@' + metadata.owner.split('@')[0] : m.chat.match('-') ? '@' + m.chat.split('-')[0] : '-'}
	◦  *Addressing Mode :* ${metadata.addressingMode}
	◦  *Created :* ${moment(metadata.creation * 1000).format('DD/MM/YY HH:mm:ss')}
	◦  *Member :* ${metadata.participants.length}
	◦  *Admin :* ${admin.length}
	
乂  *G R O U P - S E T T I N G*

	◦  *${statusIndicator(set.welcome)}* Welcome Message
	◦  *${statusIndicator(set.goodbye)}* Goodbye Message
	◦  *${statusIndicator(set.detect)}* Detect Message
	◦  *${statusIndicator(set.antitoxic)}* Anti Toxic
	◦  *${statusIndicator(set.antilink)}* Anti Link
	◦  *${statusIndicator(set.antivirtex)}* Anti Virtex
	◦  *${statusIndicator(set.antibot)}* Anti Bot
	◦  *${statusIndicator(set.antiluar)}* Anti Luar
	◦  *${statusIndicator(set.antihidetag)}* Anti Hidetag
	◦  *${statusIndicator(set.antidelete)}* Anti Delete
	◦  *${statusIndicator(set.antiedited)}* Anti Edited
	◦  *${statusIndicator(set.antiporn)}* Anti Porn
	◦  *${statusIndicator(set.antihacked)}* Anti Hacked
	◦  *${statusIndicator(set.antigsm)}* Anti Group Status Mention
	◦  *${statusIndicator(set.autosholat)}* Auto Sholat/Adzan
	◦  *${statusIndicator(set.autokicksider)}* Auto Kick Sider

乂  *G R O U P - S T A T U S*

	◦  Muted : *${statusIndicator(set.mute)}*
	◦  Kirim pesan : *${metadata.announce ? 'Hanya admin' : 'Semua peserta'}*
	◦  Edit info grup : *${metadata.restrict ? 'Hanya admin' : 'Semua peserta'}*
	◦  Expired : *${set.sewa.expired == 0 ? '-' : func.timeReverse(set.sewa.expired)}*`
    lulli.sendMessageModify(m.chat, caption, m, {
        largeThumb: true,
        thumbnail: pic,
        expiration: m.expiration
    })
}

function statusIndicator(boolean) {
    return boolean ? '✅' : '❌'
}

module.exports = {
    run,
    cmd: 'groupinfo',
    alias: ['infogroup', 'gcinfo'],
    type: 'group',
    group: true,
    location: 'plugins/group/groupinfo.js'
}