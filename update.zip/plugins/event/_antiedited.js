let DATABASE={},main=async(t,i,{store:e,groups:s,lid:a,errorMessage:n})=>{try{if(s.antiedited&&t.msg&&14===t.msg.type){var d=t.msg.key;if(d){if(!DATABASE[d.id]){var r=await e.loadMessage(d.id);if(!r)return;console.log("EDIT",r),DATABASE[d.id]={jid:r.key.participant,from:r.message?.extendedTextMessage?.text||r?.message?.conversation||r?.message?.imageMessage?.caption,to:t.msg?.editedMessage?.extendedTextMessage?.text||t.msg?.editedMessage?.conversation||t.msg?.editedMessage?.imageMessage?.caption}}var g=DATABASE[d.id];if(g&&void 0!==g.from){var o=t.msg?.editedMessage?.extendedTextMessage?.text||t.msg?.editedMessage?.conversation||t.msg?.editedMessage?.imageMessage?.caption;let e=`乂  *E D I T E D - M E S S A G E*

`;a.isLidUser(g.jid)&&(g.jid=a.get(g.jid)||g.jid),e+=`@${g.jid.replace(/@.+/,"")} edited the message.

`;var m=g.from,l=o!==g.to?o:g.to,p=(e=e+`➠ *From* : ${m}
`+("➠ *To* : "+l),compareTexts(m,l));null!=p&&(e+=`

Kata yang diganti:
`+p.map(e=>"- "+e).join("\n")),DATABASE[d.id].from=o,await i.reply(t.chat,e,t,{expiration:86400})}}}}catch(e){return n(e)}};function compareTexts(e,t){e=e.trim(),t=t.trim();if(e.split(" ").length<3||t.split(" ").length<3)return null;if(e===t)return null;let i=e.split(" ");e=t.split(" ").filter(e=>e&&!i.includes(e)).map(e=>e);return 10<e.length?null:e}module.exports={main:main,group:!0,location:"plugins/event/_antiedited.js"};