import fs from 'fs/promises';
import chalk from 'chalk';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'url';

import YT from './lib/savetube.js';
import Cases from './lib/cases.js';
import spamDetector from './lib/spamdetector.js';
import autoRusuh from './lib/autorusuh.js';
import lid from './system/lid.js';
import func from './system/functions.js';
import socket from './system/socket.js';
import consoleHandler from './system/console.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const CASE = new Cases('./case.js');
const cooldowns = new Map();
const notifiedUsers = new Set();
const cachedSender = new Set();
const developer = '6285126904781@s.whatsapp.net';

const exceptPlugins = [
    'register', 'unregister', 'owner', 'rules', 'donate',
    'premium', 'sewabot', 'cekpanel', 'buypanel', 'renewalpanel', 'buyscript',
    'suit', 'tictactoe', 'werewolf',
    'topup', 'listharga', 'saldo', 'payment',
    'sticker', 'menu', 'menfes', 'script',
    'jadibot', 'listbot', 'stopbot', 'delsesibot'
].map(replaceJsExtension);

const exceptEvent = [
    '_antihidetag', '_antitoxic', '_antilink', '_antivirtex',
    '_antiedited', '_response', '_antilinkch'
].map(replaceJsExtension);

const exceptCommand = (command) => {
    return /^(sewa|sewabot|prem|buyprem|premium|vote|ww|werewolf|batu|gunting|kertas)$/i.test(command);
};

function replaceJsExtension(file) {
    return file.replace(/\.js$/, '') + '.js';
}

let lastMtime = 0;

async function getCaseHandler() {
    const caseFilePath = path.join(__dirname, 'case.js');
    const stats = await fs.stat(caseFilePath);
    if (stats.mtimeMs !== lastMtime) {
        lastMtime = stats.mtimeMs;
        return (await import(`${pathToFileURL(caseFilePath).href}?update=${Date.now()}`)).default;
    }
    return (await import(`${pathToFileURL(caseFilePath).href}?update=${lastMtime}`)).default;
}

const handler = async (lulli, extra) => {
    const {
        store,
        m,
        cfg,
        plugins,
        commands,
        events,
        database
    } = extra;
    const {
        setting,
        chat,
        sender,
        budy,
        prefix,
        command,
        allcommand,
        cmd,
        arg,
        args,
        text,
        mtype,
        reply,
        expiration,
        fromMe,
        isDevs,
        isOwner,
        isPrem,
        isVIP,
        isPrefix,
        isBot,
        isPc,
        isGc,
        isAdmin,
        isBotAdmin
    } = m;
    const Tnow = Math.floor(Date.now() / 1000);
    const Intervalmsg = 3600;

    if (Tnow - m.messageTimestamp > Intervalmsg) {
        return console.log(chalk.redBright.bold('✦ SPAM'), chalk.white(`Pesan lebih dari ${Intervalmsg} detik yang lalu diabaikan agar tidak nyepam`));
    }

    if (socket.cek(sender) && !lulli.user.jadibot) return;

    try {
        const users = global.db.users[sender];
        const groups = global.db.groups[chat];
        if (!users || (isGc && !groups)) return;

        consoleHandler(lulli, m, groups);
        if (groups?.banned) return;

        const { date, time } = func.getCurrentTimeInZone('Asia/Jakarta');
        const packname = (setting?.packname || 'create by lulli bot\n\ncreate at :\n+date\n+time\n\nsewa bot? chat:\n+62 895-4154-97664')
            .replace('+date', date).replace('+time', time).replace('+name', users.name);
        const author = (setting?.author || '').replace('+date', date).replace('+time', time).replace('+name', users.name);
        const isBanned = users.banned;

        if (setting.maintenance && !isDevs && !fromMe) return;

        if (isPc && users && setting.autoblock && !isOwner && !isDevs && !fromMe) {
            users.maxchats = (users.maxchats || 0) + 1;
            if (users.maxchats > 0) {
                users.blocked = true;
                return await lulli.updateBlockStatus(sender, 'block');
            }
        }
        
        if (setting.groupmode && isPc && !isOwner && !isDevs && !fromMe) return;

        if (setting.antispam && (isPc || (isGc && groups.antispam && isBotAdmin && !isAdmin)) && !/protocolMessage|reactionMessage|pollUpdateMessage|pollCreationMessage/.test(mtype) && !isPrem && !isOwner && !isDevs && !isBot && !fromMe && !isBanned) {
            const result = spamDetector.detectSpam(sender);

            if (result.status === 'warning') {
                if (cfg.mess.antispam) {
                    const warningMessage = cfg.mess.antispam
                        .replace('@sender', '@' + sender.split('@')[0])
                        .replace('@warning', result.warning)
                        .replace('@cooldown', cfg.spam.cooldown)
                        .replace('@maxwarning', cfg.spam.warning);
                    await reply(warningMessage);
                }
                return;
            }

            if (result.status === 'blocked') {
                if (cfg.mess.antispam2) {
                    const warningMessage = cfg.mess.antispam2
                        .replace('@sender', `@${sender.split('@')[0]}`);
                    await reply(warningMessage);
                }

                try {
                    await handleAction(cfg.spam.action, sender, chat, lulli, m);
                } catch (error) {
                    console.error("✗ Terjadi kesalahan saat memproses tindakan spam:", error.message);
                    await reply('✗ Terjadi kesalahan, tindakan spam gagal.');
                }
                return;
            }
        }
        
        if (isGc && Array.isArray(groups.blacklist) && groups.blacklist.includes(sender) && isBotAdmin && !isAdmin && !isPrem && !isOwner && !isDevs) {
            await lulli.sendMessage(chat, {
                delete: {
                    remoteJid: chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: sender
                }
            });
            await new Promise(resolve => setTimeout(resolve, 1000));
            return;
        }

        const multicommands = [...commands, ...CASE.list()];
        
        if (budy && multicommands.includes(allcommand) && !isBot && !fromMe) {
            const getPrefix = m.arg[0]?.charAt(0);
            const isAllPrefixes = getPrefix?.match(cfg.prefixes);
            if (!setting.self && isAllPrefixes && getPrefix !== prefix && !setting.multiprefix) {
                return await m.reply(`✦ Awalan salah!, bot ini menggunakan awalan : *[ ${prefix} ]*\n\n➠ ${prefix}${allcommand} ${text || ''}`.trim());
            }
        }
        
        if (command && multicommands.includes(command)) {
            if (!exceptCommand(command) && !/pollUpdateMessage|pollCreationMessage/.test(mtype) && !isDevs && !isOwner && !isPrem && !isBot) {
                if (cooldowns.has(command) && cooldowns.get(command) > Date.now()) {
                    const remainingTime = Math.ceil((cooldowns.get(command) - Date.now()) / 1000);
                    return await reply(cfg.mess.cooldown.replace('@detik', remainingTime));
                } else {
                    cooldowns.set(command, Date.now() + cfg.cooldown.command);
                }
            }
            const blocked = checkBlocked(command);
            if ((isPc || (isGc && !groups.mute)) && blocked.status && !setting.self && !/^(blockcmd|unblockcmd)/.test(command)) {
                return await reply(cfg.mess.block[blocked.system ? 'system' : 'owner']);
            }
        }
        
        const operations = {
            func,
            cfg,
            socket,
            plugins,
            commands,
            events,
            database,
            store,
            users,
            groups,
            setting,
            date,
            time,
            packname,
            author,
            isBot,
            isBanned,
            quoted: m.quoted || m,
            froms: m.quoted?.sender || (text ? isJid(text) : false),
            errorMessage,
            YT,
            CASE,
            lid
        };

        try {
            const caseHandler = await getCaseHandler();
            await caseHandler(m, lulli, operations);
        } catch (error) {
            console.error(chalk.red('✗ Error in case.js handler:'), error);
        }

        if (isBot) {
            const excludedBotIds = /^(MECHA|LULLI|SADAP)/.test(m.key.id);
            if (isGc && groups.antibot && isBotAdmin && !excludedBotIds && !isOwner && !isPrem && !isAdmin && !fromMe) {
                await reply('✦ BOT - DETECTED\n\nYou are detected by a bot, sorry I will kick you.')
                    .then(async () => {
                        await lulli.groupParticipantsUpdate(chat, [sender], 'remove');
                    });
            }
            if (!excludedBotIds) func.logAndWrite('bot', `${sender.replace(/@.+/, '')} detected is a bot: ${m.key.id}`);
            return;
        }

        for (const name in events) {
            const event = events[name];
            if (!event || !event.main) continue;

            const basename = path.basename(name);

            if (isPc && cfg.blocks.some(no => sender.startsWith(no))) return await lulli.updateBlockStatus(sender, 'block');
            if (isPc && isBot && !fromMe && !isPrem && !isOwner && !isDevs) return await lulli.updateBlockStatus(sender, 'block');

            if (!exceptEvent.includes(basename) && ((users && users.banned && !isPrem && !isOwner && !isDevs) || (groups && groups.mute && !isPrem && !isAdmin && !isOwner && !isDevs))) continue;
            
            if (event.devs && !isDevs) continue;
            if (event.owner && !isOwner) continue;
            if (event.group && !isGc) continue;
            if (event.limit && users.limit < 1) continue;
            if (event.botAdmin && !isBotAdmin) continue;
            if (event.admin && !isAdmin) continue;
            if (event.private && isGc) continue;

            await event.main(m, lulli, operations).catch(async (err) => {
                if (func.checkError(err)) return;
                console.error(chalk.red(`✗ EVENT ERROR] ${name}:`), err);
                await lulli.sendMessage(cfg.owner, {
                    text: '✦ SYSTEM-ERROR\n\n' + func.jsonFormat(err)
                }, {
                    quoted: m,
                    ephemeralExpiration: expiration
                });
            });
        }

        if (setting.autorusuh && !isPrefix) {
            await autoRusuh(lulli, m);
            return;
        }

        let matcher = func.matcher(command, multicommands).filter(v => v.accuracy >= 60);
        if (isPrefix && !multicommands.includes(command) && !/pollUpdateMessage|pollCreationMessage/.test(mtype) && !/(batu|gunting|kertas)/.test(command) && matcher.length > 0 && !setting.self) {
            if ((isPc || (isGc && !groups.mute)) && !users.banned) {
                return await lulli.sendMessage(chat, {
                    text: "Command not found, maybe you meant :" + "\n\n" + matcher.map(v => '✦ *' + prefix + v.string + '* (' + v.accuracy + '%)').join('\n')
                }, {
                    quoted: m,
                    ephemeralExpiration: expiration
                });
            }
        }
        
        if (command && commands.includes(command)) {
            const iscommands = Object.fromEntries(Object.entries(plugins).filter(([_, plugin]) => plugin.cmd));
            for (const name in iscommands) {
                const plugin = iscommands[name];
                if (!plugin || !plugin.cmd) continue;

                const basename = path.basename(name);
                const usage = Array.isArray(plugin.cmd) ? plugin.cmd.includes(command) : typeof plugin.cmd === 'string' ? plugin.cmd === command : false;
                const hidden = Array.isArray(plugin.alias) ? plugin.alias.includes(command) : typeof plugin.alias === 'string' ? plugin.alias === command : false;

                if (!usage && !hidden) continue;

                if (chat.endsWith('broadcast') || /pollUpdate/.test(m.mtype)) continue;

                if (isPc && cfg.blocks.some(no => sender.startsWith(no))) return await lulli.updateBlockStatus(sender, 'block');
                if (setting.self && !isOwner && !fromMe) return;
                if (isGc && groups.mute && !isAdmin && !isPrem && !isOwner && !/^(vote)$/i.test(command)) return;

                if (!/^(me|owner|rules|qris|payment)\.js$/i.test(basename) && users.banned && !isOwner) {
                    if (isPc || (isGc && !groups.mute)) {
                        const uniqueId = `banned-${chat}-${sender}`;
                        if (!notifiedUsers.has(uniqueId)) {
                            notifiedUsers.add(uniqueId);
                            setTimeout(() => notifiedUsers.delete(uniqueId), 5 * 60 * 1000);
                            let expire = users.expired.banned === 'PERMANENT' ? 'PERMANENT' : func.toTime(users.expired.banned - Date.now());
                            await reply(cfg.mess.banned2.replace('@expire', expire));
                        }
                        return;
                    }
                }

                if (setting.verify && !users.register && global.registered && typeof global.registered[sender] === 'undefined' && !exceptPlugins.includes(basename) && !isPrem && !isOwner && !isVIP) {
                    if (!global.registered[sender]) {
                        try {
                            let { key } = await lulli.reply(chat, `Registrasi dulu yuk! siapa namamu? *Kasih tau nama asli ya biar gak kena banned!* 😉`, m, {
                                expiration
                            });
                            global.registered[sender] = {
                                id: sender,
                                keyId: key,
                                sesi: 'name',
                                name: '-',
                                age: '-',
                                gender: '-',
                                timeout: setTimeout(() => {
                                    const { keyId } = global.registered[sender];
                                    keyId && lulli.sendMessage(chat, { delete: keyId });
                                    delete global.registered[sender];
                                }, 60 * 1000 * 3),
                            };
                        } catch (error) {
                            console.error(chalk.red("✗ Error during registration prompt:"), error);
                            let registerData = global.registered[sender];
                            if (registerData && registerData.timeout) clearTimeout(registerData.timeout);
                            delete global.registered[sender];
                            lulli.reply(chat, "✗ Something went wrong during registration: " + error.message + "\nPlease try again.", m, {
                                expiration
                            });
                        }
                    }
                    continue;
                }
                
                if (plugin.restrict && text && Array.isArray(setting.toxic) && new RegExp('\\b' + setting.toxic.join('\\b|\\b') + '\\b').test(text.toLowerCase()) && !isOwner && !isPrem) {
                    let menit = ((setting.timer / 1000) / 60);
                    await reply(cfg.mess.restrict.replace('@menit', menit));
                    users.banned = true;
                    users.expired.banned = Date.now() + setting.timer;
                    continue;
                }

                if (plugin.devs && !isDevs) { await reply(cfg.mess.devs); continue; }
                if (plugin.owner && !isOwner) { await reply(cfg.mess.owner); continue; }
                if (plugin.premium && !isOwner && !isPrem && !isVIP) { await reply(cfg.mess.premium); continue; }
                if (plugin.register && !users.register) { await reply(cfg.mess.notverified.replace('@command', prefix + 'register')); continue; }

                if (plugin.limit && !isPrem && !isVIP) {
                    const limitAmount = plugin.limit.constructor.name === 'Boolean' ? 1 : plugin.limit;
                    if (users.limit < limitAmount) {
                        return await reply(`Limit kamu kurang, soalnya fitur ini butuh ${limitAmount} limit. 😅`);
                    }
                    users.limit -= limitAmount;
                }

                if (plugin.group && !isGc) { await reply(cfg.mess.group); continue; }
                if (plugin.botAdmin && !isBotAdmin) { await reply(cfg.mess.botAdmin); continue; }
                if (plugin.admin && !isAdmin && !isOwner) { await reply(cfg.mess.admin); continue; }
                if (plugin.private && isGc) { await reply(cfg.mess.private); continue; }

                if (usage || hidden) {
                    func.addcommand(command);
                }

                await plugin.run(m, lulli, operations).catch(async (err) => {
                    if (func.checkError(err)) return;
                    console.error(chalk.red(`✗ PLUGIN ERROR] ${name}:`), err);
                    if (m.message) {
                        delete m.message.messageContextInfo;
                    }
                    let messageId = generateErrorMessageId();
                    await lulli.sendMessage(developer, {
                        text: "✦ SYSTEM ERROR\n\n" + func.jsonFormat(err)
                    }, {
                        quoted: m,
                        messageId,
                        ephemeralExpiration: expiration
                    });

                    if (!global.db.error.some(x => x.command === command)) {
                        global.db.error.push({
                            error: true,
                            chatId: chat,
                            command: command,
                            id: messageId,
                            msg: { key: m.key, message: m.message }
                        });
                    }
                    
                    if (setting.autoblockcmd) {
                        let blockcmd = global.db.blockcmd.find(v => v.command === command);
                        if (!blockcmd) {
                            global.db.blockcmd.push({ command, amount: 1, system: true, blocked: false });
                        } else {
                            blockcmd.amount++;
                            if (blockcmd.amount >= 5) {
                                blockcmd.blocked = true;
                                return await reply(`✗ Fitur tersebut telah di blockir oleh system karena terjadi error sebanyak ${blockcmd.amount}x`);
                            }
                        }
                    }
                    if (!global.suryadev.includes(chat)) {
                        await lulli.sendMessage(chat, {
                            text: isGc && isDevs ? err.message : '✗ Maaf! ada yang error :(\nLaporan error telah dikirim ke owner otomatis untuk diperbaiki.'
                        }, {
                            quoted: m,
                            ephemeralExpiration: expiration
                        });
                    }
                });
            }
        }
        
        async function errorMessage(error = '') {
            await lulli.sendMessage(cfg.owner, {
                text: func.texted('monospace', func.jsonFormat(error))
            }, {
                quoted: m,
                ephemeralExpiration: expiration
            });
        }
        async function kickParticipant(jid, targetChat = chat) {
            if (isGc && isBotAdmin) {
                await lulli.groupParticipantsUpdate(targetChat, [jid], 'remove');
            }
        }
        async function bannedAndBlockUser(jid) {
            if (global.db.users[jid]) {
                global.db.users[jid].banned = true;
                global.db.users[jid].expired.banned = 'PERMANENT';
                await lulli.updateBlockStatus(jid, 'block');
            }
        }
        async function handleAction(action, jid, targetChat, lulliClient, message) {
            if (/block/i.test(action)) {
                await bannedAndBlockUser(jid);
            } else if (/kick/i.test(action)) {
                await kickParticipant(jid, targetChat);
            } else if (/both/i.test(action)) {
                await kickParticipant(jid, targetChat);
                await bannedAndBlockUser(jid);
            } else {
                console.warn("✗ Tindakan spam tidak valid:", action);
            }
        }

    } catch (err) {
        console.error(chalk.red('✗ HANDLER GLOBAL ERROR]:'), err);
        if (func.checkError(err)) return;
        if (!fromMe) {
            await lulli.sendMessage(cfg.owner, {
                text: "✗ Something went wrong in handler's catch block:" + func.jsonFormat(err)
            }, {
                quoted: m,
                ephemeralExpiration: expiration
            });
        }
    }
};

function isJid(text = '') {
    const cleanedText = text.replace(/[^0-9]/g, '');
    if (!isNaN(cleanedText)) {
        const sender = lid.get(`${cleanedText}@lid`);
        if (sender) return sender;
    }
    return cleanedText.length > 0 && !isNaN(cleanedText) ? `${cleanedText}@s.whatsapp.net` : false;
}

function checkBlocked(command) {
    let blocked = global.db.blockcmd.find(v => v.command === command && v.blocked);
    if (blocked) {
        return { status: true, system: blocked.system };
    } else {
        return { status: false, system: false };
    }
}

function generateErrorMessageId() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return 'ERROR' + Array.from({
        length: 11
    }, () => characters.charAt(Math.floor(Math.random() * characters.length))).join('');
}

export default handler;