/*
 * Nama Pengembang: SuryaDev.
 * Kontak Whatsapp: wa.me/62895415497664
 * Kontak Telegram: t.me/yaudahiya05
 * Akun Instagram: surya_skylark05
 * Catatan: tolong laporkan kepada saya jika anda menemukan ada yang menjual script ini tanpa seizin saya.
 */

import { spawn } from 'child_process';
import fs from 'fs';
import chalk from 'chalk';
import path from 'path';
import assert from 'assert';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

process.on('unhandledRejection', (reason, promise) => {
    console.log('❌ Unhandled Rejection at:', promise, 'reason:', reason)
});
process.on('rejectionHandled', (reason, promise) => {
    console.log("❌ Rejection Handled at:", promise, 'reason:', reason)
});
process.on("uncaughtException", async (err) => {
    console.log('❌ Uncaught Exception at:', err)
});

function updateFileBaileys() {
    const dirPath = './node_modules/@whiskeysockets/baileys/lib/';
    const listPath = [
        { from: 'groups.js', to: 'Socket/groups.js' },
        { from: 'messages-send.js', to: 'Socket/messages-send.js' }
    ];

    for (const move of listPath) {
        const fileContent = fs.readFileSync(path.join('baileys', move.from), 'utf-8');
        fs.writeFileSync(path.join(dirPath, move.to), fileContent);
    }
}

function startApp() {
    updateFileBaileys();
    let args = [path.join(__dirname, 'main.js'), ...process.argv.slice(2)];
    let p = spawn(process.argv[0], args, {
        stdio: ['inherit', 'inherit', 'inherit', 'ipc']
    })
    .on('message', data => {
        if (data == 'reset') {
            console.log('Restarting...')
            p.kill()
        }
    })
    .on('exit', code => {
        console.error('Exited with code:', code)
        startApp()
    })
}

console.log(`[✔] Start App ...`);

// --- Node v20.x check ---
const [major] = process.versions.node.split(".").map(Number);

if (major < 20 || major >= 21) {
    console.error(`❌ Script ini hanya kompatibel dengan Node.js versi 20.x`);
    console.info(chalk.blue.bold("[INFO]"), "Jika kamu menjalankan script ini melalui panel, buka menu Startup, lalu ubah Docker Image ke versi Node.js 20");

    setTimeout(() => process.exit(1), 60_000);
} else {
    // Coloring
    const RESET = '\x1b[0m'
    const BRIGHT = '\x1b[1m'
    const DIM = '\x1b[2m'
    const RED = '\x1b[31m'
    const GREEN = '\x1b[32m'
    const BLUE = '\x1b[34m'

    let folders = ['lib', 'system'];
    let files = [];

    for (let folder of folders) {
        for (let file of fs.readdirSync(folder).filter(v => v.endsWith('.js'))) {
            files.push(path.resolve(path.join(folder, file)))
        }
    }

    for (let file of files) {
        if (file == path.join(__dirname, __filename)) continue

        console.error(`${BRIGHT}${BLUE}Checking${RESET} ${file}`) // Highlight "Checking" in blue
        spawn(process.argv[0], ['-c', file])
            .on('close', () => {
                assert.ok(file)
                console.log(`${BRIGHT}${GREEN}Done${RESET} ${file} ${BRIGHT}${Math.floor(Math.random() * 100)}%$${RESET}`)
            })
            .stderr.on('data', chunk => assert.ok(chunk.length < 1, `$${RED}${DIM}${file}` + "\n\n" + `${chunk}${RESET}`))
    }

    startApp();
}