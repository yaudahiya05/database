import fs from 'fs';
import chalk from 'chalk';
import util from 'util';
import path from 'path';
import crypto from 'crypto';
import moment from 'moment-timezone';
import phonenumber from 'awesome-phonenumber';
import * as baileys from '@whiskeysockets/baileys';
import toMs from 'ms';
import yts from 'yt-search';
import ytdl from 'ytdl-core';
import axios from 'axios';
import * as cheerio from 'cheerio';
import request from 'request';
import ms from 'parse-ms';
import fetch from 'node-fetch';
import { exec } from 'child_process';
import func from './system/functions.js';
import { fileURLToPath } from 'url';
import {
    createRequire
} from 'module';
const __filename = fileURLToPath(import.meta.url);
const require = createRequire(import.meta.url);

export default async (m, lulli, extra) => {
    const {
        chat,
        sender,
        body,
        budy,
        prefix,
        command,
        cmd,
        args,
        text,
        mtype,
        reply,
        expiration,
        isDevs,
        isOwner,
        isPrem,
        isVIP,
        isPrefix,
        isBot,
        isPc,
        isGc,
        isAdmin,
        isBotAdmin
    } = m;
    const {
        cfg,
        socket,
        plugins,
        commands,
        events,
        database,
        store,
        users,
        groups,
        setting,
        date,
        time,
        packname,
        author,
        isBaileys,
        isBanned,
        quoted,
        mime,
        froms,
        errorMessage,
        YT,
        CASE,
        lid
    } = extra;

    function get(jid) {
        if (jid.endsWith('@g.us')) {
            return global.db.groups[jid]
        } else {
            jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
            return global.db.users[jid]
        }
    }

    let target;
    if (froms) {
        target = global.db.users[froms];
    }

    // Memblokir command dari baileys
    if (isBaileys) return
    // Memblokir command yang sudah ada pada plugins
    if (command && commands.includes(command)) return
    // Feature Versi Case
    switch (command) {
        case 'sendmail': {
            if (!isDevs) return reply(cfg.mess.devs);
            const args = text.split('|');
            if (args.length < 3)
                return reply(`Format salah!\nGunakan: ${prefix + command} email|subject|pesan`);
            const [target, subject, message] = args.map(arg => arg.trim());
            reply('Mengirim email...');
            try {
                const data = JSON.stringify({
                    to: target,
                    subject,
                    message
                });

                const config = {
                    method: 'POST',
                    url: 'https://lemon-email.vercel.app/send-email',
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/134.0.0.0 Mobile Safari/537.36',
                        'Content-Type': 'application/json',
                        'sec-ch-ua-platform': '"Android"',
                        'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
                        'sec-ch-ua-mobile': '?1',
                        'origin': 'https://lemon-email.vercel.app',
                        'sec-fetch-site': 'same-origin',
                        'sec-fetch-mode': 'cors',
                        'sec-fetch-dest': 'empty',
                        'referer': 'https://lemon-email.vercel.app/',
                        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                        'priority': 'u=1, i'
                    },
                    data
                };
                axios.request(config)
                    .then(response => reply(`Hasil: ${JSON.stringify(response.data, null, 2)}`))
                    .catch(error => reply(`Error: ${error.message}`));
            } catch (error) {
                await reply(`Error: ${error.message}`);
            }
        }
        break
        case 'desah':
            await reply('ahh ahh ahh🥵')
            break;

        case 'sayang':
            reply('iya apa sayang?')
            break;
        case 'tes':
            lulli.sendMessageModify(chat, `Quick Test Done! ${m.pushname}`, m, {
                title: 'Aktif Selama :',
                body: func.runtime(process.uptime()),
                thumbUrl: setting.cover,
                largeThumb: false,
                url: null,
                expiration
            })
            break
        case 'join': {
            if (m.quoted || text) {
                try {
                    let url = m.quoted ? m.quoted.text : text;
                    if (url.includes('chat.whatsapp.com')) {
                        await lulli.groupAcceptInvite(url.split('https://chat.whatsapp.com/')[1])
                            .then(json => {
                                let string = String(json);
                                if (!string) {
                                    reply('Mohon untuk menerima bot agar dapat bergabung ke dalam grup.');
                                } else if (string.endsWith('@g.us')) {
                                    reply(string);
                                }
                            })
                    } else reply('Masukkan link grup dengan benar!')
                } catch (error) {
                    console.log('errorAcceptInvite:', error.message);
                    if (error.message.includes('already-exists')) {
                        return reply('Bot sudah pernah melakukan permintaan bergabung sebelumnya.');
                    }
                    return reply('Bot sudah terkick, tidak dapat join.')
                }
            } else reply(`Kirim perintah ${m.cmd} link grup\n_Contoh: ${m.cmd} https://chat.whatsapp.com/BgrnHVRRpRaJKHN7AxGYEa_`)
        }
        break
        case 'sange': {
            if (!m.isGc) return m.reply(cfg.mess.group);
            let target = m.members.map(x => x.id).random();
            await reply(`orang tersange di grup ini adalah @${target.replace(/@.+/, '')}`)
        }
        break
        default:
            // EVAL & EXEC CODE
            if (isDevs && /^(x|xx)$/.test(m.command)) {
                let evalCode;
                let evalCmd;
                if (m.command === 'x') evalCode = text ? text : false;
                else if (m.command === 'xx') evalCode = m.quoted && m.quoted.text ? m.quoted.text : text ? text : false
                if (!evalCode) return false;
                try {
                    evalCmd = /await/i.test(evalCode) ? eval("(async () => { " + evalCode + " })()") : eval(evalCode)
                    let evaled = await evalCmd;
                    if (typeof evaled !== 'string') evaled = util.inspect(evaled)
                    lulli.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (error) {
                    lulli.sendMessage(m.chat, {
                        text: error.message
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (isDevs && m.command === '=>' && text) {
                try {
                    let evaled = await eval(`(async () => { return ${text} })()`)
                    lulli.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (e) {
                    lulli.sendMessage(m.chat, {
                        text: util.format(e)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (isDevs && m.command === '$' && text) {
                lulli.sendReact(m.chat, '🕒', m.key)
                exec(text, (err, stdout) => {
                    if (err) return lulli.sendMessage(m.chat, {
                        text: err.toString()
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                    if (stdout) return lulli.sendMessage(m.chat, {
                        text: util.format(stdout)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                })
            }
    }
}

func.reloadFile(__filename);