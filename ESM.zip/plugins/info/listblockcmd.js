let run=async(n,l)=>{var a=global.db.blockcmd||[];if(0===a.length)return n.reply("✦ Empty data.");var o="✦ LIST - BLOCK - COMMANDS ✦\n\n",o=(o+=`Total: *${a.length}* commands blocked

`)+a.map(l=>"- "+n.prefix+l.command).join("\n");await n.reply(o)};export default{run:run,cmd:"listblockcmd",alias:"listblokcmd",type:"info",location:"plugins/info/listblockcmd.js"};