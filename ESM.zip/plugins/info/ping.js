import os from"node:os";import{performance}from"node:perf_hooks";let run=async(o,e,{func:t})=>{var r=performance.now(),n=(os.totalmem()/Math.pow(1024,3)).toFixed(2),p=(os.freemem()/Math.pow(1024,3)).toFixed(2),p=`✦ SERVER INFORMATION

✦ CPU: ${os.cpus().length} core(s) - ${os.cpus()[0]?.model??"Tidak diketahui"}
✦ Uptime: ${Math.floor(os.uptime()/86400)} hari
✦ RAM: ${p} GB / ${n} GB
✦ Speed: ${(performance.now()-r).toFixed(5)} ms`;await o.reply(t.texted("monospace",p))};export default{run:run,cmd:"ping",type:"info",location:"plugins/info/ping.js"};