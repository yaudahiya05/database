import moment from"moment-timezone";let run=async(t,e,{func:a,setting:s})=>{var r=await e.fetchBlocklist().catch(()=>[]);class o extends Array{total(a){return this.reduce((t,e)=>t+(e[a]||0),0)}}var n=new o(...Object.values(global.db.statistic||{})),e={users:Object.keys(global.db.users).length,groups:await(await Object.entries(await e.groupFetchAllParticipating()).slice(0).map(t=>t[1])).map(t=>t.id).length,banned:Object.values(global.db.users).filter(t=>t.banned).length,premium:Object.values(global.db.users).filter(t=>t.premium).length,blocked:r.length,hitstat:0!==n.total("hit")?n.total("hit"):0,uptime:a.runtime(process.uptime())};await t.reply(`✦ B O T S T A T ✦

✦ ${a.formatNumber((r=e).groups)} Groups Joined
✦ ${a.formatNumber(r.users)} Users In Database
✦ ${a.formatNumber(r.banned)} Users Banned
✦ ${a.formatNumber(r.blocked)} Users Blocked
✦ ${a.formatNumber(r.premium)} Premium Users
✦ ${a.formatNumber(r.hitstat)} Commands Hit
✦ Memory Used : ${a.fileSize(process.memoryUsage().rss)} / ${void 0!==process.env.SERVER_MEMORY&&0!==process.env.SERVER_MEMORY?process.env.SERVER_MEMORY+" MB":"∞"}
✦ Platform : ${process.platform+" "+process.arch}
✦ Runtime : ${r.uptime}
✦ Hostname : ${process.env.HOSTNAME??"-"}

✦ S Y S T E M

✦ ${statusIndicator(s.online)} Always Online
✦ ${statusIndicator(s.autodownload)} Auto Download
✦ ${statusIndicator(s.autoblockcmd)} Auto Blockcmd 
✦ ${statusIndicator(s.antispam)} Anti Spam
✦ ${statusIndicator(s.anticall)} Anti Call
✦ ${statusIndicator(s.groupmode)} Group Mode
✦ ${statusIndicator(s.maintenance)} Maintenance Mode
✦ ${statusIndicator(s.self)} Self Mode
✦ Prefix : ( ${t.prefix} )
✦ Reset At : `+moment(s.lastreset).format("DD/MM/YYYY HH:mm"))};function statusIndicator(t){return t?"✅":"❌"}export default{run:run,cmd:"botstat",type:"info",location:"plugins/info/botstat.js"};