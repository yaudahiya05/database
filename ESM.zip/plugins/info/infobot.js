import fs from"node:fs";import path from"node:path";import fetch from"node-fetch";let sensorNumber=e=>{var a,t=e.toString();return t.length<=6?e:(e=t.slice(0,3),a=t.slice(-3),""+e+"×".repeat(t.length-6)+a)},run=async(s,o,{func:n,setting:e,cfg:i})=>{let a="@whiskeysockets/baileys";fs.existsSync("./node_modules/baileys")?a="baileys":fs.existsSync("./node_modules/@adiwajshing/baileys")&&(a="@adiwajshing/baileys");let t,r;try{var l=await import(a+"/package.json",{assert:{type:"json"}}),c=(t=l.default.version,await import(process.cwd()+"/package.json",{assert:{type:"json"}}));r=c.default.version}catch(e){console.error("✗ Failed to load package.json versions:",e),t="Unknown",r="Unknown"}switch(s.command){case"infobot":case"botinfo":var m=`✦ BOT INFORMATION

- Creator: @62895415497664
- Creator Name: SuryaDev.
- Bot Name: Lulli Bot
- Library: @whiskeysockets/baileys^${t}
- Versions: lulli-bot v${r} (Beta)
- Memory Used: ${n.fileSize(process.memoryUsage().rss)} / ${void 0!==process.env.SERVER_MEMORY&&0!==process.env.SERVER_MEMORY?process.env.SERVER_MEMORY+" MB":"∞"}
- Hostname: ${process.env.HOSTNAME??"-"}
- Platform: ${process.platform+" "+process.arch}
- Mode: ${e.self?"Self":"Public"}
- Total User: ${Object.keys(global.db.users||{}).length} Users
- Total Group: ${Object.keys(global.db.groups||{}).length} Groups
- Deskripsi:

Lulli adalah Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence).
Sistem bot ini mampu berperan aktif sebagai asisten virtual yang membalas setiap pesan WhatsApp secara otomatis dalam hitungan detik.

Bot ini Dirancang dan Dikembangkan Oleh SuryaDev.`;await s.reply(m);break;case"script":case"sc":try{let{status:e,buyers:a}=await(await fetch("https://lulli-bot.vercel.app/buyer/list")).json(),t=`✦ SELL SCRIPT LULLI BOT V1

Lulli adalah Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence) dan serba otomatis yang dapat membantu anda mencari informasi atau mendownload sosial media, dan bisa juga bermain game dengan fitur-fitur keren yang sudah disediakan.

✦ Preview Features:
- Downloader (tiktok, instagram, facebook, snackvideo, twitter, capcut, youtube dll)
- AI & AI Image
- Remini
- Hdvideo
- Brat
- Quickchat
- Response Polling
- Button List
- Menfess (Confession)
- 40 Mini Games & RPG Games (coming soon)
- Advanced Menu Options
- And more...

✦ Special Features:
- Temporary Bot (Sistem bot ganda)
- Create Panel
- Menfess/Confession
- Payment Gateaway (via orkut)
- Custom Alarm System
- Cooldown Feature
- Auto Downloader
- Groupmode (chat bot autoblock)
- AI Image (hitamkan, hijabkan, tofigure)
- Automatic Adzan System
- Automatic Latest Anime
- Automatic Gempa
- Auto Donation
- Auto Anniversary
- Auto Kick Sider
- Werewolf (seperti wibusoft)
- Tictactoe vs bot
- And more...

✦ Requirements:
- NodeJS v20
- FFMPEG
- Min. 5GB RAM

✦ Benefit:
✓ Always Update (free)
✓ Fixing Feature (free)
✓ Request Feature
✓ Free Hosting (1 month)
✓ Join Group Update & Support Eksklusif
✓ Bebas Recode & Rename

Tunggu Apalagi? Gas Belii
Harga Cuma 300k/Rp 300.000
✦ WA: wa.me/62895415497664
✦ Tele: https://t.me/suryadev05
✦ Group bot: https://chat.whatsapp.com/BgrnHVRRpRaJKHN7AxGYEa
✦ Testi: https://whatsapp.com/channel/0029Vaq3DHa4tRrvXv8LA53c`;(e||a&&0<a.length)&&(t+="\n\n✦ Buyers List:\n",a&&0!==a.length?t+=a.map((e,a)=>`${a+1}. ${e.name}
- Number: ${sensorNumber(e.number)}
- Price: Rp${n.rupiah(e.price)},-
- Purchase date: `+e.date).join("\n\n"):t+=i.mess.empty),o.sendMessage(s.chat,{text:t,mentions:[s.sender]},{quoted:s,ephemeralExpiration:s.expiration})}catch(e){console.error(e),await s.reply("✗ Something went wrong while fetching script info.")}}};export default{run:run,cmd:["infobot","script"],alias:["botinfo","sc"],type:"info",location:"plugins/info/infobot.js"};