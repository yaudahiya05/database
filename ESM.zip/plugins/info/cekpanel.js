let run=async(e,a,{func:r,froms:t})=>{if(!(t=e.isDevs||e.isOwner?t:e.sender))return e.reply("✗ Mention or reply chat target.");var n=global.db.server[t];if(!n||!n.data||n.data.length<1)return e.reply("✦ Your server data not found or is empty.");n.lastcheck||(n.lastcheck=0);var l=Date.now(),o=n.lastcheck+864e5;if(l-n.lastcheck<864e5&&!e.isDevs)return e.reply(`✦ Kamu sudah cekpanel, mohon tunggu *${r.msToTime(o-l)}* untuk bisa cek lagi.`);n.lastcheck=l,r="✦ C H E C K - P A N E L ✦\n\n",r=(r+=`✦ Jid : @${t.replace(/@.+/,"")}
✦ Total Server : ${n.data.length}
✦ Server :
`)+n.data.map((e,a)=>`${a+1}. ${e.username}
- ID: ${e.id}
- RAM: ${e.ram}
- Expire: `+calculateExpireTime(e.expired)).join("\n\n"),await e.reply(r)};function calculateExpireTime(e){var a,r,t,n;return(e=e-Date.now())<=0?"Expired":(a=Math.floor(e/1e3%60),r=Math.floor(e/6e4%60),t=Math.floor(e/36e5%24),n=[],0<(e=Math.floor(e/864e5))&&n.push(e+"D"),0<t&&n.push(t+"H"),0<r&&n.push(r+"M"),(0<a||0===n.length)&&n.push(a+"S"),n.join(" "))}export default{run:run,cmd:"cekpanel",alias:"cekserver",type:"info",location:"plugins/info/cekpanel.js"};