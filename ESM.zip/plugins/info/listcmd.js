let run=async(t,e,{cfg:r})=>{var n=Object.entries(global.db.stickercmd||{});if(0===n.length)return t.reply(r.mess.empty);r=`✦ LIST - STICKER - CMD ✦
`,r+=n.map(([,t],e)=>`
${e+1}. ${t.text}
`+"- Creator: @"+t.creator.split("@")[0]).join("\n"),await t.reply(r)};export default{run:run,cmd:"listcmd",type:"info",location:"plugins/info/listcmd.js"};