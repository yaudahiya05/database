import fs from"node:fs";let run=async(e,t,{func:i})=>{var a=Object.values(global.db.users),n=fs.statSync("./database/database.json").size,n="function"==typeof n.sizeString?n.sizeString():i&&"function"==typeof i.fileSize?i.fileSize(n):(n/1048576).toFixed(2)+" MB";i=`✦ DATABASE STATISTICS ✦

✦ Basic Information :
- Total Users : ${a.length}
- Registered : ${a.filter(e=>e.register).length}
- Premium : ${a.filter(e=>e.premium).length}
- Banned : ${a.filter(e=>e.banned).length}
- Database Size : `+n,await e.reply(i)};export default{run:run,cmd:"cekdb",alias:"cekdatabase",type:"info",location:"plugins/info/cekdb.js"};