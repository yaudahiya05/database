import os from"node:os";let run=async(e,o,{func:r})=>{let t;try{t=await r.fetchJson("http://ip-api.com/json")}catch(e){console.error("✗ Failed to fetch server geoinfo:",e),t={}}delete t.status,delete t.query;let s=`✦ INFORMATION SERVER ✦

`;for(var a in s=(s+=`┌  ◦  OS: ${os.type()} (${os.arch()} / ${os.release()})
`)+`│  ◦  RAM: ${r.formatSize(process.memoryUsage().rss)} / ${r.formatSize(os.totalmem())}
`,t)Object.prototype.hasOwnProperty.call(t,a)&&null!=t[a]&&(s+=`│  ◦  ${r.ucword(a)}: ${t[a]}
`);s=(s+=`│  ◦  Uptime: ${r.toTime(1e3*os.uptime())}
`)+"└  ◦  Processor: "+("linux"===process.platform&&0<os.cpus().length?os.cpus()[0].model:"-"),await e.reply(s)};export default{run:run,cmd:"server",type:"info",location:"plugins/info/server.js"};