import os from"os";import{performance}from"node:perf_hooks";import{exec}from"node:child_process";let run=async(m,l)=>{let p=performance.now();l.sendReact(m.chat,"🕒",m.key);try{exec("neofetch --stdout",async(e,o,r)=>{let t=performance.now()-p,s="Not found (neofetch might not be installed)",n=(o?s=(s=o.toString("utf-8")).replace(/Memory:/g,"Ram:"):r?(console.error("Neofetch error:",r),s="Error running neofetch: "+r):e&&(console.error("Exec neofetch error:",e),s="Error executing neofetch: "+e.message),"N/A"),a="N/A",c="N/A",i="N/A";try{n=os.version(),a=os.platform(),c=os.hostname(),i=Math.round(os.totalmem()/1048576)}catch(e){console.error("Error getting OS details:",e),n=`Error (${e.message})`}o=(process.memoryUsage().heapUsed/1048576).toFixed(2),r=`✦ SYSTEM INFORMATION

`,r=(r=(r=(r=(r=(r+=`*CPU* : ${s.trim()}
`)+`*Speed* : ${t.toFixed(4)} MS
`)+`*Memory* : ${o}MB / ${i}MB
`)+`*OS* : ${n}
`)+`*Platform* : ${a}
`)+"*Hostname* : "+c,await m.reply(r),l.sendReact(m.chat,"",m.key)})}catch(e){console.error("Error in OS plugin:",e),await m.reply("✗ An error occurred while fetching system information: "+e.message),l.sendReact(m.chat,"❌",m.key)}};export default{run:run,cmd:"os",alias:["spec","systeminfo","sys"],use:"Displays bot system information and latency.",type:"info",desc:"Displays operating system details, memory usage, CPU, and bot response speed.",location:"plugins/info/os.js"};