let run=async(a,n)=>{var e=`Halo ${a.pushname}👋

Kamu bisa mendukung agar bot ini tetap aktif dengan
✦ Dana   : 0895415497664
✦ Ovo    : 0895415497664
✦ Gopay  : 0895415497664
✦ Pulsa  : 085700408187

Hasil donasi akan digunakan untuk membeli *Server Bot* agar bot dapat aktif 24 jam tanpa kendala.
Berapapun donasi kamu akan sangat berarti, Terimakasih!`;n.sendMessage(a.chat,{image:{url:"https://telegra.ph/file/918f03c67027e1fd7a3c1.jpg"},caption:e},{quoted:a,ephemeralExpiration:a.expiration})};export default{run:run,cmd:"donate",alias:"donasi",type:"info",location:"plugins/info/donate.js"};