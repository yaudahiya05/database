let run=async(t,e,{func:a,plugins:r})=>{var l=Object.entries(r).filter(([,t])=>t.run&&t.cmd);let n={},u=(l.forEach(([,t])=>{t.type&&(n[t.type]||(n[t.type]=[]),n[t.type].push(t))}),l=Object.keys(n).sort(),"✦ F E A T U R E - L I S T ✦\n");l.forEach(t=>{var e=n[t].flatMap(t=>Array.isArray(t.cmd)?t.cmd.map(t=>({cmd:t})):[{cmd:t.cmd}]);u+=`
- ${a.ucword(t)} : ${e.length} feature`}),u=(u+=`

✦ Total Plugins : ${Object.keys(r).length}*`)+`
✦ Total Feature : ${a.totalFeature(r)} Commands*`,await t.reply(u)};export default{run:run,cmd:"totalfitur",alias:"fitur",type:"info",location:"plugins/info/totalfitur.js"};