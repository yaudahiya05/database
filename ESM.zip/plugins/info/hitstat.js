let run=async(e,t)=>{var i=(s=Object.entries(global.db.statistic||{})).sort(([,t],[,i])=>(i.hit||0)-(t.hit||0));if(0===(s=s.map(([,t])=>t.hit||0).reduce((t,i)=>t+i,0)))return e.reply("✦ No command used.");a=`✦ H I T - S T A T ✦

`+`✦ Total command hit statistics are currently ${s} Hits.
`+`
`;var a,s=Math.min(10,i.length);a+=i.slice(0,s).map(([t,i],a)=>`✦ ${a+1}. *Command* :  ${e.prefix}${t}
`+`    *Hit* : ${i.hit||0}
`+"    *Last Hit* : "+(i.lastused?(Date.now()-i.lastused).timers():"N/A")).join("\n"),await e.reply(a)};export default{run:run,cmd:"hitstat",type:"info",location:"plugins/info/hitstat.js"};