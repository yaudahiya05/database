let run=async(e,r,{func:o})=>{var s=void 0!==process.env.SERVER_MEMORY&&"0"!==process.env.SERVER_MEMORY?process.env.SERVER_MEMORY+" MB":"∞",o=`✦ Memory Information

`+`- Ram Used Bot: ${o.fileSize(process.memoryUsage().rss)}
`+"- Max Ram Server: "+s;await e.reply(o)};export default{run:run,cmd:"memory",alias:"ram",type:"info",location:"plugins/info/memory.js"};