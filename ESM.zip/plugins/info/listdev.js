let run=async(e,l,{cfg:t})=>{var i=t.devs||[];if(0===i.length)return e.reply(t.mess.empty);t=`✦ *LIST - DEVELOPER*

`;t+=i.map((e,l)=>l+1+". @"+e.split("@")[0]).join("\n"),await e.reply(t)};export default{run:run,cmd:"listdev",alias:"listdeveloper",type:"info",location:"plugins/info/listdev.js"};