let run=async(o,t,{func:e})=>{var a=Object.entries(global.db.statistic||{}),i=a.map(([,t])=>t.hittoday||0).reduce((t,a)=>t+a,0);if(0===i)return o.reply("✦ No command used today.");i=`✦ H I T - D A I L Y ✦

`+`✦ Total command hit statistics for today ${i} Hits.
`+`
`+a.sort(([,t],[,a])=>(a.hittoday||0)-(t.hittoday||0)).slice(0,10).map(([t,a],i)=>`✦ ${i+1}. *Command* : ${o.prefix}${t}
`+`    *Hit* : ${e.formatNumber(a.hittoday||0)}
`+"    *Last Hit* : "+(a.lastused?e.timers(Date.now()-a.lastused):"N/A")).join("\n");await o.reply(i)};export default{run:run,cmd:"hitdaily",type:"info",location:"plugins/info/hitdaily.js"};