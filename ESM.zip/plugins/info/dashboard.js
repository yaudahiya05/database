import fs from"node:fs";import path from"node:path";let run=async(e,s,{cfg:r,func:a})=>{let t="./session",o=(s.user?.jadibot?(s=global.db.jadibot?.find(s=>s.number===e.bot))?.session&&(t=s.session):r.baileys?.session&&(t=r.baileys.session),fs.existsSync(t)||(console.warn("✗ Session directory not found: "+t),t="./session"),[]),i=0;if(fs.existsSync(t))try{for(var n of o=fs.readdirSync(t))try{var c=path.join(t,n);i+=fs.statSync(c).size}catch(s){console.error(`✗ Error reading file stat for ${n} in sessionsDir:`,s.message)}}catch(s){console.error(`✗ Error reading session directory ${t}:`,s.message)}let l=0;if(fs.existsSync(s="./database/database.json"))try{l=fs.statSync(s).size}catch(s){console.error("✗ Error reading database file stat:",s.message)}r=Object.entries(global.db.statistic||{}).sort((s,e)=>(e[1]?.hit||0)-(s[1]?.hit||0));let d=0;if(fs.existsSync(s="./sampah"))try{d=fs.readdirSync(s).filter(e=>["gif","png","mp3","m4a","opus","mp4","jpg","jpeg","webp","webm"].some(s=>e.endsWith(s))).length}catch(s){console.error("✗ Error reading sampah directory: "+s.message)}s=`✦ DASHBOARD ✦

✦ PERFORMANCE & USAGE
- Runtime: ${a.clockString(1e3*process.uptime())}
- System OS: ${process.platform+" "+process.arch}
- Node.js Version: ${process.version}
- RAM Used: ${process.memoryUsage().rss.sizeString()}
- Max Server RAM: ${process.env.SERVER_MEMORY?process.env.SERVER_MEMORY+" MB":"∞ (Unlimited)"}
- Time Server: ${process.env.TZ||"-"}
- Server Location: ${process.env.P_SERVER_LOCATION||"-"}

✦ STORAGE & DATA
- Total Session: ${o.length} Files
- Size Session: ${i.sizeString()}
- Size Database: ${l.sizeString()}
- Total Sampah: ${d} Files
- Database User: ${Object.keys(global.db.users).length} Users
 
✦ COMMAND STATISTICS
- Total Commands Hit: ${Object.values(global.db.statistic||{}).map(s=>s.hit||0).reduce((s,e)=>s+e,0)}
- Top 10 Commands:
${r.slice(0,10).map(([s,e],r)=>`  ${r+1}. - *${s}* (Hit: ${a.formatNumber(e.hit||0)} | Last: ${e.lastused?(Date.now()-e.lastused).timers().replace(" detik","s").replace(" menit","m").replace(" jam","h").replace(" hari","d"):"N/A"})`).join("\n")}

✦ END REPORT ✦`,await e.reply(s)};export default{run:run,cmd:"dashboard",alias:"dash",type:"info",location:"plugins/info/dashboard.js"};