let run=async(t,n,{cfg:i,setting:e})=>{if(0===e.toxic.length)return t.reply(i.mess.empty);i=`✦ LIST BAD WORD

Total : ${e.toxic.length}
`,i+=e.toxic.map((t,n)=>n+1+". "+t).join("\n"),await t.reply(i)};export default{run:run,cmd:"listbadword",type:"info",location:"plugins/info/listbadword.js"};