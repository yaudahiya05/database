let run=async(e,s,{func:a,cfg:i})=>{var t=Object.values(global.db.groups||{}).filter(e=>e.sewa?.status);if(0===t.length)return e.reply(i.mess.empty);i="✦ L I S T - S E W A ✦\n",i+=t.map((e,s)=>`
${s+1}. ${e.name}
`+`- ID: ${e.jid}
`+`- VIP: ${e.sewa?.vip?"✓":"✗"}
`+"- Expire: "+(/PERMANENT/.test(e.sewa?.expired)?"PERMANENT":a.expireTime(e.sewa?.expired))).join("\n"),await e.reply(i)};export default{run:run,cmd:"listsewa",type:"info",location:"plugins/info/listsewa.js"};