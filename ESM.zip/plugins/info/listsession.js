import fs from"node:fs";import path from"node:path";function formatSizeUnits(t){return 1073741824<=t?t=(t/1073741824).toFixed(2)+" GB":1048576<=t?t=(t/1048576).toFixed(2)+" MB":1024<=t?t=(t/1024).toFixed(2)+" KB":1<t?t+=" bytes":1===t?t+=" byte":t="0 bytes",t}function formatDate(t){return t.toLocaleString("en-GB",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit"})}let run=async(t,i,{cfg:e})=>{let n=e.baileys.session;if(!fs.existsSync(n))return t.reply(`✗ Direktori sesi '${n}' tidak ditemukan.`);e=fs.readdirSync(n);let a="",f=0;e.sort((t,i)=>{try{var e=fs.statSync(path.join(n,t)).size;return fs.statSync(path.join(n,i)).size-e}catch(t){return console.error("✗ Error getting size for comparison: "+t),0}}),e.forEach((t,i)=>{var e=path.join(n,t);try{var r=fs.statSync(e),s=r.size,o=formatDate(r.mtime);f+=s,a+=`✦ ${i+1}. ${t}
`+`   - Size        : ${formatSizeUnits(s)}
`+`   - Last Modified: ${o}
`}catch(e){console.error(`✗ Error processing file ${t}:`,e),a+=`✦ ${i+1}. ${t} (Error reading file)
`}}),e=`✦ SESSION LIST ✦

`+`✦ Total Sessions : ${e.length} files
`+`✦ Total Size     : ${formatSizeUnits(f)}

`+a+`
`+"✦ END REPORT ✦",i.reply(t.chat,e.slice(0,65536),t,{expiration:t.expiration})};export default{run:run,cmd:"listsession",alias:"listsesi",type:"info",location:"plugins/info/listsession.js"};