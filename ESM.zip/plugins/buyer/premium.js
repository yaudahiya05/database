import crypto from 'node:crypto';
import moment from 'moment-timezone';
import toMs from 'ms';
import { proto, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import * as paymentModule from '../../lib/payment.js';

let timeoutData = {};

const createTimeout = async (m, lulli, buyerData, minute = 3) => {
    if (timeoutData[m.sender]) clearTimeout(timeoutData[m.sender]);
    timeoutData[m.sender] = setTimeout(async () => {
        if (buyerData.keyId) {
            try {
                await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            } catch (e) { console.error("✗ Error deleting old keyId message:", e.message); }
            
            await lulli.sendMessage(m.chat, {
                text: '✗ Sesi pembelian premium Anda telah kadaluarsa.'
            }, {
                quoted: buyerData.quoted,
                ephemeralExpiration: m.expiration
            });
        }
        paymentModule.deleteSession(buyerData.number, global.db.premium);
        delete timeoutData[m.sender];
    }, 1000 * 60 * minute);
};

const run = async (m, lulli, { func, cfg }) => {
    global.db.premium = global.db.premium || {};

    if (global.db.premium[m.sender]) {
        const buyerData = global.db.premium[m.sender];
        await lulli.sendbut(m.chat, 'Proses pembelian premium kamu sebelumnya masih ada yang berjalan', 'ingin membatalkan pembelian premium sebelumnya?', [['Batalkan', 'batalkan']], m, {
            caption: '\nKetik *Batal* untuk membatalkan sesi sebelumnya.',
            expiration: m.expiration
        });
        return;
    }

    let keyId = null;
    let caption = '';
    
    if (cfg.baileys.button) {
        let title = '✦ PRICE LIST PREMIUM USER';
        let footer = 'silahkan pilih paket premium dibawah';
        
        caption = cfg.packagePremium.map(data => `*PAKET ${data.id.toUpperCase()}*\n- Rp${func.toRupiah(data.price)} / ${data.duration + (data.normal_price ? '\nHarga normal *~Rp' + func.toRupiah(data.normal_price) + '~*' : '')}`).join('\n\n');
        
        let sections = cfg.packagePremium.map((data, index) => ({
            title: `PAKET ${data.name.toUpperCase()}`,
            highlight_label: data.duration.includes('30 day') ? 'Populer Premium' : '',
            rows: [{
                header: `Paket ${data.name}`,
                title: `Rp. ${func.toRupiah(data.price)}`,
                description: `Duration ${data.duration}`,
                id: String(index + 1)
            }]
        }));
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: footer }),
                        header: proto.Message.InteractiveMessage.Header.create({ title: title, subtitle: '', hasMediaAttachment: false }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: 'Click Here ⎙', sections }) }]
                        }),
                        contextInfo: { mentionedJid: [m.sender], forwardingScore: 100, isForwarded: false }
                    })
                }
            }
        }, { quoted: m });
        await lulli.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
        keyId = msg.key;

    } else {
        caption = '✦ PRICE LIST PREMIUM USER\n\n';
        caption += cfg.packagePremium.map((data, index) => {
            return `${index + 1}. ${data.name.toUpperCase()}\n- Duration: ${data.duration}\n- Price: Rp${func.toRupiah(data.price) + (data.normal_price ? ' _*~Rp' + func.toRupiah(data.normal_price) + '~*_' : '')}`;
        }).join('\n\n');
        caption += `\n\nBenefits:\n- unlimited limit\n- unlock premium features\n- can use bot privately\n- can increase balance faster\n\nNotes:\n- Ketik ID premium yang sudah tersedia di atas untuk melanjutkan pembelian premium.\n\n_(Contoh, ketik: *1* untuk memilih opsi *PREMIUM 1*_)`;
        
        let { key } = await lulli.sendMessage(m.chat, { text: caption.trim() }, { quoted: m, ephemeralExpiration: m.expiration });
        keyId = key;
    }

    global.db.premium[m.sender] = {
        id: crypto.randomBytes(5).toString('hex').toUpperCase(),
        number: m.sender,
        name: m.pushname,
        session: 'select_package',
        date: moment().tz('Asia/Jakarta').format('DD MMMM YYYY'),
        payment: null,
        data: null,
        quoted: { key: m.key, message: m.message },
        keyId: keyId
    };
    await createTimeout(m, lulli, global.db.premium[m.sender], 3);
};

const main = async (m, lulli, { func, cfg, quoted, store }) => {
    global.db.premium = global.db.premium || {};

    const buyerData = global.db.premium[m.sender];
    if (!buyerData) return;

    if (timeoutData[m.sender]) clearTimeout(timeoutData[m.sender]);
    
    const userResponse = m.budy.trim();
    const index = parseFloat(userResponse);

    if (/^(batal|batalkan)$/i.test(userResponse)) {
        if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
        await m.reply(`✓ Baik kak, pembelian premium dengan ID : ${buyerData.id} sudah dibatalkan.`);
        paymentModule.deleteSession(buyerData.number, global.db.premium);
        delete timeoutData[m.sender];
        return;
    }

    switch (buyerData.session) {
        case 'select_package': {
            if (isNaN(index) || index < 1 || index > cfg.packagePremium.length) {
                await m.reply('✗ Masukkan nomor paket premium yang valid.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }
            buyerData.data = cfg.packagePremium[index - 1];
            
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            
            let caption = '✦ METODE PEMBAYARAN\n';
            cfg.paymentMethods.forEach((item, idx) => {
                caption += `\n\n⋄ ${idx + 1}. ${item.name} (${item.name === 'QRIS' ? 'otomatis' : 'manual'})`;
                if (item.desc) caption += '\n' + item.desc;
            });

            const buttons = cfg.paymentMethods.map((item, idx) => ([item.name, String(idx + 1)]));
            let { key } = await lulli.sendbut(m.chat, caption, 'click the button below to select payment method', buttons, m, {
                caption: '\n\nKetik angka (1-...) untuk memilih metode pembayaran..',
                mentions: [m.sender],
                expiration: m.expiration
            });
            buyerData.keyId = key;
            buyerData.session = 'payment_method';
            await createTimeout(m, lulli, buyerData, 5);
            break;
        }

        case 'payment_method': {
            if (isNaN(index) || index < 1 || index > cfg.paymentMethods.length) {
                await m.reply('✗ Masukkan nomor metode pembayaran yang valid.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }
            buyerData.payment = cfg.paymentMethods[index - 1];
            
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            
            let caption = `⋄ KONFIRMASI PREMIUM\n\n` +
                          `⋄ ID : ${buyerData.id}\n` +
                          `⋄ Nomor : @${buyerData.number.split('@')[0]}\n` +
                          `⋄ Tanggal : ${buyerData.date}\n` +
                          `⋄ Nama Paket : ${buyerData.data.name}\n` +
                          `⋄ Durasi : ${buyerData.data.duration}\n` +
                          `⋄ Pembayaran Via : ${buyerData.payment.name}\n` +
                          `⋄ Harga : Rp${func.toRupiah(buyerData.data.price)},-\n\n` +
                          `⋄ Informasi:\n` +
                          `- Melakukan pembelian artinya Anda setuju dengan segala kebijakan kami.\n` +
                          `- Transfer sesuai nominal & wajib sertakan bukti transfer.\n` +
                          `- Semua pembelian bergaransi.`;
            
            const buttons = [['Lanjut', 'lanjut'], ['Batal', 'batal']];
            let { key } = await lulli.sendbut(m.chat, caption, 'please select the button below', buttons, m, {
                caption: '\n\nKetik *Lanjut* atau *Batal* untuk melanjutkan atau membatalkan pembelian._',
                mentions: [m.sender],
                expiration: m.expiration
            });
            buyerData.keyId = key;
            buyerData.session = 'premium_confirmation';
            await createTimeout(m, lulli, buyerData, 5);
            break;
        }

        case 'premium_confirmation': {
            if (/^(lanjut|lanjutkan)$/i.test(userResponse)) {
                await createTimeout(m, lulli, buyerData, 10);
                if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });

                const topupAmount = buyerData.data.price;
                const paymentMethod = buyerData.payment;
                
                if (/QRIS/i.test(paymentMethod.name)) {
                    const qrisCaption = cfg.mess.payment.qris
                        .replace(/@an/g, paymentMethod.an)
                        .replace(/@username/g, paymentMethod.username)
                        .replace(/@price/g, `Rp${func.toRupiah(topupAmount)},-`);
                    
                    if (paymentModule && paymentModule.generateQRIS && paymentModule.createQR) {
                        let qrCodeData = paymentModule.generateQRIS(String(topupAmount));
                        let imageBuffer = await paymentModule.createQR(qrCodeData);
                        let { key } = await lulli.sendMessage(m.chat, { image: imageBuffer, caption: qrisCaption }, { quoted: m, ephemeralExpiration: m.expiration });
                        buyerData.keyId = key;
                    } else {
                        throw new Error('✗ Payment module function for QRIS not found.');
                    }
                    if (paymentModule && paymentModule.addPaymentSession) {
                        paymentModule.addPaymentSession(buyerData.number, topupAmount, async () => {
                            await lulli.reply(m.chat, `✓ Pembelian premium kamu telah dikonfirmasi otomatis oleh sistem.`, m);
                            paymentModule.deleteSession(buyerData.number, global.db.premium);
                        }, global.db.premium, lulli, m.expiration);
                    } else {
                        throw new Error('✗ Payment module function addPaymentSession not found.');
                    }
                } 
                else {
                    const ewalletCaption = cfg.mess.payment.ewallet
                        .replace(/@ewallet/g, paymentMethod.name.toUpperCase())
                        .replace(/@nomor/g, paymentMethod.src)
                        .replace(/@an/g, paymentMethod.an)
                        .replace(/@price/g, `Rp${func.toRupiah(buyerData.data.price)},-`);
                    
                    let { key } = await lulli.sendMessage(m.chat, { text: ewalletCaption }, { quoted: m, ephemeralExpiration: m.expiration });
                    buyerData.keyId = key;
                    await m.reply('Silakan transfer ke nomor di atas, lalu kirim bukti transfer dengan *BUKTI* atau reply gambar dengan caption *BUKTI*.');
                    await createTimeout(m, lulli, buyerData, 10);
                }
            } else if (/^(batal|batalkan)$/i.test(userResponse)) {
                if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
                await m.reply(`✓ Pembelian premium dengan ID: ${buyerData.id} telah dibatalkan.`);
                paymentModule.deleteSession(buyerData.number, global.db.premium);
                delete timeoutData[m.sender];
            } else {
                await m.reply('✗ Respon tidak valid. Ketik *Lanjut* atau *Batal*.');
                await createTimeout(m, lulli, buyerData, 1);
            }
            break;
        }

        case 'bukti_pembayaran': {
            if (/^(bukti|\.bukti)$/i.test(userResponse)) {
                if (!quoted || !/image\/(jpe?g|png)/.test(quoted.mimetype)) {
                    await m.reply(`✗ Kirim gambar dengan caption *BUKTI* atau reply gambar yang sudah dikirim dengan caption *BUKTI*`);
                    await createTimeout(m, lulli, buyerData, 1);
                    return;
                }
                
                clearTimeout(timeoutData[m.sender]);
                delete timeoutData[m.sender];

                let media = await quoted.download();
                
                let caption = `⋄ BUKTI PEMBELIAN PREMIUM\n\n` +
                              `⋄ ID : ${buyerData.id}\n` +
                              `⋄ Nomor : @${buyerData.number.split('@')[0]}\n` +
                              `⋄ Tanggal : ${buyerData.date}\n` +
                              `⋄ Nama Paket : ${buyerData.data.name}\n` +
                              `⋄ Durasi : ${buyerData.data.duration}\n` +
                              `⋄ Harga : Rp${func.toRupiah(buyerData.data.price)},-\n\n` +
                              `Ada yang transfer nih kak, coba dicek saldonya`;
                
                const buttons = [
                    ['accept', `${m.prefix}accprem ${buyerData.number.split('@')[0]}`],
                    ['reject', `${m.prefix}rejectprem ${buyerData.number.split('@')[0]}`]
                ];
                
                await lulli.sendbut(cfg.owner, caption, 'click the button bellow to accept or reject premium', buttons, null, {
                    media: media,
                    caption: `\n\n_Jika sudah masuk kirim \`${m.prefix}accprem ${buyerData.number.split('@')[0]}\`_\n_Jika belum masuk kirim \`${m.prefix}rejectprem ${buyerData.number.split('@')[0]}\`_`,
                    mentions: [m.sender],
                    expiration: m.expiration
                });
                
                await m.reply('✓ Mohon tunggu, owner akan memeriksa bukti transfer 🙏🏻');
                paymentModule.deleteSession(buyerData.number, global.db.premium);

            } else {
                await m.reply('✗ Respon tidak valid. Harap kirim bukti pembayaran dengan caption *BUKTI*.');
                await createTimeout(m, lulli, buyerData, 1);
            }
            break;
        }
    }
    if (buyerData) {
        await createTimeout(m, lulli, buyerData, 3);
    }
};


export default {
    run,
    main,
    cmd: 'buyprem',
    alias: ['premium', 'prem'],
    type: 'buyer',
    location: 'plugins/buyer/premium.js'
};
