import crypto from 'node:crypto';
import moment from 'moment-timezone';
import toMs from 'ms';
import axios from 'axios';
import fetch from 'node-fetch';
import { proto, generateWAMessageFromContent } from "@whiskeysockets/baileys";

import * as paymentModule from '../../lib/payment.js';
import * as groupfetchModule from '../../system/groupfetch.js';

let timeoutData = {};
const DELAY_BETWEEN_ACTIONS_MS = 1000 * 15;

const createTimeout = async (m, lulli, buyerData, minute = 3) => {
    if (timeoutData[m.sender]) clearTimeout(timeoutData[m.sender]);
    timeoutData[m.sender] = setTimeout(async () => {
        if (buyerData.keyId) {
            try {
                await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            } catch (e) { console.error("✗ Error deleting old keyId message:", e.message); }
            
            await lulli.sendMessage(m.chat, {
                text: '✗ Sesi penyewaan bot Anda telah kadaluarsa.'
            }, {
                quoted: buyerData.quoted,
                ephemeralExpiration: m.expiration
            });
        }
        paymentModule.deleteSession(buyerData.number, global.db.sewabot);
        delete timeoutData[m.sender];
    }, 1000 * 60 * minute);
};

async function getGroupIdWithGroupLink(lulli, url) {
    try {
        const regex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;
        const [_, code] = url.match(regex) || [];
        if (!code) return { status: false, message: '✗ No invite url detected.' };

        const response = await lulli.query({
            tag: 'iq', attrs: { type: 'get', xmlns: 'w:g2', to: '@g.us' },
            content: [{ tag: 'invite', attrs: { code: code } }]
        });
        const group = getBinaryNodeChild(response, 'group');
        const groupId = group?.attrs?.id?.includes('@') ? group.attrs.id : group?.attrs?.id + '@g.us';
        const subject = group?.attrs?.subject;
        
        if (!groupId) return { status: false, message: '✗ Failed to retrieve Group ID from the link.' };

        return { status: true, code, groupId, subject };
    } catch (error) {
        console.error("✗ Error in getGroupIdWithGroupLink:", error);
        return { status: false, message: error.message };
    }
}

function parseError(error) {
    return `✗ Ada yang salah:\n${error.message}\n\n_jika ada kendala silahkan hubungi owner bot._`;
}

const run = async (m, lulli, { func, cfg }) => {
    global.db.sewabot = global.db.sewabot || {};
    global.db.groups = global.db.groups || {};

    if (global.db.sewabot[m.sender]) {
        const buyerData = global.db.sewabot[m.sender];
        await lulli.sendbut(m.chat, 'Proses sewabot kamu sebelumnya masih ada yang berjalan', 'ingin membatalkan sewabot sebelumnya?', [['Batalkan', 'batalkan']], m, {
            caption: '\nKetik *Batal* untuk membatalkan sesi sebelumnya.',
            mentions: [m.sender],
            expiration: m.expiration
        });
        return;
    }

    let keyId = null;
    let caption = '';
    
    if (cfg.baileys.button) {
        let title = '✦ LIST HARGA SEWA BOT';
        let footer = 'silahkan pilih paket sewabot dibawah';
        
        caption = cfg.packageSewabot.map(data => `*PAKET ${data.name.toUpperCase()}*\n- Rp${func.toRupiah(data.price)} / ${data.duration + (data.normal_price ? '\nHarga normal *~Rp' + func.toRupiah(data.normal_price) + '~*' : '')}`).join('\n\n');
        
        let sections = cfg.packageSewabot.map((data, index) => ({
            title: `PAKET ${data.name.toUpperCase()}`,
            highlight_label: data.duration.includes('30 day') ? 'Populer Sewabot' : '',
            rows: [{
                header: `Paket ${data.name}`,
                title: `Rp. ${func.toRupiah(data.price)}`,
                description: `Duration ${data.duration}`,
                id: String(index + 1)
            }]
        }));
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: footer }),
                        header: proto.Message.InteractiveMessage.Header.create({ title: title, subtitle: '', hasMediaAttachment: false }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: 'Click Here ⎙', sections }) }]
                        }),
                        contextInfo: { mentionedJid: [m.sender], forwardingScore: 100, isForwarded: false }
                    })
                }
            }
        }, { quoted: m });
        await lulli.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
        keyId = msg.key;

    } else {
        caption = '✦ PRICE LIST SEWA BOT\n\n';
        caption += cfg.packageSewabot.map((data, index) => {
            return `${index + 1}. PAKET ${data.name.toUpperCase()}\n- Duration: ${data.duration}\n- Price: Rp${func.toRupiah(data.price) + (data.normal_price ? ' _*~Rp' + func.toRupiah(data.normal_price) + '~*_' : '')}`
        }).join('\n\n');
        caption += `\n\n✦ BENEFITS:\n- bot fast respon\n- memakai sistem bot ganda agar tidak delay (singkronisasi)\n- bot online 24 jam\n- fitur keamanan untuk grup\n- fitur game untuk bermain\n- fitur pengunduh\n- fitur AI (artificial intelligence)\n- and more...\n\n✦ ATTENTION:\n1. bot bergaransi, apabila bot di kick sebelum waktu sewa habis maka garansi hangus.\n2. harga sewa hanya berlaku untuk 1 grup.\n3. jika bot tidak merespon dalam jangka waktu lama silahkan hubungi owner.\n\n✦ CARA SEWA:\nKetik \`nomor sewa\` yang sudah tersedia di atas untuk melanjutkan sewabot.\n\n_(Contoh, ketik *1* untuk memilih opsi *SEWA 1*_)`;
        
        let { key } = await lulli.sendMessage(m.chat, { text: caption.trim() }, { quoted: m, ephemeralExpiration: m.expiration });
        keyId = key;
    }

    global.db.sewabot[m.sender] = {
        id: crypto.randomBytes(5).toString('hex').toUpperCase(),
        chatId: m.chat,
        number: m.sender,
        name: m.pushname,
        session: 'select_package',
        date: moment().tz('Asia/Jakarta').format('DD MMMM YYYY'),
        payment: null,
        data: null,
        quoted: { key: m.key, message: m.message },
        keyId: keyId
    };
    await createTimeout(m, lulli, global.db.sewabot[m.sender], 3);
};


export const main = async (m, lulli, { func, cfg, quoted }) => {
    global.db.sewabot = global.db.sewabot || {};
    global.db.groups = global.db.groups || {};

    const buyerData = global.db.sewabot[m.sender];
    if (!buyerData) return;

    if (timeoutData[m.sender]) clearTimeout(timeoutData[m.sender]);
    
    const userResponse = m.budy.trim();
    const index = parseFloat(userResponse);

    if (/^(batal|batalkan)$/i.test(userResponse)) {
        if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
        await m.reply(`✓ Baik kak, penyewaan bot dengan ID : ${buyerData.id} sudah dibatalkan.`);
        paymentModule.deleteSession(buyerData.number, global.db.sewabot);
        delete timeoutData[m.sender];
        return;
    }

    switch (buyerData.session) {
        case 'select_package': {
            if (isNaN(index) || index < 1 || index > cfg.packageSewabot.length) {
                await m.reply('✗ Masukkan nomor paket sewa yang valid.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }
            buyerData.data = cfg.packageSewabot[index - 1];
            
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            
            let caption = '✦ METODE PEMBAYARAN\n';
            cfg.paymentMethods.forEach((item, idx) => {
                caption += `\n\n⋄ ${idx + 1}. ${item.name} (${item.name === 'QRIS' ? 'otomatis' : 'manual'})`;
                if (item.desc) caption += '\n' + item.desc;
            });

            const buttons = cfg.paymentMethods.map((item, idx) => ([item.name, String(idx + 1)]));
            let { key } = await lulli.sendbut(m.chat, caption, 'click the button below to select payment method', buttons, m, {
                caption: `\n\nKetik angka (1-...) untuk memilih metode pembayaran..`,
                mentions: [m.sender],
                expiration: m.expiration
            });
            buyerData.keyId = key;
            buyerData.session = 'payment_method';
            await createTimeout(m, lulli, buyerData, 5);
            break;
        }

        case 'payment_method': {
            if (isNaN(index) || index < 1 || index > cfg.paymentMethods.length) {
                await m.reply('✗ Masukkan nomor metode pembayaran yang valid.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }
            buyerData.payment = cfg.paymentMethods[index - 1];
            
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            
            let caption = `✦ KONFIRMASI SEWA BOT\n\n` +
                          `⋄ ID : ${buyerData.id}\n` +
                          `⋄ Nomor : @${buyerData.number.split('@')[0]}\n` +
                          `⋄ Tanggal : ${buyerData.date}\n` +
                          `⋄ Nama Paket : ${buyerData.data.name}\n` +
                          `⋄ Durasi : ${buyerData.data.duration}\n` +
                          `⋄ Pembayaran Via : ${buyerData.payment.name}\n` +
                          `⋄ Harga : Rp${func.toRupiah(buyerData.data.price)},-\n\n` +
                          `⋄ Informasi:\n` +
                          `- Melakukan pembelian artinya Anda setuju dengan segala kebijakan kami.\n` +
                          `- Transfer sesuai nominal & wajib sertakan bukti transfer.\n` +
                          `- Semua pembelian bergaransi.`;
            
            const buttons = [['Lanjut', 'lanjut'], ['Batal', 'batal']];
            let { key } = await lulli.sendbut(m.chat, caption, 'please select the button below', buttons, m, {
                caption: '\n\nKetik *Lanjut* atau *Batal* untuk melanjutkan atau membatalkan pembelian._',
                mentions: [m.sender],
                expiration: m.expiration
            });
            buyerData.keyId = key;
            buyerData.session = 'sewabot_confirmation';
            await createTimeout(m, lulli, buyerData, 5);
            break;
        }

        case 'sewabot_confirmation': {
            if (/^(lanjut|lanjutkan)$/i.test(userResponse)) {
                await createTimeout(m, lulli, buyerData, 10);
                if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });

                const topupAmount = buyerData.data.price;
                const paymentMethod = buyerData.payment;
                
                if (/QRIS/i.test(paymentMethod.name)) {
                    buyerData.session = 'bukti_pembayaran';
                    const qrisCaption = cfg.mess.payment.qris
                        .replace(/@an/g, paymentMethod.an)
                        .replace(/@username/g, paymentMethod.username)
                        .replace(/@price/g, `Rp${func.toRupiah(topupAmount)},-`);
                    
                    if (paymentModule && paymentModule.generateQRIS && paymentModule.createQR) {
                        let qrCodeData = paymentModule.generateQRIS(String(topupAmount));
                        let imageBuffer = await paymentModule.createQR(qrCodeData);
                        let { key } = await lulli.sendMessage(m.chat, { image: imageBuffer, caption: qrisCaption }, { quoted: m, ephemeralExpiration: m.expiration });
                        buyerData.keyId = key;
                    } else {
                        throw new Error('✗ Payment module function for QRIS not found.');
                    }
                    if (paymentModule && paymentModule.addPaymentSession) {
                        paymentModule.addPaymentSession(buyerData.number, topupAmount, async () => {
                            await lulli.reply(m.chat, `✓ Pembelian sewa bot kamu telah dikonfirmasi otomatis oleh sistem. Silakan kirim *link grup* kamu.`, m);
                            buyerData.session = 'link_group';
                            await createTimeout(m, lulli, buyerData, 5);
                        }, global.db.sewabot, lulli, m.expiration);
                    } else {
                        throw new Error('✗ Payment module function addPaymentSession not found.');
                    }
                } 
                else {
                    buyerData.session = 'bukti_pembayaran';
                    const ewalletCaption = cfg.mess.payment.ewallet
                        .replace(/@ewallet/g, paymentMethod.name.toUpperCase())
                        .replace(/@nomor/g, paymentMethod.src)
                        .replace(/@an/g, paymentMethod.an)
                        .replace(/@price/g, `Rp${func.toRupiah(buyerData.data.price)},-`);
                    
                    let { key } = await lulli.sendMessage(m.chat, { text: ewalletCaption }, { quoted: m, ephemeralExpiration: m.expiration });
                    buyerData.keyId = key;
                    await m.reply('Silakan transfer ke nomor di atas, lalu kirim bukti transfer dengan *BUKTI* atau reply gambar dengan caption *BUKTI*.');
                    await createTimeout(m, lulli, buyerData, 10);
                }
            } else if (/^(batal|batalkan)/i.test(userResponse)) {
                if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
                await m.reply(`✓ Penyewaan bot dengan ID : ${buyerData.id} telah dibatalkan.`);
                paymentModule.deleteSession(buyerData.number, global.db.sewabot);
                delete timeoutData[m.sender];
            } else {
                await m.reply('✗ Respon tidak valid. Ketik *Lanjut* atau *Batal*.');
                await createTimeout(m, lulli, buyerData, 1);
            }
            break;
        }

        case 'bukti_pembayaran': {
            if (/^(bukti|\.bukti)$/i.test(userResponse)) {
                if (!quoted || !/image\/(jpe?g|png)/.test(quoted.mimetype)) {
                    await m.reply(`✗ Kirim gambar dengan caption *BUKTI* atau reply gambar yang sudah dikirim dengan caption *BUKTI*`);
                    await createTimeout(m, lulli, buyerData, 1);
                    return;
                }
                
                clearTimeout(timeoutData[m.sender]);
                delete timeoutData[m.sender];

                let media = await quoted.download();
                
                let caption = `✦ BUKTI PEMBELIAN SEWABOT\n\n` +
                              `⋄ ID : ${buyerData.id}\n` +
                              `⋄ Nomor : @${buyerData.number.split('@')[0]}\n` +
                              `⋄ Tanggal : ${buyerData.date}\n` +
                              `⋄ Nama Paket : ${buyerData.data.name}\n` +
                              `⋄ Durasi : ${buyerData.data.duration}\n` +
                              `⋄ Harga : Rp${func.toRupiah(buyerData.data.price)},-\n\n` +
                              `Ada yang transfer nih kak, coba dicek saldonya`;
                
                const buttons = [
                    ['accept', `${m.prefix}accsewa ${buyerData.number.split('@')[0]}`],
                    ['reject', `${m.prefix}rejectsewa ${buyerData.number.split('@')[0]}`]
                ];
                
                await lulli.sendbut(cfg.owner, caption, 'click the button bellow to accept or reject sewabot', buttons, null, {
                    media: media,
                    caption: `\n\n_Jika sudah masuk kirim \`${m.prefix}accsewa ${buyerData.number.split('@')[0]}\`_\n_Jika belum masuk kirim \`${m.prefix}rejectsewa ${buyerData.number.split('@')[0]}\`_`,
                    mentions: [m.sender],
                    expiration: m.expiration
                });
                
                await m.reply('✓ Mohon tunggu, owner akan memeriksa bukti transfer 🙏🏻');
                paymentModule.deleteSession(buyerData.number, global.db.sewabot);

            } else {
                await m.reply('✗ Respon tidak valid. Harap kirim bukti pembayaran dengan caption *BUKTI*.');
                await createTimeout(m, lulli, buyerData, 1);
            }
            break;
        }
        
        case 'link_group': {
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            
            if (!/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(userResponse)) {
                await m.reply('✗ Link grup tidak valid. Harap kirim link grup WhatsApp yang benar.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }

            try {
                const { status, groupId, code, subject, message } = await getGroupIdWithGroupLink(lulli, userResponse);
                if (!status) throw new Error(message);
                
                const groupMetadataCache = groupfetchModule ? groupfetchModule.getCache(lulli.user.id) : null;
                const groupsList = groupMetadataCache ? Object.values(groupMetadataCache).map(item => item.id) : [];

                let isAcceptInvite = false;
                if (!groupsList.includes(groupId)) {
                    try {
                        await lulli.groupAcceptInvite(code);
                        isAcceptInvite = true;
                    } catch (error) {
                        const err = error.message;
                        if (err.includes('already-exists')) {
                            isAcceptInvite = true;
                        } else if (err.includes('conflict')) {
                            throw new Error('✗ Bot sudah bergabung ke dalam grup tersebut.');
                        } else if (err.includes('not-authorized')) {
                            throw new Error('✗ Bot sudah terkick! tidak dapat join.');
                        } else {
                            throw new Error('✗ Gagal menerima undangan grup: ' + err);
                        }
                    }
                }
                
                if (buyerData.data && buyerData.data.renew) {
                    const existingGroupData = global.db.groups[groupId];
                    const minRemainingTime = toMs('3d');

                    if (existingGroupData?.sewa?.status && existingGroupData.sewa.expired && (existingGroupData.sewa.expired !== 'PERMANENT') && ((existingGroupData.sewa.expired - Date.now()) > minRemainingTime)) {
                        await lulli.reply(buyerData.chatId, `✗ Maaf perpanjangan untuk grup “${subject}“ ditolak karena perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari terimakasih.\n\nMasa aktif tersisa: *${func.expireTime(existingGroupData.sewa.expired)}*`, m);
                        paymentModule.deleteSession(buyerData.number, global.db.sewabot);
                        return;
                    }
                    existingGroupData.sewa.expired = (existingGroupData.sewa.expired || Date.now()) + toMs(buyerData.data.duration);
                    existingGroupData.sewa.notice = true;

                    const caption = `⋄ ID : ${buyerData.id}\n` +
                                    `⋄ Nama Grup : ${subject}\n` +
                                    `⋄ Tanggal : ${buyerData.date}\n` +
                                    `⋄ Nama Paket : ${buyerData.data.name}\n` +
                                    `⋄ Durasi : ${buyerData.data.duration}\n` +
                                    `⋄ Harga : Rp${func.toRupiah(buyerData.data.price)},-`;
                    await lulli.sendMessage(buyerData.chatId, { text: 'Masa sewa bot telah berhasil diperpanjang!\n\n' + caption + (isAcceptInvite ? '\n\nMohon untuk menerima bot agar dapat bergabung ke dalam grup. Jika permohonan ditolak, maka sewa bot akan dibatalkan dan tidak ada pengembalian dana_.' : '') });
                    const testimonialText = '✦ TESTIMONI RENEW SEWA BOT\n\n' + caption;
                    await lulli.sendMessageTestimony(testimonialText);
                    
                    if (isAcceptInvite) {
                        setTimeout(async () => {
                            await lulli.sendMessage(groupId, { text: 'Masa sewa bot telah berhasil diperpanjang!\n\n' + caption }, { ephemeralExpiration: m.expiration });
                        }, DELAY_BETWEEN_ACTIONS_MS);
                    }
                    paymentModule.deleteSession(buyerData.number, global.db.sewabot);
                    return;
                }
                const caption = `⋄ ID : ${buyerData.id}\n` +
                                `⋄ Nama Grup : ${subject}\n` +
                                `⋄ Tanggal : ${buyerData.date}\n` +
                                `⋄ Nama Paket : ${buyerData.data.name}\n` +
                                `⋄ Durasi : ${buyerData.data.duration}\n` +
                                `⋄ Harga : Rp${func.toRupiah(buyerData.data.price)},-`;
                
                global.db.groups[groupId] = global.db.groups[groupId] || { jid: groupId, name: subject, sewa: {} };
                global.db.groups[groupId].sewa = {
                    status: true,
                    notice: true,
                    expired: Date.now() + toMs(buyerData.data.duration)
                };

                await lulli.sendMessage(buyerData.chatId, { text: '✦ SEWA BOT BERHASIL\n\n' + caption + (isAcceptInvite ? '\n\nMohon untuk menerima bot agar dapat bergabung ke dalam grup. Jika permohonan ditolak, maka sewa bot akan dibatalkan dan tidak ada pengembalian dana_.' : '') });
                const testimonialText = '✦ TESTIMONI SEWA BOT\n\n' + caption;
                await lulli.sendMessageTestimony(testimonialText);
                
                if (isAcceptInvite) {
                    setTimeout(async () => {
                        await lulli.sendMessage(groupId, { text: '✦ SEWA BOT BERHASIL\n\n' + caption + '\n\n_Jangan lupa follow https://whatsapp.com/channel/0029Vaq3DHa4tRrvXv8LA53c_' }, { ephemeralExpiration: m.expiration });
                    }, DELAY_BETWEEN_ACTIONS_MS);
                }
                paymentModule.deleteSession(buyerData.number, global.db.sewabot);
            } catch (error) {
                console.error("✗ Error processing link_group:", error);
                await m.reply(parseError(error));
                paymentModule.deleteSession(buyerData.number, global.db.sewabot);
            }
            break;
        }
    }
    if (buyerData) {
        await createTimeout(m, lulli, buyerData, 3);
    }
};

export default {
    run,
    main,
    cmd: 'sewabot',
    alias: ['sewa', 'rentbot'],
    type: 'buyer',
    location: 'plugins/buyer/sewabot.js'
};
