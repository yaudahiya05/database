import crypto from"node:crypto";import moment from"moment-timezone";import axios from"axios";import fetch from"node-fetch";import*as paymentModule from"../../lib/payment.js";let timeoutData={},createTimeout=async(e,a,t,i=3)=>{timeoutData[e.sender]&&clearTimeout(timeoutData[e.sender]),timeoutData[e.sender]=setTimeout(async()=>{if(t.keyId){try{await a.sendMessage(t.keyId.remoteJid||e.chat,{delete:t.keyId})}catch(e){console.error("Error deleting old keyId message:",e.message)}await a.sendMessage(e.chat,{text:"Sesi pembelian Anda telah kadaluarsa."},{quoted:t.quoted,ephemeralExpiration:e.expiration})}paymentModule&&paymentModule.deleteSession(t.number,global.db.script),delete timeoutData[e.sender]},6e4*i)},run=async(e,a,{func:t,cfg:i})=>{var n,r;global.db.script=global.db.script||{},global.db.script[e.sender]?(global.db.script[e.sender],await a.sendButton(e.chat,"Proses pembelian script kamu sebelumnya masih ada yang berjalan","ingin membatalkan pembelian script sebelumnya?",[["Batal","batal"]],e,{caption:"\nKetik *Batal* untuk membatalkan sesi sebelumnya.",expiration:e.expiration})):(n=await a.reply(e.chat,(n=`*SELL SCRIPT MECHA BOT V10*

- Normal price: Rp. 100.000
- Discount price: Rp. 80.000
- Features: 800+
- Type: plugins (CJS)

*Key Features:*
- Support QR/Pairing
- Support button
- Size dibawah 1MB
- 95% Scraper
- Login with username & password to get access
- Copy pairing code from website

*Preview Features:*
- Downloader (tiktok, instagram, facebook, snackvideo, twitter, capcut, youtube dll)
- Temporary Bot (Jadibot)
- Menfess (Confession)
- Tiktok Search
- AI & AI Image
- Imagehd
- Hdvideo
- 31 Mini Games & RPG Games
- Response Polling
- Button List
- Advanced Menu Options
- And more...

*Additional Features:*
- Create Panel
- Auto Downloader
- Anonymous Chat
- And more...

*Requirements:*
- NodeJS v18
- FFMPEG
- Min. 5GB RAM

*Benefit:*
- Always Update (free)
- Request Features
- Fixing Features
- Free Hosting (1 month)`).trim(),e,{expiration:e.expiration}),global.db.script[e.sender]={id:crypto.randomBytes(5).toString("hex").toUpperCase(),chatId:e.chat,number:e.sender,name:e.pushname,session:"script_confirmation",date:moment.tz("Asia/Jakarta").format("DD MMMM YYYY"),payment:i.paymentMethods[0],data:{name:"Script Mecha Bot V10",price:8e4,username:"",password:""},quoted:{key:e.key,message:e.message},keyId:n.key},i=`*KONFIRMASI SCRIPT*

`+`⋄ ID : ${(r=global.db.script[e.sender]).id}
`+`⋄ Nomor : @${r.number.split("@")[0]}
`+`⋄ Tanggal : ${r.date}
`+`⋄ Nama Produk : ${r.data.name}
`+`⋄ Pembayaran Via : ${r.payment.name}
`+`⋄ Harga : Rp${t.toRupiah(r.data.price)},-

`+`*Informasi:*
`+`- Melakukan pembelian artinya Anda setuju dengan segala kebijakan kami.
`+`- Transfer sesuai nominal & wajib sertakan bukti transfer.
`+"- Semua pembelian bergaransi.",await t.delay(1500),t=(await a.sendbut(e.chat,i,"please select the button below",[["Lanjut","lanjut"],["Batal","batal"]],n,{caption:"\n\n_Ketik *Lanjut* atau *Batal* untuk melanjutkan atau membatalkan pembelian._",expiration:e.expiration})).key,r.keyId=t,await createTimeout(e,a,r,3))},main=async(e,a,{func:t,cfg:i,quoted:n})=>{global.db.script=global.db.script||{};let r=global.db.script[e.sender];if(r){timeoutData[e.sender]&&clearTimeout(timeoutData[e.sender]);var s=e.budy.trim();if(/^(batal|batalkan)$/i.test(s))r.keyId&&await a.sendMessage(r.keyId.remoteJid||e.chat,{delete:r.keyId}),await e.reply(`Baik kak, script dengan ID : ${r.id} sudah dibatalkan.`),paymentModule&&paymentModule.deleteSession(r.number,global.db.script),delete timeoutData[e.sender];else{switch(r.session){case"script_confirmation":if(/^(lanjut|lanjutkan)$/i.test(s)){r.session="check_payment",r.keyId&&await a.sendMessage(r.keyId.remoteJid||e.chat,{delete:r.keyId});var o=r.data.price,m=r.payment;if(/QRIS/i.test(m.name)){var l=i.mess.payment.qris.replace(/@an/g,m.an).replace(/@username/g,m.username).replace(/@price/g,`Rp${t.toRupiah(o)},-`);if(!(paymentModule&&paymentModule.generateQRIS&&paymentModule.createQR))throw new Error("Payment module function for QRIS not found.");var d=paymentModule.generateQRIS(String(o)),d=await paymentModule.createQR(d),d=(await a.sendMessage(e.chat,{image:d,caption:l},{quoted:e,ephemeralExpiration:e.expiration})).key;if(r.keyId=d,!paymentModule||!paymentModule.addPaymentSession)throw new Error("Payment module function addPaymentSession not found.");paymentModule.addPaymentSession(r.number,o,async()=>{await a.reply(e.chat,"Pembelian script kamu telah dikonfirmasi otomatis oleh sistem, silahkan KETIK username untuk akses script kamu.",e),r.session="username",await createTimeout(e,a,r,3)},global.db.script,a,e.expiration)}else l=i.mess.payment.ewallet.replace(/@ewallet/g,m.name.toUpperCase()).replace(/@nomor/g,m.src).replace(/@an/g,m.an).replace(/@price/g,`Rp${t.toRupiah(r.data.price)},-`),d=(await a.sendMessage(e.chat,{text:l},{quoted:e,ephemeralExpiration:e.expiration})).key,r.keyId=d,await e.reply("Silakan transfer ke nomor di atas, lalu kirim bukti transfer dengan *BUKTI* atau reply gambar dengan caption *BUKTI*."),await createTimeout(e,a,r,10)}else await e.reply("Respon tidak valid. Ketik *Lanjut* atau *Batal*."),await createTimeout(e,a,r,1);break;case"username":if(s&&!e.isPrefix){if(s.includes(" "))return e.reply("Username tidak boleh menggunakan spasi.");if(s.length<5)return e.reply("Username tidak boleh kurang dari 5 karakter.");if(10<s.length)return e.reply("Username tidak boleh melebihi 10 karakter.");r.data.username=s,r.session="password",await a.sendReact(e.chat,"✅",e.key),await a.reply(e.chat,"_Silakan KETIK password (min 5, max 15 karakter, tanpa spasi) untuk akses script kamu._",e,{expiration:e.expiration}),await createTimeout(e,a,r,3)}else await e.reply("Respon tidak valid. Silakan masukkan username."),await createTimeout(e,a,r,1);break;case"password":if(s&&!e.isPrefix){if(s.includes(" "))return e.reply("Password tidak boleh menggunakan spasi.");if(s.length<5)return e.reply("Password tidak boleh kurang dari 5 karakter.");if(15<s.length)return e.reply("Password tidak boleh melebihi 15 karakter.");r.data.password=s,await a.sendReact(e.chat,"🕒",e.key);try{var p=r.data.username,u=r.data.password,c=await t.fetchJson(`https://lulli.vercel.app/database/createuser?username=${p}&password=${u}&pin=210505`);if(!c||!c.message)throw new Error(c?.error||"Gagal membuat akun akses script.");var k=`Terima kasih telah membeli script mecha-bot v10.

*Akun Anda:*
- Username: ${p}
- Password: ${u}

*Catatan*: Harap simpan file script dan akun Anda, karena kami tidak bertanggung jawab jika Anda lupa.`;await a.sendMessage(r.number,{document:{url:"./media/mecha-bot v10.1.0.zip"},caption:k,mimetype:"application/zip",fileName:"mecha-bot v10.1.0.zip"},{quoted:null,ephemeralExpiration:0}),await a.reply(e.chat,"Akun akses dan file script Anda telah dikirimkan ke chat pribadi."),paymentModule&&paymentModule.deleteSession(r.number,global.db.script)}catch(t){console.error("Error creating script account:",t),await a.reply(e.chat,"Terjadi kesalahan saat membuat akun atau mengirim script: "+t.message+"\n\n- Silahkan hubungi owner jika terjadi kendala.",e),paymentModule&&paymentModule.deleteSession(r.number,global.db.script)}}else await e.reply("Respon tidak valid. Silakan masukkan password."),await createTimeout(e,a,r,1);break;case"check_payment":if(/^(bukti|\.bukti)$/i.test(s)){if(!n||!/image\/(jpe?g|png)/.test(n.mimetype))return await e.reply("Kirim gambar dengan caption *BUKTI* atau reply gambar yang sudah dikirim dengan caption *BUKTI*"),void await createTimeout(e,a,r,1);clearTimeout(timeoutData[e.sender]),delete timeoutData[e.sender],o=await n.download(),m=`*BUKTI PEMBELIAN SCRIPT*

`+`⋄ ID : ${r.id}
`+`⋄ Nomor : @${r.number.split("@")[0]}
`+`⋄ Tanggal : ${r.date}
`+`⋄ Nama Produk : ${r.data.name}
`+`⋄ Harga : Rp${t.toRupiah(r.data.price)},-

`+"Ada yang transfer nih kak, coba dicek saldonya",l=[["accept",e.prefix+"accsc "+r.number.split("@")[0]],["reject",e.prefix+"rejectsc "+r.number.split("@")[0]]],await a.sendButton(i.owner,m,"click the button bellow to accept or reject script",l,null,{media:o,caption:`

_Jika sudah masuk kirim \`${e.prefix}accsc ${r.number.split("@")[0]}\`_
_Jika belum masuk kirim \`${e.prefix}rejectsc ${r.number.split("@")[0]}\`_`,expiration:e.expiration}),await e.reply("_Mohon tunggu, owner akan memeriksa bukti transfer_ 🙏🏻"),paymentModule&&paymentModule.deleteSession(r.number,global.db.script)}else await e.reply("Respon tidak valid. Harap kirim bukti pembayaran dengan caption *BUKTI*."),await createTimeout(e,a,r,1)}r&&await createTimeout(e,a,r,3)}}};export default{run:run,main:main,cmd:"buyscript",alias:"buysc",type:"buyer",location:"plugins/buyer/buyscript.js"};export{run,main};