import crypto from 'node:crypto';
import moment from 'moment-timezone';
import axios from 'axios';
import fetch from 'node-fetch';

import * as paymentModule from '../../lib/payment.js';

let timeoutData = {};

const createTimeout = async (m, lulli, buyerData, minute = 3) => {
    if (timeoutData[m.sender]) clearTimeout(timeoutData[m.sender]);
    timeoutData[m.sender] = setTimeout(async () => {
        if (buyerData.keyId) {
            try {
                await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            } catch (e) { console.error("✗ Error deleting old keyId message:", e.message); }
            
            await lulli.sendMessage(m.chat, {
                text: '✗ Sesi pembelian Anda telah kadaluarsa.'
            }, {
                quoted: buyerData.quoted,
                ephemeralExpiration: m.expiration
            });
        }
        if (paymentModule) paymentModule.deleteSession(buyerData.number, global.db.panel);
        delete timeoutData[m.sender];
    }, 1000 * 60 * minute);
};

async function createServer(lulli, m, func, cfg, jid, startup_cmd, user = {}, servers = {}) {
    try {
        const timezone = func.getCurrentTimeInZone('Asia/Jakarta');
        let buyerData = global.db.panel[jid];

        let userIdToUse;
        if (user && user.id) {
            userIdToUse = user.id;
        } else {
            const result = await findUserId(lulli, cfg, jid);
            if (!result.status) {
                buyerData.session = 'create_new';
                await lulli.reply(m.chat, cfg.mess.wrong(result.message) + '\n\n✦ _Sistem otomatis mengalihkan ke metode *create new*, silahkan KETIK username untuk akun panel kamu._', m);
                return;
            }
            userIdToUse = result.id;
        }

        const response = await fetch(`${cfg.panelApi.domain}/api/application/servers`, {
            method: "POST",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + cfg.panelApi.apikey,
            },
            body: JSON.stringify({
                "name": servers.username + ` - ${servers.ram.toUpperCase()}`,
                "description": `${timezone.date} (${timezone.time})`,
                "user": userIdToUse,
                "egg": parseInt(cfg.panelApi.eggs),
                "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                "startup": startup_cmd,
                "environment": {
                    "INST": "npm",
                    "USER_UPLOAD": "0",
                    "AUTO_UPDATE": "0",
                    "CMD_RUN": "npm start"
                },
                "limits": {
                    "memory": servers.memory,
                    "swap": 0,
                    "disk": servers.disk,
                    "io": 500,
                    "cpu": servers.cpu
                },
                "feature_limits": {
                    "databases": 5,
                    "backups": 5,
                    "allocations": 5
                },
                deploy: {
                    locations: [parseInt('1')],
                    dedicated_ip: false,
                    port_range: [],
                },
            })
        });

        const res = await response.json();
        if (res.errors) throw new Error(res.errors[0].detail || res.errors[0].code);

        const server = res.attributes;
        let serverInfo = `\n- Server ID : \`${server.id}\``;
        serverInfo += `\n- UUID : \`${server.uuid}\``;
        serverInfo += `\n- Name : \`${server.name}\``;
        serverInfo += `\n- Description : \`${server.description}\``;
        serverInfo += `\n- Memory : \`${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory + ' MB'}\``;
        serverInfo += `\n- Disk : \`${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + ' MB'}\``;
        serverInfo += `\n- CPU : \`${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + ' %'}\``;
        serverInfo += `\n- Created At : \`${server.created_at}\``;
        
        let expire = Date.now() + 2592000000;
        if (!global.db.server[jid]) {
            global.db.server[jid] = { jid: jid, data: [] };
        }
        global.db.server[jid].data.push({
            id: server.id,
            ram: servers.ram.toLowerCase(),
            username: servers.username,
            password: servers.password,
            expired: expire,
            date: timezone.date
        });

        const testimonialText = `✦ TESTIMONI BUY PANEL\n\n` +
                                `✦ ID : ${buyerData.id}\n` +
                                `✦ Durasi : ${buyerData.data.duration}\n` +
                                `✦ Harga : Rp${func.toRupiah(buyerData.data.price)},-\n` +
                                `✦ Username : ${servers.username}\n` +
                                `✦ Server ID : \`${server.id}\`\n` +
                                `✦ Memory : \`${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory + ' MB'}\`\n` +
                                `✦ Disk : \`${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + ' MB'}\`\n` +
                                `✦ CPU : \`${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + ' %'}\``;
        
        await lulli.sendMessage(cfg.owner, { text: testimonialText });
        
        if (paymentModule) paymentModule.deleteSession(jid, global.db.panel);
        
        await lulli.reply(m.chat, `✓ SERVER BERHASIL DIBUAT!`, m);

    } catch (error) {
        console.error("✗ Error creating server:", error);
        await lulli.reply(m.chat, '✗ Terjadi kesalahan saat membuat server: ' + error.message + '\n\n- Silahkan hubungi owner jika terjadi kendala.', m);
        if (paymentModule) paymentModule.deleteSession(jid, global.db.panel);
    }
}

async function findUserId(lulli, cfg, jid, usernameToFind = null) {
    try {
        const response = await fetch(`${cfg.panelApi.domain}/api/application/users`, {
            method: "GET",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + cfg.panelApi.apikey
            }
        });
        const result = await response.json();
        if (result.errors) throw new Error(result.errors[0].detail);

        const allPanelUsers = result.data.map(item => item.attributes);
        
        let foundUser = null;
        if (usernameToFind) { // Cari berdasarkan username yang diinput
            foundUser = allPanelUsers.find(item => item.username.toLowerCase() === usernameToFind.toLowerCase());
        } else { // Cari berdasarkan JID yang terhubung ke server di DB bot
            const userServerData = global.db.server[jid];
            if (userServerData && userServerData.data) {
                const existingUsernames = userServerData.data.map(item => item.username?.toLowerCase()).filter(Boolean);
                foundUser = allPanelUsers.find(item => existingUsernames.includes(item.username.toLowerCase()));
            }
        }
        
        if (foundUser) {
            return { status: true, id: foundUser.id, attributes: foundUser };
        }
        return { status: false, message: '✗ User ID tidak ditemukan di panel.' };
    } catch (error) {
        console.error("✗ Error finding user ID:", error.message);
        return { status: false, message: '✗ Gagal mencari User ID: ' + error.message };
    }
}

export const run = async (m, lulli, { func, cfg, setting }) => {
    global.db.panel = global.db.panel || {};
    global.db.server = global.db.server || {};

    if (global.db.panel[m.sender]) {
        const buyerData = global.db.panel[m.sender];
        await lulli.sendButton(m.chat, 'Proses pembelian panel kamu sebelumnya masih ada yang berjalan', 'ingin membatalkan pembelian panel sebelumnya?', [['Batalkan', 'batalkan']], m, {
            caption: '\nKetik *Batal* untuk membatalkan sesi sebelumnya.',
            expiration: m.expiration
        });
        return;
    }

    let keyId = null;
    let caption = '';
    
    if (cfg.baileys.button) {
        const { proto, generateWAMessageFromContent } = require(cfg.baileys.module);
        let title = '✦ PRICE LIST LULLI HOST';
        caption = `✦ Benefits:
- harga di atas untuk 1 bulan
- private server (anti colong script)
- hemat kuota dan penyimpanan
- web & wa close bot tetep jalan
- garansi 30 hari
- spek VPS Premium AMD

✦ Catatan Penting: 
penggunaan panel harus sesuai dengan ketentuan layanan (TOS). *Dilarang digunakan untuk:*
- DDOS
- HACKING
- MINING
- Aktivitas ilegal lainnya`;
        
        let rows = cfg.packagePanel.map((data, index) => ({
            header: `PANEL ${data.name}`,
            title: `Rp. ${func.toRupiah(data.price)} / ${data.duration}`,
            description: `CPU ${data.cpu}%`,
            id: String(index + 1)
        }));
        
        let sections = [{
            title: 'PANEL PRICE LIST',
            rows: rows
        }];
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
                        footer: proto.Message.InteractiveMessage.Footer.create({ text: 'please select the list below' }),
                        header: proto.Message.InteractiveMessage.Header.create({ title: title, subtitle: '', hasMediaAttachment: false }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: 'Click Here ⎙', sections }) }]
                        }),
                        contextInfo: { mentionedJid: [m.sender], forwardingScore: 100, isForwarded: false }
                    })
                }
            }
        }, { quoted: m });
        await lulli.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
        keyId = msg.key;

    } else {
        caption = '✦ PRICE LIST LULLI PANEL\n\n';
        caption += cfg.packagePanel.map((data, index) => {
            return `${index + 1}. PANEL ${data.name}\n- CPU: ${data.cpu}%\n- Price: Rp. ${func.toRupiah(data.price)} ${data.normal_price ? '_~*' + func.toRupiah(data.normal_price) + '*~_' : ''}`;
        }).join('\n\n');
        caption += `\n\n✦ Benefits:\n- harga di atas untuk 1 bulan\n- private server (anti colong script)\n- hemat kuota dan penyimpanan\n- web & wa close bot tetep jalan\n- garansi 30 hari\n- spek VPS Premium AMD\n\n✦ Catatan Penting:\npenggunaan panel harus sesuai dengan ketentuan layanan (TOS). *Dilarang digunakan untuk:*\n- DDOS\n- HACKING\n- MINING\n- Aktivitas ilegal lainnya\n\n✦ Notes:\n- Ketik ID panel yang sudah tersedia di atas untuk melanjutkan pembelian panel.\n\n_(Contoh, ketik: *1* untuk memilih opsi *PANEL 1GB*_).`;
        
        let { key } = await lulli.sendMessage(m.chat, { text: caption.trim() }, { quoted: m, ephemeralExpiration: m.expiration });
        keyId = key;
    }

    global.db.panel[m.sender] = {
        id: crypto.randomBytes(5).toString('hex').toUpperCase(),
        chatId: m.chat,
        number: m.sender,
        name: m.pushname,
        session: 'select_package',
        date: moment().tz('Asia/Jakarta').format('DD MMMM YYYY'),
        payment: null,
        data: null,
        quoted: { key: m.key, message: m.message },
        keyId: keyId
    };
    await createTimeout(m, lulli, global.db.panel[m.sender], 3);
};

export const main = async (m, lulli, { func, cfg, quoted }) => {
    global.db.panel = global.db.panel || {};
    global.db.server = global.db.server || {};

    const buyerData = global.db.panel[m.sender];
    if (!buyerData) return;

    if (timeoutData[m.sender]) clearTimeout(timeoutData[m.sender]);
    
    const userResponse = m.budy.trim();
    const index = parseFloat(userResponse);

    if (/^(batal|batalkan)$/i.test(userResponse)) {
        if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
        await m.reply(`✓ Baik kak, pembelian panel dengan ID : ${buyerData.id} sudah dibatalkan.`);
        if (paymentModule) paymentModule.deleteSession(buyerData.number, global.db.panel);
        delete timeoutData[m.sender];
        return;
    }

    switch (buyerData.session) {
        case 'select_package': {
            if (isNaN(index) || index < 1 || index > cfg.packagePanel.length) {
                await m.reply('✗ Masukkan nomor paket yang valid.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }
            buyerData.data = cfg.packagePanel[index - 1];
            
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
            
            let caption = '✦ METODE PEMBAYARAN\n';
            cfg.paymentMethods.forEach((item, idx) => {
                caption += `\n✦ ${idx + 1}. ${item.name} (${item.name === 'QRIS' ? 'otomatis' : 'manual'})`;
                if (item.desc) caption += '\n' + item.desc;
            });

            const buttons = cfg.paymentMethods.map((item, idx) => ([item.name, String(idx + 1)]));
            let { key } = await lulli.sendButton(m.chat, caption, 'click the button below to select payment method', buttons, m, {
                caption: '\n\n✦ Ketik angka (1-...) untuk memilih metode pembayaran..',
                expiration: m.expiration
            });
            buyerData.keyId = key;
            buyerData.session = 'payment_method';
            await createTimeout(m, lulli, buyerData, 5);
            break;
        }

        case 'payment_method': {
            if (isNaN(index) || index < 1 || index > cfg.paymentMethods.length) {
                await m.reply('✗ Masukkan nomor metode pembayaran yang valid.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }
            buyerData.payment = cfg.paymentMethods[index - 1];
            
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });

            if (/QRIS/i.test(buyerData.payment.name)) {
                buyerData.data.price += 300;
            }

            let caption = `✦ KONFIRMASI PANEL\n\n` +
                          `✦ ID : ${buyerData.id}\n` +
                          `✦ Nomor : @${buyerData.number.split('@')[0]}\n` +
                          `✦ Tanggal : ${buyerData.date}\n` +
                          `✦ Nama Produk : ${buyerData.data.name}\n` +
                          `✦ CPU : ${buyerData.data.cpu}%\n` +
                          `✦ Durasi : ${buyerData.data.duration}\n` +
                          `✦ Pembayaran Via : ${buyerData.payment.name}\n` +
                          `✦ Harga : Rp${func.toRupiah(buyerData.data.price)},-\n\n` +
                          `✦ Informasi:\n` +
                          `- Melakukan pembelian artinya Anda setuju dengan segala kebijakan kami.\n` +
                          `- Transfer sesuai nominal & wajib sertakan bukti transfer.\n` +
                          `- Semua pembelian bergaransi.`;
            
            const buttons = [['Lanjut', 'lanjut'], ['Batal', 'batal']];
            let { key } = await lulli.sendButton(m.chat, caption, 'please select the button below', buttons, m, {
                caption: '\n\n✦ Ketik *Lanjut* atau *Batal* untuk melanjutkan atau membatalkan pembelian._',
                expiration: m.expiration
            });
            buyerData.keyId = key;
            buyerData.session = 'panel_confirmation';
            await createTimeout(m, lulli, buyerData, 5);
            break;
        }

        case 'panel_confirmation': {
            if (/^(lanjut|lanjutkan)$/i.test(userResponse)) {
                await createTimeout(m, lulli, buyerData, 10);
                if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });

                if (/QRIS/i.test(buyerData.payment.name)) {
                    buyerData.session = 'bukti_pembayaran';
                    const topupAmount = buyerData.data.price;
                    const qrisCaption = cfg.mess.payment.qris
                        .replace(/@an/g, buyerData.payment.an)
                        .replace(/@username/g, buyerData.payment.username)
                        .replace(/@price/g, `Rp${func.toRupiah(topupAmount)},-`);
                    
                    if (paymentModule && paymentModule.generateQRIS && paymentModule.createQR) {
                        let qrCodeData = paymentModule.generateQRIS(String(topupAmount));
                        let imageBuffer = await paymentModule.createQR(qrCodeData);
                        let { key } = await lulli.sendMessage(m.chat, { image: imageBuffer, caption: qrisCaption }, { quoted: m, ephemeralExpiration: m.expiration });
                        buyerData.keyId = key;
                    } else {
                        throw new Error('✗ Payment module function for QRIS not found.');
                    }
                } else {
                    buyerData.session = 'bukti_pembayaran';
                    const ewalletCaption = cfg.mess.payment.ewallet
                        .replace(/@ewallet/g, buyerData.payment.name.toUpperCase())
                        .replace(/@nomor/g, buyerData.payment.src)
                        .replace(/@an/g, buyerData.payment.an)
                        .replace(/@price/g, `Rp${func.toRupiah(buyerData.data.price)},-`);
                    let { key } = await lulli.sendMessage(m.chat, { text: ewalletCaption }, { quoted: m, ephemeralExpiration: m.expiration });
                    buyerData.keyId = key;
                }
            } else if (/^(batal|batalkan)$/i.test(userResponse)) {
                if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });
                await m.reply(`✓ Baik kak, pembelian panel dengan ID : ${buyerData.id} sudah dibatalkan.`);
                if (paymentModule) paymentModule.deleteSession(buyerData.number, global.db.panel);
                delete timeoutData[m.sender];
            } else {
                await m.reply('✗ Respon tidak valid. Ketik *Lanjut* atau *Batal*.');
                await createTimeout(m, lulli, buyerData, 1);
            }
            break;
        }

        case 'bukti_pembayaran': {
            if (/^(bukti|\.bukti)$/i.test(userResponse)) {
                if (!quoted || !/image\/(jpe?g|png)/.test(quoted.mimetype)) {
                    await m.reply(`✗ Kirim gambar dengan caption *BUKTI* atau reply gambar yang sudah dikirim dengan caption *BUKTI*`);
                    await createTimeout(m, lulli, buyerData, 1);
                    return;
                }
                
                clearTimeout(timeoutData[m.sender]);
                delete timeoutData[m.sender];

                let media = await quoted.download();
                
                let caption = `✦ BUKTI PEMBELIAN PANEL\n\n` +
                              `✦ ID : ${buyerData.id}\n` +
                              `✦ Nomor : @${buyerData.number.split('@')[0]}\n` +
                              `✦ Tanggal : ${buyerData.date}\n` +
                              `✦ Nama Produk : Panel ${buyerData.data.name}\n` +
                              `✦ CPU : ${buyerData.data.cpu}%\n` +
                              `✦ Durasi : ${buyerData.data.duration}\n` +
                              `✦ Harga : Rp${func.toRupiah(buyerData.data.price)},-\n\n` +
                              `Ada yang transfer nih kak, coba dicek saldonya`;
                
                const buttons = [
                    ['accept', `${m.prefix}accpanel ${buyerData.number.split('@')[0]}`],
                    ['reject', `${m.prefix}rejectpanel ${buyerData.number.split('@')[0]}`]
                ];
                
                await lulli.sendButton(cfg.owner, caption, 'click the button bellow to accept or reject panel', buttons, null, {
                    media: media,
                    caption: `\n\n_Jika sudah masuk kirim \`${m.prefix}accpanel ${buyerData.number.split('@')[0]}\`_\n_Jika belum masuk kirim \`${m.prefix}rejectpanel ${buyerData.number.split('@')[0]}\`_`,
                    expiration: m.expiration
                });
                
                await m.reply('✓ Mohon tunggu, owner akan memeriksa bukti transfer 🙏🏻');
                if (paymentModule) paymentModule.deleteSession(buyerData.number, global.db.panel);

            } else {
                await m.reply('✗ Respon tidak valid. Harap kirim bukti pembayaran dengan caption *BUKTI*.');
                await createTimeout(m, lulli, buyerData, 1);
            }
            break;
        }

        case 'panel_options': {
            if (isNaN(index) || index < 1 || index > 2) {
                await m.reply('✗ Respon tidak valid. Ketik 1 untuk membuat akun baru, atau 2 untuk menambahkan server.');
                await createTimeout(m, lulli, buyerData, 1);
                return;
            }
            
            if (buyerData.keyId) await lulli.sendMessage(buyerData.keyId.remoteJid || m.chat, { delete: buyerData.keyId });

            if (index === 1) {
                buyerData.session = 'create_new';
                await lulli.reply(m.chat, `✓ Baik kak, silahkan KETIK username untuk akun panel kamu.`, m);
            } else if (index === 2) {
                buyerData.session = 'add_server';
                await lulli.reply(m.chat, `✓ Baik kak, silahkan KETIK username (login panel) untuk menambahkan server kamu.`, m);
            }
            await createTimeout(m, lulli, buyerData, 3);
            break;
        }

        case 'add_server': {
            if (m.isPrefix) return;
            
            const username = userResponse;
            if (username.includes(' ')) return m.reply('✗ Username tidak boleh menggunakan spasi.');
            if (username.length > 10) return m.reply('✗ Username tidak boleh melebihi 10 karakter.');
            
            const jid = buyerData.number;
            const packageConfig = buyerData.data;
            
            try {
                const findUserResult = await findUserId(lulli, cfg, jid, username);
                if (!findUserResult.status) throw new Error(findUserResult.message || '✗ User ID tidak ditemukan di panel.');
                const panelUser = findUserResult.attributes;
                
                const eggResponse = await fetch(`${cfg.panelApi.domain}/api/application/nests/5/eggs/${cfg.panelApi.eggs}`, {
                    method: "GET",
                    headers: { "Accept": "application/json", "Authorization": "Bearer " + cfg.panelApi.apikey }
                });
                const eggData = await eggResponse.json();
                if (eggData.errors) throw new Error(eggData.errors[0].detail);
                const startup_cmd = (eggData.attributes?.startup || eggData.data?.[0]?.attributes?.startup);
                if (!startup_cmd) throw new Error('✗ Startup command untuk egg tidak ditemukan.');

                await createServer(lulli, m, func, cfg, jid, startup_cmd, panelUser, {
                    username: username,
                    password: null,
                    ram: packageConfig.name,
                    memory: packageConfig.memory,
                    disk: packageConfig.disk,
                    cpu: packageConfig.cpu
                });
            } catch (error) {
                console.error("✗ Error in add_server session:", error);
                await m.reply('✗ Terjadi kesalahan saat menambahkan server: ' + error.message + '\n\n- Silahkan hubungi owner jika terjadi kendala.', m);
                if (paymentModule) paymentModule.deleteSession(buyerData.number, global.db.panel);
            }
            break;
        }

        case 'create_new': {
            if (m.isPrefix) return;
            
            const username = userResponse;
            if (username.includes(' ')) return m.reply('✗ Username tidak boleh menggunakan spasi.');
            if (username.length > 10) return m.reply('✗ Username tidak boleh melebihi 10 karakter.');
            
            const jid = buyerData.number;
            const packageConfig = buyerData.data;
            const email = username.toLowerCase() + "@sweetrabit.ml";
            const password = username.toLowerCase() + Math.floor(Math.random() * 10000);
            
            try {
                const createUserResponse = await fetch(`${cfg.panelApi.domain}/api/application/users`, {
                    method: "POST",
                    headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + cfg.panelApi.apikey },
                    body: JSON.stringify({
                        "email": email, "username": username, "first_name": username, "last_name": username,
                        "language": "en", "password": password
                    })
                });
                const userData = await createUserResponse.json();
                if (userData.errors) throw new Error(userData.errors[0].detail);
                const panelUser = userData.attributes;

                const accountDetailsCaption = `✦ Berikut data akun panel Anda:\n` +
                                             `- Username: ${panelUser.username}\n` +
                                             `- Password: ${password}\n` +
                                             `- Link: ${cfg.panelApi.domain}\n` +
                                             `- Timeout: 30 detik\n\n` +
                                             `✦ *Harap simpan akun panel Anda dengan baik. Kami tidak bertanggung jawab jika Anda lupa password*.`;
                
                await lulli.reply(m.chat, accountDetailsCaption, m);
                
                const eggResponse = await fetch(`${cfg.panelApi.domain}/api/application/nests/5/eggs/${cfg.panelApi.eggs}`, {
                    method: "GET",
                    headers: { "Accept": "application/json", "Authorization": "Bearer " + cfg.panelApi.apikey }
                });
                const eggData = await eggResponse.json();
                if (eggData.errors) throw new Error(eggData.errors[0].detail);
                const startup_cmd = (eggData.attributes?.startup || eggData.data?.[0]?.attributes?.startup);
                if (!startup_cmd) throw new Error('✗ Startup command untuk egg tidak ditemukan.');

                await createServer(lulli, m, func, cfg, jid, startup_cmd, panelUser, {
                    username: username,
                    password: password,
                    ram: packageConfig.name,
                    memory: packageConfig.memory,
                    disk: packageConfig.disk,
                    cpu: packageConfig.cpu
                });

            } catch (error) {
                console.error("✗ Error in create_new session:", error);
                await m.reply('✗ Terjadi kesalahan saat membuat akun/server panel: ' + error.message + '\n\n> silahkan hubungi owner jika terjadi kendala.', m);
                if (paymentModule) paymentModule.deleteSession(buyerData.number, global.db.panel);
            }
            break;
        }
    }
    await createTimeout(m, lulli, buyerData, 3);
};


export default {
    run,
    main,
    cmd: 'buypanel',
    alias: 'panel',
    type: 'buyer',
    location: 'plugins/buyer/buypanel.js'
};
