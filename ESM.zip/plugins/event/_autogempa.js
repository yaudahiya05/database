let fs=require("fs");module.exports={main:async(a,d)=>{let t="./database/lastEarthquake.json",p=(fs.existsSync(t)||fs.writeFileSync(t,JSON.stringify({},null,2)),"https://data.bmkg.go.id/DataMKG/TEWS/");p;d.autogempa||!d.user||d.user.jadibot||(d.autogempa=setInterval(async function(){var m=await(async()=>{try{return(await(await fetch("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json")).json()).Infogempa.gempa}catch(a){console.error("Error fetching earthquake data:",a)}})(),a=await(fs.existsSync(t)?JSON.parse(fs.readFileSync(t)):null);!m||a&&m.Tanggal===a.Tanggal&&m.Jam===a.Jam||(a=m,await fs.writeFileSync(t,JSON.stringify(a,null,2)),(async a=>{var{Wilayah:a,Tanggal:t,Jam:e,Lintang:n,Bujur:i,Potensi:s,Magnitude:r,Kedalaman:g,Coordinates:o,Dirasakan:l,Shakemap:u}=m;let c="*AUTO GEMPA BUMI*";c=(c=(c=(c=(c+=`

- *Wilayah*: `+a)+`
- *Tanggal*: `+t+`
- *Waktu*: `+e)+`
- *Potensi*: `+s+`
- *Lintang*: `+n)+`
- *Bujur*: `+i+`
- *Magnitude*: `+r)+`
- *Kedalaman*: `+g+`
- *Koordinat*: `+o,l&&3<l.length&&(c+=`
- *Dirasakan*: `+(Array.isArray(l)?l.join(", "):l)),a=cfg.id.group,await d.sendMessage(a,{image:{url:p+u},caption:c},{ephemeralExpiration:604800})})())},6e5))},location:"plugins/event/_autogempa.js"};