const main = async (m, lulli, { func, groups, users, setting }) => {
    if (m.budy && users && users.afk > 0 && !/(reactionMessage|protocolMessage)/.test(m.mtype) && !groups.mute) {
        // if (users.premium && !/^stopafk$/i.test(m.budy)) return;
        let alasan = users.reason ? users.reason : 'Tidak ada alasan';
        let waktu = func.afkTime(Date.now() - users.afk);
        let key = await lulli.sendMessageModify(m.chat, `*Alasan*: ${alasan}\n*Selama*: ${waktu}`, users.afkObj || null, {
            title: m.pushname,
            body: 'telah kembali dari AFK',
            thumbUrl: setting.cover,
            largeThumb: false,
            url: setting.link || 'https://iyaudah-iya.vercel.app',
            expiration: m.expiration
        });

        users.afk = 0;
        users.reason = '';
        users.afkObj = null;
        
        return true;
    }

    let AFK_mentioned = [];
    if (m.mentionedJid) AFK_mentioned.push(...m.mentionedJid);
    if (m.quoted && global.db.users[m.quoted.sender] && !global.db.users[m.quoted.sender].premium) {
        AFK_mentioned.push(m.quoted.sender);
    }
    AFK_mentioned = [...new Set(AFK_mentioned)];

    for (let jid of AFK_mentioned) {
        let user = global.db.users[jid];
        if (!user || !user.afk || user.afk < 0) continue;
        if (lulli.user.id === jid) continue;
        let reason = user.alasan || '';
        if (!m.fromMe && AFK_mentioned.length < 10 && !groups.mute && !/setalasan/.test(m.command)) {
            let caption = `✗ Jangan tag dia!\nDia sedang AFK ${reason ? 'dengan alasan: ' + '“' + reason + '“' : ''}\nSelama *${func.clockString(Date.now() - user.afk)}*`;
            await lulli.reply(m.chat, caption.trim(), m, { expiration: m.expiration });
        }
    }
    return false;
};

export default {
    main,
    group: true,
    location: 'plugins/event/_afkdetector.js'
};