const main = async (m, lulli, { func, groups, errorMessage, cfg }) => {
    try {
        const allowedGroupIds = [cfg.id.group, '120363185217910448@g.us'].filter(Boolean);
        if (!allowedGroupIds.includes(m.chat)) return;

        if (m.budy && m.budy.match(/(whatsapp.com\/channel)/gi) && !m.isAdmin && !m.isOwner) {
            return await lulli.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: m.key.id,
                    participant: m.sender
                }
            });
        } else {
            const newsletterMessage = m.msg?.contextInfo?.forwardedNewsletterMessageInfo;
            if (newsletterMessage && !m.isAdmin && !m.isOwner) {
                if (['120363261409301854@newsletter'].includes(newsletterMessage.newsletterJid)) return;
                let text = `*Newsletter Message Detected*\n\n` +
                           `- JID Channel: ${newsletterMessage.newsletterJid}\n` +
                           `- Nama Channel: ${newsletterMessage.newsletterName || 'Tidak Diketahui'}`;
                await lulli.reply(m.chat, text, m, {
                    expiration: m.expiration
                });
                return await lulli.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.sender
                    }
                });
            }
        }
    } catch (e) {
        console.error("✗ Error in antilinkch.js:", e);
        return errorMessage(e);
    }
};

export default {
    main,
    group: true,
    botAdmin: true,
    location: 'plugins/event/antilinkch.js'
};