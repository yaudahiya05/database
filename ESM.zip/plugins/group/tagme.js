const run = async (m, lulli, { func }) => {
    await lulli.reply(m.chat, func.tag(m.sender), m, {
        expiration: m.expiration
    });
};

export default {
    run,
    cmd: 'tagme',
    type: 'group',
    group: true,
    desc: 'Tags yourself.',
    location: 'plugins/group/tagme.js'
};