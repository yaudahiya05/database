const run = async (m, lulli) => {
    try {
        const inviteCode = await lulli.groupInviteCode(m.chat);
        const url = 'https://chat.whatsapp.com/' + inviteCode;
        lulli.sendMessage(m.chat, {
            text: `Link ${m.groupName}: ${url}`
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    } catch (e) {
        await m.reply(`✗ Failed to get group link. Error: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'linkgroup',
    alias: ['linkgrup', 'linkgc'],
    type: 'group',
    group: true,
    botAdmin: true,
    location: 'plugins/group/linkgroup.js'
};