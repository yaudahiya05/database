const run = async (m, lulli, {}) => {
    const groupData = Object.values(global.db.groups || {}).filter(x => x.vip);
    if (!groupData || groupData.length === 0) {
        return m.reply('✦ No VIP group data found.');
    }
    let caption = '✦ *V I P - G R O U P - L I S T*';
    groupData.forEach((group, index) => {
        caption += `\n\n${index + 1}. ${group.name}\n✦ ID: ${group.jid}`;
    });

    await m.reply(caption);
};

export default {
    run,
    cmd: 'listvipgc',
    alias: 'listgcvip',
    use: 'Displays a list of all VIP groups registered with the bot.',
    type: 'developer',
    devs: true,
    desc: 'Shows a list of all groups that have VIP status.',
    location: 'plugins/special/listvipgc.js'
};