import PhoneNumber from 'awesome-phonenumber';

const getCountryFlag = (regionCode) => {
    if (!regionCode) return '🏳️';
    return regionCode
        .toUpperCase()
        .split('')
        .map((char) => String.fromCodePoint(0x1F1E6 + (char.charCodeAt(0) - 65)))
        .join('');
};

const run = async (m, lulli, {}) => {
    let regionNames = new Intl.DisplayNames(['en'], { type: 'region' });
    let data = m.metadata;
    let participants = data.participants;

    let countryMembers = {};
    for (let participant of participants) {
        let phoneNumber = '+' + participant.id.split('@')[0];
        let regionCode = new PhoneNumber(phoneNumber).getRegionCode();
        let country = 'Unknown';
        let flag = '🏳️';
        if (regionCode) {
            country = regionNames.of(regionCode) || 'Unknown';
            flag = getCountryFlag(regionCode);
        }
        if (!countryMembers[country]) {
            countryMembers[country] = { total: 0, flag };
        }
        countryMembers[country].total++;
    }

    let totalSum = participants.length;
    let totalRegion = Object.keys(countryMembers).length;
    let countryList = Object.entries(countryMembers)
        .map(([name, { total, flag }]) => `${flag} *${name}*: ${total} members`)
        .join('\n');
    let caption = `✦ *GROUP COUNTRY CHECKER*\n\n`;
    caption += `✧ Total Members: ${totalSum}\n`;
    caption += `✧ Total Regions: ${totalRegion}\n\n`;
    caption += `✧ Country List:\n${countryList || 'No country data found.'}`;
    await m.reply(caption);
};

export default {
    run,
    cmd: 'groupcountry',
    alias: ['country', 'region'],
    type: 'group',
    group: true,
    location: 'plugins/group/groupcountry.js'
};