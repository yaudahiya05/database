const run = async (m, lulli, { func, froms }) => {
    const displayPartnerStatus = async (targetJid, isTaggedUser = false) => {
        const targetUserData = global.db.users[targetJid];
        const mentionText = isTaggedUser ? 'The person you tagged' : 'You';

        if (!targetUserData) {
            return m.reply('✗ User data not found.');
        }

        const partnerId = targetUserData.pasangan?.id;
        const partnerTime = targetUserData.pasangan?.time;

        if (!partnerId) {
            return m.reply(`✦ ${mentionText} does not have a partner and is not proposing to anyone.\n\n✦ Send *${m.prefix}propose @tag* to propose to someone.`);
        }

        const partnerUserData = global.db.users[partnerId];
        if (!partnerUserData) {
            return m.reply('✗ Partner data not found in the database.');
        }

        if (partnerUserData.pasangan?.id === targetJid) {
            const timeTogether = func.toTime(Date.now() - partnerTime);
            return m.reply(`✓ ${mentionText} is in a relationship with @${partnerId.split('@')[0]} 🥳🥳\nFor ${timeTogether}`);
        } else {
            return m.reply(`✦ ${mentionText} is being left hanging by @${partnerId.split('@')[0]} as the proposal has not been accepted or rejected.\n\n✦ Send *${m.prefix}letgo* to remove them from your heart.`);
        }
    };

    if (m.quoted || m.text) {
        if (froms) {
            await displayPartnerStatus(froms, true);
        } else {
            return m.reply('✗ Please tag/reply to the user you want to check.');
        }
    } else {
        await displayPartnerStatus(m.sender, false);
    }
};

export default {
    run,
    cmd: 'cekpacar',
    use: 'mention or reply',
    type: 'group',
    group: true,
    location: 'plugins/group/cekpacar.js'
};