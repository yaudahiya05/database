const run = async (m, lulli, { cfg, func, users, setting }) => {
    switch (m.command) {
        case 'afk': {
            if (m.text && m.text.length > 1000 && !m.isDevs) return m.reply('✗ Maximum 1000 characters for AFK reason.');
            if (m.message) {
                delete m.message.messageContextInfo;
            }
            let afkObj = {
                key: m.key,
                message: m.message
            };
            let reason = m.text ? m.text : '';
            users.reason = reason;
            users.afkObj = afkObj;
            if (users.afk < 1) {
                users.afk = Date.now();
            }
            await m.reply(`✓ ${m.pushName} is now AFK${reason ? '\nReason: ' + reason : ''}`);
            break;
        }

        case 'setafk': {
            if (!m.isOwner) return m.reply('✗ This command can only be used by the owner.');
            if (m.text && isNaN(m.text)) return m.reply('✗ Time must be a number (milliseconds).');
            if (!m.quoted) return m.reply('✗ Reply to the target message!');
            const targetJid = m.quoted.sender;
            const afkTime = m.text ? parseInt(m.text) : Date.now();
            if (global.db.users[targetJid]) {
                global.db.users[targetJid].afk = afkTime;
            } else {
                return m.reply('✗ Target user not found in the database.');
            }
            lulli.sendReact(m.chat, '✅', m.key);
            break;
        }

        case 'setalasan': {
            if (!m.isOwner) return m.reply('✗ This command can only be used by the owner.');
            if (!m.text) return m.reply('✗ Please enter the reason!');
            if (!m.quoted) return m.reply('✗ Reply to the target message!');
            const targetJidReason = m.quoted.sender;
            if (global.db.users[targetJidReason]) {
                global.db.users[targetJidReason].reason = m.text;
            } else {
                return m.reply('✗ Target user not found in the database.');
            }
            if (m.key) {
                lulli.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.key.id, participant: m.sender } });
            }
            break;
        }

        case 'listafk': {
            const afkData = Object.values(global.db.users || {}).filter(v => v.afk && v.afk > 0);
            if (afkData.length === 0) return m.reply('✦ No users are currently AFK.');
            let caption = `✦ *AFK USERS LIST*\nTotal: *${afkData.length}*\n`;
            caption += afkData.map((v, i) => 
                `\n${i + 1}. @${v.jid.split('@')[0]}\n` +
                `✧ Reason: ${v.reason ? v.reason : '-'}\n` +
                `✧ Duration: ${func.clockString(Date.now() - v.afk)}`
            ).join('\n');
            await m.reply(caption);
            break;
        }
    }
};

export default {
    run,
    cmd: ['afk', 'setafk', 'setalasan', 'listafk'],
    type: 'group',
    restrict: true,
    group: true,
    location: 'plugins/group/afk.js'
};