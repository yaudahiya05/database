const run = async (m, lulli, { froms }) => {
    if (!froms) {
        return m.reply('✗ Please mention or reply to a message.');
    }
    await lulli.sendMessage(m.chat, {
        text: `@${froms.replace(/[^0-9]/gi, '')}`,
        mentions: [froms]
    });
};

export default {
    run,
    cmd: 'tag',
    type: 'group',
    group: true,
    location: 'plugins/group/tag.js'
};