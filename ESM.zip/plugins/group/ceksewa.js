const run = async (m, lulli, { func, groups }) => {
    if (!groups.sewa || !groups.sewa.status) {
        return m.reply(`✗ This group is not registered in the bot rental list. Type ${m.prefix}listrent for more info.`);
    }

    let caption = `✦ *GROUP RENTAL CHECK*\n`;
    caption += `\n✧ Name: ${m.groupName}`;
    caption += `\n✧ ID: ${m.chat}`;
    caption += `\n✧ VIP: ${groups.sewa?.vip ? '✅' : '❌'}`;
    caption += `\n✧ Expire: ${/PERMANENT/.test(groups.sewa?.expired) ? 'PERMANENT' : func.expireTime(groups.sewa?.expired)}`;
    await m.reply(caption);
};

export default {
    run,
    cmd: 'ceksewa',
    alias: 'checksewa',
    type: 'group',
    group: true,
    location: 'plugins/group/ceksewa.js'
};