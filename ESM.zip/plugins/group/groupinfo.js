import moment from 'moment-timezone';
import { areJidsSameUser } from '@whiskeysockets/baileys';

const statusIndicator = (boolean) => {
    return boolean ? '✓' : '✗';
};

const run = async (m, lulli, { func, cfg, groups, lid }) => {
    groups = groups || {};
    groups.sewa = groups.sewa || { expired: 0 };
    const metadata = await lulli.groupMetadata(m.chat);
    lid.convertLidParticipants(metadata);
    const admin = metadata.participants.filter(v => v.admin);
    const pic = await func.fetchBuffer(await lulli.profilePictureUrl(m.chat, 'image').catch(() => 'https://telegra.ph/file/320b066dc81928b782c7b.png'));
    let caption = `✧ *GROUP INFO*\n\n`;
	caption += `Name: ${metadata.subject}\n`;
	caption += `ID: ${metadata.id}\n`;
	caption += `Owner: ${metadata.ownerPn ? '@' + metadata.ownerPn.split('@')[0] : metadata.owner ? '@' + metadata.owner.split('@')[0] : (m.chat.match('-') ? '@' + m.chat.split('-')[0] : '-')}\n`;
	caption += `Addressing Mode: ${metadata.addressingMode}\n`;
	caption += `Created: ${moment(metadata.creation * 1000).format('DD/MM/YY HH:mm:ss')}\n`;
	caption += `Member: ${metadata.participants.length}\n`;
	caption += `Admin: ${admin.length}\n\n`;

	caption += `✧ *GROUP SETTING*\n\n`;
	caption += `${statusIndicator(groups.welcome)} Welcome Message\n`;
	caption += `${statusIndicator(groups.goodbye)} Goodbye Message\n`;
	caption += `${statusIndicator(groups.detect)} Detect Message\n`;
	caption += `${statusIndicator(groups.antitoxic)} Anti Toxic\n`;
	caption += `${statusIndicator(groups.antilink)} Anti Link\n`;
	caption += `${statusIndicator(groups.antivirtex)} Anti Virtex\n`;
	caption += `${statusIndicator(groups.antibot)} Anti Bot\n`;
	caption += `${statusIndicator(groups.antiluar)} Anti Outside\n`;
	caption += `${statusIndicator(groups.antihidetag)} Anti Hidetag\n`;
	caption += `${statusIndicator(groups.antidelete)} Anti Deleted\n`;
	caption += `${statusIndicator(groups.antiedited)} Anti Edited\n`;
	caption += `${statusIndicator(groups.antiporn)} Anti Porn\n`;
	caption += `${statusIndicator(groups.antihacked)} Anti Hacked\n`;
	caption += `${statusIndicator(groups.antigsm)} Anti Group Status Mention\n`;
	caption += `${statusIndicator(groups.autosholat)} Auto Sholat/Adzan\n`;
	caption += `${statusIndicator(groups.autokicksider)} Auto Kick Sider\n\n`;

	caption += `✧ *GROUP STATUS*\n\n`;
	caption += `Muted: ${statusIndicator(groups.mute)}\n`;
	caption += `Send messages: ${metadata.announce ? 'Admins only' : 'All participants'}\n`;
	caption += `Edit group info: ${metadata.restrict ? 'Admins only' : 'All participants'}\n`;
	caption += `Bot Rental Expired: ${groups.sewa.expired === 0 ? '-' : func.timeReverse(groups.sewa.expired)}`;

    await lulli.sendMessageModify(m.chat, caption, m, {
        largeThumb: true,
        thumbnail: pic,
        expiration: m.expiration
    });
};

export default {
    run,
    cmd: 'groupinfo',
    alias: ['infogroup', 'gcinfo'],
    type: 'group',
    group: true,
    location: 'plugins/group/groupinfo.js'
};