import ms from 'parse-ms';

function timeReverse(duration) {
    let cek = ms(duration - Date.now());
    let d = cek.days;
    let h = cek.hours;
    let m = cek.minutes;
    let s = cek.seconds;

    let dDisplay = d > 0 ? d + 'd' : '';
    let hDisplay = h > 0 ? (d > 0 ? ' ' : '') + h + 'h' : '';
    let mDisplay = m > 0 ? (h > 0 ? ' ' : '') + m + 'm' : '';
    let sDisplay = s > 0 ? (m > 0 ? ' ' : '') + s + 's' : '';

    let result = [dDisplay, hDisplay, mDisplay, sDisplay].filter(Boolean).join(' ');
    return result || '0s';
}

const run = async (m, lulli, {}) => {
    const groupsadmin = m.metadata.participants.filter(v => v.admin);
    const groupMembersDb = global.db.groups[m.chat]?.member || {};
    let listadmin = groupsadmin.map((v, i) => {
        const memberInfo = groupMembersDb[v.id];
        let expirationText = '';
        if (memberInfo && memberInfo.admin && memberInfo.expired !== 0) {
            expirationText = ` _*(${timeReverse(memberInfo.expired)})*_`;
        }
        return `${i + 1}. @${v.id.split('@')[0]}${expirationText}`;
    }).join('\n');

    let caption = '乂 *L I S T - A D M I N*\n\n';
    caption += `- Total: ${groupsadmin.length}\n`;
    caption += listadmin;
    await lulli.sendMessage(m.chat, {
        text: caption,
        mentions: groupsadmin.map(v => v.id)
    }, {
        quoted: m,
        ephemeralExpiration: m.expiration
    });
};

export default {
    run,
    cmd: 'listadmin',
    alias: 'adminlist',
    type: 'group',
    group: true,
    location: 'plugins/group/listadmin.js'
};