const run = async (m, lulli, { cfg, date, groups, socket }) => {
    let caption;
    let absenData = groups.absen;
    
    if (!absenData) {
        groups.absen = {
            status: false,
            reason: '-',
            date: '',
            participants: [],
            key: []
        };
        absenData = groups.absen;
    }

    const buttons = [
        ['Absen', m.prefix + 'absen']
    ];

    switch (m.command) {
        case 'mulaiabsen': {
            if (!m.isAdmin && !m.isOwner) return m.reply('✗ You are not authorized to use this command.');
            if (absenData.status) return m.reply(`✗ An attendance session is already active in this group. Send *${m.prefix}hapusabsen* to remove it.`);
            groups.absen = {
                status: true,
                reason: m.text ? m.text : '-',
                date: date,
                participants: [],
                key: []
            };
            caption = `✦ *ATTENDANCE STARTED*\n\n- Date: ${groups.absen.date}\n- Reason: ${groups.absen.reason}`;
            const mentions = groups.absen.participants.map(x => x.jid);
            const { key: newKey } = await lulli.sendbut(m.chat, caption.trim(), 'click the button below to attend', buttons, m, {
                caption: caption + `\n\nSend *${m.prefix}absen* to mark attendance`,
                mentions,
                expiration: m.expiration
            });
            groups.absen.key.push({
                ...newKey,
                botId: lulli.user.jid
            });
            break;
        }

        case 'absen':
        case 'attend': {
            if (!absenData.status) return m.reply(`✗ No attendance session is active in this group!`);
            let isAbsen = absenData.participants.some(x => x.jid === m.sender);
            if (isAbsen) return m.reply('✗ You have already marked attendance!');
            if (m.text && m.text.length > 30) return m.reply('✗ Maximum 30 characters allowed.');
            groups.absen.participants.push({
                jid: m.sender,
                text: m.text || ''
            });
            caption = `乂 *A T T E N D A N C E*\n\n- Date: ${absenData.date}\n- Reason: ${absenData.reason}\n- Total: ${absenData.participants.length}\n- Attendance List: ${absenData.participants.length < 1 ? '-' : formatAbsen(absenData.participants)}`;
            if (groups.absen.key.length > 0) {
                for (const oldKey of groups.absen.key) {
                    const clientToSend = socket.get(oldKey.botId) || lulli;
                    try {
                        await clientToSend.sendMessage(oldKey.remoteJid, { delete: oldKey });
                    } catch (error) {
                        // Error deleting message, but continue process
                    }
                }
                groups.absen.key = [];
            }
            const mentions = groups.absen.participants.map(x => x.jid);
            const { key: updatedKey } = await lulli.sendbut(m.chat, caption.trim(), 'click the button below to attend', buttons, m, {
                caption: caption + `\n\nSend *${m.prefix}absen* to mark attendance`,
                mentions,
                expiration: 86400
            });
            groups.absen.key.push({
                ...updatedKey,
                botId: lulli.user.jid
            });
            break;
        }

        case 'cekabsen': {
            if (!absenData.status) return m.reply('✗ No attendance session is active!');
            caption = `乂 ${m.groupName}\n\n- Date: ${absenData.date}\n- Reason: ${absenData.reason}\n- Total: ${absenData.participants.length}\n- Attendance List: ${absenData.participants.length < 1 ? '-' : formatAbsen(absenData.participants)}\n\nSend *${m.prefix}absen* to mark attendance`;
            await m.reply(caption.trim());
            break;
        }

        case 'hapusabsen': {
            if (!m.isAdmin && !m.isOwner) return m.reply('✗ You are not authorized to use this command.');
            if (!absenData.status) return m.reply('✗ No attendance session is active!');
            groups.absen = {
                status: false,
                reason: '-',
                date: '',
                participants: [],
                key: []
            };
            await m.reply('✓ Attendance session successfully deleted.');
            break;
        }
    }
};

function formatAbsen(participants) {
    if (!Array.isArray(participants) || participants.length === 0) return '-';
    return '\n' + participants.map((item, index) => 
        `${index + 1}. @${item.jid.split('@')[0]} ${item.text ? `(${item.text})` : ''}`
    ).join('\n');
}

export default {
    run,
    cmd: [
        'mulaiabsen',
        'absen',
        'cekabsen',
        'hapusabsen',
    ],
    alias: [
         'attend',
    ],
    use: '[reason]',
    type: 'group',
    group: true,
    location: 'plugins/group/absen.js'
};