const run = async (m, lulli, { cfg, froms }) => {
    switch (m.command) {
        case 'getname': {
            if (m.quoted || m.text) {
                if (!froms) return m.reply('✗ Please mention or reply to the target chat.');
                let name;
                if (global.db.users && global.db.users[froms] && global.db.users[froms].name) {
                    name = global.db.users[froms].name;
                } else {
                    name = await lulli.getName(froms);
                }
                await m.reply(name);
            } else {
                m.reply('✗ Please mention or reply to the target chat.');
            }
            break;
        }

        case 'getpp': {
            if (m.quoted || m.text) {
                if (!froms) return m.reply('✗ Please mention or reply to the target chat.');
                const isOwnerOrDev = [cfg.owner, ...(cfg.devs || []), ...(global.suryadev || [])].includes(froms);
                if (isOwnerOrDev && !m.isDevs) return m.reply('✗ Access denied.');
                lulli.sendReact(m.chat, '🕒', m.key);
                let pporang = await lulli.profilePictureUrl(froms, 'image').catch(() => '');
                if (pporang) {
                    await lulli.sendMessage(m.chat, {
                        image: { url: pporang },
                        caption: `Profile picture of @${froms.split('@')[0]}`,
                        mentions: [froms]
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                    lulli.sendReact(m.chat, '✅', m.key);
                } else {
                    await m.reply('✗ Failed! Profile is private or has no profile picture.');
                    lulli.sendReact(m.chat, '❌', m.key);
                }
            } else {
                m.reply('✗ Please mention or reply to the target chat.');
            }
            break;
        }

        case 'getbio': {
            if (m.quoted || m.text) {
                if (!froms) return m.reply('✗ Please mention or reply to the target chat.');
                let bionya = (await lulli.fetchStatus(froms).catch(() => {
                    return {};
                }) || {}).status || '✗ Bio is private or not found!';
                await m.reply(bionya);
            } else {
                m.reply('✗ Please mention or reply to the target chat.');
            }
            break;
        }
    }
};

export default {
    run,
    cmd: [
        'getname',
        'getpp',
        'getbio'
    ],
    use: 'mention or reply',
    type: 'group',
    limit: true,
    location: 'plugins/group/getname.js'
};