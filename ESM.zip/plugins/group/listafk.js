async function run(a,n,{func:l}){var t=Object.values(global.db.users).filter(a=>0<a.afk);if(0==t.length)return a.reply("Data kosong.");var o=`*DAFTAR PENGGUNA AFK*
Total : *${t.length}*
`;o+=t.map((a,n)=>`
${n+1}. @${a.jid.split("@")[0]}
◦  Reason: ${a.alasan??"tanpa alasan"}
◦  Selama: `+l.clockString(Date.now()-a.afk)).join("\n"),await a.reply(o)}module.exports={run:run,cmd:"listafk",type:"group",group:!0,location:"plugins/group/listafk.js"};