import { createCanvas, loadImage } from 'canvas';
import { getUserChatCount } from '../../lib/totalchat.js';

if (typeof Number.prototype.rupiah !== 'function') {
    Number.prototype.rupiah = function () {
        return this.toLocaleString('en-US');
    };
}

async function totalchatCanvas(name, profileImageUrl, groupName, totalchat) {
    const canvasWidth = 720;
    const canvasHeight = 200;
    const padding = 15;
    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#181818';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    const profileImage = await loadImage(profileImageUrl);
    const imageSize = 115;
    const imageX = padding + 10;
    const imageY = (canvasHeight - imageSize) / 2;
    const borderRadius = 20;

    ctx.save();
    ctx.beginPath();
    ctx.moveTo(imageX + borderRadius, imageY);
    ctx.lineTo(imageX + imageSize - borderRadius, imageY);
    ctx.arcTo(imageX + imageSize, imageY, imageX + imageSize, imageY + borderRadius, borderRadius);
    ctx.lineTo(imageX + imageSize, imageY + imageSize - borderRadius);
    ctx.arcTo(imageX + imageSize, imageY + imageSize, imageX + imageSize - borderRadius, imageY + imageSize, borderRadius);
    ctx.lineTo(imageX + borderRadius, imageY + imageSize);
    ctx.arcTo(imageX, imageY + imageSize, imageX, imageY + imageSize - borderRadius, borderRadius);
    ctx.lineTo(imageX, imageY + borderRadius);
    ctx.arcTo(imageX, imageY, imageX + borderRadius, imageY, borderRadius);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(profileImage, imageX, imageY, imageSize, imageSize);
    ctx.restore();

    const textX = imageX + imageSize + 20;
    const baseFontSize = canvasWidth / 25;
    const titleFontSize = Math.max(baseFontSize, 28);
    const subTextFontSize = titleFontSize * 0.65;
    const smallTextFontSize = titleFontSize * 0.6;
    const titlePaddingTop = 30;

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${titleFontSize}px Inter`;
    ctx.fillText(name, textX, imageY + titlePaddingTop);

    const subTextPaddingTop = 40 + subTextFontSize + 5;
    ctx.fillStyle = '#D1D5DB';
    ctx.font = `${subTextFontSize}px Inter`;
    ctx.fillText('XEoms Meta Client', textX, imageY + subTextPaddingTop);

    const chatIcon = await loadImage('https://files.catbox.moe/yzcz62.png');
    const chatIconSize = 26;
    const chatIconX = textX;
    const chatIconY = imageY + subTextPaddingTop + 15;
    ctx.drawImage(chatIcon, chatIconX, chatIconY, chatIconSize, chatIconSize);

    const chatTextPaddingTop = chatIconY + chatIconSize - 5;
    ctx.font = `${smallTextFontSize}px Inter`;
    ctx.fillText(`${totalchat} chats`, chatIconX + chatIconSize + 10, chatTextPaddingTop);

    const globeIcon = await loadImage('https://files.catbox.moe/2b9s3p.png');
    const globeSize = 36;
    const globeX = canvasWidth - globeSize - padding - 30;
    const globeY = (canvasHeight - globeSize) / 2;
    ctx.drawImage(globeIcon, globeX, globeY, globeSize, globeSize);

    const buffer = canvas.toBuffer('image/png');
    return buffer;
}

const run = async (m, lulli, { setting }) => {
    lulli.sendReact(m.chat, '🕒', m.key);
    const profile = await lulli.profilePictureUrl(m.sender, 'image').catch(() => setting.cover);
    const userChatCount = getUserChatCount(m.chat, m.sender);

    if (!userChatCount) {
        return m.reply('✗ Your data not found.');
    }
    const buffer = await totalchatCanvas(m.pushName, profile, m.groupName || 'Unknown Group', userChatCount.rupiah());
    lulli.sendMessage(m.chat, {
        image: buffer
    }, {
        quoted: m,
        ephemeralExpiration: m.expiration
    });
};

export default {
    run,
    cmd: 'totalchatme',
    alias: 'tcm',
    type: 'group',
    group: true,
    limit: true,
    location: 'plugins/group/totalchatme.js'
};