const run = async (m, lulli, {}) => {
    if (!global.giveawayParticipants || !global.giveawayParticipants[m.chat]) {
        await m.reply(`✧ Giveaway has not started! Admin can start it with the command *${m.prefix}giveaway*`);
        return;
    }

    if (global.giveawayParticipants[m.chat].has(m.sender)) {
        await m.reply(`✧ @${m.sender.split('@')[0]}, you have already joined the giveaway!`);
        return;
    }

    global.giveawayParticipants[m.chat].add(m.sender);
    await m.reply(`✓ @${m.sender.split('@')[0]} has joined the giveaway!`);
};

export default {
    run,
    cmd: 'ikut',
    type: 'group',
    group: true,
    location: 'plugins/group/ikut.js'
};