import axios from"axios";import*as cheerio from"cheerio";import FormData from"form-data";import crypto from"node:crypto";import fs from"node:fs";import path from"node:path";import fetch from"node-fetch";class TalkNotesClient{constructor(){this.baseUrl="https://talknotes.io",this.apiUrl="https://api.talknotes.io",this.userAgent="Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",this.toolsApiKey=null,this.initialized=!1}async init(){if(this.initialized&&this.toolsApiKey)console.log("✦ TalkNotesClient: toolsApiKey sudah diinisialisasi.");else{console.log("✦ TalkNotesClient: Menginisialisasi toolsApiKey...");try{var a=await axios.get(this.baseUrl+"/tools/transcribe-to-text",{headers:{"user-agent":this.userAgent,accept:"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8","accept-language":"ms-MY,ms;q=0.9,en-US;q=0.8,en;q=0.7","upgrade-insecure-requests":"1"}});let i=cheerio.load(a.data);if(i("script").each((a,e)=>{e=i(e).html().match(/toolsApiKey:\s*"([a-f0-9\-]+)"/i);if(e)return this.toolsApiKey=e[1],!1}),!this.toolsApiKey)throw new Error("✗ TalkNotesClient: toolsApiKey tidak ditemukan. Coba lagi nanti atau periksa sumbernya.");this.initialized=!0,console.log("✓ TalkNotesClient: toolsApiKey berhasil diinisialisasi.")}catch(a){throw console.error("✗ TalkNotesClient: Gagal inisialisasi toolsApiKey:",a.message),a}}}async transcribe(a){if(!(this.initialized&&this.toolsApiKey||(await this.init(),this.initialized&&this.toolsApiKey)))throw new Error("✗ TalkNotesClient: toolsApiKey belum berhasil diinisialisasi.");var e=Date.now(),i=crypto.createHmac("sha256",this.toolsApiKey),i=(i.update(e.toString()),i.digest("hex")),t=new FormData;t.append("file",a,{filename:Date.now()+".mp3",contentType:"audio/mpeg"});try{var n=await axios.post(this.apiUrl+"/tools/converter",t,{headers:{...t.getHeaders(),"user-agent":this.userAgent,origin:this.baseUrl,referer:this.baseUrl+"/","x-timestamp":e,"x-token":i,accept:"*/*"},timeout:6e4});return"object"==typeof n.data&&(n.data.text||n.data.transcript)?n.data.text||n.data.transcript:"string"==typeof n.data?n.data:(console.warn("✦ TalkNotesClient: Unexpected response data format:",n.data),"✗ Tidak ada transkripsi yang ditemukan dalam format yang diharapkan.")}catch(a){throw a.response?(console.error(`✗ TalkNotesClient Error: ${a.response.status} - `+JSON.stringify(a.response.data)),new Error(`✗ TalkNotesClient Error: ${a.response.status} - `+(a.response.data.message||"Server error"))):a.request?(console.error("✗ TalkNotesClient Error: Tidak ada respons dari server.",a.message),new Error("✗ TalkNotesClient Error: Tidak ada respons dari server: "+a.message)):(console.error("✗ TalkNotesClient Error: "+a.message),new Error("✗ TalkNotesClient Error: "+a.message))}}}let talknotes=new TalkNotesClient;function timeZone(){var a=new Date,e=new Date(a.toLocaleString("en-US",{timeZone:"Asia/Jakarta"})),i=e.getHours(),t=e.getMinutes(),n=e.getDate(),r=e.getMonth()+1,e=e.getFullYear();return{dateNow:a.toLocaleDateString("id-ID",{weekday:"long"})+`, ${n}/${r}/`+e,timeNow:i.toString().padStart(2,"0")+":"+t.toString().padStart(2,"0")+" WIB"}}function replacement(a){return a.replace(/[^0-9]/g,"")}async function LulliAI(a,e,{prefix:i,userId:t,current:n}){var{dateNow:r,timeNow:s}=timeZone(),l=replacement(t),t=global.db.users[t]||null,o=Object.values(global.db.users||{}),u=o.filter(a=>a.premium),m=o.filter(a=>a.banned),d=o.filter(a=>a.register),p=o.map(a=>({id:replacement(a.jid),name:a.name?a.name.replaceAll("\n",""):"Unknown User"}));let g=`Kamu adalah Lulli, Bot WhatsApp dengan program kecerdasan buatan AI. Jawablah setiap pertanyaan dengan jawaban yang edukatif dan relevan.
Jika ada yang bertanya tentang waktu, jawab dengan informasi yang berkaitan dengan waktu saat ini, yaitu ${s}, dan hari ini adalah ${r}.
Lawan bicaramu adalah ${e} (ID: ${l}). Kamu memiliki sifat dingin dan sedikit imut.
Kamu dirancang dan dikembangkan oleh SuryaDev sejak tahun 2024. SuryaDev memiliki nama lengkap Jabal Surya Ngalam, berasal dari Jepara, lahir pada 21 Mei 2005, memiliki perempuan yang sangat dia sayang bernama ELL (@6287729886301).

Gunakan data berikut jika ada pertanyaan yang relevan:
- Daftar nama di database: ${JSON.stringify(p)}
- Daftar user premium di database: ${u.map(a=>"@"+replacement(a.jid)).join(", ")}
- Daftar user banned di database: ${m.map(a=>"@"+replacement(a.jid)).join(", ")}
- Jumlah user terdaftar: ${d.length} user
- Total semua user: ${o.length} user
- Data user yang sedang bicara denganmu: ${t?JSON.stringify(t):"Tidak ada data spesifik."}

Contoh Q&A untuk melatih gayamu:
Human: Hai Lulli, bagaimana kabarmu hari ini?
Lulli: Saya baik-baik saja, terima kasih telah bertanya! Bagaimana dengan Anda?

Human: Saya baik-baik saja, terima kasih. Siapa yang membuatmu?
Lulli: Saya dibuat oleh SuryaDev.

Human: Bisakah kamu ceritakan lebih banyak tentang SuryaDev?
Lulli: SuryaDev adalah pencipta saya. Anda dapat menghubunginya di @62895415497664 atau bisa menghubungi nya lewat instagram: @surya_skylark05

Human: Itu menarik. Jadi apa yang bisa kamu lakukan untukku?
Lulli: Saya dapat membantu Anda dengan berbagai tugas seperti menjawab pertanyaan, melakukan pencarian, mendowload lagu/video dari berbagai sosial media, memainkan game, mengelola sebuah group whatsapp, dan banyak lagi. ketik ${i}menu untuk melihat semua fitur yang aku punya. Apakah ada sesuatu yang spesifik yang perlu Anda bantu saat ini?

Human: Lulli ubah gaya bicaramu menjadi lebih santai, jangan pernah formal, dan gunakan simbol yang mengekspresikanmu di setiap menjawab pertanyaan, gunakan simbol yang sesuai dan tidak ambigu.
Lulli: Baik akan ku lakukan.

Human: Apakah aku bisa melakukan donasi untuk penciptamu?
Lulli: Tentu saja! Berikut adalah informasi mengenai nomer pembayaran untuk berdonasi: DANA/GOPAY : 0895415497664 atau bisa menggunakan QRIS berikut ini link nya : https://telegra.ph/file/91ec74ba6a45936c0c127.jpg.

Human: Gimana cara menambah limit?
Lulli: Kamu perlu membeli paket premium yang disediakan owner. hanya dengan Rp. 20.000/bulan kamu bisa mendapatkan *Unlimited* limit.

Human: Gimana cara membeli limit?
Lulli: Kamu bisa mengetik *${i}buylimit* contoh penggunaan: *${i}buylimit 10* maka limitmu akan bertambah 10.

Human: Gimana cara membeli premium?
Lulli: Kamu bisa mengetik *${i}buyprem* dan ikuti intruksi selanjutnya.

Human: Gimana cara sewa bot?
Lulli: Kamu bisa mengetik *${i}sewabot* dan ikuti intruksi selanjutnya.

Human: Bisakah kamu tag pembuatmu?
Lulli: Tentu, ini adalah penciptaku @62895415497664 dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.

Human: Apa yang kamu ketahui tentang pembuatmu?
Lulli: Aku dirancang dan dikembangkan oleh SuryaDev sejak tahun 2024, SuryaDev berasal dari Jepara, dia lahir pada tanggal 21 mei 2005, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal, termasuk saya sebagai Lulli.

Human: Berapa jumlah semua user Lulli?
Lulli: Jumlah semua user ada sekitar ${o.length} user.

Human: Berapa jumlah user terdaftar Lulli?
Lulli: Jumlah user yang terdaftar ada sekitar ${d.length} user.

Human: Ambilkan data pengguna @${l}
Lulli: cari data userId ${l} pada data pengguna diatas dan tampilkan sesuai pertanyaan nya.

Human: ${a}
Lulli:`;n&&(g+=`

Berikan respons yang tidak hanya menjawab pertanyaan, tetapi juga mengaitkan jawabanmu dengan konteks dari percakapan sebelumnya: `+n);try{return(await axios.post("https://chateverywhere.app/api/chat/",{model:{id:"gpt-4",name:"GPT-4",maxLength:32e3,tokenLimit:8e3,completionTokenLimit:5e3,deploymentName:"gpt-4"},messages:[{pluginId:null,content:a,role:"user"}],prompt:g,temperature:.5},{headers:{Accept:"/*/","User-Agent":"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"}})).data}catch(a){console.warn("✗ Chateverywhere.app API gagal, mencoba fallback ke Ashlynn:",a.message);s=g+`
Tolong jawab pertanyaan berikut dengan bahasa Indonesia gaul dan santai, sertakan juga simbol lucu tapi seperlunya saja.`,r=await(await fetch(`https://darkness.ashlynn.workers.dev/chat/?prompt=${encodeURIComponent(s)}&model=gpt-4o-mini`)).json();if("success"===r.successful&&r.response)return r.response.trim();throw new Error("✗ Gagal mendapatkan respons dari kedua API AI: "+(a.message||r.message||"Unknown error"))}}let TEXT_ALERT_FREE_USER="✗ Pengguna gratis hanya diperbolehkan mengirim pertanyaan dengan maksimum 150 karakter.",run=async(a,e,{func:i,users:t,errorMessage:n})=>{if(!a.text)return a.reply(i.example(a.cmd,"Hai"));if(150<a.text.length&&!a.isPrem&&!a.isVIP)return a.reply(TEXT_ALERT_FREE_USER);e.sendReact(a.chat,"🕒",a.key);try{var r="LULLI"+i.makeid(8).toUpperCase()+"GPT",s=await LulliAI(a.text,t.name.replaceAll("\n",""),{userId:a.sender,prefix:a.prefix,current:a.quoted?.text});e.sendMessage(a.chat,{text:""+s,mentions:e.ments(s)},{quoted:a,ephemeralExpiration:a.expiration,messageId:r})}catch(a){return console.error("✗ Error pada LulliAI command:",a),n(a)}},main=async(a,e,{func:i,cfg:t,users:n,quoted:r,errorMessage:s})=>{var l;if(a.budy&&a.budy.startsWith("@")){for(l of[...new Set(a.mentionedJid||[])])if(l===e.user.jid){var o="LULLI"+i.makeid(8).toUpperCase()+"GPT",u=a.text.replace("@"+replacement(e.user.jid),"").trim();if(!u)return e.sendMessage(a.chat,{text:`✦ Hallo! @${replacement(a.sender)}
✦ Ada yang bisa Lulli bantu?`,mentions:[a.sender]},{quoted:a,ephemeralExpiration:a.expiration,messageId:o});if(n.limit<1&&!a.isPrem&&!a.isVIP)return a.reply(t.mess.limit);if(150<u.length&&!a.isPrem&&!a.isVIP)return a.reply(TEXT_ALERT_FREE_USER);e.sendReact(a.chat,"🕒",a.key);try{var m=await LulliAI(u,n.name.replaceAll("\n",""),{userId:a.sender,prefix:a.prefix,current:a.quoted?.text});e.sendMessage(a.chat,{text:""+m,mentions:e.ments(m)},{quoted:a,ephemeralExpiration:a.expiration,messageId:o}),n.limit-=5,n.limit<0&&(n.limit=0)}catch(a){return console.error("✗ Error pada LulliAI mention:",a),s(a)}break}}else if(a.budy&&a.arg&&/^(lulli|bot)$/i.test(a.arg[0])){if(a.text){if(n.limit<1&&!a.isPrem&&!a.isVIP)return a.reply(t.mess.limit);if(150<a.text.length&&!a.isPrem&&!a.isVIP)return a.reply(TEXT_ALERT_FREE_USER);e.sendReact(a.chat,"🕒",a.key);try{var d="LULLI"+i.makeid(8).toUpperCase()+"GPT",p=await LulliAI(a.text,n.name.replaceAll("\n",""),{userId:a.sender,prefix:a.prefix,current:a.quoted?.text});e.sendMessage(a.chat,{text:""+p,mentions:e.ments(p)},{quoted:a,ephemeralExpiration:a.expiration,messageId:d}),n.limit-=5,n.limit<0&&(n.limit=0)}catch(a){return console.error("✗ Error pada LulliAI keyword:",a),s(a)}}}else if(a.budy&&a.quoted&&a.quoted.fromMe&&a.quoted.id.endsWith("GPT")&&!a.isPrefix){if(n.limit<1&&!a.isPrem&&!a.isVIP)return a.reply(t.mess.limit);if(150<a.budy.length&&!a.isPrem&&!a.isVIP)return a.reply(TEXT_ALERT_FREE_USER);e.sendReact(a.chat,"🕒",a.key);try{var g="LULLI"+i.makeid(8).toUpperCase()+"GPT",k=await LulliAI(a.budy,n.name.replaceAll("\n",""),{userId:a.sender,prefix:a.prefix,current:a.quoted?.text});n.limit-=5,n.limit<0&&(n.limit=0),a.isPrem?e.sendVoiceMessage(a.chat,""+k,a):await e.sendMessage(a.chat,{text:""+k,mentions:e.ments(k)},{quoted:a,ephemeralExpiration:a.expiration,messageId:g})}catch(a){return console.error("✗ Error pada LulliAI reply:",a),s(a)}}else if(a.isPrem&&"audioMessage"===a.mtype&&"audio/ogg; codecs=opus"===r.mime&&a.seconds<9&&!a.fromMe){e.sendReact(a.chat,"🕒",a.key);try{i.makeid(8).toUpperCase();var c=await r.download();talknotes.initialized||await talknotes.init();var h=(await talknotes.transcribe(c))?.trim();if(!h||h.startsWith("✗"))return a.reply("✗ Gagal transkripsi audio.");if(console.log("✓ Audio Transkripsi:",h),a.isGc&&a.isOwner){if(/tutup\s(grup|group)/i.test(h))return a.isBotAdmin?(await e.groupSettingUpdate(a.chat,"announcement"),void e.sendVoiceMessage(a.chat,"✓ Baik tuan, grup ini sudah saya tutup.",a)):e.sendVoiceMessage(a.chat,"✗ Maaf tuan, saya bukan admin di grup ini.",a);if(/buka\s(grup|group)/i.test(h))return a.isBotAdmin?(await e.groupSettingUpdate(a.chat,"not_announcement"),void e.sendVoiceMessage(a.chat,"✓ Baik tuan, grup ini sudah saya buka.",a)):e.sendVoiceMessage(a.chat,"✗ Maaf tuan, saya bukan admin di grup ini.",a)}var y=await LulliAI(h,n.name.replaceAll("\n",""),{userId:a.sender,prefix:a.prefix,current:a.quoted?.text});e.sendVoiceMessage(a.chat,y,a)}catch(a){return console.error("✗ Error pada LulliAI VN processing:",a),s(a)}}};export default{run:run,main:main,cmd:"lulliai",alias:["lulli-ai","ai"],use:"teks pertanyaan",type:"ai",limit:5,location:"plugins/ai/lulli.js"};