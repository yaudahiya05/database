let run=async(a,r,{func:e})=>{var t=a.args[0];if(!t||isNaN(t))return a.reply(e.example(a.cmd,"17"));if((t=Number(t))<1||114<t)return a.reply("✗ Nomor surah tidak valid. Harus antara 1 sampai 114.");try{var n=`https://raw.githubusercontent.com/Jabalsurya2105/database/master/surah/surah%20${t}.json`,s=await e.fetchJson(n);if(!s||!s.ayat||0===s.ayat.length)return a.reply("✗ Data surah tidak ditemukan atau kosong.");var i=`✦ QURAN

`,i=(i+=`✦ QS. *${s.name}* : 1-${s.jumlah_ayat} Ayat

`)+s.ayat.map((a,r)=>`✦ *${a.arab}*
`+`- ${r+1}. ${a.latin}
`+"- Artinya: "+a.id).join("\n\n");await r.sendMessage(a.chat,{text:i},{quoted:a,ephemeralExpiration:a.expiration})}catch(r){console.error("✗ Terjadi kesalahan pada Quran Viewer:",r),a.reply(`✗ Terjadi kesalahan saat mencari surah: ${r.message}. Pastikan nomor surah benar.`)}};export default{run:run,cmd:"quran",use:"Nomor surah",type:"islamic",location:"plugins/islamic/quran.js"};