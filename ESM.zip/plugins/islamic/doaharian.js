import fetch from"node-fetch";let doaharianCache=null,run=async(a,e)=>{try{if(!doaharianCache){var t=await fetch("https://raw.githubusercontent.com/Jabalsurya2105/database/master/data/doaharian.json");if(!t.ok)throw new Error("✗ Gagal memuat data Doa Harian: "+t.statusText);doaharianCache=await t.json(),console.log("✓ Cache Doa Harian berhasil dimuat.")}if(!doaharianCache||0===doaharianCache.length)return a.reply("✗ Gagal memuat data Doa Harian atau data kosong.");let e=parseInt(a.text);if(!a.text||isNaN(e)||e<1||e>doaharianCache.length){var i="✦ DOA - HARIAN\n\n",i=(i+=`✦ (Contoh, ketik: *${a.cmd} 1* untuk memilih opsi 1).

`)+doaharianCache.map(a=>`✦ ${a.index}. `+a.title).join("\n");await a.reply(i)}else{var r=doaharianCache.find(a=>a.index===e);if(!r)return a.reply("✗ Nomor doa tidak ditemukan.");var n=`✦ DETAIL DOA HARIAN

`,n=(n+=`- Nomor    : ${r.index}
`)+`- Judul    : *${r.title}*

`+`- Arab     : *${r.arabic}*
`+`- Latin    : _${r.latin}_

`+`- Artinya  : *${r.translation}*`;await a.reply(n)}}catch(e){console.error("✗ Terjadi kesalahan pada Doa Harian:",e),await a.reply("✗ Terjadi kesalahan: "+e.message)}};export default{run:run,cmd:["doaharian"],alias:["d-h"],use:"Nomor (1 - 35)",type:"islamic",location:"plugins/islamic/doaharian.js"};