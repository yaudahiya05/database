let run=async(a,r,{func:e})=>{var[t,n]=a.args;if(!t||isNaN(t))return a.reply(`✗ Contoh penggunaan:
*${a.cmd} 17 32*

✦ Maka hasilnya adalah surah Al-Isra ayat 32 beserta audionya.`);if((t=Number(t))<1||114<t)return a.reply("✗ Nomor surah tidak valid. Harus antara 1 sampai 114.");let i=1;if(n){if(isNaN(n))return a.reply(`✗ Nomor ayat tidak valid. Contoh penggunaan:
*${a.cmd} 17 32*`);i=Number(n)}try{var s,o,u,l=`https://raw.githubusercontent.com/Jabalsurya2105/database/master/surah/surah%20${t}.json`,m=await e.fetchJson(l);return m&&m.ayat&&0!==m.ayat.length?i<1||i>m.ayat.length?a.reply(`✗ Surah ini hanya sampai *${m.ayat.length}* ayat. Mohon masukkan nomor ayat yang valid.`):(s=m.ayat[i-1],o=`✦ AL-QURAN

`,o=(o+=`- Arab    : *${s.arab}*

`)+`- Inggris : ${s.en}

`+`- Arti    : *${s.id}*

`+`✦ (Q.S ${m.name} : ${s.no})
`,u=await r.sendMessage(a.chat,{text:o},{quoted:a,ephemeralExpiration:a.expiration}),void(s.audio&&await r.sendMessage(a.chat,{audio:{url:s.audio},mimetype:"audio/mpeg",fileName:`Surah_${m.name}_Ayat_${s.no}.mp3`},{quoted:u,ephemeralExpiration:a.expiration}))):a.reply("✗ Data surah tidak ditemukan atau kosong.")}catch(r){console.error("✗ Terjadi kesalahan pada Al-Quran:",r),a.reply(`✗ Terjadi kesalahan saat mencari surah atau ayat: ${r.message}. Pastikan nomor surah dan ayat benar.`)}};export default{run:run,cmd:["alquran"],alias:["aq"],use:"Nomor_Surah [Nomor_Ayat]",type:"islamic",location:"plugins/islamic/alquran.js"};