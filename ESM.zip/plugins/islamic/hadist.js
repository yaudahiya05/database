let hadistCache={},run=async(i,a,{func:t})=>{var r={"abu-daud":4590,ahmad:26363,bukhari:7008,darimi:3367,tirmidzi:3891,"ibnu-majah":4331,nasai:5662,malik:1594,muslim:5362},[d,e]=i.args;if(!d){let a="✦ DAFTAR KITAB HADIST\n\n";for(var s in a+=`✦ Contoh: *${i.cmd} bukhari 1*

`,r)a+=`✦ ${s} (1 - ${r[s]})
`;return i.reply(a)}if(d=d.toLowerCase(),!["abu-daud","ahmad","bukhari","darimi","tirmidzi","ibnu-majah","nasai","malik","muslim"].includes(d)){let a="✗ Pilihan kitab tidak valid. Tersedia:\n\n";for(var n in r)a+=`✦ ${n} (1 - ${r[n]})
`;return i.reply(a)}if(!e)return i.reply(`✗ Hadist ke berapa?

✦ Contoh: *${i.cmd} ${d} 1*`);if(e=parseFloat(e),isNaN(e)||e<1||r[d]<e)return i.reply(`✗ Nomor hadist tidak valid. Untuk kitab *${d}*, hadist ke- harus antara 1 sampai *${r[d]}*.`);try{if(!hadistCache[d]){var h=`https://raw.githubusercontent.com/Jabalsurya2105/database/master/hadis/hadis%20${d}.json`,o=await t.fetchJson(h);if(!o||!o.hadits)throw new Error("✗ Data hadist tidak ditemukan atau format tidak valid.");hadistCache[d]=o,console.log(`✓ Cache hadist '${d}' berhasil dimuat.`)}var l,m,u=hadistCache[d];return e>u.hadits.length?i.reply(`✗ Hadist ini hanya sampai *${u.hadits.length}* nomor. Mohon masukkan nomor yang valid.`):(l=u.hadits[e-1])&&l.arab&&l.id?(m=`✦ HADIST

`,m=(m+=`- Kitab  : *${u.name}* (No. ${l.number})

`)+`- Arab   : *${l.arab}*

`+`- Arti   : *${l.id}*`,void await a.reply(i.chat,m,i,{expiration:i.expiration})):i.reply(`✗ Data hadist *${d}* nomor *${e}* tidak ditemukan atau tidak lengkap.`)}catch(a){console.error("✗ Terjadi kesalahan pada Hadist:",a),await i.reply("✗ Terjadi kesalahan: "+a.message)}};export default{run:run,cmd:"hadist",alias:["hadits","hadis"],use:"Kitab_Hadist Nomor_Hadist",type:"islamic",location:"plugins/islamic/hadist.js"};