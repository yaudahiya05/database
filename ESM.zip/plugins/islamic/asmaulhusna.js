import fetch from"node-fetch";let asmaulHusnaCache=null,run=async(a,s)=>{try{if(!asmaulHusnaCache){var t=await fetch("https://raw.githubusercontent.com/Jabalsurya2105/database/master/data/asmaulhusna.json");if(!t.ok)throw new Error("✗ Gagal memuat data Asmaul Husna: "+t.statusText);asmaulHusnaCache=await t.json(),console.log("✓ Cache Asmaul Husna berhasil dimuat.")}if(!asmaulHusnaCache||0===asmaulHusnaCache.length)return a.reply("✗ Gagal memuat data Asmaul Husna atau data kosong.");let s=parseInt(a.text);if(!a.text||isNaN(s)||s<1||s>asmaulHusnaCache.length){var e="✦ ASMAUL HUSNA\n\n",e=(e+=`✦ (Contoh, ketik: *${a.cmd} 1* untuk memilih opsi 1).

`)+asmaulHusnaCache.map(a=>`✦ ${a.index}. `+a.latin).join("\n");await a.reply(e)}else{var n=asmaulHusnaCache.find(a=>a.index===s);if(!n)return a.reply("✗ Nomor Asmaul Husna tidak ditemukan.");var u=`✦ DETAIL ASMAUL HUSNA

`,u=(u+=`- Nomor    : ${n.index}
`)+`- Latin    : *${n.latin}*
`+`- Arab     : *${n.arabic}*

`+`- Arti ID  : *${n.translation_id}*
`+"- Arti EN  : "+n.translation_en;await a.reply(u)}}catch(s){console.error("✗ Terjadi kesalahan pada Asmaul Husna:",s),await a.reply("✗ Terjadi kesalahan: "+s.message)}};export default{run:run,cmd:["asmaulhusna"],alias:"a-h",use:"Nomor (1 - 99)",type:"islamic",location:"plugins/islamic/asmaulhusna.js"};