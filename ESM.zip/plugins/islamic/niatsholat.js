let niatShalat={subuh:{sendiri:`أُصَلِّى فَرْضَ الصُّبْح رَكَعتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لله تَعَالَى.

✦ "Ushallii fardash-Shubhi rak’ataini mustaqbilal qiblati adaa’an lillaahi ta’aalaa."

✦ Artinya: Saya (berniat) mengerjakan sholat fardhu subuh sebanyak dua raka’at dengan menghadap kiblat, karena Allah Ta’ala.`,makmum:`أُصَلِّى فَرْضَ الصُّبْح رَكَعتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً (مَأْمُوْمًا/إِمَامًا) لله تَعَالَى.

✦ "Ushallii fardhash-Shubhi rak’ataini mustaqbilal qiblati makmuuman lillaahi ta’aalaa."

✦ Artinya: Saya (berniat) mengerjakan sholat fardhu subuh sebanyak dua raka’at dengan menghadap kiblat, sebagai makmum, karena Allah Ta’ala.`},dzuhur:{sendiri:`أُصَلِّى فَرْضَ الظُّهْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى

✦ (Ushollii fardhodz dzuhri arba’a roka’aatin mustaqbilal qiblati adaa’an lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Dzuhur empat raka’at, menghadap kiblat, saat ini karena Allah Ta’ala.`,makmum:`أُصَلِّى فَرْضَ الظُّهْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً مَأْمُوْمًا لِلَّهِ تَعَالَى

✦ (Ushollii fardhodz dzuhri arba’a roka’aatin mustaqbilal qiblati adaa’an ma’muuman lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Dzuhur empat raka’at, menghadap kiblat, saat ini sebagai makmum karena Allah Ta’ala.`},ashar:{sendiri:`أُصَلِّى فَرْضَ الْعَصْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى

✦ (Ushollii fardhol ‘ashri arba’a roka’aatin mustaqbilal qiblati adaa’an lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Ashar empat raka’at, menghadap kiblat, saat ini karena Allah Ta’ala.`,makmum:`أُصَلِّى فَرْضَ الْعَصْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً مَأْمُوْمًا لِلَّهِ تَعَالَى

✦ (Ushollii fardhol ‘ashri arba’a roka’aatin mustaqbilal qiblati adaa’an ma’muuman lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Ashar empat raka’at, menghadap kiblat, saat ini sebagai makmum karena Allah Ta’ala.`},maghrib:{sendiri:`أُصَلِّى فَرْضَ الْمَغْرِبِ ثَلَاثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى

✦ (Ushollii fardhol maghribi tsalaatsa roka’aatin mustaqbilal qiblati adaa’an lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Maghrib tiga raka’at, menghadap kiblat, saat ini karena Allah Ta’ala.`,makmum:`أُصَلِّى فَرْضَ الْمَغْرِبِ ثَلَاثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً مَأْمُوْمًا لِلَّهِ تَعَالَى

✦ (Ushollii fardhol maghribi tsalaatsa roka’aatin mustaqbilal qiblati adaa’an ma’muuman lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Maghrib tiga raka’at, menghadap kiblat, saat ini sebagai makmum karena Allah Ta’ala.`},isya:{sendiri:`أُصَلِّى فَرْضَ الْعِشَاءِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى

✦ (Ushollii fardhol ‘isyaa’i arba’a roka’aatin mustaqbilal qiblati adaa’an lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Isya empat raka’at, menghadap kiblat, saat ini karena Allah Ta’ala.`,makmum:`أُصَلِّى فَرْضَ الْعِشَاءِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً مَأْمُوْمًا لِلَّهِ تَعَالَى

✦ (Ushollii fardhol ‘isyaa’i arba’a roka’aatin mustaqbilal qiblati adaa’an ma’muuman lillaahi ta’aalaa)

✦ Artinya:
Aku niat sholat fardhu Isya empat raka’at, menghadap kiblat, saat ini sebagai makmum karena Allah Ta’ala.`}};function getGreeting(){var a=new Date;let i="",l;return{greeting:(l=4<=(a=parseInt(a.toLocaleString("en-US",{hour:"numeric",timeZone:"Asia/Jakarta"}),10))&&a<12?(i="Selamat pagi!","subuh"):12<=a&&a<15?(i="Selamat siang!","dzuhur"):15<=a&&a<18?(i="Selamat sore!","ashar"):18<=a&&a<19?(i="Selamat petang!","maghrib"):(i="Selamat malam!","isya"),"✦ "+i),waktuShalat:l}}async function run(a,i){var{greeting:l,waktuShalat:t}=getGreeting();let n=t;(t=a.text?a.text.toLowerCase().trim():"").includes("subuh")?n="subuh":t.includes("dzuhur")||t.includes("zuhur")?n="dzuhur":t.includes("ashar")||t.includes("asar")?n="ashar":t.includes("maghrib")||t.includes("magrib")?n="maghrib":t.includes("isya")&&(n="isya"),(t=niatShalat[n])?(l=l+`

`+`✦ Niat sholat ${n} (sendiri):*

${t.sendiri}

`+`-------------------

`+`✦ Niat sholat ${n} (makmum):*

`+t.makmum,await i.sendMessage(a.chat,{text:l},{quoted:a,ephemeralExpiration:a.expiration})):await i.sendMessage(a.chat,{text:"✗ Waktu sholat tidak ditemukan atau belum ditentukan. Mohon spesifikasikan (subuh, dzuhur, ashar, maghrib, isya)."},{quoted:a,ephemeralExpiration:a.expiration})}export default{run:run,cmd:"niatsholat",alias:"niatshalat",type:"islamic",location:"plugins/islamic/niatsholat.js"};