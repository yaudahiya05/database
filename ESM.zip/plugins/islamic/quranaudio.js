import fetch from"node-fetch";let quranAudioCache=null,run=async(s,l,{func:a})=>{var r=s.args[0];if(!r||isNaN(r))return s.reply(a.example(s.cmd,"1"));let m=Number(r);if(m<1||114<m)return s.reply("✗ Nomor surah tidak valid. Harus antara 1 sampai 114.");try{if(!quranAudioCache){var h=await fetch("https://raw.githubusercontent.com/Jabalsurya2105/database/master/data/quranaudio.json");if(!h.ok)throw new Error("✗ Gagal memuat data audio Al-Quran: "+h.statusText);quranAudioCache=await h.json(),console.log("✓ Cache audio Al-Quran berhasil dimuat.")}if(!quranAudioCache||0===quranAudioCache.length)return s.reply("✗ Gagal memuat data audio Al-Quran atau data kosong.");var p=quranAudioCache.find(a=>a.number===m);if(!p)return s.reply("✗ Data audio surah tidak ditemukan.");let{number:a,ayatCount:r,asma:i,preBismillah:u,type:e,tafsir:t,audio:n,urutan:o}=p,d=`✦ QURAN AUDIO

`;d=(d=(d+=`- Nomor Surah  : ${a}
`)+`- Nama Surah   : *${i.id.long}*
`)+`- Jumlah Ayat  : ${r}
`+`- Urutan Pewahyuan : ${o||"N/A"}
`,u&&(d+=`- Pre-Bismillah: Disediakan
`),d=(d+=`- Tipe Surah   : ${e}
`)+`- Tafsir       : ${t}

`+"✦ Mohon tunggu, audio surah sedang dikirim...";var c=await l.reply(s.chat,d,s,{expiration:s.expiration});n&&n.url?await l.sendMessage(s.chat,{audio:{url:n.url},mimetype:"audio/mpeg",fileName:i.id.long+".mp3"},{quoted:c,ephemeralExpiration:s.expiration}):s.reply("✗ Link audio untuk surah ini tidak tersedia.")}catch(a){console.error("✗ Terjadi kesalahan pada Quran Audio:",a),await s.reply(`✗ Terjadi kesalahan: ${a.message}. Pastikan nomor surah benar.`)}};export default{run:run,cmd:["quranaudio"],alias:["qa"],use:"Nomor surah (1 - 114)",type:"islamic",location:"plugins/islamic/quranaudio.js"};