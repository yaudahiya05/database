const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const {
    spawn
} = require('child_process')
const {
    Readable,
    PassThrough,
    Writable
} = require('stream');

class BufferCollector extends Writable {
    constructor(options) {
        super(options);
        this.buffers = [];
    }
    _write(chunk, encoding, callback) {
        this.buffers.push(chunk);
        callback();
    }
    getBuffer() {
        return Buffer.concat(this.buffers);
    }
}

async function toPTT2(buffer, mimetype) {
    return new Promise((resolve, reject) => {
        const stream = new Readable();
        stream.push(buffer);
        stream.push(null);

        const chunks = [];
        const proc = ffmpeg(stream);

        if (/audio\/mpeg/.test(mimetype)) {
            proc.inputFormat('mp3');
        } else if (/audio\/(aac|m4a)/.test(mimetype)) {
            proc.inputFormat('aac');
        }

        proc.outputOptions([
                '-c:a libopus',
                '-ac 1',
                '-ar 16000',
                '-vbr on',
                '-b:a 128k',
                '-f ogg'
            ])
            .on('error', (err) => reject(new Error(`Gagal konversi: ${err.message}`)))
            .on('end', () => resolve(Buffer.concat(chunks)))
            .pipe(new PassThrough().on('data', (chunk) => chunks.push(chunk)));
    });
}

const run = async (m, lulli, {
    cfg,
    func,
    quoted,
    packname,
    author
}) => {
    if (/audio|image|video|webp/.test(quoted.mime)) {
        lulli.sendReact(m.chat, '🕒', m.key)
        if (!m.text || !m.text.includes('whatsapp.com/channel')) return m.reply('Link channel invalid.')
        let linkRegex = /whatsapp\.com\/channel\/([0-9A-Za-z]{20,24})/i;
        let [_, code] = m.text.match(linkRegex) || {};
        try {
            let results;
            if (!global.db.newsletter[code]) {
                results = await lulli.newsletterMetadata("invite", code)
                if (!results) return m.reply(func.jsonFormat(result))
                const name = results?.thread_metadata?.name?.text || "yaudah iya"
                const json = {
                    id: results.id,
                    name: name
                }
                global.db.newsletter[code] = json;
                results = json;
            } else {
                results = global.db.newsletter[code];
            }
            const {
                id,
                name
            } = results;
            const newsletterJid = id ? id : cfg.id.newsletter;
            const buffer = await quoted.download();
            if (/video/.test(quoted.mime)) {
                let caption = quoted.caption || '';
                await lulli.sendMessage(newsletterJid, {
                    video: buffer,
                    caption,
                    mentions: lulli.ments(caption)
                })
                await lulli.sendReact(m.chat, '✅', m.key)
            } else if (/image\/(jpe?g|png)/.test(quoted.mime)) {
                let caption = quoted.caption || '';
                await lulli.sendMessage(newsletterJid, {
                    image: buffer,
                    caption,
                    mentions: lulli.ments(caption)
                })
                await lulli.sendReact(m.chat, '✅', m.key)
            } else if (/audio/.test(quoted.mime)) {
                let audioBuffer = await toPTT2(buffer, quoted.mime);
                await lulli.sendMessage(newsletterJid, {
                    audio: audioBuffer,
                    mimetype: 'audio/ogg; codecs=opus',
                    ptt: true
                })
                await lulli.sendReact(m.chat, '✅', m.key)
            } else if (/webp/.test(quoted.mime)) {
                await lulli.sendStickerFromUrl(newsletterJid, buffer, null, {
                    packname,
                    author,
                    expiration: 0
                })
                await lulli.sendReact(m.chat, '✅', m.key)
            }
        } catch (e) {
            await m.reply(e.message);
        }
    } else m.reply('Reply audio/video/image/sticker yang ingin di upload ke saluran.')
}

module.exports = {
    run,
    cmd: 'upch',
    alias: ['uptoch', 'upsaluran'],
    use: 'reply media',
    type: 'developer',
    desc: 'mengirim media ke saluran WhatsApp',
    devs: true,
    location: 'plugins/developer/upch.js'
}