let calculateExpireTime=e=>{var a,r,t;return(e=e-Date.now())<=0?"Expired":(a=Math.floor(e/1e3%60),r=Math.floor(e/6e4%60),t=Math.floor(e/36e5%24),Math.floor(e/864e5)+` Hari ${t} Jam ${r} Menit ${a} Detik`)},formatExpiredDate=e=>e&&"number"==typeof e?new Date(e).toLocaleString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric",hour:"2-digit",minute:"2-digit",hour12:!1,timeZone:"Asia/Jakarta"}).replace(/\./g,":").replace("pukul","jam").trim():"✗ Timestamp tidak valid",convertObjToText=e=>{let i="",a=1;for(var r in e){var t=e[r],l=t.data?t.data.length:0;0!==l&&(i=(i+=`[ ${a} ] @${r.replace(/@.+/,"")}
`)+`- Total Server : ${l}
`+`- Daftar Panel :
`,t.data.forEach((e,a)=>{var r=calculateExpireTime(e.expired),t=formatExpiredDate(e.expired);i=(i=(i=(i+=`  - [ ${a+1} ] Username : ${e.username}
`)+`    - ID       : ${e.id}
`)+`    - RAM      : ${e.ram}
`)+`    - Expired  : ${r}
`+`    - Tanggal  : ${t}

`}),a++)}return i.trim()},run=async(e,a)=>{if(0===Object.values(global.db.server).filter(e=>e.data&&0<e.data.length).length)return e.reply("✗ Data kosong. Tidak ada panel yang terdaftar.");var r="DAFTAR PANEL\n\n";r+=convertObjToText(global.db.server),await a.reply(e.chat,r,e,{expiration:e.expiration})};export default{run:run,cmd:"listpanel",type:"developer",devs:!0,location:"plugins/developer/listpanel.js"};