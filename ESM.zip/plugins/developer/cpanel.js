let is_eggs=!1,location="1";import fetch from"node-fetch";let run=async(w,j,{func:e,cfg:_})=>{try{let A={"1gb":"30","2gb":"50","3gb":"75","4gb":"100","5gb":"125","6gb":"150","7gb":"175","8gb":"200",unli:"0"},$={"1gb":"1024","2gb":"2024","3gb":"3024","4gb":"4024","5gb":"5024","6gb":"6024","7gb":"7024","8gb":"8024",unli:"0"},k=e.getCurrentTimeInZone("Asia/Jakarta");switch(w.command){case"listram":var a=`*PRICE LIST LULLI PANEL*

⭝ ram 1𝗀𝖻 𝖼𝗉𝗎 ${A["1gb"]}% : 3.000
⭝ ram 2𝗀𝖻 𝖼𝗉𝗎 ${A["2gb"]}% : 5.000
⭝ ram 3𝗀𝖻 𝖼𝗉𝗎 ${A["3gb"]}% : 7.000
⭝ ram 4𝗀𝖻 𝖼𝗉𝗎 ${A["4gb"]}% : 9.000
⭝ ram 5𝗀𝖻 𝖼𝗉𝗎 ${A["5gb"]}% : 11.000
⭝ ram 6𝗀𝖻 𝖼𝗉𝗎 ${A["6gb"]}% : 13.000
⭝ ram 7𝗀𝖻 𝖼𝗉𝗎 ${A["7gb"]}% : 15.000
⭝ ram 8𝗀𝖻 𝖼𝗉𝗎 ${A["8gb"]}% : 17.000
⭝ ram unli 𝖼𝗉𝗎 unli : 20.000

*Benefits:*
- harga di atas untuk 1 bulan
- server private anti colong² script
- hemat kuota dan penyimpanan 
- web & wa close bot tetep jalan

*Payments:*
- Dana : 0895415497664
- Ovo : 0895415497664
- Gopay : 0895415497664
- QRIS (All Payment)

*Informations:*
- 𝗍𝗋𝖺𝗇𝗌𝖿𝖾𝗋 𝗌𝖾𝗌𝗎𝖺𝗂 𝗇𝗈𝗆𝗂𝗇𝖺Ⲓ & 𝗐𝖺𝗃𝗂𝖻 𝗌𝖾𝗋𝗍𝖺𝗄𝖺𝗇 𝖻𝗎𝗄𝗍𝗂 𝗍𝗋𝖺𝗇𝗌𝖿𝖾𝗋.
- melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
- semua pembelian bergaransi.
- tidak puas dengan layanan kami? kami kembalikan uang anda 100% dalam jangka waktu 1 jam setelah pembelian.

Berminat? Hubungi :
wa.me/`+_.owner.replace(/[^0-9]/g,"");j.reply(w.chat,a,w,{expiration:w.expiration});break;case"listsrv":{if(!w.isDevs)return w.reply(_.mess.devs);var t,i=w.args[0]||"1",r=await(await fetch(_.panelApi.domain+"/api/application/servers?page="+i,{method:"GET",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey}})).json(),n=r.data;let e="Berikut adalah daftar server:\n\n";for(t of n){var s=t.attributes,p=await(await fetch(_.panelApi.domain+"/api/client/servers/"+s.uuid.split`-`[0]+"/resources",{method:"GET",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.capikey}})).json(),o=p.attributes?p.attributes.current_state:s.status;e=(e+=`ID Server: ${s.id}
`)+`Nama Server: ${s.name}
`+`Status: ${o}

`}e=(e+=`Halaman: ${r.meta.pagination.current_page}/${r.meta.pagination.total_pages}
`)+"Total Server: "+r.meta.pagination.count,await j.sendMessage(w.chat,{text:e},{quoted:w,ephemeralExpiration:w.expiration}),r.meta.pagination.current_page<r.meta.pagination.total_pages&&w.reply(`Gunakan perintah ${w.prefix}listsrv ${r.meta.pagination.current_page+1} untuk melihat halaman selanjutnya.`)}break;case"delsrv":if(!w.isDevs)return w.reply(_.mess.devs);var l=w.args[0];if(!l)return w.reply("ID nya mana?");var m=await fetch(_.panelApi.domain+"/api/application/servers/"+l,{method:"DELETE",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey}});if((m.ok?{errors:null}:await m.json()).errors)return w.reply("Server tidak ditemukan");w.reply("Berhasil minghapus Server.");break;case"listusr":{if(!w.isDevs)return w.reply(_.mess.devs);var d,u=w.args[0]||"1",c=await(await fetch(_.panelApi.domain+"/api/application/users?page="+u,{method:"GET",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey}})).json(),L=c.data;let e="Berikut list user:\n\n";for(d of L){var g=d.attributes;e=(e=(e=(e+=`ID: ${g.id} - ${g.username}
`)+`Status: ${null===g.attributes?.user?.server_limit?"Inactive":"Active"}
`)+`First Name: ${g.first_name}
`)+`Last Name: ${g.last_name}

`}e=(e+=`Page: ${c.meta.pagination.current_page}/${c.meta.pagination.total_pages}
`)+"Total Users: "+c.meta.pagination.count,await j.sendMessage(w.chat,{text:e},{quoted:w,ephemeralExpiration:w.expiration}),c.meta.pagination.current_page<c.meta.pagination.total_pages&&w.reply(`Gunakan perintah ${w.prefix}listusr ${c.meta.pagination.current_page+1} untuk melihat halaman selanjutnya.`)}break;case"delusr":if(!w.isDevs)return w.reply(_.mess.devs);var b=w.args[0];if(!b)return w.reply("ID nya mana?");var y=await fetch(_.panelApi.domain+"/api/application/users/"+b,{method:"DELETE",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey}});if((y.ok?{errors:null}:await y.json()).errors)return w.reply("User tidak ditemukan");w.reply("Berhasil menghapus User");break;case"addsrv":{if(!w.isDevs)return w.reply(_.mess.devs);var[f,h,v]=w.text.split(",");if(!(f&&h&&v))return w.reply(`*Format salah!*

Penggunaan:
${w.cmd} username,userId,ram

\`Example\` : ${w.prefix}addsrv SuryaDev,1,3gb`);let e,a,t;if(/^(unli)$/i.test(v))e="0",a="0",t="0";else if(/^(1gb)$/i.test(v))e="1024",a="1024",t=A["1gb"];else if(/^(2gb)$/i.test(v))e="2024",a="2024",t=A["2gb"];else if(/^(3gb)$/i.test(v))e="3024",a="3024",t=A["3gb"];else if(/^(4gb)$/i.test(v))e="4024",a="4024",t=A["4gb"];else if(/^(5gb)$/i.test(v))e="5024",a="5024",t=A["5gb"];else if(/^(6gb)$/i.test(v))e="6024",a="6024",t=A["6gb"];else if(/^(7gb)$/i.test(v))e="7024",a="7024",t=A["7gb"];else{if(!/^(8gb)$/i.test(v))return w.reply(`ram tidak valid!

*LIST RAM* :
- 1gb
- 2gb
- 3gb
- 4gb
- 5gb
- 6gb
- 7gb
- 8gb
- unli`);e="8024",a="8024",t=A["8gb"]}var S=await(await fetch(_.panelApi.domain+"/api/application/nests/5/eggs"+(is_eggs?"/"+_.panelApi.eggs:""),{method:"GET",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey}})).json(),T=S?.attributes?.startup||S?.data[0]?.attributes?.startup;if(!T)return w.reply(JSON.stringify(S,null,2));var U=await(await fetch(_.panelApi.domain+"/api/application/servers",{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey},body:JSON.stringify({name:f,description:`${k.date} (${k.time})`,user:h,egg:parseInt(_.panelApi.eggs),docker_image:"ghcr.io/parkervcp/yolks:nodejs_19",startup:T,environment:{INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start"},limits:{memory:e,swap:0,disk:a,io:500,cpu:t},feature_limits:{databases:5,backups:5,allocations:5},deploy:{locations:[parseInt(location)],dedicated_ip:!1,port_range:[]}})})).json();if(U.errors)return w.reply(JSON.stringify(U.errors[0],null,2));var D=U.attributes;w.reply(`*SUCCESSFULLY ADD SERVER*

TYPE: \`${U.object}\`

ID: \`${D.id}\`
UUID: ${D.uuid}\`
NAME: ${D.name}\`
DESCRIPTION: \`${D.description}\`
MEMORY: \`${0===D.limits.memory?"Unlimited":D.limits.memory} MB\`
DISK: \`${0===D.limits.disk?"Unlimited":D.limits.disk} MB\`
CPU: \`${D.limits.cpu}%\`
CREATED AT: ${D.created_at}\``)}break;case"1gb":case"2gb":case"3gb":case"4gb":case"5gb":case"6gb":case"7gb":case"8gb":case"unli":{if(!w.isDevs)return w.reply(_.mess.devs);let e,a,t=$[w.command],i=t,r=A[w.command];if(w.quoted&&w.quoted.sender&&w.text)e=w.quoted.sender,a=w.text;else{if(!w.text)return w.reply("Invalid format!");var[E,x]=w.text.split(",");if(!E||!x)return w.reply(`*Format salah!*
Penggunaan:
${w.cmd} user,nomer`);a=E,e=x.replace(/[^0-9]/g,"")+"@s.whatsapp.net"}if(!(e&&a&&t&&i))return j.sendReact(w.chat,"❌",w.key);var R=a.toLowerCase()+"zxv@sweetrabit.ml",I=a.toLowerCase()+Math.floor(1e4*Math.random()),C=((await j.onWhatsApp(e.split("@")[0]))[0],await(await fetch(_.panelApi.domain+"/api/application/users",{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey},body:JSON.stringify({email:R,username:a,first_name:a,last_name:a,language:"en",password:I})})).json());if(C.errors)return w.reply(JSON.stringify(C.errors[0],null,2));var N=C.attributes,z=await fetch(_.panelApi.domain+"/api/application/nests/5/eggs"+(is_eggs?"/"+_.panelApi.eggs:""),{method:"GET",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey}}),J=`Hai @${e.split("@")[0]}, berikut data panel anda >
- Username: ${N.username}
- Password: ${I}
- Link: `+_.panelApi.domain,O=(await j.sendMessage(w.chat,{text:J,mentions:[e]}),await z.json()),P=O?.attributes?.startup||O?.data[0]?.attributes?.startup;if(!P)return w.reply(JSON.stringify(O,null,2));var B=await(await fetch(_.panelApi.domain+"/api/application/servers",{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey},body:JSON.stringify({name:a+(" - "+w.command.toUpperCase()),description:`${k.date} (${k.time})`,user:N.id,egg:parseInt(_.panelApi.eggs),docker_image:"ghcr.io/parkervcp/yolks:nodejs_18",startup:P,environment:{INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start"},limits:{memory:t,swap:0,disk:i,io:500,cpu:r},feature_limits:{databases:5,backups:5,allocations:5},deploy:{locations:[parseInt(location)],dedicated_ip:!1,port_range:[]}})})).json();if(B.errors)return w.reply(JSON.stringify(B.errors[0],null,2));let n=B.attributes,s=(await w.reply(`Sukses menambahkan User dan Server

- UserId : ${N.id}
- ServerId : ${n.id}
- Username : ${N.username}
- Email : ${N.email}
- Name : ${N.first_name} ${N.last_name}
- Memory : ${0===n.limits.memory?"Unlimited":n.limits.memory} MB
- Disk : ${0===n.limits.disk?"Unlimited":n.limits.disk+"MB"}
- Cpu : `+(0===n.limits.cpu?"Unlimited":n.limits.cpu+"%")),global.db.server[e]),p=n.id,o=Date.now()+2592e6;if(s){if(s.data.find(e=>e.username===a))return;if(s.data.find(e=>e.id===p))return;s.data.push({id:p,ram:w.command,username:a,expired:o,date:k.date})}else global.db.server[e]={jid:e,data:[{id:p,ram:w.command,username:a,expired:o,date:k.date}]}}break;case"autocpanel":if(!w.isDevs)return w.reply(_.mess.devs);await w.reply("Memulai auto create panel...");for(var[G,M]of Object.entries(global.db.server)){let a=Date.now();void 0===M.cooldown&&(M.cooldown=0),M.data&&0<M.data.length&&M.cooldown<a&&(M.data=M.data.filter(e=>e.expired>a),await(async(p,o)=>{var e=o[0]?.username?.trim(),a=(o[0]?.ram,o[0]?.id,$,A,e.toLowerCase()+"zxv@sweetrabit.ml"),l=e.toLowerCase()+Math.floor(1e4*Math.random()),t=(await j.onWhatsApp(p.split("@")[0]))[0]||{};if(t.hasOwnProperty("exists")&&t.exists)try{var i=await(await fetch(_.panelApi.domain+"/api/application/users",{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey},body:JSON.stringify({email:a,username:e,first_name:e,last_name:e,language:"en",password:l})})).json();if(i.errors)return j.reply(_.owner,JSON.stringify(i.errors[0],null,2),null);var m=i.attributes,r=await fetch(_.panelApi.domain+"/api/application/nests/5/eggs"+(is_eggs?"/"+_.panelApi.eggs:""),{method:"GET",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey}}),n=`Hai @${p.split("@")[0]}, berikut data akun panel anda >
- Username: ${m.username}
- Password: ${l}
- Link: `+_.panelApi.domain,s=(await j.sendMessage(w.chat,{text:n,mentions:[p]}),await r.json()),d=s?.attributes?.startup||s?.data[0]?.attributes?.startup;if(!d)return j.reply(_.owner,JSON.stringify(s,null,2),null,{expiration:w.expiration});var u=global.db.server[p];u.cooldown||(u.cooldown=Date.now()+6e5);{let e=p,a=l,t=d,i=m,r=o,n=1,s=r.length;do{for(var[c,g]of r.entries()){n++;var b=g.username,y=g.ram,f=g.id,h=$[y],v=A[y];if((b=await(await fetch(_.panelApi.domain+"/api/application/servers",{method:"POST",headers:{Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+_.panelApi.apikey},body:JSON.stringify({name:b+(" - "+y.toUpperCase()),description:`${k.date} (${k.time})`,user:i.id,egg:parseInt(_.panelApi.eggs),docker_image:"ghcr.io/parkervcp/yolks:nodejs_18",startup:t,environment:{INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start"},limits:{memory:h,swap:0,disk:h,io:500,cpu:v},feature_limits:{databases:5,backups:5,allocations:5},deploy:{locations:[parseInt(location)],dedicated_ip:!1,port_range:[]}})})).json()).errors)return void await j.reply(_.owner,JSON.stringify(b.errors[0],null,2),null,{expiration:w.expiration});f!=(y=b.attributes).id&&(g.id=y.id),h=`*U S E R - I N F O*

- Jid : @${e.split("@")[0]}
- ID : ${i.id}
- Username : ${i.username}
- Password : ${a}
- Email : ${i.email}
- First Name : ${i.first_name}
- Last Name : ${i.last_name}

*S E R V E R - I N F O*

- ID : \`${y.id}\`
- UUID : ${y.uuid}\`
- Name : ${y.name}\`
- Description : \`${y.description}\`
- Memory : \`${0===y.limits.memory?"Unlimited":y.limits.memory} MB\`
- Disk : \`${0===y.limits.disk?"Unlimited":y.limits.disk} MB\`
- CPU : \`${y.limits.cpu}%\`
- Created At : ${y.created_at}\``,await j.reply(_.owner,h,null,{expiration:w.expiration}),await new Promise(e=>setTimeout(e,5e3))}}while(n<=s)}}catch(a){console.error("Error creating user:",a),await j.reply(_.owner,`Error creating user for ${e}: `+a.message,null)}})(G,M.data)),await new Promise(e=>setTimeout(e,3e3))}await j.reply(w.chat,"Successfully created an automatic panel.",w,{expiration:w.expiration})}}catch(l){return j.reply(w.chat,e.jsonFormat(l),w)}};export default{run:run,cmd:["listram","listsrv","delsrv","listusr","delusr","addsrv","1gb","2gb","3gb","4gb","5gb","6gb","7gb","8gb","unli","autocpanel"],use:"parameter",type:"cpanel",location:"plugins/developer/cpanel.js"};