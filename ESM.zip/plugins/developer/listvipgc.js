let run=async(e,l)=>{var a=Object.values(global.db.groups||{}).filter(e=>e.vip);if(!a||0===a.length)return e.reply("No VIP group data found.");let i="✦ *VIP - GROUP - LIST*";a.forEach((e,l)=>{i+=`

${l+1}. ${e.name}
✧ ID: `+e.jid}),await e.reply(i)};export default{run:run,cmd:"listvipgc",alias:"listgcvip",type:"developer",devs:!0,location:"plugins/special/listvipgc.js"};