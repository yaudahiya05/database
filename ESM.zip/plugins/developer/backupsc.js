import fs from"node:fs";let run=async(e,a,{func:i,cfg:t})=>{a.sendReact(e.chat,"🕒",e.key);try{var n=await i.backupSC(),c=`Berikut adalah file backup kode bot:

File Name: ${n.name}
File Size: ${n.size} MB`;await a.sendMessage(t.owner,{document:{url:n.name},caption:c,mimetype:"application/zip",fileName:n.name},{quoted:e,ephemeralExpiration:e.expiration}),fs.unlinkSync(n.name)}catch(a){await e.reply(`✗ Terjadi kesalahan saat membuat backup :

• Detail: `+a.message)}};export default{run:run,cmd:"backupsc",alias:"backupme",type:"developer",devs:!0,location:"plugins/developer/backupsc.js"};