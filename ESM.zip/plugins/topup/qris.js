// setting order kuota
global.okeUrl = 'https://okeconnect.com/harga/json?id=905ccd028329b0a'
global.memberId = 'OK1361511' // untuk mendapatkannya chat https://t.me/orderkuota
global.pin = '' // pin order kuota
global.pw = '' // password order kuota

import axios from 'axios';
import fetch from 'node-fetch';

global.pajak = 3;
global.untung = 10;

global.payment = {
    qris: {
        link: 'https://telegra.ph/file/91ec74ba6a45936c0c127.jpg',
        an: 'SURYA SHOP'
    },
    dana: {
        nope: '0895415497664',
        an: 'ASM×××××'
    }
};

global.calculateProfit = function(harga) {
    let biayaAdmin = (global.untung / 100) * harga;
    return biayaAdmin;
};

const run = async (m, lulli, {
    func,
    cfg,
    setting
}) => {
    if (/^payment$/i.test(m.command)) {
        lulli.sendMessage(m.chat, {
            text: `*PAYMENT E-WALLET*

${cfg.paymentMethods.filter(x => x.name !== 'QRIS').map(payment => `${payment.name}: ${payment.src}\nA/N: ${payment.an}`).join('\n\n')}

*SERTAKAN BUKTI TRANSFER*`
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    } else if (/^qris$/i.test(m.command)) {
        lulli.sendReact(m.chat, '🕒', m.key);
        const QRIS = cfg.paymentMethods.find(x =>
            x.name === 'QRIS' &&
            x.status &&
            x.src &&
            typeof x.src === 'string' &&
            x.src.match(/https?:\/\//gi)
        );
        if (!QRIS) return m.reply('untuk payment QRIS belum tersedia.')
        const qrisUrl = QRIS.src;
        lulli.sendMessage(m.chat, {
            image: {
                url: qrisUrl
            },
            caption: `*QRIS ALL PAYMENT*\n\n${QRIS.desc ? QRIS.desc + '\n' : ''}\n_pembayaran via \`QRIS\` + 300p untuk biaya admin_\n\n*SERTAKAN BUKTI TRANSFER*`
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    }
}

export default {
    run,
    cmd: ['qris', 'payment'],
    type: 'topup',
    location: 'plugins/topup/qris.js'
};