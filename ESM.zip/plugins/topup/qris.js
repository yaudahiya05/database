global.okeUrl="https://okeconnect.com/harga/json?id=905ccd028329b0a",global.memberId="",global.pin="",global.pw="";import axios from"axios";import fetch from"node-fetch";global.pajak=3,global.untung=10,global.payment={qris:{link:"https://telegra.ph/file/91ec74ba6a45936c0c127.jpg",an:"SURYA SHOP"},dana:{nope:"0895415497664",an:"ASM×××××"}},global.calculateProfit=function(a){return global.untung/100*a};let run=async(a,e,{})=>{if(/^payment$/i.test(a.command))e.sendMessage(a.chat,{text:`*PAYMENT E-WALLET*

${cfg.paymentMethods.filter(a=>"QRIS"!==a.name).map(a=>a.name+`: ${a.src}
A/N: `+a.an).join("\n\n")}

*SERTAKAN BUKTI TRANSFER*`},{quoted:a,ephemeralExpiration:a.expiration});else if(/^qris$/i.test(a.command)){e.sendReact(a.chat,"🕒",a.key);var t=cfg.paymentMethods.find(a=>"QRIS"===a.name&&a.status&&a.src&&"string"==typeof a.src&&a.src.match(/https?:\/\//gi));if(!t)return a.reply("untuk payment QRIS belum tersedia.");var n=t.src;e.sendMessage(a.chat,{image:{url:n},caption:`*QRIS ALL PAYMENT*

${t.desc?t.desc+"\n":""}
_pembayaran via \`QRIS\` + 300p untuk biaya admin_

*SERTAKAN BUKTI TRANSFER*`},{quoted:a,ephemeralExpiration:a.expiration})}};export default{run:run,cmd:["qris","payment"],type:"topup",location:"plugins/topup/qris.js"};