import axios from"axios";import fetch from"node-fetch";let addSaldo=(e,a)=>{var t=global.db.saldo.findIndex(a=>a.id===e);-1!==t?global.db.saldo[t].saldo+=a:global.db.saldo.push({id:e,saldo:a})},minSaldo=(e,a)=>{var t=global.db.saldo.findIndex(a=>a.id===e);-1!==t&&(global.db.saldo[t].saldo-=a)},cekSaldo=e=>{var a=global.db.saldo.find(a=>a.id===e);return a?a.saldo:0},run=async(t,d,{func:o,cfg:i})=>{d.sendReact(t.chat,"🕒",t.key);try{var a,e;if("saldo"===t.command)a=cekSaldo(t.sender),e=`
╭─「 💰 S A L D O - A N D A 💰 」
│
✦ Nama   : *${t.pushname}*
✦ Nomor  : *${t.sender.split("@")[0]}*
│
✦ Saldo  : *Rp${o.toRupiah(a)},-*
│
» *Catatan:*
» _Saldo hanya bisa untuk topup._
» _Tidak bisa ditarik atau transfer._
╰───────────────────────────
`,await t.reply(e.trim()),d.sendReact(t.chat,"✅",t.key);else{if(!t.isDevs)return t.reply(i.mess.devs||"✗ Maaf, fitur ini hanya untuk Developer Bot.");let a,e;if(t.quoted&&t.quoted.sender)a=t.quoted.sender,e=t.args[0];else{var[r,s]=t.text?t.text.split(",").map(a=>a.trim()):[void 0,void 0];if(!r||!s)return t.reply(o.example(t.cmd,"628xx,20000"));a=(r.startsWith("08")?r.replace("08","628"):r).replace(/[^0-9]/g,"")+"@s.whatsapp.net",e=s}if(e=Number(e),isNaN(e)||e<=0)return t.reply("✗ Nominal saldo harus berupa angka positif.");var[l]=await d.onWhatsApp(a);if(!l?.jid)return t.reply("✗ Masukkan nomor yang valid dan terdaftar di WhatsApp!");switch(a=l.jid,t.command){case"saldo+":addSaldo(a,e),await o.delay(500);var n=cekSaldo(a),p=`
╭─「 ➕ S A L D O - D I T A M B A H ➕ 」
│
✦ ID User    : *${a.split("@")[0]}*
✦ Nomor      : @${a.split("@")[0]}
│
✦ Jumlah Ditambah: *Rp${o.toRupiah(e)}*
✦ Saldo Akhir    : *Rp${o.toRupiah(n)}*
╰───────────────────────────
`;await d.sendMessage(t.chat,{text:p.trim(),mentions:[a]},{quoted:t,ephemeralExpiration:t.expiration}),d.sendReact(t.chat,"✅",t.key);break;case"saldo-":var u=cekSaldo(a);if(0===u)return t.reply("✗ Pengguna ini belum terdaftar di database saldo.");if(u<e)return t.reply(`✗ Saldo pengguna *${u}*, tidak bisa dikurangi sebesar *${e}*.`);minSaldo(a,e),await o.delay(500);var m=cekSaldo(a),c=`
╭─「 ➖ S A L D O - D I K U R A N G I ➖ 」
│
✦ ID User    : *${a.split("@")[0]}*
✦ Nomor      : @${a.split("@")[0]}
│
✦ Jumlah Dikurangi: *Rp${o.toRupiah(e)}*
✦ Saldo Akhir     : *Rp${o.toRupiah(m)}*
╰───────────────────────────
`;await d.sendMessage(t.chat,{text:c.trim(),mentions:[a]},{quoted:t,ephemeralExpiration:t.expiration}),d.sendReact(t.chat,"✅",t.key)}}}catch(a){console.error("✗ Terjadi kesalahan pada Manajemen Saldo:",a),d.sendReact(t.chat,"❌",t.key),await t.reply("✗ Terjadi kesalahan: "+a.message)}};export default{run:run,cmd:["saldo+","saldo-","saldo"],use:"Nomor,Nominal (untuk +/-) | atau kosong (untuk cek saldo)",type:"topup",location:"plugins/topup/saldo.js"};