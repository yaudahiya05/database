import fs from"node:fs";import path from"node:path";let DEPOSIT_FILE_PATH="./database/deposit/",addSaldo=(e,a)=>{var t=global.db.saldo.findIndex(a=>a.id===e);-1!==t?global.db.saldo[t].saldo+=a:global.db.saldo.push({id:e,saldo:a})},toRupiah=a=>{if(isNaN(a))return"0";let e="",t=a.toString().split("").reverse().join("");for(let a=0;a<t.length;a++)a%3==0&&(e+=t.substr(a,3)+".");return e.split("",e.length-1).reverse().join("")},run=async(a,e,{func:t})=>{if(!a.text)return a.reply(t.example(a.cmd,"628xxxxxxxxx"));let i=a.text.replace(/[^0-9]/g,"");if(!i.startsWith("62")){if(!i.startsWith("0"))return a.reply("✗ Format nomor tidak valid. Awali dengan `62` atau `08`.");i="62"+i.substring(1)}i;var n=path.join(DEPOSIT_FILE_PATH,i+".json");if(!fs.existsSync(n))return a.reply("✗ Data deposit untuk nomor tersebut tidak ditemukan!");var o,r,d,s=JSON.parse(fs.readFileSync(n,"utf-8"));try{"accdepo"===a.command?(o=global.pajak/100*s.price,addSaldo(s.number,Number(s.price)),r=`╭─「 ✅ D E P O S I T - S U K S E S ✅ 」
│
`,r=(r+=`✦ ID Deposit     : *${s.id}*
`)+`✦ Nomor          : @${s.number.split("@")[0]}
`+`✦ Metode Bayar   : *${s.payment.name}*
`+`✦ Tanggal        : *${s.date.split(" ")[0]}*
`+`✦ Jumlah Deposit : *Rp${toRupiah(s.price)}*
`+`✦ Pajak          : *Rp${toRupiah(Math.ceil(o))}*
`+`✦ Total Dibayar  : *Rp${toRupiah(s.price+Math.ceil(o))}*
│
`+`» _Deposit kamu telah dikonfirmasi oleh admin._
`+"» _Silakan cek saldo dengan tombol di bawah._",d=[[{title:"Cek Saldo",id:a.prefix+"saldo"}]],await e.sendButton(s.chatId,r,"» Klik tombol ini untuk cek saldo.",d,null,{expiration:a.expiration,mentions:[s.number]}),await a.reply(`✓ Sukses acc deposit dengan ID: *${s.id}* untuk @${s.number.split("@")[0]}.`)):"rejectdepo"===a.command&&(await e.reply(s.number,`✗ Maaf, deposit dengan ID: *${s.id}* ditolak.
» _Jika ada kendala, silakan hubungi owner bot._`,t.fstatus("System Notification")||void 0,{expiration:a.expiration,mentions:[s.number]}),await a.reply(`✗ Sukses menolak deposit dengan ID: *${s.id}* untuk @${s.number.split("@")[0]}.`)),fs.unlinkSync(n),e.sendReact(a.chat,"✅",a.key)}catch(t){console.error("✗ Terjadi kesalahan pada Acc/Reject Deposit:",t),e.sendReact(a.chat,"❌",a.key),await a.reply("✗ Terjadi kesalahan: "+t.message)}};export default{run:run,cmd:["accdepo","rejectdepo"],use:"nomor_tujuan (628xxx)",type:"owner",devs:!0,location:"plugins/topup/acc-rejectdepo.js"};