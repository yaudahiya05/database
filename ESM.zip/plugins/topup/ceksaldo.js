import fetch from 'node-fetch';

const run = async (m, lulli, { func }) => {
    try {
        if (!global.memberId || !global.pin || !global.pw) {
            return m.reply('✗ Konfigurasi API OkeConnect tidak lengkap. Mohon hubungi developer bot.');
        }
        lulli.sendReact(m.chat, '🕒', m.key);
        const apiUrl = `https://b2b.okeconnect.com/trx-v2/balance?memberID=${global.memberId}&pin=${global.pin}&password=${global.pw}`;
        const response = await fetch(apiUrl);
        const results = await response.json();

        if (results.status && results.status.includes('GAGAL')) {
            const ipMatch = results.message.match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/);
            const ipAddress = ipMatch ? ipMatch[0] : 'Tidak diketahui';
            
            return m.reply(`✗ Gagal mengambil saldo: ${results.message}\n» Mohon sambungkan IP *${ipAddress}* ke provider.`);
        }

        let caption = '✦ *SALDO ORDER KUOTA*\n\n';
        caption += `~ Sisa Saldo: *Rp${func.toRupiah(results.message.replace(/[^0-9]+/g, ''))}*`;

        await m.reply(caption);
        lulli.sendReact(m.chat, '✅', m.key);

    } catch (error) {
        console.error('✗ Terjadi kesalahan pada Cek Saldo:', error);
        lulli.sendReact(m.chat, '❌', m.key);
        await m.reply(`✗ Terjadi kesalahan saat mengambil saldo: ${error.message}`);
    }
};

export default {
    run,
    cmd: 'ceksaldo',
    type: 'topup',
    devs: true,
    location: 'plugins/topup/ceksaldo.js'
};