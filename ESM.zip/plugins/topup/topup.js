import axios from"axios";import crypto from"node:crypto";import fs from"node:fs";import path from"node:path";import{stalkff,stalkml}from"../../lib/stalker.js";let TOPUP_DB_PATH="./database/",cekSaldo=e=>{var a=global.db.saldo.find(a=>a.id===e);return a?a.saldo:0},minSaldo=(e,a)=>{var t=global.db.saldo.findIndex(a=>a.id===e);-1!==t&&(global.db.saldo[t].saldo-=a)},delay=e=>new Promise(a=>setTimeout(a,e));function filterText(a){try{var e=a.split("/");return{token:e[0],sn:e.slice(1).join("/")}}catch{return{token:a,sn:a}}}async function cekIDPelanggan(a){a.refID=crypto.randomBytes(5).toString("hex").toUpperCase();let e;var t=await axios.get(`https://b2b.okeconnect.com/trx-v2?product=CPLN&dest=${a.data.dest}&refID=${a.refID}&memberID=${global.memberId}&pin=${global.pin}&password=`+global.pw);for(e=t.data;"PROSES"===e.status;)await delay(3e3),t=await axios.get(`https://b2b.okeconnect.com/trx-v2?product=CPLN&dest=${a.data.dest}&refID=${a.refID}&memberID=${global.memberId}&pin=${global.pin}&password=`+global.pw),e=t.data;return e}let run=async(r,n,{func:i,time:s})=>{n.sendReact(r.chat,"🕒",r.key);let[o,a]=r.text?r.text.split(",").map(a=>a.trim()):[void 0,void 0];var d=path.join(TOPUP_DB_PATH,r.sender.split("@")[0]+".json");if(cekSaldo(r.sender)<1)return r.reply(`*SALDO TIDAK CUKUP*

Maaf *${r.pushname}*, saldo kamu saat ini Rp${i.toRupiah(cekSaldo(r.sender))}.
Silakan deposit terlebih dahulu.`);if(fs.existsSync(d))p=`*TOPUP PENDING*

`,p=(p=(p+=`⋄ ID Order : ${(l=JSON.parse(fs.readFileSync(d,"utf-8"))).data.id}
`)+`⋄ Produk : ${l.data.produk}
`)+`⋄ Total : Rp${i.toRupiah(l.data.price)}

`,await n.sendbut(r.chat,p+="_Ketik *Lanjutkan* atau *Batalkan*._","Klik tombol di bawah.",[["Lanjutkan","lanjutkan"],["Batalkan","batalkan"]],r,{expiration:r.expiration}),n.sendReact(r.chat,"✅",r.key);else{if(!o||!a)return r.reply(`*FORMAT TOPUP INVALID*

`+`*Mobile Legends:*
${r.prefix+r.command} [kode],[ID](Zone)
Ex: ${r.prefix+r.command} ML1500,382948365(9782)

`+`*Produk Lainnya:*
${r.prefix+r.command} [kode],[ID/No]
Ex: ${r.prefix+r.command} D10000,08123456789

`+`_Ketik *${r.prefix}listharga* untuk kode produk._`);var l=o.startsWith("DML")||o.startsWith("ML");let e,t;if(l){var p=a.match(/^(\d+)\((\d+)\)$/);if(!p)return r.reply(`*FORMAT ML SALAH*

Contoh: ${r.prefix+r.command} ${o},12345678(1234)`);e=p[1],t=p[2]}else if((e=a.replace(/[^0-9]/g,"").trim()).length<5)return r.reply("*ID TUJUAN TERLALU PENDEK*");try{var c=(await axios.get(global.okeUrl)).data;if(!Array.isArray(c))return r.reply("*GAGAL MENGAMBIL DATA PRODUK*");var u=c.find(a=>a.kode===o);if(!u)return r.reply(`*KODE ${o} TIDAK DITEMUKAN*`);var m=Number(u.harga.replace(/[^0-9]/g,"")),k=global.calculateProfit(m)||0,f=m+Math.ceil(k);if(cekSaldo(r.sender)<f)return r.reply(`*SALDO KURANG*

⋄ Harga : Rp${i.toRupiah(f)}
⋄ Saldo : Rp`+i.toRupiah(cekSaldo(r.sender)));var b=await(await fetch(`https://b2b.okeconnect.com/trx-v2/balance?memberID=${global.memberId}&pin=${global.pin}&password=`+global.pw)).json();if(b.status&&b.status.includes("GAGAL"))return r.reply(`*LAYANAN OFF*

Fitur topup sedang maintenance sementara.`);var y=crypto.randomBytes(5).toString("hex").toUpperCase(),g={session:"proses_topup",number:r.sender,data:{id:y,idgame:l?e:"",zone:l?t:"",nickname:"",dest:e,code:o,produk:u.keterangan,price:f,time:s}};fs.mkdirSync(TOPUP_DB_PATH,{recursive:!0});let a=`*KONFIRMASI TOPUP*

`;if(a=(a=(a+=`⋄ ID Order : ${g.data.id}
`)+`⋄ Produk : ${g.data.produk}
`)+`⋄ Total : Rp${i.toRupiah(g.data.price)}
`,l){a=(a+=`⋄ Game ID : ${g.data.idgame}
`)+`⋄ Zone ID : ${g.data.zone}
`,await r.reply("_Mengecek Nickname..._");var $=await stalkml(g.data.idgame,g.data.zone);if(200!==$.status)return r.reply(`*ID GAME TIDAK VALID*
Nickname tidak ditemukan.`);g.data.nickname=$.nickname,a+=`⋄ Nickname : ${$.nickname}
`}else if(a+=`⋄ Tujuan : ${g.data.dest}
`,o.startsWith("PLN")){await r.reply("_Mengecek ID PLN..._");var D=await cekIDPelanggan(g);if("SUKSES"!==D.status)return r.reply("*ID PLN TIDAK VALID*");a+=`⋄ Nama : ${D.message}
`}g.session="konfirmasi_topup",fs.writeFileSync(d,JSON.stringify(g,null,3)),a+=`
_Ketik *Lanjutkan* untuk memproses pesanan._`;var I=[["Lanjutkan","lanjutkan"],["Batalkan","batalkan"]];await n.sendbut(r.chat,a,"Klik tombol di bawah.",I,r,{expiration:r.expiration}),n.sendReact(r.chat,"✅",r.key)}catch(a){fs.existsSync(d)&&fs.unlinkSync(d),n.sendReact(r.chat,"❌",r.key),await r.reply("*ERROR:* "+a.message)}}},main=async(t,a,{func:r})=>{var e=path.join(TOPUP_DB_PATH,t.sender.split("@")[0]+".json");if(fs.existsSync(e)){var n,i,s=JSON.parse(fs.readFileSync(e,"utf-8"));if("konfirmasi_topup"===s.session)if(/^(lanjut|lanjutkan)$/i.test(t.budy)){a.sendReact(t.chat,"🕒",t.key);try{await t.reply("_Sedang memproses transaksi..._");let e=(await axios.get(`https://b2b.okeconnect.com/trx-v2?product=${s.data.code}&dest=${s.data.dest}&refID=${s.data.id}&memberID=${global.memberId}&pin=${global.pin}&password=`+global.pw)).data;for(;"PROSES"===e.status||"PENDING"===e.status;){await delay(5e3);var o=await axios.get(`https://b2b.okeconnect.com/trx-v2?product=${s.data.code}&dest=${s.data.dest}&refID=${s.data.id}&memberID=${global.memberId}&pin=${global.pin}&password=`+global.pw);e=o.data}if("SUKSES"===e.status){let a=`*✅ TOPUP BERHASIL*

`;a=(a=(a=(a+=`⋄ ID Order : ${e.refid||s.data.id}
`)+`⋄ Produk : ${s.data.produk}
`)+`⋄ Harga : Rp${r.toRupiah(s.data.price)}
`)+`⋄ Tujuan : ${s.data.dest}
`,e.sn&&({token:n,sn:i}=filterText(e.sn),a+=s.data.code.startsWith("PLN")?`⋄ Token : ${n}
⋄ SN : `+i:"⋄ SN : "+e.sn),a+=`

_Terima kasih telah berlangganan._`,await t.reply(a),minSaldo(t.sender,Number(s.data.price))}else await t.reply(`*❌ TOPUP GAGAL*

⋄ Alasan : `+(e.message||"Layanan Error"))}catch(a){await t.reply("*ERROR:* "+a.message)}finally{fs.unlinkSync(e)}}else/^(batal|batalkan)$/i.test(t.budy)&&(await t.reply(`*DIBATALKAN*
⋄ ID Order : ${s.data.id} berhasil dihapus.`),fs.unlinkSync(e))}};export default{run:run,main:main,cmd:"topup",use:"KodeProduk,ID/No",type:"topup",location:"plugins/topup/topup.js"};