let axios=require("axios"),run=async(e,t,{})=>{var A;cfg.baileys.button?(A=[["list","Click Here ⎙",[{title:"VOUCHER GAME",rows:[{title:"1 LIST HARGA TOPUP ML",id:"#1"},{title:"2 LIST HARGA TOPUP FF",id:"#2"},{title:"3 LIST HARGA TOPUP PUBG",id:"#3"}]},{title:"TOKEN LISTRIK",rows:[{title:"4 LIST HARGA TOKEN PLN",id:"#4"}]},{title:"TOPUP SALDO",rows:[{title:"5 LIST HARGA SALDO DANA",id:"#5"},{title:"6 LIST HARGA SALDO GOPAY",id:"#6"},{title:"7 LIST HARGA SALDO OVO",id:"#7"},{title:"8 LIST HARGA SALDO SHOPEEPAY",id:"#8"},{title:"9 LIST HARGA SALDO LINKAJA",id:"#9"}]},{title:"KUOTA INTERNET",rows:[{title:"10 LIST HARGA KUOTA SMARTFREN",id:"#10"},{title:"11 LIST HARGA KUOTA TELKOMSEL",id:"#11"},{title:"12 LIST HARGA KUOTA BYU",id:"#12"},{title:"13 LIST HARGA KUOTA AXIS",id:"#13"},{title:"14 LIST HARGA KUOTA XL",id:"#14"},{title:"15 LIST HARGA KUOTA INDOSAT",id:"#15"},{title:"16 LIST HARGA KUOTA THREE",id:"#16"}]},{title:"PULSA TRANSFER",rows:[{title:"17 LIST HARGA PULSA SMARTFREN",id:"#17"},{title:"18 LIST HARGA PULSA TELKOMSEL",id:"#18"},{title:"19 LIST HARGA PULSA BYU",id:"#19"},{title:"20 LIST HARGA PULSA AXIS",id:"#20"},{title:"21 LIST HARGA PULSA AXIS",id:"#21"},{title:"22 LIST HARGA PULSA INDOSAT",id:"#22"},{title:"23 LIST HARGA PULSA THREE",id:"#23"},{title:"24 LIST HARGA PULSA TRANSFER",id:"#24"}]}]]],await t.sendButton(e.chat,"","Hi @"+e.sender.split("@")[0],"please select the list button below.",A,e,{expiration:e.expiration})):await e.reply(`*L I S T - H A R G A*

_(Contoh, ketik: *#1* untuk memilih opsi 1)._

- *VOUCHER GAME*
#1 LIST HARGA TOPUP ML
#2 LIST HARGA TOPUP FF
#3 LIST HARGA TOPUP PUBG

- *TOKEN LISTRIK*
#4 LIST HARGA TOKEN PLN

- *TOPUP SALDO*
#5 LIST HARGA SALDO DANA
#6 LIST HARGA SALDO GOPAY
#7 LIST HARGA SALDO OVO
#8 LIST HARGA SALDO SHOPEEPAY
#9 LIST HARGA SALDO LINKAJA

- *KUOTA INTERNET*
#10 LIST HARGA KUOTA SMARTFREN
#11 LIST HARGA KUOTA TELKOMSEL
#12 LIST HARGA KUOTA BYU
#13 LIST HARGA KUOTA AXIS
#14 LIST HARGA KUOTA INDOSAT
#15 LIST HARGA KUOTA THREE

- *PULSA TRANSFER*
#16 LIST HARGA PULSA SMARTFREN
#17 LIST HARGA PULSA TELKOMSEL
#18 LIST HARGA PULSA BYU
#19 LIST HARGA PULSA AXIS
#20 LIST HARGA PULSA INDOSAT
#21 LIST HARGA PULSA THREE
#22 LIST HARGA PULSA TRANSFER`)},getCleanKeterangan=(e,t)=>{if("game"===t){if(e.includes("Customer H2H "))return e.replace("Customer H2H ","");if(e.includes("Customer "))return e.replace("Customer ","")}else if(e.includes("H2H "))return e.replace("H2H ","");return e},commandConfigs={"#1":{title:"LIST HARGA TOPUP ML",filterFn:e=>e.kode.startsWith("DML"),keteranganType:"game"},"#2":{title:"LIST HARGA TOPUP FF",filterFn:e=>e.kode.startsWith("FF"),keteranganType:"game"},"#3":{title:"LIST HARGA TOPUP PUBG",filterFn:e=>e.kode.startsWith("PUBG"),keteranganType:"game"},"#4":{title:"LIST HARGA TOKEN PLN",filterFn:e=>e.kode.startsWith("PLN"),keteranganType:"default"},"#5":{title:"LIST HARGA SALDO DANA",filterFn:e=>e.kode.startsWith("D")&&"DOMPET DIGITAL"===e.kategori,keteranganType:"default"},"#6":{title:"LIST HARGA SALDO GOPAY",filterFn:e=>e.kode.startsWith("GJK"),keteranganType:"game"},"#7":{title:"LIST HARGA SALDO OVO",filterFn:e=>e.kode.startsWith("OVO"),keteranganType:"default"},"#8":{title:"LIST HARGA SALDO SHOPEEPAY",filterFn:e=>e.kode.startsWith("SHOPE"),keteranganType:"default"},"#9":{title:"LIST HARGA SALDO LINKAJA",filterFn:e=>e.kode.startsWith("LINK"),keteranganType:"default"},"#10":{title:"LIST HARGA KUOTA SMARTFREN",filterFn:e=>e.kategori.includes("KUOTA SMARTFREN"),keteranganType:"default"},"#11":{title:"LIST HARGA KUOTA TELKOMSEL",filterFn:e=>e.kategori.includes("KUOTA TELKOMSEL"),keteranganType:"default"},"#12":{title:"LIST HARGA KUOTA BYU",filterFn:e=>e.kategori.includes("KUOTA BYU"),keteranganType:"default"},"#13":{title:"LIST HARGA KUOTA AXIS",filterFn:e=>e.kategori.includes("KUOTA AXIS"),keteranganType:"default"},"#14":{title:"LIST HARGA KUOTA XL",filterFn:e=>e.kategori.includes("KUOTA XL"),keteranganType:"default"},"#15":{title:"LIST HARGA KUOTA INDOSAT",filterFn:e=>e.kategori.includes("KUOTA INDOSAT"),keteranganType:"default"},"#16":{title:"LIST HARGA KUOTA THREE",filterFn:e=>e.kategori.includes("KUOTA TRI"),keteranganType:"default"},"#17":{title:"LIST HARGA PULSA SMARTFREN",filterFn:e=>e.kategori.includes("PULSA")&&!e.kategori.includes("PULSA TRANSFER")&&e.produk.includes("Smartfren"),keteranganType:"default"},"#18":{title:"LIST HARGA PULSA TELKOMSEL",filterFn:e=>e.kategori.includes("PULSA")&&!e.kategori.includes("PULSA TRANSFER")&&e.produk.includes("Telkomsel"),keteranganType:"default"},"#19":{title:"LIST HARGA PULSA BYU",filterFn:e=>e.kategori.includes("PULSA")&&!e.kategori.includes("PULSA TRANSFER")&&e.produk.includes("By U"),keteranganType:"default"},"#20":{title:"LIST HARGA PULSA AXIS",filterFn:e=>e.kategori.includes("PULSA")&&!e.kategori.includes("PULSA TRANSFER")&&e.produk.includes("Axis"),keteranganType:"default"},"#21":{title:"LIST HARGA PULSA XL",filterFn:e=>e.kategori.includes("PULSA")&&!e.kategori.includes("PULSA TRANSFER")&&e.produk.includes("XL"),keteranganType:"default"},"#22":{title:"LIST HARGA PULSA INDOSAT",filterFn:e=>e.kategori.includes("PULSA")&&!e.kategori.includes("PULSA TRANSFER")&&e.produk.includes("Indosat"),keteranganType:"default"},"#23":{title:"LIST HARGA PULSA THREE",filterFn:e=>e.kategori.includes("PULSA")&&!e.kategori.includes("PULSA TRANSFER")&&e.produk.includes("Three"),keteranganType:"default"},"#24":{title:"LIST HARGA PULSA TRANSFER",filterFn:e=>e.kategori.includes("PULSA")&&e.kategori.includes("PULSA TRANSFER"),keteranganType:"default"}},buildCaption=(e,t,A,i)=>{let a=`*${t.title}*

Ingin melakukan topup? ketik *${A}topup*`;for(var T of e){var l,S;t.filterFn(T)&&(l=global.calculateProfit(T.harga),S=getCleanKeterangan(T.keterangan,t.keteranganType),a+=`

*Kode:* ${T.kode}
*Nama:* ${S}
*Harga:* Rp${i.toRupiah(Number(T.harga)+Number(Math.ceil(l)))}
*Status:* `+("1"==T.status?"✅":"❌"))}return a},main=async(t,e,{func:A})=>{var i=commandConfigs[t.budy];if(i){e.sendReact(t.chat,"🕒",t.key);try{var a=(await axios.get("https://okeconnect.com/harga/json?id=905ccd028329b0a&produk=pulsa,pulsa_transfer,kuota_telkomsel,kuota_byu,kuota_indosat,kuota_tri,kuota_xl,kuota_axis,kuota_smartfren,token_pln,saldo_gojek,cetak_voucher,digital")).data,T=(a.sort((e,t)=>Number(e.harga.replace(/[^0-9.-]+/g,""))-Number(t.harga.replace(/[^0-9.-]+/g,""))),buildCaption(a,i,t.prefix,A));await t.reply(T)}catch(e){console.error("Error fetching data:",e),await t.reply("Terjadi kesalahan saat mengambil data harga. Coba lagi nanti.")}}};module.exports={run:run,main:main,cmd:"listharga",type:"topup",location:"plugins/topup/listharga.js"};