import util from"node:util";let gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/kbbi.json",random=a=>a[Math.floor(Math.random()*a.length)];async function genKata(){return new Promise(async a=>{let e=await fetch(gamesUrl).then(a=>a.json()),n=random(["a","b","c","d","e","g","h","i","j","k","l","m","n","p","r","s","t","u","w"]),t=e.filter(a=>a.startsWith(n)),r=random(t);for(;!r||r.length<3;)r=random(t);a(r)})}async function cekKata(e=""){return new Promise(async a=>{(await fetch(gamesUrl).then(a=>a.json())).find(a=>a===e.toLowerCase())?a(!0):a(!1)})}function filter(a){if(!/[aiueo][aiueo]([qwrtypsdfghjklzxcvbnm])?$/.test(a)&&2<=a.length){var e=a.substring(a.length-2);if(e.match(/[aiueo]/)&&e.match(/[qwrtypsdfghjklzxcvbnm]/))return e}return a.substring(a.length-1)}global.skata=global.skata||{};let EPHEMERAL_EXPIRATION=86400,run=async(n,t,{func:r,cfg:i})=>{try{let a=n.chat,e=global.skata[a],u=async(e,a,n,t,r,i,l)=>{clearTimeout(i.timeout);let s=`✗ @${e.split("@")[0]} ${n}
`;global.db.users[e]=global.db.users[e]||{balance:0},global.db.users[e].balance=(global.db.users[e].balance||0)-a,s+=`✧ Hadiah: -${l.formatNumber(a)} balance.`,-1!==(n=i.player.findIndex(a=>a.id===e))&&i.player.splice(n,1),1===i.player.length?(a=i.player[0],global.db.users[a.id]=global.db.users[a.id]||{balance:0,game:{}},n=500*(i.basi.length+1),global.db.users[a.id].balance+=n,global.db.users[a.id].game.sambungkata=(global.db.users[a.id].game.sambungkata||0)+1,s+=`

🎉 Selamat @${a.id.split("@")[0]}, kamu adalah pemenangnya!
Kamu mendapatkan bonus kemenangan sebesar ${l.formatNumber(n)} balance!`,await t.reply(r,s,i.chat,{mentions:[e,a.id],expiration:EPHEMERAL_EXPIRATION}),delete global.skata[r]):0===i.player.length?(s+=`

✗ Semua pemain telah kalah. Game berakhir.`,await t.reply(r,s,i.chat,{mentions:[e],expiration:EPHEMERAL_EXPIRATION}),delete global.skata[r]):(i.index>=i.player.length&&(i.index=0),i.current=i.player[i.index].id,i.player[i.index].chance=3,s=(s=(s+=`

Giliran berikutnya: @`+i.current.split("@")[0])+`
Kata saat ini: *${i.kata}*
Carilah kata yang berawalan *${i.filter(i.kata)}*`)+`
Waktu: ${i.timer}s
Kesempatan: `+i.player[i.index].chance,i.chat=await t.reply(r,s,i.chat,{mentions:[e,i.current],expiration:EPHEMERAL_EXPIRATION}),i.timeout=setTimeout(()=>{u(i.current,100*i.kata.length,"waktu habis dan kalah!",t,r,i,l)},1e3*i.timer))};e||(l=await genKata(),global.skata[a]={owner:n.sender,player:[],status:"wait",basi:[],point:0,chance:0,index:0,current:"",kata:l,timer:40,timeout:null,genKata:genKata,cekKata:cekKata,filter:filter},e=global.skata[a]);var l,s=(n.args[0]||"").toLowerCase();if(!s)return n.reply(`✦ Kirim perintah :

- *${n.cmd} help*
- *${n.cmd} join*
- *${n.cmd} start*
- *${n.cmd} exit*
- *${n.cmd} delete*
- *${n.cmd} player*

✧ Minimal 2 orang`);switch(s){case"help":case"rules":case"menu":t.reply(a,`✦ *S A M B U N G - K A T A - H E L P*

1. Permainan harus dimainkan minimal 2 pemain
2. Saat permainan dimulai bot akan memberikan 1 kata
3. Kemudian, player harus membuat 1 kata dari suku kata terakhir dari kata sebelumnya
4. Contohnya: *Teknologi*, maka jawabannya *Gigih* atau *Girang*
5. Permainan akan terus diulang sampai ada yang kalah
6. Tiap pemain diberi waktu 30 detik untuk menjawab
7. Tiap pemain diberi 3 kesempatan untuk menjawab
8. Kata yang dijawab harus terdaftar dalam KBBI dan belum pernah dijawab
9. Apabila benar, akan diberikan balance sesuai jumlah huruf kata yang dijawab dikali 100
10. Apabila 3 kesempatan atau waktu telah habis, player akan diberikan minus(-) balance dari kalkulasi jumlah balance yang telah diberikan pada permainan.

*Perubahan baru*: Jika ada pemain yang kalah, game akan terus berlanjut sampai hanya tersisa satu pemain sebagai pemenang!`,n,{expiration:EPHEMERAL_EXPIRATION});break;case"join":if(r.ceklimit(n.sender,1)&&!n.isPrem&&!n.isVIP)return n.reply("✗ "+i.mess.limit);if(e.player.find(a=>a.id===n.sender))return n.reply("✗ Kamu sudah berada di dalam list pemain.");e.player.push({id:n.sender,chance:3}),n.reply(`✓ Berhasil masuk
Jumlah pemain: `+e.player.length);break;case"exit":if(!e.player.find(a=>a.id===n.sender))return n.reply("✗ Kamu tidak dalam sesi permainan.");if("play"===e.status)return n.reply("✗ Permainan sudah dimulai, kamu tidak bisa keluar.");var m=e.player.findIndex(a=>a.id===n.sender);e.player.splice(m,1),n.reply(`✓ @${n.sender.split("@")[0]} keluar dari permainan.`);break;case"delete":if(!e)return n.reply("✗ Tidak ada sesi permainan.");if(e.owner!==n.sender&&!n.isDevs)return n.reply(`✗ Hanya @${e.owner.split("@")[0]} yang dapat menghapus sesi permainan ini.`);t.reply(a,"✓ Sesi permainan berhasil dihapus.",n,{expiration:EPHEMERAL_EXPIRATION}),e.timeout&&clearTimeout(e.timeout),delete global.skata[a];break;case"player":if(!e)return n.reply("✗ Tidak ada sesi permainan.");if(0===e.player.length)return n.reply("✗ Sesi permainan belum memiliki player.");var d="✦ *S A M B U N G - K A T A*\n\n✦ LIST PLAYER:\n";d+=e.player.map((a,e)=>e+1+". @"+a.id.split("@")[0]).join("\n"),t.reply(a,d.trim(),n,{expiration:EPHEMERAL_EXPIRATION});break;case"start":if("play"===e.status)return n.reply("✗ Permainan sudah dimulai.");if(e.player.length<2)return n.reply("✗ Minimal 2 player untuk memulai.");e.current=e.player[0].id,e.index=0,e.status="play",e.basi=[],e.point=0;var p=`✧ Giliran @${e.current.split("@")[0]}
✧ Kata : *${e.kata}*
✧ Waktu: ${e.timer}s
✧ Kesempatan: ${e.player[e.index].chance}

✧ Carilah kata yang berawalan *${e.filter(e.kata)}*`;return e.chat=await t.reply(a,p.trim(),null,{mentions:[e.current],expiration:EPHEMERAL_EXPIRATION}),e.point=100*e.kata.length,void(e.timeout=setTimeout(()=>{u(e.current,100*e.kata.length,"waktu habis dan kalah!",t,a,e,r)},1e3*e.timer));default:t.reply(a,`✗ Perintah tidak dikenal. Ketik *${n.prefix}sk help* untuk bantuan.`,n,{expiration:EPHEMERAL_EXPIRATION})}}catch(a){console.error("✗ Error in sambungkata run command:",a),await t.reply(n.chat,"✗ Terjadi kesalahan: "+a.message,n,{expiration:EPHEMERAL_EXPIRATION})}},main=async(a,e,{func:n})=>{let t=a.chat,r=global.skata[t],u=async(e,a,n,t,r,i,l)=>{clearTimeout(i.timeout);let s=`✗ @${e.split("@")[0]} ${n}
`;global.db.users[e]=global.db.users[e]||{balance:0},global.db.users[e].balance=(global.db.users[e].balance||0)-a,s+=`✧ Hadiah: -${l.formatNumber(a)} balance.`,-1!==(n=i.player.findIndex(a=>a.id===e))&&i.player.splice(n,1),1===i.player.length?(a=i.player[0],global.db.users[a.id]=global.db.users[a.id]||{balance:0,game:{}},n=500*(i.basi.length+1),global.db.users[a.id].balance+=n,global.db.users[a.id].game.sambungkata=(global.db.users[a.id].game.sambungkata||0)+1,s+=`

🎉 Selamat @${a.id.split("@")[0]}, kamu adalah pemenangnya!
Kamu mendapatkan bonus kemenangan sebesar ${l.formatNumber(n)} balance!`,await t.reply(r,s,i.chat,{mentions:[e,a.id],expiration:EPHEMERAL_EXPIRATION}),delete global.skata[r]):0===i.player.length?(s+=`

✗ Semua pemain telah kalah. Game berakhir.`,await t.reply(r,s,i.chat,{mentions:[e],expiration:EPHEMERAL_EXPIRATION}),delete global.skata[r]):(i.index>=i.player.length&&(i.index=0),i.current=i.player[i.index].id,i.player[i.index].chance=3,s=(s=(s+=`

Giliran berikutnya: @`+i.current.split("@")[0])+`
Kata saat ini: *${i.kata}*
Carilah kata yang berawalan *${i.filter(i.kata)}*`)+`
Waktu: ${i.timer}s
Kesempatan: `+i.player[i.index].chance,i.chat=await t.reply(r,s,i.chat,{mentions:[e,i.current],expiration:EPHEMERAL_EXPIRATION}),i.timeout=setTimeout(()=>{u(i.current,100*i.kata.length,"waktu habis dan kalah!",t,r,i,l)},1e3*i.timer))};var i,l,s,m;a.budy&&r&&"play"===r.status&&r.current===a.sender&&!a.isPrefix&&(l=100*(i=(a.budy||"").toLowerCase().trim().replace(/[^a-z]/g,"")).length,i.startsWith(r.filter(r.kata)))&&(r.basi.includes(i)?(s=`✗ *${i}* sudah pernah digunakan.
`,r.player[r.index].chance--,r.player[r.index].chance<=0?(m=r.current,await u(m,l,"sudah pernah digunakan dan kesempatan habis!",e,t,r,n)):await a.reply(s+"✧ Sisa kesempatan: "+r.player[r.index].chance)):await r.cekKata(i)?(clearTimeout(r.timeout),global.db.users[r.current]=global.db.users[r.current]||{balance:0,game:{}},global.db.users[r.current].balance=(global.db.users[r.current].balance||0)+l,global.db.users[r.current].game.sambungkata=(global.db.users[r.current].game.sambungkata||0)+1,r.basi.push(i),r.kata=i,r.index++,r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.player[r.index].chance=3,m=`✓ *Jawaban benar!* (+${n.formatNumber(l)} balance)
✧ Giliran: @${r.current.split("@")[0]}
✧ Kata: *${r.kata}*
✧ Waktu: ${r.timer}s
✧ Kesempatan: ${r.player[r.index].chance}

✧ Carilah kata yang berawalan *${r.filter(r.kata)}*`,r.chat=await e.reply(a.chat,m,null,{mentions:[r.current],expiration:EPHEMERAL_EXPIRATION}),r.timeout=setTimeout(()=>{u(r.current,100*r.kata.length,"waktu habis dan kalah!",e,t,r,n)},1e3*r.timer)):(s=`✗ *${i}* tidak terdaftar di KBBI.
`,r.player[r.index].chance--,r.player[r.index].chance<=0?(m=r.current,await u(m,l,"tidak terdaftar di KBBI dan kesempatan habis!",e,t,r,n)):await a.reply(s+"✧ Sisa kesempatan: "+r.player[r.index].chance)))};export default{run:run,main:main,cmd:"sambungkata",alias:"sk",use:"options",type:"games",group:!0,location:"plugins/games/sambungkata.js"};