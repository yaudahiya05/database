import fs from"node:fs";import path from"node:path";let ATTACK_COOLDOWN_MS=5e3,AFK_CHECK_DURATION_MS=9e4,AFK_PENALTY_HP=500,CHARACTER_HP=1e3;class Character{constructor(e,a){this.user=e,this.hp=CHARACTER_HP,this.lvl=a,this.turnTaken=!1,this.lastActionTime=0}isAlive(){return 0<this.hp}takeDamage(e){this.hp-=e,this.hp<0&&(this.hp=0)}}class WarGameSession{constructor(e,a){this.chatId=e,this.ownerJid=a,this.status=!1,this.balance=0,this.teamA=[],this.teamB=[],this.currentTurnPlayerIndex=0,this.currentTurnTeam="A",this.round=1,this.turnAfkTimeout=null,this.lastGameMessage=null}getAllLivingPlayers(){return[...this.teamA.filter(e=>e.isAlive()),...this.teamB.filter(e=>e.isAlive())]}getCurrentTurnPlayer(){return("A"===this.currentTurnTeam?this.teamA:this.teamB)[this.currentTurnPlayerIndex]}getLivingPlayersInTeam(e){return("A"===e?this.teamA:this.teamB).filter(e=>e.isAlive())}addPlayerToTeam(e,a,t){return e=new Character(e,a),"A"===t&&this.teamA.length<5?(this.teamA.push(e),!0):"B"===t&&this.teamB.length<5&&(this.teamB.push(e),!0)}nextTurn(){let a="A"===this.currentTurnTeam?this.teamA:this.teamB,t=!1;for(let e=this.currentTurnPlayerIndex+1;e<a.length;e++)if(a[e].isAlive()){this.currentTurnPlayerIndex=e,this.currentTurnTeam=this.currentTurnTeam,t=!0;break}if(!t){this.currentTurnTeam="A"===this.currentTurnTeam?"B":"A";var r="A"===this.currentTurnTeam?this.teamA:this.teamB;for(let e=0;e<r.length;e++)if(r[e].isAlive()){this.currentTurnPlayerIndex=e,t=!0;break}}t||(this.currentTurnPlayerIndex=-1,this.status=!1);var e=[...this.teamA,...this.teamB];e.every(e=>e.turnTaken||!e.isAlive())&&(e.forEach(e=>e.turnTaken=!1),this.round++)}startAfkTimer(e,a,t){clearTimeout(this.turnAfkTimeout);let r=this.getCurrentTurnPlayer();r&&(this.turnAfkTimeout=setTimeout(async()=>{r.takeDamage(AFK_PENALTY_HP),await e.reply(this.chatId,`✗ @${r.user.split("@")[0]} (${r.user.split("@")[0]}) sedang AFK (Denda -${AFK_PENALTY_HP} HP)!`,a,{mentions:[r.user]}),this.checkWinCondition()?await this.endGame(e,a,t):(this.nextTurn(),await this.sendTurnMessage(e,a,t))},AFK_CHECK_DURATION_MS))}async sendTurnMessage(e,a,t){var r,i=this.getCurrentTurnPlayer();i&&(this.teamA.filter(e=>e.isAlive()).map(e=>e.hp).reduce((e,a)=>e+a,0),this.teamB.filter(e=>e.isAlive()).map(e=>e.hp).reduce((e,a)=>e+a,0),r=`WARZONE BATTLE - Ronde ${this.round}

`,r=(r+=`• Team A: ${this.teamA.map(e=>`${e.isAlive()?"✦":"✖"} @${e.user.split("@")[0]} (HP:${e.hp})`).join("\n")}
`)+`• Team B: ${this.teamB.map(e=>`${e.isAlive()?"✦":"✖"} @${e.user.split("@")[0]} (HP:${e.hp})`).join("\n")}

`+`Giliran @${i.user.split("@")[0]} untuk menyerang (Waktu ${AFK_CHECK_DURATION_MS/1e3} detik).
`+`Gunakan *${a.prefix}attack @tag* untuk menyerang lawan.
`,await e.reply(this.chatId,r,a,{mentions:this.getAllLivingPlayers().map(e=>e.user)}),this.startAfkTimer(e,a,t))}checkWinCondition(){var e=this.teamA.some(e=>e.isAlive()),a=this.teamB.some(e=>e.isAlive());return e||a?e?a?null:"A":"B":"draw"}async endGame(e,i,n){clearTimeout(this.turnAfkTimeout),this.status=!1;var s,l=this.checkWinCondition();if(l){let a=`PERMAINAN WAR ZONE BERAKHIR! ✦

`,t=[],r=[];"draw"===l?a+="✦ HASIL SERI! Tidak ada yang menang.":(a+=`✦ TEAM ${l} MENANG! Selamat kepada para pemenang!`,s="A"===l?this.teamA:this.teamB,l="A"===l?this.teamB:this.teamA,a=(a+=`

• TEAM A:
`+this.teamA.map(e=>`${e.isAlive()?"✦":"✖"} @${e.user.split("@")[0]} (HP:${e.hp})`).join("\n"))+`

• TEAM B:
`+this.teamB.map(e=>`${e.isAlive()?"✦":"✖"} @${e.user.split("@")[0]} (HP:${e.hp})`).join("\n")+`

• HADIAH & DENDA BALANCE:
`,s.forEach(e=>{e.user&&(global.db.users[e.user]=global.db.users[e.user]||{balance:0,game:{}},global.db.users[e.user].balance=(global.db.users[e.user].balance||0)+this.balance,global.db.users[e.user].game.war=(global.db.users[e.user].game.war||0)+1,t.push(e.user),a+=`+ @${e.user.split("@")[0]} mendapatkan ${n.toRupiah(this.balance)}
`)}),l.forEach(e=>{e.user&&(global.db.users[e.user]=global.db.users[e.user]||{balance:0},global.db.users[e.user].balance=(global.db.users[e.user].balance||0)-this.balance,global.db.users[e.user].balance<0&&(global.db.users[e.user].balance=0),r.push(e.user),a+=`- @${e.user.split("@")[0]} kehilangan ${n.toRupiah(this.balance)}
`)})),await e.reply(this.chatId,a,i,{mentions:[...t,...r]}),delete e.warGames[this.chatId]}}}let run=async(t,e,{func:a,cfg:r})=>{e.warGames=e.warGames||{};let i=e.warGames[t.chat];var n,[s,l]=t.args,u=(global.db.users[t.sender]=global.db.users[t.sender]||{level:1,balance:0,game:{}},global.db.users[t.sender]);if(!s||/help/i.test(s))await e.sendMessage(t.chat,{text:`WAR BATTLE SQUAD

> WAR ZONE RULES
Game perang sistem _turn attack_ (menyerang bergiliran), dimulai 1v1 sampai 5v5, modal dari harta rampasan jika menang, ${CHARACTER_HP}HP.

Keberhasilan tergantung levelmu dan level musuh, waktu menyerang 40 detik, lebih dari itu dianggap AFK (-${AFK_PENALTY_HP}HP).

Tim menang jika tim lawan kalah semua (0HP) dan mendapatkan harta rampasan.

> COMMANDS LIST
*${t.prefix}war join A/B* = join game
*${t.prefix}war modal [jumlah]* = set modal taruhan (hanya pembuat room)
*${t.prefix}war exit* = keluar game
*${t.prefix}war player* = statistik pemain
*${t.prefix}war start* = start game`,contextInfo:{mentionedJid:[t.sender],externalAdReply:{title:"RPG - CLASH SQUAD",body:"Battle royale, bertempur dengan gaya",thumbnailUrl:"https://qu.ax/RmYQa.jpg",sourceUrl:"-",mediaType:1,renderLargerThumbnail:!0}}},{quoted:t,ephemeralExpiration:t.expiration});else{if(/modal/i.test(s))return i?t.sender!==i.ownerJid?e.reply(t.chat,`✗ Hanya @${i.ownerJid.split("@")[0]} sebagai pembuat room yang bisa mengganti modal awal perang.`,null,{mentions:[i.ownerJid]}):(n=parseInt(l),isNaN(n)||n<1e3?t.reply(`✗ Masukkan modal taruhan perang berupa angka (minimal $1.000 balance)

Contoh: ${t.prefix}war modal 1000`):(i.balance=n,void await t.reply("✓ Berhasil menetapkan modal perang sebesar Rp. "+n.toLocaleString()))):t.reply(`✗ Silahkan buat room terlebih dahulu (Ketik ${t.prefix}war join)`);if(/join/i.test(s)){if(a.ceklimit(t.sender,1))return t.reply(r.mess.limit);if(i){if(i.status)return t.reply("✗ Permainan sudah dimulai, tidak bisa join.");if(i.getAllLivingPlayers().some(e=>e.user===t.sender))return t.reply("✗ Anda sudah masuk ke dalam game.")}else i=new WarGameSession(t.chat,t.sender),e.warGames[t.chat]=i;return u.balance<1e3?t.reply("✗ Balance kamu minimal $1000 untuk bermain game ini."):0===i.balance&&t.sender!==i.ownerJid?t.reply(`✗ Pembuat room (@${i.ownerJid.split("@")[0]}) harus menetapkan modal awal perang terlebih dahulu.`):u.balance<i.balance&&t.sender!==i.ownerJid?t.reply(`✗ Balance kamu minimal ${i.balance.toLocaleString()} untuk bermain game ini.`):(n=l?l.toUpperCase():null)&&["A","B"].includes(n)?5<=("A"===n?i.teamA:i.teamB).length?t.reply(`✗ Tim ${n} sudah penuh (maksimal 5 pemain).`):void(i.addPlayerToTeam(t.sender,u.level,n)?await t.reply(`✓ Berhasil masuk ke dalam game sebagai Team ${n}

${t.prefix}war join A/B = join game
${t.prefix}war start = mulai game`):await t.reply(`✗ Gagal bergabung ke tim ${n}. Mungkin tim sudah penuh.`)):t.reply(`✗ Pilih salah satu tim A atau B

Contoh: ${t.prefix}war join A`)}if(!/exit/i.test(s))return/player/i.test(s)?i?(r=i.getAllLivingPlayers().map(e=>e.user),l=(i.status?`Giliran: @${i.getCurrentTurnPlayer().user.split("@")[0]} (Team ${i.currentTurnTeam})`:"")+`
`+`Taruhan: ${a.toRupiah(i.balance)} balance

`+`• TEAM A: (${i.teamA.length} pemain)
`+i.teamA.map(e=>`${e.isAlive()?"✦":"✖"} @${e.user.split("@")[0]} (Lv.${e.lvl} HP:${e.hp})`).join("\n")+`

• TEAM B: (${i.teamB.length} pemain)
`+i.teamB.map(e=>`${e.isAlive()?"✦":"✖"} @${e.user.split("@")[0]} (Lv.${e.lvl} HP:${e.hp})`).join("\n"),void await e.sendMessage(t.chat,{text:l,mentions:r})):t.reply("✗ Tidak ada pemain yang join room War Zone."):/start/i.test(s)?i?i.status?t.reply("✗ Perang sudah dimulai."):t.sender!==i.ownerJid?e.reply(t.chat,`✗ Hanya @${i.ownerJid.split("@")[0]} sebagai pembuat room yang bisa memulai perang.`,null,{mentions:[i.ownerJid]}):0===i.balance?t.reply("✗ Pembuat room harus menetapkan modal awal perang terlebih dahulu."):(u=i.teamA.length,n=i.teamB.length,0===u&&0===n?t.reply("✗ Tidak ada pemain di kedua tim."):u!==n?t.reply(`✗ Tim A memiliki ${u} pemain dan Tim B memiliki ${n} pemain. Jumlah pemain harus seimbang agar permainan adil.`):0===u?t.reply("✗ Minimal ada 1 pemain di setiap tim."):(i.status=!0,i.currentTurnPlayerIndex=0,i.currentTurnTeam="A",i.round=1,await e.reply(t.chat,`✓ Permainan War Zone dimulai!

Semua pemain akan bertaruh ${a.toRupiah(i.balance)}.`,t),void await i.sendTurnMessage(e,t,a))):t.reply("✗ Tidak ada game War Zone di grup ini."):void 0;{if(!i)return t.reply("✗ Tidak ada game War Zone di grup ini.");if(i.status)return t.reply("✗ Perang sudah dimulai, anda tidak bisa keluar.");let a=!1;i.teamA=i.teamA.filter(e=>e.user!==t.sender||!(a=!0)),i.teamB=i.teamB.filter(e=>e.user!==t.sender||!(a=!0)),a?(await t.reply("✓ Berhasil keluar dari game."),0===i.teamA.length&&0===i.teamB.length&&delete e.warGames[t.chat]):await t.reply("✗ Kamu tidak sedang berada di dalam game.")}}},main=async(i,n,{func:s})=>{n.warGames=n.warGames||{};var l=n.warGames[i.chat];if(l&&l.status){var u=l.getCurrentTurnPlayer();if(!u||i.sender!==u.user)return i.reply(`✗ Sekarang adalah giliran @${u.user.split("@")[0]} untuk menyerang.`,null,{mentions:[u.user]});if("attack"===i.command){let a=i.mentionedJid?.[0]||i.quoted?.sender||null;if(!a)return i.reply(`✗ Tag musuh yang akan diserang. Contoh: ${i.prefix}attack @lawan`);var m=("A"==("A"===l.currentTurnTeam?"B":"A")?l.teamA:l.teamB).find(e=>e.user===a);if(!m||!m.isAlive())return i.reply(`✗ Musuh @${a.split("@")[0]} tidak valid atau sudah mati. Cek *${i.prefix}war player*.`,null,{mentions:[a]});clearTimeout(l.turnAfkTimeout);let e=u.lvl,t=m.lvl,r=s.ranNumb(100,500)+10*e-5*t;r<50&&(r=50),m.takeDamage(r),u.turnTaken=!0,e=`✦ @${u.user.split("@")[0]} menyerang @${m.user.split("@")[0]}! `+`
@${m.user.split("@")[0]} menerima ${r} damage. (Sisa HP: ${m.hp})`+`
Level @${u.user.split("@")[0]} (${e}) vs Level @${m.user.split("@")[0]} (${t}) sangat mempengaruhi keberhasilan serangan.`,await n.reply(i.chat,e,i,{mentions:[u.user,m.user]}),l.checkWinCondition()?await l.endGame(n,i,s):(l.nextTurn(),await l.sendTurnMessage(n,i,s))}}};export default{run:run,main:main,cmd:["war","attack"],use:"options",type:"games",group:!0,location:"plugins/war.js"};