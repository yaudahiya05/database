import fetch from"node-fetch";import similarity from"similarity";let gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/family100.json",sensitive=.75,alreadyAnswered=new Set,DATABASE={},askedQuestions=[],getNewQuestion=async()=>{var a=(await fetch(gamesUrl).then(a=>a.json())).result;askedQuestions.length===a.length&&(askedQuestions=[]);let e;for(;e=Math.floor(Math.random()*a.length),askedQuestions.includes(e););return askedQuestions.push(e),a[e]},run=async(t,i,{cfg:a,func:e,setting:n})=>{var r,s,l,m;return!e.ceklimit(t.sender,1)||t.isPrem||t.isVIP?t.chat in DATABASE?i.reply(t.chat,"✗ Masih ada soal belum terjawab di chat ini",DATABASE[t.chat].msg):({soal:r,jawaban:s}=await getNewQuestion(),Array.isArray(s)?(l=e.hadiah(n.hadiah),m=s.map(a=>{let e=a.split("/")[0];return(e=e.trim()).toLowerCase()}),e=`*FAMILY 100 GAMES*

${e.texted("monospace",r)}

Total Jawaban: ${s.length}
Hadiah: ${l} balance
Waktu: ${n.gamewaktu} detik`,e=await i.reply(t.chat,e,t,{expiration:t.expiration}),alreadyAnswered.clear(),void(DATABASE[t.chat]={soal:r,jawaban:m,hadiah:l,total:s.length,players:[],nextQuestion:1,timeout:setTimeout(()=>{var a,e;t.chat in DATABASE&&(e="Waktu habis!\nJawaban yang belum terjawab :\n"+(a=DATABASE[t.chat]).jawaban.map(a=>"- "+a).join("\n"),i.reply(t.chat,e,a.msg,{expiration:t.expiration}),delete DATABASE[t.chat])},1e3*n.gamewaktu),msg:e?{key:e.key,message:e.message}:null})):t.reply("Terjadi kesalahan, silahkan kirim ulang "+t.cmd)):t.reply(a.mess.limit)},main=async(l,m,{cfg:a,func:o,setting:u})=>{if(l.chat in DATABASE&&!l.fromMe&&!l.isPrefix){let s=DATABASE[l.chat];if(/nyerah/i.test(l.budy)){if(o.ceklimit(l.sender,1))return l.reply(a.mess.limit);s.timeout&&clearTimeout(s.timeout),a="Jawaban yang belum terjawab :\n"+s.jawaban.map(a=>"- "+a).join("\n");let r=await m.sendMessage(l.chat,{text:a},{quoted:DATABASE[l.chat].msg,ephemeralExpiration:l.expiration});return setTimeout(async()=>{var{soal:a,jawaban:e}=await getNewQuestion();if(!Array.isArray(e))return m.reply(l.chat,`✗ Terjadi kesalahan pada soal baru, silahkan kirim ulang ${l.prefix}family100`);var t=o.hadiah(u.hadiah),i=e.map(a=>{let e=a.split("/")[0];return(e=e.trim()).toLowerCase()}),n=(s.nextQuestion++,`LANJUT SOAL KE-${s.nextQuestion}

${o.texted("monospace",a)}

Total Jawaban: ${e.length}
Hadiah: ${t} balance
Waktu: ${u.gamewaktu} detik`),n=await m.sendMessage(l.chat,{text:n,edit:r.key},{quoted:l,ephemeralExpiration:l.expiration});alreadyAnswered.clear(),Object.assign(s,{soal:a,jawaban:i,hadiah:t,total:e.length,players:[],timeout:setTimeout(()=>{var a;l.chat in DATABASE&&(a="Waktu habis!\nJawaban yang belum terjawab :\n"+s.jawaban.map(a=>"- "+a).join("\n"),m.reply(l.chat,a,s.msg,{expiration:l.expiration}),delete DATABASE[l.chat])},1e3*parseInt(u.gamewaktu)),msg:n?{key:n.key,message:n.message}:null})},3e3),!1}for(var e of s.jawaban)if(checkAnswerSimilarity(e,l.budy.toLowerCase(),sensitive)){if(alreadyAnswered.has(e))return;alreadyAnswered.add(e);var t=s.jawaban.indexOf(e);-1<t&&s.jawaban.splice(t,1),s.players.push({jid:l.sender,jawaban:e.toLowerCase()});let a;return l.isGc?(a=`${s.soal}

Terdapat *${s.total}* jawaban
`+s.players.map((a,e)=>`${e+1}. ${a.jawaban} @`+a.jid.split("@")[0]).join("\n"),s.jawaban.length<1?a+=`

Selamat semua jawaban sudah tertebak!
ingin bermain lagi? kirim ${l.prefix}family100`:a+=`

${s.hadiah} balance tiap jawaban benar
ketik *nyerah* untuk menyerah`):(a=`Jawaban kamu benar!
Jawaban: ${e}

`,s.jawaban.length<1?a+=`Selamat semua jawaban sudah tertebak!
ingin bermain lagi? kirim ${l.prefix}family100`:a+="Jawaban yang belum tertebak: "+s.jawaban.length),m.reply(l.chat,a,l,{expiration:l.expiration}),global.db.users[l.sender]=global.db.users[l.sender]||{balance:0,game:{}},global.db.users[l.sender].balance=(global.db.users[l.sender].balance||0)+s.hadiah,global.db.users[l.sender].game=global.db.users[l.sender].game||{},global.db.users[l.sender].game.family100=(global.db.users[l.sender].game.family100||0)+1,void(s.jawaban.length<1&&(clearTimeout(s.timeout),delete DATABASE[l.chat]))}}};function checkAnswerSimilarity(a,e,t){let i=e.toLowerCase();return Array.isArray(a)?a.some(a=>similarity(a,i)>=t):similarity(a,i)>=t}export default{run:run,main:main,cmd:["family100"],alias:["f100"],type:"games",location:"plugins/games/family100.js"};