let tictactoe={},run=async(a,e,{cfg:t,func:n})=>{if(a.sender in tictactoe){var i=tictactoe[a.sender],s=`❌ Masih ada sesi yang belum selesai ❌

@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

${displayBoard(i.TicTacToe)}

Giliran @`+(i.status?i.penantang:i.ditantang).split("@")[0];await e.sendMessage(a.chat,{text:s,edit:i.mainBoardMessageKey,mentions:[i.ditantang,i.penantang]},{quoted:a,ephemeralExpiration:a.expiration})}else{if(n.ceklimit(a.sender,3))return a.reply(t.mess.limit);s=n.randomNomor(3e3,5e3),t=`@${a.sender.split("@")[0]} menantang bot untuk bermain TicTacToe

✦ Game akan dimulai.

Hadiah : ${s} balance`,n=(await e.sendMessage(a.chat,{text:t,mentions:[a.sender]},{quoted:a,ephemeralExpiration:a.expiration})).key,tictactoe[a.sender]={id:a.sender,mainBoardMessageKey:n,status:!0,hadiah:s,penantang:a.sender,ditantang:a.bot,TicTacToe:["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"]},await delay(2e3);i=tictactoe[a.sender];t=`@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

${displayBoard(i.TicTacToe)}

Giliran @`+i.penantang.split("@")[0],await e.sendMessage(a.chat,{text:t,edit:i.mainBoardMessageKey,mentions:[i.ditantang,i.penantang]},{quoted:a,ephemeralExpiration:a.expiration})}},main=async(e,t,{})=>{tictactoe=tictactoe||{};var a,n,i=a=>a.every(a=>"❌"===a||"⭕"===a),s=n=>[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]].some(a=>{var[a,e,t]=a;return n[a]===n[e]&&n[e]===n[t]&&("❌"===n[a]||"⭕"===n[a])});function r(t,n){var i;for(i of[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]){let a=0,e=-1;for(var s of i)t[s]===n?a++:"❌"!==t[s]&&"⭕"!==t[s]&&(e=s);if(2===a&&-1!==e)return e}return-1}if(n=e.sender,tictactoe,n in tictactoe)try{var o=tictactoe[e.sender],d=o.TicTacToe;if(!o.status)return e.reply(`Bukan giliranmu, giliran @${o.ditantang.split("@")[0]} (bot).`);var l=parseInt(e.budy);if(isNaN(l)||l<1||9<l)return e.reply("✗ Masukkan nomor papan yang valid (1-9).");var p=l-1;if("❌"===d[a=p]||"⭕"===d[a])return e.reply(`✗ Nomor ${l} sudah terisi.`);if(o.TicTacToe[p]="❌",s(o.TicTacToe))await t.sendMessage(e.chat,{text:`❌ @${o.penantang.split("@")[0]} Menang!

@${o.penantang.split("@")[0]} = ❌
@${o.ditantang.split("@")[0]} = ⭕

${displayBoard(d)}

Hadiah : ${o.hadiah} balance`,edit:o.mainBoardMessageKey,mentions:[o.ditantang,o.penantang]},{quoted:e,ephemeralExpiration:e.expiration}),await t.sendReact(e.chat,"✅",e.key),global.db.users[o.penantang]=global.db.users[o.penantang]||{balance:0,game:{}},global.db.users[o.penantang].balance=(global.db.users[o.penantang].balance||0)+o.hadiah,global.db.users[o.penantang].game.tictactoe=(global.db.users[o.penantang].game.tictactoe||0)+1,delete tictactoe[e.sender];else if(i(d))await t.sendMessage(e.chat,{text:`✧ Hasil Seri!

@${o.penantang.split("@")[0]} = ❌
@${o.ditantang.split("@")[0]} = ⭕

`+displayBoard(d),edit:o.mainBoardMessageKey,mentions:[o.ditantang,o.penantang]},{ephemeralExpiration:e.expiration}),delete tictactoe[e.sender];else{var g=`@${o.penantang.split("@")[0]} telah mengisi

@${o.penantang.split("@")[0]} = ❌
@${o.ditantang.split("@")[0]} = ⭕

${displayBoard(d)}

Giliran @`+o.ditantang.split("@")[0];await t.sendMessage(e.chat,{text:g,edit:o.mainBoardMessageKey,mentions:[o.ditantang,o.penantang]},{ephemeralExpiration:e.expiration}),o.status=!1,await delay(2e3);{var c,m=e,u=t,h=tictactoe[m.sender],T=h.TicTacToe;let a=r(T,"⭕");-1===(a=-1===(a=-1===a?r(T,"❌"):a)&&"❌"!==T[4]&&"⭕"!==T[4]?4:a)&&(c=T.map((a,e)=>"❌"!==a&&"⭕"!==a?e:-1).filter(a=>-1!==a),a=0<c.length?c[Math.floor(Math.random()*c.length)]:-1),-1!==a&&(h.TicTacToe[a]="⭕",s(h.TicTacToe)?(await u.sendMessage(m.chat,{text:`⭕ Bot Menang!

@${h.penantang.split("@")[0]} = ❌
@${h.ditantang.split("@")[0]} = ⭕

`+displayBoard(T),edit:h.mainBoardMessageKey,mentions:[h.ditantang,h.penantang]},{ephemeralExpiration:m.expiration}),delete tictactoe[m.sender]):i(T)?(await u.sendMessage(m.chat,{text:`✧ Hasil Seri!

@${h.penantang.split("@")[0]} = ❌
@${h.ditantang.split("@")[0]} = ⭕

`+displayBoard(T),edit:h.mainBoardMessageKey,mentions:[h.ditantang,h.penantang]},{ephemeralExpiration:m.expiration}),delete tictactoe[m.sender]):(c=`Bot telah mengisi

@${h.penantang.split("@")[0]} = ❌
@${h.ditantang.split("@")[0]} = ⭕

${displayBoard(T)}

Giliran @`+h.penantang.split("@")[0],await u.sendMessage(m.chat,{text:c,edit:h.mainBoardMessageKey,mentions:[h.ditantang,h.penantang]},{ephemeralExpiration:m.expiration}),h.status=!0))}}}catch(a){console.error("Error in TicTacToe main logic:",a),await e.reply("✗ Terjadi kesalahan: "+a.message)}};function displayBoard(a){let t=["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"];var e="    ";return e+(a=a.map((a,e)=>"❌"===a?"❌":"⭕"===a?"⭕":t[e]))[0]+a[1]+a[2]+`
${e+a[3]+a[4]+a[5]}
`+e+a[6]+a[7]+a[8]}function delay(e){return new Promise(a=>setTimeout(a,e))}export default{run:run,main:main,cmd:"tbot",alias:"ttt-bot",use:"to play TicTacToe with bot",type:"games",premium:!0,location:"plugins/games/tictactoe-bot.js"};