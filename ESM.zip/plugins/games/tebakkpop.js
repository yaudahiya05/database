import fetch from 'node-fetch';
global.kpopGuessRooms = global.kpopGuessRooms || {};

const run = async (m, lulli, { cfg, func, setting }) => {
    const [command, answer] = m.args
    if (!command || /help/i.test(command)) {
        const message = `✧ *TEBAK GAMBAR KPOP*

⋄ ${m.prefix}*tebakkpop create* (buat room dengan gambar acak)
⋄ ${m.prefix}*tebakkpop join* (player join ke room)
⋄ ${m.prefix}*tebakkpop gambar* (tampilkan gambar yang akan ditebak)
⋄ ${m.prefix}*tebakkpop tebak* <jawaban> (player menebak siapa pada gambar)
⋄ ${m.prefix}*tebakkpop player* (daftar pemain yang bergabung dan jawaban mereka)
⋄ ${m.prefix}*tebakkpop start* (mulai permainan dan ungkap jawaban sebenarnya)
⋄ ${m.prefix}*tebakkpop delete* (hapus sesi room game)

Tebak siapa yang ada di gambar!
Minimal player yang bergabung untuk memulai game adalah 2 pemain.`;

        await lulli.sendMessage(m.chat, {
            text: message,
            contextInfo: {
                externalAdReply: {
                    title: "GAME TEBAK KPOP",
                    body: cfg.header,
                    thumbnailUrl: setting.cover,
                    sourceUrl: setting.link,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        });
        return;
    }

    try {
        switch (command.toLowerCase()) {
            case 'create':
                if (global.kpopGuessRooms[m.chat]) {
                    return m.reply('Room sudah ada. Gunakan .tebakkpop delete untuk menghapus room yang ada.');
                }

                const response = await fetch('https://raw.githubusercontent.com/VynaaValerie/mlbb/main/Kpop-image/image-kpop.json');
                const images = await response.json();
                const randomImage = images[Math.floor(Math.random() * images.length)];
                global.kpopGuessRooms[m.chat] = {
                    creator: m.sender,
                    players: [],
                    gameStarted: false,
                    image: randomImage
                };

                m.reply(`Room berhasil dibuat. Gunakan ${m.prefix}tebakkpop gambar untuk melihat gambar yang akan ditebak.`);

                break;

            case 'join':
                if (!global.kpopGuessRooms[m.chat]) {
                    return m.reply('Belum ada room yang dibuat. Gunakan .tebakkpop create untuk membuat room.');
                }
                if (global.kpopGuessRooms[m.chat].players.find(p => p.id === m.sender)) {
                    return m.reply('Anda sudah bergabung di room.');
                }
                const playerName = m.pushname || lulli.getName(m.sender);
                global.kpopGuessRooms[m.chat].players.push({ id: m.sender, name: playerName, guess: null });
                m.reply(`Anda berhasil bergabung di room.`);
                break;

            case 'gambar':
                if (!global.kpopGuessRooms[m.chat]) {
                    return m.reply('Belum ada room yang dibuat. Gunakan .tebakkpop create untuk membuat room.');
                }
                const image = global.kpopGuessRooms[m.chat].image;
                await lulli.sendMedia(m.chat, image.image, m, {
                    caption: `Ini adalah gambar dari Kpop: ${image.question}\n\nGunakan ${m.prefix}tebakkpop tebak <jawaban> untuk menebak siapa mereka.`,
                    expiration: m.expiration
                });
                break;

            case 'tebak':
                if (!global.kpopGuessRooms[m.chat]) {
                    return m.reply('Belum ada room yang dibuat. Gunakan .tebakkpop create untuk membuat room.');
                }
                if (!answer) {
                    return m.reply('Harap masukkan jawaban Anda.');
                }
                const player = global.kpopGuessRooms[m.chat].players.find(p => p.id === m.sender);
                if (!player) {
                    return m.reply('Anda belum bergabung di room. Gunakan .tebakkpop join untuk bergabung.');
                }
                player.guess = m.args.slice(1).join(" ").toLowerCase();
                m.reply(`Jawaban Anda "${player.guess}" telah diterima.`);
                break;

            case 'player':
                if (!global.kpopGuessRooms[m.chat]) {
                    return m.reply('Belum ada room yang dibuat. Gunakan .tebakkpop create untuk membuat room.');
                }
                const players = global.kpopGuessRooms[m.chat].players;
                m.reply(`Pemain yang bergabung:\n${players.map(p => `${p.name} - ${p.guess ? p.guess : 'belum menjawab'}`).join('\n')}`);
                break;

            case 'start':
                if (!global.kpopGuessRooms[m.chat]) {
                    return m.reply('Belum ada room yang dibuat. Gunakan .tebakkpop create untuk membuat room.');
                }
                if (global.kpopGuessRooms[m.chat].players.length < 2) {
                    return m.reply('Minimal 2 pemain untuk memulai game.');
                }
                if (global.kpopGuessRooms[m.chat].gameStarted) {
                    return m.reply('Game sudah dimulai.');
                }
                if (global.kpopGuessRooms[m.chat].creator !== m.sender) {
                    return m.reply('Hanya pembuat room yang dapat memulai game.');
                }

                global.kpopGuessRooms[m.chat].gameStarted = true;

                m.reply('Jawaban akan diungkap dalam 5 detik! 🎤');

                setTimeout(async () => {
                    await m.reply('3... 🎤');
                    setTimeout(async () => {
                        await m.reply('2... 🎤');
                        setTimeout(async () => {
                            await m.reply('1... 🎤');
                            setTimeout(() => {
                                const currentRoom = global.kpopGuessRooms[m.chat];
                                const correctAnswer = currentRoom.image.answer;
                                const winners = currentRoom.players.filter(player => player.guess && player.guess === correctAnswer);

                                if (winners.length > 0) {
                                    m.reply(`Jawaban yang benar adalah "${correctAnswer}"!\nPemenangnya adalah:\n${winners.map(w => w.name).join(', ')}\nSelamat! 🎉`);
                                } else {
                                    m.reply(`Tidak ada yang menebak dengan benar. Jawaban yang benar adalah "${correctAnswer}".`);
                                }

                                delete global.kpopGuessRooms[m.chat];
                            }, 1000);
                        }, 1000);
                    }, 1000);
                }, 2000);
                break;

            case 'delete':
                if (!global.kpopGuessRooms[m.chat]) {
                    return m.reply('Belum ada room yang dibuat.');
                }
                if (global.kpopGuessRooms[m.chat].creator !== m.sender) {
                    return m.reply('Hanya pembuat room yang dapat menghapus room.');
                }
                delete global.kpopGuessRooms[m.chat];
                m.reply('Room telah dihapus.');
                break;

            default:
                m.reply(`Perintah tidak dikenal. Gunakan ${m.prefix}tebakkpop help untuk melihat daftar perintah.`);
        }
    } catch (error) {
        console.error(error);
        m.reply(`Terjadi kesalahan: ${error.message}`);
    }
};

export default {
    run,
    cmd: 'tebakkpop',
    alias: 'tkpop',
    type: 'games',
    group: true,
    location: 'plugins/games/tebakkpop.js'
};