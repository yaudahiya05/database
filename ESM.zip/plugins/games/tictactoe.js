let run=async(n,a,{func:t,cfg:e,froms:i})=>{var l;return global.db.tictactoe=global.db.tictactoe||{},n.isGc?Object.values(global.db.tictactoe).find(a=>a.penantang===n.sender||a.ditantang===n.sender)?n.reply("Selesaikan tictactoe kamu yang sebelumnya!"):i?i===a.user.id?n.reply("Tidak bisa bermain dengan bot!"):i===n.sender?n.reply("Tidak bisa bermain dengan diri sendiri."):!t.ceklimit(n.sender,1)||n.isPrem||n.isVIP?(t=t.randomNomor(3e3,5e3),l="tictactoe_"+Date.now(),await a.reply(n.chat,`@${n.sender.split("@")[0]} menantang @${i.split("@")[0]} untuk bermain TicTacToe

*Kirim (Y/N)* untuk bermain

Hadiah : ${t} balance`,n,{mentions:[n.sender,i],expiration:n.expiration}),void(global.db.tictactoe[l]={id:l,status:"WAIT",hadiah:t,asal:n.chat,penantang:n.sender,ditantang:i,TicTacToe:["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"],lastMessageKey:null})):n.reply(e.mess.limit):n.reply("Invalid number. Mention atau reply lawan yang ingin kamu tantang."):n.reply(e.mess.group)},KeisiSemua=a=>a.every(a=>"❌"===a||"⭕"===a),cekIsi=(a,n)=>"❌"===n[a]||"⭕"===n[a],cekTicTac=a=>{var n;for(n of[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]){var[t,e,i]=n;if(a[t]===a[e]&&a[e]===a[i])return!0}return!1},main=async(n,a,{func:t,cfg:e})=>{let i=Object.values(global.db.tictactoe).find(a=>a.penantang===n.sender||a.ditantang===n.sender);if(i)try{var l,s,g=i.TicTacToe;if(n.sender===i.ditantang&&n.isGc&&"WAIT"===i.status)"y"===n.budy.toLowerCase()?(await a.reply(n.chat,`Tictactoe telah dikirimkan ke chat @${i.penantang.split("@")[0]} dan @${i.ditantang.split("@")[0]}

Silahkan selesaikan tictactoe di chat masing-masing!
(Klik wa.me/${a.user.id.split("@")[0]} untuk PC bot)`,null,{mentions:[i.penantang,i.ditantang]}),a.reply(i.penantang,`Giliran kamu mengisi

@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

    ${g[0]}${g[1]}${g[2]}
    ${g[3]}${g[4]}${g[5]}
    `+g[6]+g[7]+g[8],null,{mentions:[i.penantang,i.ditantang]}).then(a=>i.lastMessageKey=a.key),a.reply(i.ditantang,`Menunggu lawan mengisi

@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

    ${g[0]}${g[1]}${g[2]}
    ${g[3]}${g[4]}${g[5]}
    ${g[6]}${g[7]}${g[8]}

_Giliran Lawan_`,null,{mentions:[i.penantang,i.ditantang]}),i.status=!0):"n"===n.budy.toLowerCase()&&(await n.reply(`@${i.ditantang.split("@")[0]} menolak, game dibatalkan.`,null,{mentions:[i.ditantang],expiration:n.expiration}),delete global.db.tictactoe[i.id]);else if((!0===i.status||!1===i.status)&&!(isNaN(n.budy)||parseInt(n.budy)<1||9<parseInt(n.budy)))return s=(l=parseInt(n.budy))-1,cekIsi(s,g)?a.reply(n.chat,`Nomor ${l} sudah terisi. Pilih nomor lain.`,n):void(n.isPc&&n.chat===i.penantang&&!0===i.status?(g[s]="❌",cekTicTac(g)?(await sendFinalBoard(a,i,g),await a.reply(i.asal,`@${i.penantang.split("@")[0]} Menang! 🎉

@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

Hadiah : ${t.formatNumber(i.hadiah)} balance
Ingin bermain lagi? ${n.prefix}tictactoe`,null,{mentions:[i.penantang,i.ditantang]}),global.db.users[i.penantang]=global.db.users[i.penantang]||{balance:0,game:{}},global.db.users[i.penantang].balance=(global.db.users[i.penantang].balance||0)+i.hadiah,global.db.users[i.penantang].game.tictactoe=(global.db.users[i.penantang].game.tictactoe||0)+1,global.db.users[i.ditantang]=global.db.users[i.ditantang]||{balance:0},global.db.users[i.ditantang].balance=(global.db.users[i.ditantang].balance||0)-i.hadiah,global.db.users[i.ditantang].balance<0&&(global.db.users[i.ditantang].balance=0),delete global.db.tictactoe[i.id]):KeisiSemua(g)?(await sendFinalBoard(a,i,g),await a.reply(i.asal,`乂  *H A S I L - S E R I* 🎉

@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

Ingin bermain lagi? ${n.prefix}tictactoe`,null,{mentions:[i.penantang,i.ditantang]}),delete global.db.tictactoe[i.id]):await updateAndSwitchTurn(a,i,n.chat,n.sender,!0)):n.isPc&&n.chat===i.ditantang&&!1===i.status&&(g[s]="⭕",cekTicTac(g)?(await sendFinalBoard(a,i,g),await a.reply(i.asal,`@${i.ditantang.split("@")[0]} Menang! 🎉

@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

Hadiah : ${t.formatNumber(i.hadiah)} balance
Ingin bermain lagi? ${n.prefix}tictactoe`,null,{mentions:[i.penantang,i.ditantang]}),global.db.users[i.ditantang]=global.db.users[i.ditantang]||{balance:0,game:{}},global.db.users[i.ditantang].balance=(global.db.users[i.ditantang].balance||0)+i.hadiah,global.db.users[i.ditantang].game.tictactoe=(global.db.users[i.ditantang].game.tictactoe||0)+1,global.db.users[i.penantang]=global.db.users[i.penantang]||{balance:0},global.db.users[i.penantang].balance=(global.db.users[i.penantang].balance||0)-i.hadiah,global.db.users[i.penantang].balance<0&&(global.db.users[i.penantang].balance=0),delete global.db.tictactoe[i.id]):KeisiSemua(g)?(await sendFinalBoard(a,i,g),await a.reply(i.asal,`乂  *H A S I L - S E R I* 🎉

@${i.penantang.split("@")[0]} = ❌
@${i.ditantang.split("@")[0]} = ⭕

Ingin bermain lagi? ${n.prefix}tictactoe`,null,{mentions:[i.penantang,i.ditantang]}),delete global.db.tictactoe[i.id]):await updateAndSwitchTurn(a,i,n.chat,n.sender,!1)))}catch(a){console.error("Error in tictactoe main logic:",a),await n.reply(e.mess.wrong(a.message)||"Terjadi kesalahan: "+a.message),i&&delete global.db.tictactoe[i.id]}};async function sendFinalBoard(a,n,t){var e=`Game tictactoe sudah selesai

@${n.penantang.split("@")[0]} = ❌
@${n.ditantang.split("@")[0]} = ⭕

`;e+=`    ${t[0]}${t[1]}${t[2]}
`,await a.reply(n.penantang,e=e+`    ${t[3]}${t[4]}${t[5]}
`+"    "+t[6]+t[7]+t[8],null,{mentions:[n.penantang,n.ditantang]}),await a.reply(n.ditantang,e,null,{mentions:[n.penantang,n.ditantang]})}async function updateAndSwitchTurn(a,n,t,e,i){var l=n.TicTacToe,s=`Kamu sudah mengisi

@${n.penantang.split("@")[0]} = ❌
@${n.ditantang.split("@")[0]} = ⭕

    ${l[0]}${l[1]}${l[2]}
    ${l[3]}${l[4]}${l[5]}
    ${l[6]}${l[7]}${l[8]}

_Giliran Lawan_`,l=`Lawan sudah mengisi

@${n.penantang.split("@")[0]} = ❌
@${n.ditantang.split("@")[0]} = ⭕

    ${l[0]}${l[1]}${l[2]}
    ${l[3]}${l[4]}${l[5]}
    ${l[6]}${l[7]}${l[8]}

_Giliran Kamu_`;await a.reply(n.penantang,i?s:l,null,{mentions:[n.penantang,n.ditantang]}),await a.reply(n.ditantang,i?l:s,null,{mentions:[n.penantang,n.ditantang]}),n.status=!i}export default{run:run,main:main,cmd:"tictactoe",alias:"ttt",use:"mention or reply",type:"games",location:"plugins/games/tictactoe.js"};