let getRandomSlot=()=>{var a=["🍊","🍇","🍉","🍌","🍍"];return a[Math.floor(Math.random()*a.length)]},checkThreeSame=(a,e,r)=>a===e&&e===r,checkNineSame=(a,e,r,m,n,t,o,c,l)=>a===e&&e===r&&r===m&&m===n&&n===t&&t===o&&o===c&&c===l,run=async(h,a,{func:i,users:k})=>{var s=2e3;if(k.balance<s)return h.reply("✗ Balance kamu tidak cukup untuk deposit slot sebanyak "+i.formatNumber(s));k.balance-=s;try{let a=Array.from({length:9},getRandomSlot),[e,r,m,n,t,o,c,l,u]=a,b,p=0,$=0;b=checkNineSame(...a)?(p=3e3,$=1e6,`✓ Kamu menang lagi dan mendapatkan Mega Jackpot!
✦ +${i.formatNumber(p)} Exp
✦ +${i.formatNumber($)} balance`):checkThreeSame(c,l,u)?(p=2e3,$=1e5,`✓ Kamu menang dan mendapatkan Jackpot!
✦ +${i.formatNumber(p)} Exp
✦ +${i.formatNumber($)} balance`):checkThreeSame(n,t,o)?(p=2e3,$=7e4,`✓ Kamu Jackpot
✦ +${i.formatNumber(p)} Exp
✦ +${i.formatNumber($)} balance`):checkThreeSame(e,r,m)?(p=1500,$=4e4,`✓ Kamu menang dalam Pertandingan ini!
✦ +${i.formatNumber(p)} Exp
✦ +${i.formatNumber($)} balance`):`✗ Kamu Kalah!
✦ -${i.formatNumber(s)} balance`,0<$&&(k.balance+=$),0<p&&(k.exp+=p);var f=`[  🎰 | SLOT BY LULLI BOT ]
-------------------
${e} : ${r} : ${m}
${n} : ${t} : ${o} <====
${c} : ${l} : ${u}
-------------------
[  🎰 | SLOTS ]
`+b;await h.reply(f)}catch(a){console.error("✗ Error in slot game:",a),await h.reply("✗ Terjadi kesalahan: "+a.message)}};export default{run:run,cmd:"slot",type:"games",limit:!0,location:"plugins/games/slot.js"};export{run};