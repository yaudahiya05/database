import axios from"axios";let DATABASE={},subjects=["bindo","tik","pkn","bing","penjas","pai","matematika","jawa","ips","ipa"],motivationalPhrases={0:"Waduh, kamu perlu belajar lebih giat lagi!",1:"Masih perlu banyak belajar nih!",2:"Lumayan, tapi bisa lebih baik!",3:"Bagus, pertahankan!",4:"Hampir setengah benar, semangat!",5:"Sudah setengah jalan! Tingkatkan lagi!",6:"Lumayan bagus!",7:"Bagus sekali!",8:"Hampir sempurna!",9:"Hampir sempurna! Tinggal sedikit lagi!",10:"Sempurna! Kamu benar-benar menguasai materi ini!"};async function sendQuestion(a,e){var n=DATABASE[e.sender],r=n.questions[n.currentQuestion];let s=`*Soal ${n.currentQuestion+1}/${n.questions.length}*

`;s+=r.pertanyaan+`

`,r.semua_jawaban.forEach(a=>{var[a,e]=Object.entries(a)[0];s+=a.toUpperCase()+`. ${e}
`}),r=await a.sendMessage(e.chat,{text:s+"\nReply pesan ini jawab opsi yang ada ya *A, B, C atau D*"},{quoted:e,ephemeralExpiration:e.expiration}),n.lastQuestionId=r.key.id,n.answered=!1}let run=async(a,e,{cfg:n})=>{if(DATABASE[a.sender])return a.reply("Kamu sedang bermain Cerdas Cermat. Selesaikan dulu soalnya!");var[r,s]=a.args.map(a=>a?a.trim().toLowerCase():"");if(!subjects.includes(r))return a.reply(`Pilih Mata Pelajaran Sama Jumlah Soal

*Mata Pelajaran Yang Ada*
- ${subjects.join("\n- ")}

*Jumlah Soal Minimal 5 Maximal 10*

*Contoh :* ${a.prefix}cc ipa 5`);if(s=parseInt(s),isNaN(s))return a.reply("Jumlah soal harus angka!");if(s<5||10<s)return a.reply("Jumlah soal harus antara 5-10!");try{var t=(await axios.get(`https://api.siputzx.my.id/api/games/cc-sd?matapelajaran=${r}&jumlahsoal=`+s)).data;if(!t||!t.data||!t.data.soal||0===t.data.soal.length)return a.reply("Gagal mendapatkan soal. Silakan coba lagi nanti.");DATABASE[a.sender]={questions:t.data.soal,currentQuestion:0,correctAnswers:0,startTime:Date.now(),lastQuestionId:null},await a.reply(`Game Cerdas Cermat dimulai untuk mata pelajaran *${r.toUpperCase()}* dengan ${s} soal!`),await sendQuestion(e,a)}catch(e){console.error("Error fetching Cerdas Cermat questions:",e),a.reply(n.mess.wrong(e.message)||"Terjadi kesalahan saat memulai game Cerdas Cermat.")}},main=async(a,e)=>{if(a.budy&&!a.isBot&&!a.fromMe){var n=DATABASE[a.sender];if(n){if(!a.quoted||a.quoted.id!==n.lastQuestionId)return n.answered?void 0:a.reply("Silakan jawab soal terakhir dengan me-reply pesan bot!");if(!n.answered){n.answered=!0;var r=a.budy.trim().toLowerCase(),s=n.questions[n.currentQuestion],t=s.jawaban_benar.toLowerCase();if(!(s=s.semua_jawaban.map(a=>Object.keys(a)[0].toLowerCase())).includes(r))return n.answered=!1,a.reply("Jawaban tidak valid. Pilih salah satu dari opsi yang tersedia: "+s.join(", ").toUpperCase());r===t?(n.correctAnswers++,await a.reply("Jawaban benar!")):await a.reply(`Jawaban salah! Yang benar adalah ${t.toUpperCase()}.`),n.currentQuestion++,n.currentQuestion<n.questions.length?await sendQuestion(e,a):(s=n.questions.length,r=n.correctAnswers,t=Math.round(r/s*100),e=Math.min(r,10),await a.reply(`*Hasil Cerdas Cermat*

`+`Jawaban benar: ${r}/${s}
`+`Nilai: ${t}%

`+motivationalPhrases[e]),delete DATABASE[a.sender])}}}};export default{run:run,main:main,cmd:"cerdascermat",alias:"cc",use:"matapelajaran jumlahsoal",type:"games",location:"plugins/games/cerdascermat.js"};export{run,main};