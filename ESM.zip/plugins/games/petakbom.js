let run=async(a,e,{func:b,cfg:o})=>{switch(global.db.petakbom=global.db.petakbom||{},global.db.users=global.db.users||{},a.command){case"petakbom":if(b.ceklimit(a.sender,1)&&!a.isPrem&&!a.isVIP)return a.reply(o.mess.limit);if(a.sender in global.db.petakbom)return l=global.db.petakbom[a.sender],a.reply(`Game kamu masih belum terselesaikan, lanjutkan yuk!

${l.board.join("")}

Kirim ${a.prefix}delpetakbom untuk menghapus game petak bom.`);var l=b.randomNomor(3e3,5e3),l=(global.db.petakbom[a.sender]={petak:[0,0,0,2,0,2,0,2,0,0].sort(()=>Math.random()-.5),board:["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣","🔟"],bomb:3,lolos:7,pick:0,hadiah:l,nyawa:["❤️","❤️","❤️"]},`PETAK BOM

${global.db.petakbom[a.sender].board.join("")}

Pilih lah nomor tersebut! Dan jangan sampai terkena Bom!
Bomb: ${global.db.petakbom[a.sender].bomb}
Nyawa: `+global.db.petakbom[a.sender].nyawa.join(""));e.reply(a.chat,l,a,{expiration:a.expiration});break;case"delpetakbom":if(!(a.sender in global.db.petakbom))return a.reply("Kamu sedang tidak bermain petakbom!");delete global.db.petakbom[a.sender],a.reply("Berhasil menghapus game petak bom.")}},main=async(a,e,{func:b})=>{var o,l,n=global.db.petakbom[a.sender];return n&&!a.isPrefix&&/^[1-9]|10$/i.test(a.budy)?(l=(o=parseInt(a.budy))-1,o<1||10<o?a.reply("Pilih angka antara 1 sampai 10 untuk membuka kotak."):1===n.petak[l]||2===n.petak[l]?a.reply(`Kotak nomor ${o} sudah dibuka, silakan pilih kotak yang lain.`):void(2===n.petak[l]?(n.board[l]="💣",n.pick++,n.bomb--,n.nyawa.pop(),n.nyawa.length<1?(await a.reply(`GAME OVER!
Kamu terkena bom di kotak ${o}.

${n.board.join("")}

Terpilih: ${n.pick} kotak
Nyawamu habis... balance -$`+b.rupiah(n.hadiah)),global.db.users[a.sender]=global.db.users[a.sender]||{balance:0},global.db.users[a.sender].balance=(global.db.users[a.sender].balance||0)-n.hadiah,global.db.users[a.sender].balance<0&&(global.db.users[a.sender].balance=0),delete global.db.petakbom[a.sender]):await a.reply(`PETAK BOM

Kamu terkena bom di kotak ${o}.
 ${n.board.join("")}

Terpilih: ${n.pick} kotak
Sisa nyawa: `+n.nyawa.join(""))):0===n.petak[l]&&(n.petak[l]=1,n.board[l]="🌀",n.pick++,n.lolos--,n.lolos<1?(await a.reply(`Selamat! Kamu berhasil menebak semua kotak aman🥳

${n.board.join("")}

Terpilih: ${n.pick} kotak
Sisa nyawa: ${n.nyawa.join("")}
Bom tersisa: ${n.bomb}
Hadiah: ${b.rupiah(n.hadiah)} balance`),global.db.users[a.sender]=global.db.users[a.sender]||{balance:0,game:{}},global.db.users[a.sender].balance=(global.db.users[a.sender].balance||0)+n.hadiah,global.db.users[a.sender].game.petakbom=(global.db.users[a.sender].game.petakbom||0)+1,delete global.db.petakbom[a.sender]):await a.reply(`PETAK BOM

${n.board.join("")}

Terpilih: ${n.pick} kotak
Sisa nyawa: ${n.nyawa.join("")}
Bom tersisa: `+n.bomb)))):void 0};export default{run:run,main:main,cmd:["petakbom","delpetakbom"],type:"games",location:"plugins/games/petakbom.js"};