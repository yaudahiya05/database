let run=async(t,a,{func:o})=>{a.cowboy=a.cowboy||{musuh:[],shoot:[]};var e,i=()=>{var o=`COWBOY CHASING CRIMINALS

`;return(o+=`Your territory:
${a.cowboy.shoot.join(" ")}
`)+`Criminals territory:
${a.cowboy.musuh.join(" ")}
`+`
Example: ${t.cmd} right, ${t.cmd} left, or ${t.cmd} shoot`};/left/i.test(t.text)?(0<(e=a.cowboy.shoot.indexOf("C"))&&(a.cowboy.shoot=["・","・","・","・","・"],a.cowboy.shoot[e-1]="C"),await t.reply(i())):/right/i.test(t.text)?((e=a.cowboy.shoot.indexOf("C"))<4&&(a.cowboy.shoot=["・","・","・","・","・"],a.cowboy.shoot[e+1]="C"),await t.reply(i())):/shoot/i.test(t.text)?a.cowboy.shoot.indexOf("C")===a.cowboy.musuh.indexOf("K")?(delete a.cowboy[t.chat],await t.reply("Selamat! Kamu berhasil mengejar penjahat!")):await t.reply("✗ Gagal menembak! Penjahat ada di posisi lain."):(a.cowboy.musuh=o.pickRandom((e=[["X","・","・","・","・"],["・","X","・","・","・"],["・","・","X","・","・"],["・","・","・","X","・"],["・","・","・","・","X"]]).map(o=>o.map(o=>"X"===o?"K":o))),a.cowboy.shoot=o.pickRandom(e.map(o=>o.map(o=>"X"===o?"C":o))),await t.reply(i()))};export default{run:run,cmd:["cowboy"],alias:["coboy"],type:"games",limit:!0,location:"plugins/games/cowboy.js"};