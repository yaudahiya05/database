let DATABASE={},run=async(e,t,{func:a,cfg:i})=>{if(a.ceklimit(e.sender,1)&&!e.isPrem&&!e.isVIP)return e.reply(i.mess.limit);let n=e.chat;if(n in DATABASE)return t.reply(e.chat,"Sesi ini belum selesai!",DATABASE[n].msg,{expiration:e.expiration});a=["💥","✅","✅","✅","✅","✅","✅","✅","✅"].sort(()=>Math.random()-.5);let r=["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"],o=a.map((a,e)=>({emot:a,number:r[e],position:e+1,state:!1})),m=`B O M B

Reply pesan ini dengan angka 1 - 9 untuk membuka 9 kotak nomor di bawah ini :

`;for(let a=0;a<o.length;a+=3)m+=o.slice(a,a+3).map(a=>a.state?a.emot:a.number).join("")+"\n";m+=`
Timeout : 3 menit
Apabila mendapat kotak yang berisi bom maka balance akan dikurangi.`,i=await t.reply(e.chat,m,e,{expiration:e.expiration}),DATABASE[n]={msg:i,array:o,time:setTimeout(()=>{var a=o.find(a=>"💥"===a.emot);DATABASE[n]&&t.reply(e.chat,`Waktu habis!, Bom berada di kotak nomor ${a.number}.`,DATABASE[n].msg,{expiration:e.expiration}),delete DATABASE[n]},18e4)}},main=async(i,n,{func:r,setting:a})=>{try{var o=i.chat,m=r.hadiah(a.hadiah||1e4),l=(global.db.users=global.db.users||{},global.db.users[i.sender]=global.db.users[i.sender]||{balance:0},global.db.users[i.sender]),e=(DATABASE=DATABASE||{},/^(me)?nyerah|surr?ender$/i.test(i.budy));if(DATABASE[o]&&e)return await n.reply(i.chat,"Menyerah. Permainan dibatalkan.",i,{expiration:i.expiration}),clearTimeout(DATABASE[o].time),void delete DATABASE[o];if(DATABASE[o]&&i.quoted&&i.quoted.id===DATABASE[o].msg.key.id&&!isNaN(i.budy)){let e=parseInt(i.budy),t=DATABASE[o],a=t.array.find(a=>a.position===e);if(!a)return n.reply(i.chat,"Untuk membuka kotak, reply pesan ini dengan angka 1 - 9.",t.msg,{expiration:i.expiration});if(a.state)return n.reply(i.chat,`Kotak ${a.number} sudah dibuka, silakan pilih kotak yang lain.`,i,{expiration:i.expiration});if("💥"===a.emot){a.state=!0;let e=`B O M B

`;for(let a=0;a<t.array.length;a+=3)e+=t.array.slice(a,a+3).map(a=>a.state?a.emot:a.number).join("")+"\n";e=(e+=`
Timeout : 3 menit
`)+`Permainan selesai!, kotak berisi bom terbuka: (- $${r.formatNumber(m)} balance)`,await n.reply(i.chat,e,i,{expiration:i.expiration}),l.balance=(l.balance||0)-m,l.balance<0&&(l.balance=0),clearTimeout(t.time),delete DATABASE[o]}else if(a.state=!0,8<=t.array.filter(a=>a.state&&"💥"!==a.emot).length){let e=`B O M B

`;e+=`Reply pesan ini dengan angka 1 - 9 untuk membuka 9 kotak nomor di bawah ini :

`;for(let a=0;a<t.array.length;a+=3)e+=t.array.slice(a,a+3).map(a=>a.state?a.emot:a.number).join("")+"\n";e=(e+=`
Timeout : 3 menit
`)+`Permainan selesai! kotak berisi bom tidak terbuka: (+ $${r.formatNumber(m)} balance)`,await n.reply(i.chat,e,i,{expiration:i.expiration}),l.balance=(l.balance||0)+m,clearTimeout(t.time),delete DATABASE[o]}else{let e=`B O M B

`;e+=`Reply pesan ini dengan angka 1 - 9 untuk membuka 9 kotak nomor di bawah ini :

`;for(let a=0;a<t.array.length;a+=3)e+=t.array.slice(a,a+3).map(a=>a.state?a.emot:a.number).join("")+"\n";e=(e+=`
Timeout : 3 menit
`)+`Kotak berisi bom tidak terbuka : (+ $${r.formatNumber(m)} balance)`,await n.relayMessage(i.chat,{protocolMessage:{key:t.msg.key,type:14,editedMessage:{conversation:e}}},{}),l.balance=(l.balance||0)+m}}}catch(r){console.error("Error in bomb game:",r),n.reply(i.chat,"✗ Terjadi kesalahan dalam game Bomb. Mohon coba lagi atau hubungi owner.",i,{expiration:i.expiration})}return!0};export default{run:run,main:main,cmd:"bomb",alias:"tebakbom",type:"games",location:"plugins/games/bomb.js"};