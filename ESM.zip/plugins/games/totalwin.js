let run=async(a,e,{func:t})=>{global.db.users=global.db.users||{};var l,n,r=global.db.users[a.sender];return r?.game?(r=r.game,0===(l=Object.values(r).reduce((a,e)=>a+(e||0),0))?a.reply("Data kemenangan kosong."):(n=`✧ *LIST TOTAL WIN GAMES*

`,n+=Object.entries(r).filter(([,a])=>0<a).map(([a,e])=>`› ${t.ucword(a)} : ${e}
`).join(""),void await e.reply(a.chat,n+=`
• Total: `+l,a,{expiration:a.expiration}))):a.reply("Kamu belum memiliki data permainan.")};export default{run:run,cmd:"totalwin",alias:["listtotalwin","totalmenang"],type:"games",location:"plugins/games/totalwin.js"};