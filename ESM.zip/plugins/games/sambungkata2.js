let fetch=require("node-fetch"),util=require("util"),gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/kbbi.json",random=a=>a[Math.floor(Math.random()*a.length)];function rwd(a,e){return a=Math.ceil(a),e=Math.floor(e),Math.floor(Math.random()*(e-a+1))+a}async function genKata(){return new Promise(async a=>{let e=await fetch(gamesUrl).then(a=>a.json()),t=random(["a","b","c","d","e","g","h","i","j","k","l","m","n","p","r","s","t","u","w"]),r=e.filter(a=>a.startsWith(t)),n=random(r);for(;n.length<3;)n=random(r);a(n)})}async function cekKata(e=""){return new Promise(async a=>{a((await fetch(gamesUrl).then(a=>a.json())).includes(e.toLowerCase()))})}function filter(a){let e=["q","w","r","t","y","p","s","d","f","g","h","j","k","l","z","x","c","v","b","n","m"];if(/[aiueo][aiueo]([qwrtypsdfghjklzxcvbnm])?$/i.test(a))return a.substring(a.length-1);var t,r=Array.from(a).filter(a=>e.includes(a));let n=r[r.length-1];for(t of e)a.endsWith(t)&&(n=r[r.length-2]);var i=a.split(n);return n+i[i.length-1]}module.exports={cmd:["sambungkata2"],alias:["sk2"],use:"options",type:"games",run:async(l,s,{func:u})=>{s.skata2=s.skata2||{};try{let a=`*Sambung Kata Help*
            
1. Permainan harus dimainkan minimal 2 pemain
2. Saat permainan dimulai bot akan memberikan 1 kata
3. Kemudian, player harus membuat 1 kata dari suku kata terakhir dari kata sebelumnya
4. Contohnya: *Teknologi*, maka jawabannya *Gigih* atau *Girang*
5. Permainan akan terus diulang sampai ada yang kalah
6. Tiap pemain diberi waktu 30 detik untuk menjawab
7. Tiap pemain diberi 3 kesempatan untuk menjawab
8. Kata yang dijawab harus terdaftar dalam KBBI dan belum pernah dijawab
9. Apabila benar, akan diberikan balance sesuai jumlah huruf kata yang dijawab dikali 100
10. Apabila 3 kesempatan atau waktu telah habis, player akan diberikan minus(-) balance dari kalkulasi jumlah balance yang telah diberikan pada permainan.`.trim(),t=l.chat,e,r=`Kirim perintah :
            
- ${l.cmd} help
- ${l.cmd} join
- ${l.cmd} start
- ${l.cmd} exit
- ${l.cmd} delete
- ${l.cmd} player
            
Minimal 2 orang`.trim(),n=(t in s.skata2||(e=await genKata(),s.skata2[t]={owner:l.sender,player:[],status:"wait",basi:[],point:0,chance:0,index:0,current:"",kata:e,genKata:genKata,cekKata:cekKata,filter:filter,chat:!1,timer:30,timeout:null}),(l.args[0]||"").toLowerCase()),i=(!n&&s.skata2[t]&&(s.skata2[t].chat=await s.reply(t,r,l,{expiration:l.expiration})),s.skata2[t]);switch(n){case"help":case"rules":case"menu":s.reply(t,a,l,{expiration:l.expiration});break;case"join":if(u.ceklimit(l.sender,1))return l.reply(cfg.mess.limit);if(i.player.find(a=>a.id==l.sender))return l.reply("kamu sudah berada didalam list");s.skata2[t].player.push({id:l.sender,chance:3}),l.reply((`Berhasil masuk
Jumlah pemain: `+i.player.length).trim());break;case"exit":if(!i)return l.reply("Tidak ada sesi permainan");if(!i.player.find(a=>a.id==l.sender))return l.reply("Kamu tidak dalam sesi permainan.");if("play"==i.status)return l.reply("Permainan sudah dimulai, kamu tidak bisa keluar");var p=i.player.findIndex(a=>a.id===l.sender);i.player.splice(p,1),l.reply(`@${l.sender.split("@")[0]} keluar dari permainan.`);break;case"delete":if(!i)return l.reply("Tidak ada sesi permainan.");if(i.owner!==l.sender&&"play"==i.status)return l.reply(`Hanya @${i.owner.split("@")[0]} yang dapat menghapus sesi permainan ini.`);s.reply(t,"Sesi permainan berhasil dihapus.",l,{expiration:l.expiration}),i.timeout&&clearTimeout(i.timeout),delete s.skata2[t];break;case"player":if(!i)return l.reply("Tidak ada sesi permainan.");if(!i.player.find(a=>a.id==l.sender))return l.reply("Kamu tidak dalam sesi permainan.");if(0==i.player.length)return l.reply("Sesi permainan belum memiliki player.");var c="*S A M B U N G - K A T A*\n\nLIST PLAYER:\n";c+=i.player.map((a,e)=>e+1+". @"+a.id.split("@")[0]).join("\n"),s.reply(t,c.trim(),l,{expiration:l.expiration});break;case"start":if(i.player.length<2)return l.reply("Minimal 2 player.");if("wait"!==i.status)return s.reply(t,"Room sambungkata ini belum selesai",i.chat,{expiration:l.expiration}),!1;i.current=i.player[0].id,i.index=0,i.status="play";for(var o of i.player){var m=global.db.users[o.id];m.game||(m.game={}),m.game.hasOwnProperty("sambungkata")||(m.game.sambungkata=0)}c=`Giliran @${i.current.split("@")[0]}
Kata : *${i.kata}*
Waktu: ${i.timer}s
Kesempatan: ${i.player[i.index].chance}

Carilah kata yang berawalan *${i.filter(i.kata)}*`,i.chat=await s.reply(t,c.trim(),null,{mentions:[i.current],expiration:l.expiration}),i.point=100*i.kata.length;let e=()=>setTimeout(async()=>{s.reply(t,`Waktu habis @${i.current.split("@")[0]} tereliminasi.
Hadiah: -${i.point} balance`,i.chat,{mentions:[i.current],expiration:l.expiration}),global.db.users[i.current].balance-=i.point,i.timeout&&clearTimeout(i.timeout);var a=i.index,a=(i.player.splice(i.index,1),i.current=(1<i.player.length?i.player[a]:i.player[0])?.id,{player:i.player,current:i.current});if(u.logAndWrite("room skata1",a),1==i.player.length&&"play"==i.status)return global.db.users[i.current].game.sambungkata+=1,global.db.users[i.current].balance+=i.point,s.reply(l.chat,`@${i.current.split("@")[0]} Menang
Hadiah: $${i.point} balance`,i.chat,{mentions:[i.current],expiration:l.expiration}),delete s.skata2[t],!1;i.kata=await i.genKata(),a=`Lanjut Giliran @${i.current.split("@")[0]}
Kata: *${i.kata}*
Waktu: ${i.timer}s
Kesempatan: ${i.player[i.index].chance}

Carilah kata yang berawalan *${i.filter(i.kata)}*`.trim(),i.chat=await s.reply(l.chat,a,null,{mentions:[i.current],expiration:l.expiration}),i.point=100*i.kata.length,i.timeout=e()},1e3*i.timer);return i.timeout=e(),i}}catch(a){console.log(a),s.reply(l.chat,a.message,l,{expiration:l.expiration})}},main:async(i,l,{func:s})=>{if(l.skata2=l.skata2||{},i.chat in l.skata2&&i.budy){let n=i.chat;if(l.skata2[n]){let r=l.skata2[n];if("play"===r.status&&r.current===i.sender){var a=i.budy.toLowerCase().split(" ")[0].trim().replace(/[^a-z]/gi,""),u=await r.cekKata(a),p=100*a.length,c=(console.log("ANSWER:",a),r.filter(r.kata));if(console.log("filteredWord:",c),a.startsWith(c)){if(c===a){let t="Jawaban kamu sama dengan soal\n";if(!(r.player[r.index].chance<=1||0===r.player[r.index].chance))return--r.player[r.index].chance,i.reply(t+(`
Sisa kesempatan: `+r.player[r.index].chance));if(global.db.users[r.current].balance-=p,1<r.player.length){r.player.splice(r.index,1),r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration});let e=()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point,r.timeout&&clearTimeout(r.timeout);var a=r.index,a=(r.player.splice(r.index,1),r.current=(1<r.player.length?r.player[a]:r.player[0])?.id,{player:r.player,current:r.current});if(s.logAndWrite("room skata2",a),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=e()},1e3*r.timer);r.timeout=e()}else if(1==r.player.length)return r.current=r.player[0].id,global.db.users[r.current].balance+=100*r.kata.length,global.db.users[r.current].game.sambungkata+=1,t=`Pemenang: @${r.current.split("@")[0]}
Hadiah: ${100*r.kata.length} balance
Game Berakhir!`.trim(),r.timeout&&clearTimeout(r.timeout),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!0}if(r.basi.includes(a)){let t=`*${i.budy.toLowerCase()}* sudah pernah digunakan
`;if(r.player[r.index].chance<=1||0===r.player[r.index].chance)if(global.db.users[r.current].balance-=p,t+=`@${r.current.split("@")[0]} tereliminasi.
Hadiah: -${p} balance`,1<r.player.length){r.player.splice(r.index,1),r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration});let e=()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point,r.timeout&&clearTimeout(r.timeout);var a=r.index,a=(r.player.splice(r.index,1),r.current=(1<r.player.length?r.player[a]:r.player[0])?.id,{player:r.player,current:r.current});if(s.logAndWrite("room skata3",a),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=e()},1e3*r.timer);r.timeout=e()}else if(1==r.player.length)return r.current=r.player[0].id,global.db.users[r.current].balance+=100*r.kata.length,global.db.users[r.current].game.sambungkata+=1,t=`Pemenang: @${r.current.split("@")[0]}
Hadiah: ${100*r.kata.length} balance
Game Berakhir!`.trim(),r.timeout&&clearTimeout(r.timeout),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!0}else if(!u){let t=`*${i.budy.toLowerCase()}* tidak terdaftar di KBBI
`;if(r.player[r.index].chance<=1||0===r.player[r.index].chance)if(global.db.users[r.current].balance-=p,1<r.player.length){r.player.splice(r.index,1),r.index>=r.player.length&&(r.index=0),r.current=r.player[r.index].id,r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration});let e=()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point,r.timeout&&clearTimeout(r.timeout);var a=r.index,a=(r.player.splice(r.index,1),r.current=(1<r.player.length?r.player[a]:r.player[0])?.id,{player:r.player,current:r.current});if(s.logAndWrite("room skata4",a),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),t=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=e()},1e3*r.timer);r.timeout=e()}else if(1==r.player.length)return r.current=r.player[0].id,global.db.users[r.current].balance+=100*r.kata.length,global.db.users[r.current].game.sambungkata+=1,t=`Pemenang: @${r.current.split("@")[0]}
Hadiah: ${100*r.kata.length} balance
Game Berakhir!`.trim(),r.timeout&&clearTimeout(r.timeout),r.chat=await l.reply(i.chat,t,null,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!0}clearTimeout(r.timeout),global.db.users[r.current].balance+=p,global.db.users[r.current].game.sambungkata+=1,r.basi.push(a),c=r.index,console.log("INDEX CURRENT: ",c),console.log("OLD CURRENT: ",r.current),r.current=r.player[c+1]?.id,console.log("NEW CURRENT: ",r.current),r.current&&(r.index=c+1),!r.current&&c+1>=r.player.length&&(l.logger.warn(`
current: ${r.index+1}
player length: ${r.player.length}
Player: `+util.format(r.player)),r.current=r.player[0].id,r.index=0),r.kata=a;let e=`*Jawaban benar!*
Hadiah: ${p} balance
Giliran: @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),t=(r.chat=await i.reply(e,null,{mentions:[r.current],expiration:i.expiration}),()=>setTimeout(async()=>{l.reply(n,`Waktu habis @${r.current.split("@")[0]} tereliminasi.
Hadiah: -${r.point} balance`,r.chat,{mentions:[r.current],expiration:i.expiration}),global.db.users[r.current].balance-=r.point;var a=r.index,a=(r.player.splice(r.index,1),r.current=r.player[a]?.id||null,r.index=a,!r.current&&a+1>=r.player.length&&(l.logger.info(`Index lebih dari player:
Player length: ${r.player.length}
Index: `+(a+1)),r.index=0,r.current=r.player[r.index].id),{index:a,player:r.player,current:r.current});if(s.logAndWrite("room skata5",a),1==r.player.length&&"play"==r.status)return global.db.users[r.current].game.sambungkata+=1,global.db.users[r.current].balance+=r.point,l.reply(i.chat,`@${r.current.split("@")[0]} Menang
Hadiah: $${r.point} balance
Game Berakhir!`,r.chat,{mentions:[r.current],expiration:i.expiration}),delete l.skata2[n],!1;r.kata=await r.genKata(),e=`Lanjut Giliran @${r.current.split("@")[0]}
Kata: *${r.kata}*
Waktu: ${r.timer}s
Kesempatan: ${r.player[r.index].chance}

Carilah kata yang berawalan *${r.filter(r.kata)}*`.trim(),r.chat=await l.reply(i.chat,e,null,{mentions:[r.current],expiration:i.expiration}),r.point=100*r.kata.length,r.timeout=t()},1e3*r.timer));return r.timeout=t(),r}}}}},group:!0,location:"plugins/games/sk2.js"};