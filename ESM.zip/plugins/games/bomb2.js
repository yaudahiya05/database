let DATABASE={},run=async(a,i,{func:e,cfg:t})=>{if(e.ceklimit(a.sender,1)&&!a.isPrem&&!a.isVIP)return a.reply(t.mess.limit);let r=a.sender;if(r in DATABASE)return i.reply(a.chat,"Sesi ini belum selesai!",DATABASE[r].msg,{expiration:a.expiration});e=["💥","✅","✅","✅","✅","✅","✅","✅","✅"].sort(()=>Math.random()-.5);let n=["1️⃣","2️⃣","3️⃣","4️⃣","5️⃣","6️⃣","7️⃣","8️⃣","9️⃣"],o=e.map((e,a)=>({emot:e,number:n[a],position:a+1,state:!1})),m=`B O M B - 2

Kirim angka 1 - 9 untuk membuka 9 kotak nomor di bawah ini :

`;for(let e=0;e<o.length;e+=3)m+=o.slice(e,e+3).map(e=>e.state?e.emot:e.number).join("")+"\n";m+=`
Timeout : 3 menit
Apabila mendapat kotak yang berisi bom maka balance akan dikurangi.`,t=await i.reply(a.chat,m,a,{expiration:a.expiration}),DATABASE[r]={msg:t,array:o,time:setTimeout(()=>{var e=o.find(e=>"💥"===e.emot);DATABASE[r]&&i.reply(a.chat,`Waktu habis! Bom berada di kotak nomor ${e.number}.`,DATABASE[r].msg,{expiration:a.expiration}),delete DATABASE[r]},18e4)}},main=async(o,m,{func:l,setting:e})=>{try{let t=o.sender,r=l.hadiah(e.hadiah||1e4),n=(global.db.users=global.db.users||{},global.db.users[o.sender]=global.db.users[o.sender]||{balance:0},global.db.users[o.sender]);DATABASE=DATABASE||{};var a=/^(me)?nyerah|surr?ender$/i.test(o.budy);if(DATABASE[t]&&a)return await m.reply(o.chat,"Menyerah. Permainan dibatalkan.",o,{expiration:o.expiration}),clearTimeout(DATABASE[t].time),void delete DATABASE[t];if(t in DATABASE&&!isNaN(o.budy)){let a=parseInt(o.budy),i=DATABASE[t],e=i.array.find(e=>e.position===a);if(!e)return m.reply(o.chat,"Untuk membuka kotak, kirim angka 1 - 9.",o,{expiration:o.expiration});if(e.state)return m.reply(o.chat,`Kotak ${e.number} sudah dibuka, silakan pilih kotak yang lain.`,o,{expiration:o.expiration});if("💥"===e.emot){e.state=!0;let a=`B O M B - 2

`;for(let e=0;e<i.array.length;e+=3)a+=i.array.slice(e,e+3).map(e=>e.state?e.emot:e.number).join("")+"\n";a=(a+=`
Timeout : 3 menit
`)+`Permainan selesai!, kotak berisi bom terbuka: (- $${l.rupiah(r)} balance)`,await m.reply(o.chat,a.trim(),o,{expiration:o.expiration}),n.balance=(n.balance||0)-r,n.balance<0&&(n.balance=0),clearTimeout(i.time),delete DATABASE[t]}else if(e.state=!0,8<=i.array.filter(e=>e.state&&"💥"!==e.emot).length){let a=`B O M B - 2

`;a+=`Kirim angka 1 - 9 untuk membuka 9 kotak nomor di bawah ini :

`;for(let e=0;e<i.array.length;e+=3)a+=i.array.slice(e,e+3).map(e=>e.state?e.emot:e.number).join("")+"\n";a=(a+=`
Timeout : 3 menit
`)+`Permainan selesai! kotak berisi bom tidak terbuka: (+ $${l.rupiah(r)} balance)`,m.reply(o.chat,a.trim(),o,{expiration:o.expiration}),n.balance=(n.balance||0)+r,clearTimeout(i.time),delete DATABASE[t]}else{let a=`B O M B - 2

`;a+=`Kirim angka 1 - 9 untuk membuka 9 kotak nomor di bawah ini :

`;for(let e=0;e<i.array.length;e+=3)a+=i.array.slice(e,e+3).map(e=>e.state?e.emot:e.number).join("")+"\n";a=(a+=`
Timeout : 3 menit
`)+`Kotak berisi bom tidak terbuka : (+ $${l.rupiah(r)} balance)`,m.relayMessage(o.chat,{protocolMessage:{key:i.msg.key,type:14,editedMessage:{conversation:a}}},{quoted:o,ephemeralExpiration:o.expiration}).then(()=>{n.balance=(n.balance||0)+r})}}}catch(e){console.error("Error in bomb2 game:",e),m.reply(o.chat,"✗ Terjadi kesalahan dalam game Bomb2. Mohon coba lagi atau hubungi owner.",o,{expiration:o.expiration})}return!0};export default{run:run,main:main,cmd:["bomb2"],alias:["tebakbom2"],use:"enter number",type:"games",location:"plugins/games/bomb2.js"};