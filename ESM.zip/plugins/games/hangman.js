import fetch from"node-fetch";let gamesUrl="https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/tebakkata.json",DATABASE={};class HangmanGame{constructor(a){this.sessionId=a,this.guesses=[],this.maxAttempts=7,this.currentStage=0,this.quest=null,this.lastQuestionId=null}getRandomQuest=async()=>{try{var a,e=await fetch(gamesUrl).then(a=>a.json());if(e.result&&0!==e.result.length)return{clue:(a=e.result[Math.floor(Math.random()*e.result.length)]).soal,quest:a.jawaban.toLowerCase()};throw new Error("No questions found in the database.")}catch(a){throw console.error("Error fetching random quest:",a),new Error("Failed to fetch a random quest.")}};initializeGame=async()=>{try{this.quest=await this.getRandomQuest(),this.maxAttempts=6,this.guesses=[],this.currentStage=0,this.lastQuestionId=null}catch(a){throw console.error("Error initializing game:",a),new Error("Failed to initialize the game.")}};displayBoard=()=>(`*Current Stage:* ${["😐","😕","😟","😧","😢","😨","😵"][this.currentStage]}
`+`%==========
`+`||       |
`+`|        ${1<=this.currentStage?"O":""}
`+`|       ${3<=this.currentStage?"/":""}${2<=this.currentStage?"|":""}${4<=this.currentStage?"\\":""}
`+`|       ${5<=this.currentStage?"/":""} ${6<=this.currentStage?"\\":""}
`+`|
`+`==========%
`+"*Clue:* "+this.quest.clue).replaceAll("%","```");displayWord=()=>this.quest.quest.split("").map(a=>this.guesses.includes(a)?""+a:"__").join(" ");makeGuess=a=>this.isAlphabet(a)?(a=a.toLowerCase(),this.guesses.includes(a)?"repeat":(this.guesses.push(a),this.quest.quest.includes(a)||this.currentStage++,this.checkGameOver()?"over":this.checkGameWin()?"win":"continue")):"invalid";isAlphabet=a=>/^[a-zA-Z]$/.test(a);checkGameOver=()=>this.currentStage>=this.maxAttempts;checkGameWin=()=>[...new Set(this.quest.quest)].every(a=>this.guesses.includes(a));getHint=()=>"*Hint:* "+this.quest.quest}let run=async(a,e,{func:t,cfg:s})=>{var n,[i,r]=a.args;try{switch(i){case"end":DATABASE[a.chat]&&DATABASE[a.chat].sessionId===a.sender?(delete DATABASE[a.chat],await a.reply("Sesi Hangman berhasil diakhiri. 👋")):await a.reply("Tidak ada sesi Hangman yang sedang berlangsung atau kamu bukan pemainnya.");break;case"start":if(t.ceklimit(a.sender,1)&&!a.isPrem&&!a.isVIP)return a.reply(s.mess.limit);DATABASE[a.chat]?await a.reply(`Sesi Hangman sudah berjalan. Gunakan ${a.prefix}hangman *end* untuk mengakhiri sesi.`):(await(n=new HangmanGame(a.sender)).initializeGame(),DATABASE[a.chat]=n,await a.reply(`Sesi Hangman dimulai. 🎉

*ID Sesi:* ${n.sessionId}
${n.displayBoard()}

*Tebak Kata:*
${n.displayWord()}

Kirim huruf untuk menebak, contoh: *${a.prefix}hangman guess a*`));break;case"guess":if(DATABASE[a.chat]){if(!r||!/^[a-zA-Z]$/.test(r))return void await a.reply(`Masukkan huruf yang ingin kamu tebak setelah *guess*. Contoh: *${a.prefix}hangman guess a*`);var u=DATABASE[a.chat];if(u.sessionId!==a.sender)return a.reply("Kamu bukan pemain yang memulai sesi ini.");var h=r.toLowerCase(),l=u.makeGuess(h),m={invalid:"Masukkan huruf yang valid (a-z).",repeat:"Kamu sudah menebak huruf ini sebelumnya. Coba huruf yang lain.",continue:`*Tebak Huruf:*
${u.guesses.join(", ")}
${u.displayBoard()}

*Tebak Kata:*
${u.displayWord()}
 
*Percobaan Tersisa:* `+(u.maxAttempts-u.currentStage),over:`Permainan telah berakhir! Kamu kalah. Kata yang benar adalah *${u.quest.quest}*. 💀`,win:"Selamat! Kamu menang dalam permainan Hangman. 🎉"};await a.reply(""+m[l]),"over"!==l&&"win"!==l||delete DATABASE[a.chat]}else await a.reply("Tidak ada sesi Hangman yang sedang berlangsung. Gunakan *start* untuk memulai sesi.");break;case"hint":if(DATABASE[a.chat]){var g=DATABASE[a.chat];if(g.sessionId!==a.sender)return a.reply("Kamu bukan pemain yang memulai sesi ini.");await a.reply(g.getHint())}else await a.reply("Tidak ada sesi Hangman yang sedang berlangsung. Gunakan *start* untuk memulai sesi.");break;case"help":await a.reply(`*H A N G M A N - G A M E S*

*Commands:*
- *${a.prefix}hangman start :* Memulai game Hangman.
- *${a.prefix}hangman end :* Mengakhiri sesi game.
- *${a.prefix}hangman guess [huruf] :* Menebak huruf dalam kata.
- *${a.prefix}hangman hint :* Mendapatkan petunjuk kata.`);break;default:await a.reply(`Aksi tidak valid. Gunakan ${a.prefix}hangman *help* untuk melihat cara penggunaan command.`)}}catch(e){console.error("Error in hangman handler:",e),await a.reply("Terjadi kesalahan dalam game Hangman. Silakan coba lagi.")}};export default{run:run,cmd:"hangman",alias:"hm",use:"options",type:"games",limit:!0,location:"plugins/games/hangman.js"};