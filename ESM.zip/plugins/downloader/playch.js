import fs from 'fs';
import path from 'path';
import ffmpeg from 'fluent-ffmpeg';
import {
    fileURLToPath
} from 'url';
import yts from 'yt-search';
import fetch from 'node-fetch';
import { exec } from 'child_process';
import { promisify } from 'util';
const execPromise = promisify(exec);
import {
    Readable,
    PassThrough
} from 'stream';

async function toPTT(buffer, mimetype = 'audio/mpeg') {
    return new Promise((resolve, reject) => {
        const stream = new Readable();
        stream.push(buffer);
        stream.push(null);

        const chunks = [];
        const proc = ffmpeg(stream);

        // Menggunakan Regex Test untuk menentukan format input
        if (/audio\/mpeg/.test(mimetype)) {
            proc.inputFormat('mp3');
        } else if (/audio\/(aac|m4a)/.test(mimetype)) {
            proc.inputFormat('aac');
        }

        proc.outputOptions([
                '-c:a libopus',
                '-ac 1',
                '-ar 16000',
                '-vbr on',
                '-b:a 128k',
                '-f ogg'
            ])
            .on('error', (err) => reject(new Error(`Gagal konversi: ${err.message}`)))
            .on('end', () => resolve(Buffer.concat(chunks)))
            .pipe(new PassThrough().on('data', (chunk) => chunks.push(chunk)));
    });
}

const fkontak = {
    key: {
        participant: '0@s.whatsapp.net',
        remoteJid: '0@s.whatsapp.net',
        fromMe: false,
        id: 'Powered by WhatsApp',
    },
    message: {
        conversation: `Musik Anda Siap Diputar di Channel 🎶`,
    },
};

const parseDuration = (duration) => {
    const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
    const hours = (parseInt(match[1]) || 0);
    const minutes = (parseInt(match[2]) || 0);
    const seconds = (parseInt(match[3]) || 0);
    return [
        hours,
        minutes,
        seconds
    ].map(v => v.toString().padStart(2, '0')).join(':');
};

const run = async (m, lulli, {
    func
}) => {
    const text = m.text.split('|');
    const example = func.example(m.cmd, 'NDX AKA | https://whatsapp.com/channel/...');
    if (text.length < 1) {
        return m.reply(example)
    }
    const [query, recipient] = m.text.split('|').map(s => s.trim());
    if (!query) {
        return m.reply(`*Nama lagu tidak boleh kosong!*\n${example}`)
    }
    if (!recipient) {
        return m.reply(`*ID atau Link channel tidak boleh kosong!*\n${example}`);
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    // const tmpInput = path.join(cfg.path.trash, func.filename('mp3'));
    // const tmpOutput = path.join(cfg.path.trash, func.filename('ogg'));
    try {
        let channelId;
        if (recipient.startsWith('https://whatsapp.com/channel/')) {
            try {
                const parts = recipient.split('/');
                const inviteCode = parts.filter(part => part.length > 0).pop();
                if (!inviteCode || inviteCode.length < 20) return m.reply('❌ URL channel tidak valid!');
                const metadata = await lulli.newsletterMetadata('invite', inviteCode, 'GUEST');
                if (!metadata || !metadata.id) {
                    return m.reply('Channel tidak ditemukan atau URL/Invite Code tidak valid.');
                }
                channelId = metadata.id;
                if (!channelId.includes('@newsletter')) return m.reply('❌ Gagal mengambil ID channel dari URL!');
            } catch (err) {
                return m.reply(`❌ Gagal memvalidasi URL channel: ${err.message || err}`);
            }
        } else {
            channelId = recipient;
            if (!channelId.includes('@newsletter')) return m.reply('❌ ID channel tidak valid! Harus berakhiran @newsletter');
        }
        const results = await yts(query);
        const video = results.all[0];
        if (!video) {
            return m.reply('❌ Video tidak ditemukan, coba cari dengan kata kunci lain.');
        }
        const {
            url: ytUrl,
            videoId,
            title
        } = video;
        const YOUTUBE_API_KEY = "AIzaSyDIYncRwLjGqDjwWbsREwJ0BFXUfBeR6wE";
        const videoDetailsResponse = await fetch(`https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=${videoId}&key=${YOUTUBE_API_KEY}`);
        const videoDetails = await videoDetailsResponse.json();
        if (!videoDetails.items || videoDetails.items.length === 0) {
            throw new Error('Detail video tidak dapat ditemukan. Mungkin video ini pribadi atau telah dihapus.');
        }
        const {
            snippet,
            statistics,
            contentDetails
        } = videoDetails.items[0];
        const publishedAt = new Date(snippet.publishedAt).toLocaleDateString('id-ID', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        const duration = parseDuration(contentDetails.duration);
        const viewCount = Number(statistics.viewCount).toLocaleString('id-ID');
        const likeCount = Number(statistics.likeCount).toLocaleString('id-ID');
        const commentCount = Number(statistics.commentCount).toLocaleString('id-ID');
        const apiUrl = `https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(ytUrl)}`;
        const downloaderResponse = await fetch(apiUrl);
        const downloaderJson = await downloaderResponse.json();
        if (!downloaderJson.status || !downloaderJson.result || !downloaderJson.result.mp3) {
            return m.reply('Gagal mendapatkan link unduhan audio. API mungkin sedang down.');
        }
        const {
            mp3: mp3Link,
            thumbnail: thumbnailUrl
        } = downloaderJson.result;
        const audioBuffer = await (await fetch(mp3Link)).buffer();
        if (!Buffer.isBuffer(audioBuffer)) throw new Error("Gagal mengunduh audio dari API.");
        let thumbnailBuffer;
        try {
            thumbnailBuffer = await (await fetch(thumbnailUrl)).buffer();
        } catch (e) {
            console.error("Gagal download thumbnail.");
            thumbnailBuffer = undefined;
        }
        // fs.writeFileSync(tmpInput, audioBuffer);
        /*await new Promise((resolve, reject) => {
            ffmpeg(tmpInput).toFormat("ogg").audioCodec("libopus").on("end", resolve).on("error", reject).save(tmpOutput);
        });*/
        // await execPromise(`ffmpeg -i "${tmpInput}" -c:a libopus -b:a 48k -vbr on "${tmpOutput}"`);
        const converted = await toPTT(audioBuffer);
        /*const caption = `*${title}*
🎵 *Durasi:* ${duration}
👀 *Tayangan:* ${viewCount}
❤️ *Suka:* ${likeCount}
💬 *Komentar:* ${commentCount}
📅 *Upload:* ${publishedAt}`;*/
        const newBody = `🎵${duration} | 👀${viewCount} | ❤️${likeCount} | 💬${commentCount}`;
        const contextInfo = {
            externalAdReply: {
                title: `${title} || ${publishedAt}`,
                body: newBody,
                thumbnailUrl: thumbnailUrl,
                sourceUrl: cfg.link.channel,
                mediaType: 1,
                renderLargerThumbnail: true,
                showAdAttribution: false
            }
        };
        await lulli.sendMessage(channelId, {
            audio: converted,
            mimetype: "audio/ogg; codecs=opus",
            ptt: true,
            jpegThumbnail: thumbnailBuffer,
            contextInfo: contextInfo
        });
        await lulli.reply(m.chat, `✅ Successfully sending *"${title}"* to channel as Voice Note!`, fkontak);
    } catch (err) {
        console.error(err);
        await m.reply(`${err.message || err}`);
    /*} finally {
        try {
            if (fs.existsSync(tmpInput)) fs.unlinkSync(tmpInput);
            if (fs.existsSync(tmpOutput)) fs.unlinkSync(tmpOutput);
        } catch (e) {
            console.error("Gagal membersihkan file temp:", e);
        }*/
    }
};

export default {
    run,
    cmd: 'playch',
    alias: 'musikch',
    use: '<nama_lagu>|<id/url_channel>',
    type: 'owner',
    owner: true,
    location: 'plugins/owner/playch.js'
};