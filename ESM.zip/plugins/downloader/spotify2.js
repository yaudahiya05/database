import aio from "../../lib/aio.js";

const run = async (m, lulli, {
    func
}) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'terbang bersamaku'));
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const query = m.text.trim();
        if (/open\.spotify\.com/.test(query)) {
            const track = await aio(query);
            if (track.error) return m.reply(track.error);
            await lulli.sendMessage(m.chat, {
                audio: {
                    url: track.medias[0].url
                },
                mimetype: "audio/mpeg",
                ptt: false,
                contextInfo: {
                    externalAdReply: {
                        title: track.title,
                        body: track.author,
                        thumbnailUrl: track.thumbnail,
                        mediaType: 1,
                        mediaUrl: track.thumbnail,
                        sourceUrl: track.url,
                    },
                },
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            return
        }
        const apiUrl = `https://api.siputzx.my.id/api/s/spotify?query=${encodeURIComponent(query)}`;
        const trackResults = await func.fetchJson(apiUrl);
        if (!trackResults || !trackResults.status || !trackResults.data || trackResults.data.length === 0) {
            return m.reply('✗ Gagal mengambil data lagu dari Spotify atau lagu tidak ditemukan. Coba lagi nanti.');
        }
        let bodyCaption = `✧ Query: *${query}*`;
        let rows = [];
        for (const [index, data] of trackResults.data.entries()) {
            if (!data.track_url || !data.artist || !data.title || !data.album || !data.release_date || !data.duration) {
                console.warn('✗ Melewatkan item data yang tidak lengkap:', data);
                continue;
            }
            rows.push({
                title: `✧ ${index + 1}) ${data.title}`,
                description: `- Artis: ${data.artist}\n- Album: ${data.album}\n- Durasi: ${data.duration}\n- Rilis: ${data.release_date}`,
                id: `${m.prefix}spdl ${data.track_url}`
            });
        }
        if (rows.length === 0) {
            return m.reply('✗ Tidak ditemukan lagu yang valid dari hasil pencarian.');
        }
        const sections = [{
            title: '✧ PILIH SPOTIFY DI BAWAH',
            rows: rows
        }];
        let buttons = [
            ['list', 'Click Here ⎙', sections],
        ]
        await lulli.sendButton(m.chat, `✦ SPOTIFY - SEARCH`, bodyCaption, 'silahkan pilih dari daftar di bawah ini.', buttons, m, {
            expiration: m.expiration
        });
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada Spotify Search:', error);
        await m.reply(`✗ Terjadi kesalahan: ${error.message}`);
    }
};
export default {
    run,
    cmd: 'spotify2',
    alias: ['spt2', 'spdl'],
    use: 'judul lagu',
    type: 'downloader',
    premium: true,
    location: 'plugins/downloader/spotify2.js'
};