const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(func.example(m.cmd, 'terbang bersamaku'));
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        const query = m.text.trim();
        const apiUrl = `https://api.siputzx.my.id/api/s/spotify?query=${encodeURIComponent(query)}`;
        const trackResults = await func.fetchJson(apiUrl);
        if (!trackResults || !trackResults.status || !trackResults.data || trackResults.data.length === 0) {
            return m.reply('✗ Gagal mengambil data lagu dari Spotify atau lagu tidak ditemukan. Coba lagi nanti.');
        }

        let bodyCaption = `✦ *HASIL PENCARIAN SPOTIFY*\n\n- Query: *${query}*\n\n`;
        let rows = [];
        
        for (const [index, data] of trackResults.data.entries()) {
            if (!data.track_url || !data.artist || !data.title || !data.album || !data.release_date || !data.duration) {
                console.warn('✗ Melewatkan item data yang tidak lengkap:', data);
                continue;
            }
            rows.push({
                title: `${index + 1}. ${data.title}`,
                description: `- Artis: ${data.artist}\n- Album: ${data.album}\n- Durasi: ${data.duration}\n- Rilis: ${data.release_date}`,
                id: `${m.prefix}spdl ${data.track_url}`
            });
        }
        if (rows.length === 0) {
            return m.reply('✗ Tidak ditemukan lagu yang valid dari hasil pencarian.');
        }
        const sections = [{
            title: '✦ PILIH SPOTIFY DI BAWAH',
            rows: rows
        }];
        await lulli.sendButton(m.chat, `✦ SPOTIFY - SEARCH`, bodyCaption, '✦ Silakan pilih dari daftar di bawah ini.', sections, m, {
            expiration: m.expiration
        });
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada Spotify Search:', error);
        await m.reply(`✗ Terjadi kesalahan: ${error.message}`);
    }
};

export default {
    run,
    cmd: 'spotify',
    alias: 'spt',
    use: 'judul lagu',
    type: 'downloader',
    premium: true,
    location: 'plugins/downloader/spotify.js'
};