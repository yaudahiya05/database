import{readFileSync}from"node:fs";import{fileURLToPath}from"node:url";import{dirname,join}from"node:path";import fetch from"node-fetch";import moment from"moment-timezone";let styles=e=>{var a=[..."abcdefghijklmnopqrstuvwxyz1234567890"];let t=["α","𝖻","𝖼","𝖽","ᧉ","𝖿","𝗀","𝗁","ꪱ","𝗃","𝗄","𝗅","𝗆","𝗇","𝗈","𝗉","𝗊","𝗋","𝗌","𝗍","𝗎","𝗏","ѡ","𝗑","ⴗ","𝗓","1","2","3","4","5","6","7","8","9","0"],r=Object.fromEntries(a.map((e,a)=>[e,t[a]]));return e.toLowerCase().split("").map(e=>r[e]||e).join("")};function getAgeFromDate(e){var[e,a,t]=e.split("/").map(Number);return!!(e&&a&&t)&&(t=new Date-new Date(t,a-1,e),new Date(t).getUTCFullYear()-1970)}function getGreetingAudioUrl(){var e=((new Date).getUTCHours()+7)%24;let a;return"https://raw.githubusercontent.com/Jabalsurya2105/database/master/audio/"+(a=5<=e&&e<=10?"pagi.m4a":11<=e&&e<15?"siang.m4a":15<=e&&e<=18?"sore.m4a":18<e&&e<=19?"petang.m4a":"malam.m4a")}function getGreetingText(){var e=((new Date).getUTCHours()+7)%24;return 5<=e&&e<=10?"Pagi":11<=e&&e<15?"Siang":15<=e&&e<=18?"Sore":18<e&&e<=19?"Petang":"Malam"}function countdown(e,a,t){var r=new Date,a=new Date(a+` ${e}, ${t} 00:00:00`),e=(a.getTime()<r.getTime()&&a.setFullYear(a.getFullYear()+1),a.getTime()-r.getTime());return e<0?"Sudah lewat!":Math.floor(e/864e5)+` hari ${Math.floor(e%864e5/36e5)} jam ${Math.floor(e%36e5/6e4)} menit ${Math.floor(e%6e4/1e3)} detik`}let formatCommandInternal=(e,a,t)=>({cmd:e,use:a.use?t.texted("bold",a.use):"",info:a.premium?"[P]":a.limit?"[L]":""}),buildCommandsInternal=(e,a,t)=>{let r=[];return e.map(([,a])=>{Array.isArray(a.cmd)?a.cmd.map(e=>r.push(formatCommandInternal(e,a,t))):"string"==typeof a.cmd&&r.push(formatCommandInternal(a.cmd,a,t))}),r.sort((e,a)=>e.cmd.localeCompare(a.cmd)).map(e=>`- ${a+e.cmd} ${e.use} `+e.info).join("\n")},AUDIO_MENU_DEFAULT=!0,IMAGE_MENU_DEFAULT=!1,menuStyleTemplates={},run=(menuStyleTemplates[1]=async(n,i,{func:o,cfg:s,plugins:l,setting:m},e=!1,a=null)=>{let t;try{t=JSON.parse(readFileSync(join(process.cwd(),"package.json"),"utf-8"))}catch(e){console.error("✗ Error reading package.json:",e.message),t={name:"lulli-bot",version:"1.0.0",dependencies:{}}}let r="Unknown";try{t.dependencies["@adiwajshing/baileys"]?(u=join(process.cwd(),"node_modules","@adiwajshing","baileys","package.json"),readFileSync(u)&&(r="@adiwajshing/baileys^"+JSON.parse(readFileSync(u,"utf-8")).version)):t.dependencies["@whiskeysockets/baileys"]&&(c=join(process.cwd(),"node_modules","@whiskeysockets","baileys","package.json"),readFileSync(c))&&(r="@whiskeysockets/baileys^"+JSON.parse(readFileSync(c,"utf-8")).version)}catch(e){console.warn("✗ Could not determine Baileys version:",e.message)}var u=t.name+" v"+t.version,c=o.formatNumber(Object.values(global.db.statistic||{}).reduce((e,a)=>e+(a.hittoday||0),0)),d=o.formatNumber(Object.values(global.db.statistic||{}).reduce((e,a)=>e+(a.hit||0),0)),p=s.mongoUrl&&/mongo/.test(s.mongoUrl)?"MongoDB":`Local (${readFileSync("./database/database.json")?readFileSync("./database/database.json").byteLength+" bytes":"0 bytes"})`,y=getAgeFromDate("21/05/2005"),f=countdown("21","05","2025"),y=`Halo, ${n.pushname.replaceAll("\n","")} 👏🏻
`+`Selamat *${getGreetingText()}*, Saya adalah bot WhatsApp otomatis yang siap membantu Anda dengan berbagai kebutuhan.

`+`┌─═「 DEVELOPER 」═─
`+`│⋄ Nama : SuryaDev.
`+`│⋄ Umur : ${y} Tahun
`+`│⋄ Hobi : Coding
`+`│⋄ Asal : Jepara
`+`│⋄ Ulang Tahun : ${f}
`+`└─────────────────

`+`┌─═「 BOT INFO 」═─
`+`│⋄ Database : ${p}
`+`│⋄ Library : ${r}
`+`│⋄ Versi : ${u}
`+`│⋄ Hit Hari Ini : ${c}
`+`│⋄ Total Hit : ${d}
`+`│⋄ Total Fitur : ${o.totalFeature(l)}
`+`│⋄ Gaya Menu : 1 (Default)
`+"└──────────────────";let g={},h=(Object.entries(l).forEach(([,e])=>{e&&e.type&&(g[e.type]=g[e.type]||[],g[e.type].push(e))}),Object.keys(g).sort());f=async e=>{var a=m.cover;let t=null;if(a)try{t=await(await fetch(a)).buffer()}catch(e){console.error("✗ Error fetching thumbnail for sendMessageModify:",e.message)}return i.sendMessageModify(n.chat,e+"\n\n"+s.footer,n,{thumbnail:t,thumbUrl:a,largeThumb:!0,url:m.link,expiration:n.expiration})};if(e||a){let e=styles(y);var b,$=[];for(b of a?[a]:h){var w=(a=>Object.entries(l).filter(([,e])=>e.cmd&&e.type===a.toLowerCase()))(b);0<w.length&&(e=(e+=`

───「 ${b.toUpperCase().split("").join(" ")} 」───
`)+styles(buildCommandsInternal(w,n.prefix,o)),$.push(b))}return a&&!$.includes(a)?(await n.reply(`✗ Kategori *${a}* tidak memiliki command.`),!1):(p=await f(e),AUDIO_MENU_DEFAULT&&(u=getGreetingAudioUrl(),await i.sendMessage(n.chat,{audio:{url:u},mimetype:"audio/mpeg",ptt:!1},{quoted:p,ephemeralExpiration:n.expiration})),!0)}if(s.baileys.button){let t=[],r={highlight_label:"Fitur Populer"};h.sort((e,a)=>e.localeCompare(a)).map((a,e)=>t.push({.../downloader|convert|games|ai/.test(a)?r:{},rows:[{title:o.ucword(a)+" Fitur",description:`Ada ${Object.entries(l).filter(([,e])=>e.cmd&&e.type===a.trim().toLowerCase()).flatMap(([,e])=>Array.isArray(e.cmd)?e.cmd:[e.cmd]).length} perintah`,id:n.cmd+" "+a}]})),t.push({highlight_label:"Tampilkan Semua Fitur",rows:[{title:"Semua Fitur",description:`Ada ${o.totalFeature(l)} perintah`,id:n.prefix+"allmenu"}]});c=[["list","Daftar Menu",t],["url","Neo Music","https://lulli.vercel.app/neomusic"]];let e=null;if(m.cover)try{e=await(await fetch(m.cover)).buffer()}catch(e){console.error("✗ Error fetching thumbnail for button:",e.message)}try{await i.sendButton(n.chat,"",styles(y),s.footer,c,n,{media:IMAGE_MENU_DEFAULT?e:null,expiration:n.expiration})}catch(e){return console.error("✗ Error sendButton, mencoba fallback text menu:",e),await n.reply(`✗ Gagal menampilkan tombol menu. Coba lagi atau gunakan \`${n.prefix}allmenu\`.`),!1}}else d=y,await f(d=(d+=`

───「 DAFTAR MENU SINGKAT 」───
`)+h.sort((e,a)=>e.localeCompare(a)).map((e,a)=>0===a?`┌ ✧ ${n.cmd} `+e:a===h.length-1?`│✧ ${n.cmd} ${e}
└ ✧ ${n.prefix}allmenu`:`│✧ ${n.cmd} `+e).join("\n"));return!0},menuStyleTemplates[2]=async(e,a,{func:t,cfg:r,plugins:n},i=0,o=null)=>{let s="╭─「 M E N U - B O T 」\n",l=(s=(s=(s=(s=(s+=`│ *Selamat ${getGreetingText()}*, *${e.pushname||"User"}* ◆
`)+`│ Saya adalah ${r.botName||"Bot"} yang siap melayani Anda.
`)+`│ Waktu: ${moment().tz("Asia/Jakarta").format("HH:mm:ss DD/MM/YYYY")}
`)+`│ Prefix: ${e.prefix}
`)+`│ Gaya Menu: 2 (Sederhana)
`+"│\n",{});Object.entries(n).forEach(([,e])=>{e&&e.type&&(l[e.type]=l[e.type]||[],l[e.type].push(e))});var m=[];for(let a of(o?[o]:Object.keys(l)).sort())if(0<Object.entries(n).filter(([,e])=>e.cmd&&e.type===a.toLowerCase()).length){s+=`├─「 ${t.ucword(a).toUpperCase()} 」
`;for(var u of l[a].sort((e,a)=>(Array.isArray(e.cmd)?e.cmd[0]:e.cmd).localeCompare(Array.isArray(a.cmd)?a.cmd[0]:a.cmd))){var c=Array.isArray(u.cmd)?u.cmd[0]:u.cmd;s+=`│✧ ${e.prefix}${c} ${u.use?`(${u.use})`:""}
`}s+="│\n",m.push(a)}return o&&!m.includes(o)?(await e.reply(`✗ Kategori *${o}* tidak ditemukan atau tidak memiliki command.`),!1):(s+=`╰──────────────────────
`,await a.reply(e.chat,s,e,{expiration:e.expiration}),!0)},menuStyleTemplates[3]=async(e,a,{func:t,cfg:r,plugins:n},i=0,o=null)=>{let s=`━━━「 ${r.botName||"Bot"} Menu 」━━━

`,l=(s=(s=(s+=`✧ *Selamat ${getGreetingText()}*, ${e.pushname||"User"}!
`)+`✧ Waktu: ${moment().tz("Asia/Jakarta").format("HH:mm DD/MM")}
`)+`✧ Prefix: ${e.prefix}
`+`✧ Gaya Menu: 3 (Minimalis)

`,{});Object.entries(n).forEach(([,e])=>{e&&e.type&&(l[e.type]=l[e.type]||[],l[e.type].push(e))});var m=[];for(let a of(o?[o]:Object.keys(l)).sort())if(0<Object.entries(n).filter(([,e])=>e.cmd&&e.type===a.toLowerCase()).length){s+=`── ✦ ${t.ucword(a).toUpperCase()} ✦ ──
`;for(var u of l[a].sort((e,a)=>(Array.isArray(e.cmd)?e.cmd[0]:e.cmd).localeCompare(Array.isArray(a.cmd)?a.cmd[0]:a.cmd))){var c=Array.isArray(u.cmd)?u.cmd[0]:u.cmd;s+=`✧ ${e.prefix}${c}${u.use?" - "+u.use:""}
`}s+="\n",m.push(a)}return o&&!m.includes(o)?(await e.reply(`✗ Kategori *${o}* tidak ditemukan atau tidak memiliki command.`),!1):(s+="━━━ Powered by SuryaDev ━━━",await a.reply(e.chat,s,e,{expiration:e.expiration}),!0)},menuStyleTemplates[4]=async(e,a,{func:t,cfg:r,plugins:n},i=0,o=null)=>{let s=`╭━━━「 ★ MENU BOT LULLI ★ 」━━━╮

`,l=(s=(s=(s=(s+=` *Selamat ${getGreetingText()}*, ${e.pushname||"Teman"}!
`)+` ${r.botName} hadir untuk membantu Anda._
`)+`✧ Waktu: ${moment().tz("Asia/Jakarta").format("HH:mm:ss")}
`)+`✧ Prefix: ${e.prefix}
`+`✧ Gaya Menu: 4 (Bullet Style)

`,{});Object.entries(n).forEach(([,e])=>{e&&e.type&&(l[e.type]=l[e.type]||[],l[e.type].push(e))});var m={system:"⚙",tools:"🛠",downloader:"⬇",group:"👥",owner:"♔",fun:"⬡",info:"ⓘ",converter:"⇄",ai:"⚛"},u=[];for(let a of(o?[o]:Object.keys(l)).sort())if(0<Object.entries(n).filter(([,e])=>e.cmd&&e.type===a.toLowerCase()).length){var c,d=m[a.toLowerCase()]||"⌖";s+=` ${d} *${t.ucword(a).toUpperCase()}*
`;for(c of l[a].sort((e,a)=>(Array.isArray(e.cmd)?e.cmd[0]:e.cmd).localeCompare(Array.isArray(a.cmd)?a.cmd[0]:a.cmd))){var p=Array.isArray(c.cmd)?c.cmd[0]:c.cmd;s+=`✧ ${e.prefix}${p} ${c.use?`[${c.use}]`:""}
`}s+="\n",u.push(a)}return o&&!u.includes(o)?(await e.reply(`✗ Kategori *${o}* tidak ditemukan atau tidak memiliki command.`),!1):(s+="╰━━「 Powered by SuryaDev 」━━╯",await a.reply(e.chat,s,e,{expiration:e.expiration}),!0)},menuStyleTemplates[5]=async(r,n,{func:e,cfg:i,setting:o,plugins:t},a=0,s=null)=>{let l=`╔═「 ❖ LULLI BOT - MENU ❖ 」═╗
`,m=(l=(l=(l=(l=(l=(l+=`║
`)+`║  *Selamat ${getGreetingText()}*, ${r.pushname||"Pengguna"}!
`)+`║  _Saya adalah ${i.botName}_.
`)+`║  *Waktu:* ${moment().tz("Asia/Jakarta").format("HH:mm:ss, DD MMM YYYY")}
`)+`║  *Prefix:* ${r.prefix}
`)+`║  *Gaya Menu:* 5 (Card Style)
`+`║
`,{});Object.entries(t).forEach(([,e])=>{e&&e.type&&(m[e.type]=m[e.type]||[],m[e.type].push(e))});var u=[];for(let a of(s?[s]:Object.keys(m)).sort())if(0<Object.entries(t).filter(([,e])=>e.cmd&&e.type===a.toLowerCase()).length){l+=`╠═══「 ${e.ucword(a).toUpperCase()} 」═══
`;for(var c of m[a].sort((e,a)=>(Array.isArray(e.cmd)?e.cmd[0]:e.cmd).localeCompare(Array.isArray(a.cmd)?a.cmd[0]:a.cmd))){var d=Array.isArray(c.cmd)?c.cmd[0]:c.cmd;l+=`║⋄ ${r.prefix}${d} ${c.use?"| "+c.use:""}
`}l+=`║
`,u.push(a)}return s&&!u.includes(s)?(await r.reply(`✗ Kategori *${s}* tidak ditemukan atau tidak memiliki command.`),!1):(await(async e=>{var a=o.cover;let t=null;if(a)try{t=await(await fetch(a)).buffer()}catch(e){console.error("✗ Error fetching thumbnail for sendMessageModify:",e.message)}return n.sendMessageModify(r.chat,e+"\n\n"+i.footer,r,{title:i.header,body:i.footer,thumbnail:t,thumbUrl:a,largeThumb:!0,url:o.link,expiration:r.expiration})})(l+=`╚══════════════════╝
`),!0)},async(r,n,{func:i,cfg:o,plugins:s,setting:l})=>{null==l.style&&(l.style=1);var a=l.style,t=Object.keys(menuStyleTemplates).length;if("setmenu"===r.command){if(!r.isOwner&&!r.isDevs)return r.reply("✗ Perintah ini hanya bisa digunakan oleh Owner/Developer.");if(0===r.args.length)return r.reply(`✗ Penggunaan: \`${r.prefix}setmenu [angka]\`

\`\`\`Pilih gaya menu dari 1 sampai ${t}.\`\`\`
\`\`\`Gaya menu saat ini: ${a}.\`\`\``);var m=parseInt(r.args[0]);if(isNaN(m)||m<1||t<m)return r.reply(`✗ Angka gaya menu tidak valid. Pilih antara 1 sampai ${t}.`);l.style=m,await r.reply(`✓ Gaya menu berhasil diubah ke style *${m}*!`);let e=menuStyleTemplates[m];void(e?await e(r,n,{func:i,cfg:o,plugins:s,setting:l},!1,null):await r.reply(`✗ Terjadi kesalahan saat menampilkan pratinjau menu style ${m}.`))}else{let t=menuStyleTemplates[a];if(t){let e=!1,a=null;if("allmenu"===r.command)e=!0;else if("menu"===r.command&&r.text){if(a=r.text.trim().toLowerCase(),!Object.values(s).some(e=>e.cmd&&e.type===a))return r.reply(`✗ Kategori *${r.text}* tidak tersedia.`);if("developer"===a&&!r.isDevs)return r.reply("✗ Menu ini hanya untuk developer.")}try{n.sendReact(r.chat,"🕒",r.key),await t(r,n,{func:i,cfg:o,plugins:s,setting:l},e,a)||await r.reply("✗ Gagal menampilkan menu sesuai gaya yang dipilih.")}catch(e){console.error("✗ Error saat menampilkan menu:",e),await r.reply(o.mess.wrong(e.message)||"✗ Terjadi kesalahan saat memproses menu: "+e.message)}}else await r.reply(`✗ Terjadi kesalahan: Gaya menu saat ini (${a}) tidak ditemukan. Silakan coba \`${r.prefix}setmenu 1\` untuk mengatur ulang.`)}});export default{run:run,cmd:["menu","allmenu","setmenu"],restrict:!0,location:"plugins/menu.js"};export{styles,getAgeFromDate,getGreetingAudioUrl,getGreetingText,countdown,formatCommandInternal,buildCommandsInternal};