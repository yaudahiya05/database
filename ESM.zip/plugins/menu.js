import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import fetch from 'node-fetch';
import moment from 'moment-timezone';

export const styles = (text) => {
    const xStr = [...'abcdefghijklmnopqrstuvwxyz1234567890'];
    const yStr = ['α', '𝖻', '𝖼', '𝖽', 'ᧉ', '𝖿', '𝗀', '𝗁', 'ꪱ', '𝗃', '𝗄', '𝗅', '𝗆', '𝗇', '𝗈', '𝗉', '𝗊', '𝗋', '𝗌', '𝗍', '𝗎', '𝗏', 'ѡ', '𝗑', 'ⴗ', '𝗓', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];

    const replacer = Object.fromEntries(xStr.map((v, i) => [v, yStr[i]]));
    return text.toLowerCase().split('').map(v => replacer[v] || v).join('');
};

export function getAgeFromDate(userBirthday) {
    const [day, month, year] = userBirthday.split('/').map(Number);
    if (!day || !month || !year) return false;

    const age = new Date() - new Date(year, month - 1, day);
    return new Date(age).getUTCFullYear() - 1970;
}

export function getGreetingAudioUrl() {
    const now = new Date();
    const utcHours = now.getUTCHours();
    const wibHours = (utcHours + 7) % 24;
    let fileName;

    if (wibHours >= 5 && wibHours <= 10) {
        fileName = 'pagi.m4a';
    } else if (wibHours >= 11 && wibHours < 15) {
        fileName = 'siang.m4a';
    } else if (wibHours >= 15 && wibHours <= 18) {
        fileName = 'sore.m4a';
    } else if (wibHours > 18 && wibHours <= 19) {
        fileName = 'petang.m4a';
    } else {
        fileName = 'malam.m4a';
    }

    return "https://raw.githubusercontent.com/Jabalsurya2105/database/master/audio/" + fileName;
}

export function getGreetingText() {
    const now = new Date();
    const utcHours = now.getUTCHours();
    const wibHours = (utcHours + 7) % 24;

    if (wibHours >= 5 && wibHours <= 10) {
        return 'Pagi';
    } else if (wibHours >= 11 && wibHours < 15) {
        return 'Siang';
    } else if (wibHours >= 15 && wibHours <= 18) {
        return 'Sore';
    } else if (wibHours > 18 && wibHours <= 19) {
        return 'Petang';
    } else {
        return 'Malam';
    }
}

export function countdown(tanggal, bulan, tahun) {
    let now = new Date();
    let from = new Date(`${bulan} ${tanggal}, ${tahun} 00:00:00`);

    if (from.getTime() < now.getTime()) {
        from.setFullYear(from.getFullYear() + 1);
    }

    let distance = from.getTime() - now.getTime();
    if (distance < 0) return "Sudah lewat!";

    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
    let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((distance % (1000 * 60)) / 1000);

    return `${days} hari ${hours} jam ${minutes} menit ${seconds} detik`;
}

export const formatCommandInternal = (cmd, plugin, func) => {
    const use = plugin.use ? func.texted('bold', plugin.use) : '';
    const info = plugin.premium ? '[P]' : plugin.limit ? '[L]' : '';
    return { cmd, use, info };
};

export const buildCommandsInternal = (cmds, prefix, func) => {
    let commands = [];
    cmds.map(([, plugin]) => {
        if (Array.isArray(plugin.cmd)) {
            plugin.cmd.map(cmd => commands.push(formatCommandInternal(cmd, plugin, func)));
        } else if (typeof plugin.cmd === 'string') {
            commands.push(formatCommandInternal(plugin.cmd, plugin, func));
        }
    });
    return commands.sort((a, b) => a.cmd.localeCompare(b.cmd)).map(v => `- ${prefix + v.cmd} ${v.use} ${v.info}`).join('\n');
};

const AUDIO_MENU_DEFAULT = true;
const IMAGE_MENU_DEFAULT = false;

const menuStyleTemplates = {};

menuStyleTemplates[1] = async (m, lulli, { func, cfg, plugins, setting }, isAllMenu = false, targetCategory = null) => {
    const filterCommands = (key) => Object.entries(plugins).filter(([_, item]) => item.cmd && item.type === key.toLowerCase());

    let packages;
    try {
        packages = JSON.parse(readFileSync(join(process.cwd(), 'package.json'), 'utf-8'));
    } catch (e) {
        console.error("✗ Error reading package.json:", e.message);
        packages = { name: "lulli-bot", version: "1.0.0", dependencies: {} };
    }

    let baileysVersion = "Unknown";
    try {
        if (packages.dependencies['@adiwajshing/baileys']) {
            const baileysPackagePath = join(process.cwd(), 'node_modules', '@adiwajshing', 'baileys', 'package.json');
            if (readFileSync(baileysPackagePath)) {
                baileysVersion = `@adiwajshing/baileys^${JSON.parse(readFileSync(baileysPackagePath, 'utf-8')).version}`;
            }
        } else if (packages.dependencies['@whiskeysockets/baileys']) {
            const baileysPackagePath = join(process.cwd(), 'node_modules', '@whiskeysockets', 'baileys', 'package.json');
            if (readFileSync(baileysPackagePath)) {
                baileysVersion = `@whiskeysockets/baileys^${JSON.parse(readFileSync(baileysPackagePath, 'utf-8')).version}`;
            }
        }
    } catch (e) {
        console.warn("✗ Could not determine Baileys version:", e.message);
    }

    const version = `${packages.name} v${packages.version}`;
    const hit_today = func.formatNumber(Object.values(global.db.statistic || {}).reduce((a, b) => a + (b.hittoday || 0), 0));
    const total_hit = func.formatNumber(Object.values(global.db.statistic || {}).reduce((a, b) => a + (b.hit || 0), 0));
    const typedb = cfg.mongoUrl && /mongo/.test(cfg.mongoUrl) ? 'MongoDB' : `Local (${readFileSync('./database/database.json') ? (readFileSync('./database/database.json').byteLength + ' bytes') : '0 bytes'})`;

    // ubah ultah kamu disini
    const age = getAgeFromDate('21/05/2005');
    const birthday = countdown('21', '05', '2025');

    let caption = `Halo, ${m.pushname.replaceAll('\n', '')} 👏🏻\n` +
        `Selamat *${getGreetingText()}*, Saya adalah bot WhatsApp otomatis yang siap membantu Anda dengan berbagai kebutuhan.\n\n` +
        `┌─═「 DEVELOPER 」═─\n` +
        `│⋄ Nama : SuryaDev.\n` +
        `│⋄ Umur : ${age} Tahun\n` +
        `│⋄ Hobi : Coding\n` +
        `│⋄ Asal : Jepara\n` +
        `│⋄ Ulang Tahun : ${birthday}\n` +
        `└─────────────────\n\n` +
        `┌─═「 BOT INFO 」═─\n` +
        `│⋄ Database : ${typedb}\n` +
        `│⋄ Library : ${baileysVersion}\n` +
        `│⋄ Versi : ${version}\n` +
        `│⋄ Hit Hari Ini : ${hit_today}\n` +
        `│⋄ Total Hit : ${total_hit}\n` +
        `│⋄ Total Fitur : ${func.totalFeature(plugins)}\n` +
        `│⋄ Gaya Menu : 1 (Default)\n` +
        `└──────────────────`;

    const category = {};
    Object.entries(plugins).forEach(([name, cmd]) => {
        if (cmd && cmd.type) {
            category[cmd.type] = category[cmd.type] || [];
            category[cmd.type].push(cmd);
        }
    });

    const keys = Object.keys(category).sort();

    const sendMessageModify = async (printContent) => {
        let thumbnailUrl = setting.cover;
        let thumbnailBuffer = null;
        if (thumbnailUrl) {
            try {
                thumbnailBuffer = await (await fetch(thumbnailUrl)).buffer();
            } catch (e) {
                console.error("✗ Error fetching thumbnail for sendMessageModify:", e.message);
            }
        }
        return await lulli.sendMessageModify(m.chat, printContent + '\n\n' + cfg.footer, m, {
            thumbnail: thumbnailBuffer,
            thumbUrl: thumbnailUrl,
            largeThumb: true,
            url: setting.link,
            expiration: m.expiration
        });
    };

    if (isAllMenu || targetCategory) {
        let print = styles(caption);

        const categoriesToDisplay = targetCategory ? [targetCategory] : keys;
        const displayedCategories = [];

        for (let key of categoriesToDisplay) {
            const cmds = filterCommands(key);
            if (cmds.length > 0) {
                print += `\n\n───「 ${key.toUpperCase().split('').join(' ')} 」───\n`;
                print += styles(buildCommandsInternal(cmds, m.prefix, func));
                displayedCategories.push(key);
            }
        }

        if (targetCategory && !displayedCategories.includes(targetCategory)) {
            await m.reply(`✗ Kategori *${targetCategory}* tidak memiliki command.`);
            return false;
        }

        let msg = await sendMessageModify(print);

        if (AUDIO_MENU_DEFAULT) {
            const audioUrl = getGreetingAudioUrl();
            await lulli.sendMessage(m.chat, {
                audio: { url: audioUrl },
                mimetype: 'audio/mpeg',
                ptt: false
            }, {
                quoted: msg,
                ephemeralExpiration: m.expiration
            });
        }
        return true;
    } else {
        if (cfg.baileys.button) {
            let sections = [];
            const label = { highlight_label: 'Fitur Populer' };
            keys.sort((a, b) => a.localeCompare(b)).map((v, i) => sections.push({
                ...(/downloader|convert|games|ai/.test(v) ? label : {}),
                rows: [{
                    title: `${func.ucword(v)} Fitur`,
                    description: `Ada ${Object.entries(plugins).filter(([_, x]) => x.cmd && x.type === v.trim().toLowerCase()).flatMap(([_, x]) => Array.isArray(x.cmd) ? x.cmd : [x.cmd]).length} perintah`,
                    id: `${m.cmd} ${v}`
                }]
            }));
            sections.push({
                highlight_label: 'Tampilkan Semua Fitur',
                rows: [{
                    title: 'Semua Fitur',
                    description: `Ada ${func.totalFeature(plugins)} perintah`,
                    id: `${m.prefix}allmenu`
                }]
            });

            let buttons = [
                ['list', 'Daftar Menu', sections],
                ['url', 'Buy script', 'https://lulli-bot.vercel.app/elitesys'],
            ];

            let thumbnailBuffer = null;
            if (setting.cover) {
                try {
                    thumbnailBuffer = await (await fetch(setting.cover)).buffer();
                } catch (e) {
                    console.error('✗ Error fetching thumbnail for button:', e.message);
                }
            }

            try {
                await lulli.sendButton(m.chat, '', styles(caption), cfg.footer, buttons, m, {
                    media: IMAGE_MENU_DEFAULT ? thumbnailBuffer : null,
                    expiration: m.expiration
                });
            } catch (buttonError) {
                console.error('✗ Error sendButton, mencoba fallback text menu:', buttonError);
                await m.reply(`✗ Gagal menampilkan tombol menu. Coba lagi atau gunakan \`${m.prefix}allmenu\`.`);
                return false;
            }
            return true;
        } else {
            let capt = caption;
            capt += `\n\n───「 DAFTAR MENU SINGKAT 」───\n`;
            capt += keys.sort((a, b) => a.localeCompare(b)).map((v, i) => {
                if (i === 0) {
                    return `┌ ✧ ${m.cmd} ${v}`;
                } else if (i === keys.length - 1) {
                    return `│✧ ${m.cmd} ${v}\n└ ✧ ${m.prefix}allmenu`;
                } else {
                    return `│✧ ${m.cmd} ${v}`;
                }
            }).join('\n');
            await sendMessageModify(capt);
            return true;
        }
    }
};

menuStyleTemplates[2] = async (m, lulli, { func, cfg, plugins }, isAllMenu = false, targetCategory = null) => {
    let menuText = '╭─「 M E N U - B O T 」\n';
    menuText += `│ *Selamat ${getGreetingText()}*, *${m.pushname || 'User'}* ◆\n`;
    menuText += `│ Saya adalah ${cfg.botName || 'Bot'} yang siap melayani Anda.\n`;
    menuText += `│ Waktu: ${moment().tz('Asia/Jakarta').format('HH:mm:ss DD/MM/YYYY')}\n`;
    menuText += `│ Prefix: ${m.prefix}\n`;
    menuText += `│ Gaya Menu: 2 (Sederhana)\n`;
    menuText += '│\n';

    const categories = {};
    Object.entries(plugins).forEach(([name, cmd]) => {
        if (cmd && cmd.type) {
            categories[cmd.type] = categories[cmd.type] || [];
            categories[cmd.type].push(cmd);
        }
    });

    const categoriesToDisplay = targetCategory ? [targetCategory] : Object.keys(categories);
    const displayedCategories = [];

    for (const type of categoriesToDisplay.sort()) {
        const cmdsInType = Object.entries(plugins).filter(([_, item]) => item.cmd && item.type === type.toLowerCase());
        if (cmdsInType.length > 0) {
            menuText += `├─「 ${func.ucword(type).toUpperCase()} 」\n`;
            for (const plugin of categories[type].sort((a, b) => (Array.isArray(a.cmd) ? a.cmd[0] : a.cmd).localeCompare(Array.isArray(b.cmd) ? b.cmd[0] : b.cmd))) {
                const commandName = Array.isArray(plugin.cmd) ? plugin.cmd[0] : plugin.cmd;
                menuText += `│✧ ${m.prefix}${commandName} ${plugin.use ? `(${plugin.use})` : ''}\n`;
            }
            menuText += '│\n';
            displayedCategories.push(type);
        }
    }

    if (targetCategory && !displayedCategories.includes(targetCategory)) {
        await m.reply(`✗ Kategori *${targetCategory}* tidak ditemukan atau tidak memiliki command.`);
        return false;
    }

    menuText += `╰──────────────────────\n`;

    await lulli.reply(m.chat, menuText, m, {
        expiration: m.expiration
    });
    return true;
};

menuStyleTemplates[3] = async (m, lulli, { func, cfg, plugins }, isAllMenu = false, targetCategory = null) => {
    let menuText = `━━━「 ${cfg.botName || 'Bot'} Menu 」━━━\n\n`;
    menuText += `✧ *Selamat ${getGreetingText()}*, ${m.pushname || 'User'}!\n`;
    menuText += `✧ Waktu: ${moment().tz('Asia/Jakarta').format('HH:mm DD/MM')}\n`;
    menuText += `✧ Prefix: ${m.prefix}\n`;
    menuText += `✧ Gaya Menu: 3 (Minimalis)\n\n`;

    const categories = {};
    Object.entries(plugins).forEach(([name, cmd]) => {
        if (cmd && cmd.type) {
            categories[cmd.type] = categories[cmd.type] || [];
            categories[cmd.type].push(cmd);
        }
    });

    const categoriesToDisplay = targetCategory ? [targetCategory] : Object.keys(categories);
    const displayedCategories = [];

    for (const type of categoriesToDisplay.sort()) {
        const cmdsInType = Object.entries(plugins).filter(([_, item]) => item.cmd && item.type === type.toLowerCase());
        if (cmdsInType.length > 0) {
            menuText += `── ✦ ${func.ucword(type).toUpperCase()} ✦ ──\n`;
            for (const plugin of categories[type].sort((a, b) => (Array.isArray(a.cmd) ? a.cmd[0] : a.cmd).localeCompare(Array.isArray(b.cmd) ? b.cmd[0] : b.cmd))) {
                const commandName = Array.isArray(plugin.cmd) ? plugin.cmd[0] : plugin.cmd;
                menuText += `✧ ${m.prefix}${commandName}${plugin.use ? ` - ${plugin.use}` : ''}\n`;
            }
            menuText += '\n';
            displayedCategories.push(type);
        }
    }

    if (targetCategory && !displayedCategories.includes(targetCategory)) {
        await m.reply(`✗ Kategori *${targetCategory}* tidak ditemukan atau tidak memiliki command.`);
        return false;
    }

    menuText += `━━━ Powered by SuryaDev ━━━`;

    await lulli.reply(m.chat, menuText, m, {
        expiration: m.expiration
    });
    return true;
};

menuStyleTemplates[4] = async (m, lulli, { func, cfg, setting, plugins }, isAllMenu = false, targetCategory = null) => {
    let menuText = `╭━━━「 ★ MENU BOT LULLI ★ 」━━━╮\n\n`;
    menuText += ` *Selamat ${getGreetingText()}*, ${m.pushname || 'Teman'}!\n`;
    menuText += ` ${cfg.botName} hadir untuk membantu Anda._\n`;
    menuText += `✧ Waktu: ${moment().tz('Asia/Jakarta').format('HH:mm:ss')}\n`;
    menuText += `✧ Prefix: ${m.prefix}\n`;
    menuText += `✧ Gaya Menu: 4 (Bullet Style)\n\n`;

    const categories = {};
    Object.entries(plugins).forEach(([name, cmd]) => {
        if (cmd && cmd.type) {
            categories[cmd.type] = categories[cmd.type] || [];
            categories[cmd.type].push(cmd);
        }
    });

    const categorySymbols = {
        'system': '⚙',
        'tools': '🛠',
        'downloader': '⬇',
        'group': '👥',
        'owner': '♔',
        'fun': '⬡',
        'info': 'ⓘ',
        'converter': '⇄',
        'ai': '⚛',
    };

    const categoriesToDisplay = targetCategory ? [targetCategory] : Object.keys(categories);
    const displayedCategories = [];

    for (const type of categoriesToDisplay.sort()) {
        const cmdsInType = Object.entries(plugins).filter(([_, item]) => item.cmd && item.type === type.toLowerCase());
        if (cmdsInType.length > 0) {
            const symbol = categorySymbols[type.toLowerCase()] || '⌖';
            menuText += ` ${symbol} *${func.ucword(type).toUpperCase()}*\n`;
            for (const plugin of categories[type].sort((a, b) => (Array.isArray(a.cmd) ? a.cmd[0] : a.cmd).localeCompare(Array.isArray(b.cmd) ? b.cmd[0] : b.cmd))) {
                const commandName = Array.isArray(plugin.cmd) ? plugin.cmd[0] : plugin.cmd;
                menuText += `✧ ${m.prefix}${commandName} ${plugin.use ? `[${plugin.use}]` : ''}\n`;
            }
            menuText += '\n';
            displayedCategories.push(type);
        }
    }

    if (targetCategory && !displayedCategories.includes(targetCategory)) {
        await m.reply(`✗ Kategori *${targetCategory}* tidak ditemukan atau tidak memiliki command.`);
        return false;
    }

    menuText += `╰━━「 Powered by SuryaDev 」━━╯`;

    await lulli.reply(m.chat, menuText, m, {
        expiration: m.expiration
    });
    return true;
};

menuStyleTemplates[5] = async (m, lulli, { func, cfg, setting, plugins }, isAllMenu = false, targetCategory = null) => {
    let menuText = `╔═「 ❖ LULLI BOT - MENU ❖ 」═╗\n`;
    menuText += `║\n`;
    menuText += `║  *Selamat ${getGreetingText()}*, ${m.pushname || 'Pengguna'}!\n`;
    menuText += `║  _Saya adalah ${cfg.botName}_.\n`;
    menuText += `║  *Waktu:* ${moment().tz('Asia/Jakarta').format('HH:mm:ss, DD MMM YYYY')}\n`;
    menuText += `║  *Prefix:* ${m.prefix}\n`;
    menuText += `║  *Gaya Menu:* 5 (Card Style)\n`;
    menuText += `║\n`;

    const categories = {};
    Object.entries(plugins).forEach(([name, cmd]) => {
        if (cmd && cmd.type) {
            categories[cmd.type] = categories[cmd.type] || [];
            categories[cmd.type].push(cmd);
        }
    });

    const categoriesToDisplay = targetCategory ? [targetCategory] : Object.keys(categories);
    const displayedCategories = [];

    for (const type of categoriesToDisplay.sort()) {
        const cmdsInType = Object.entries(plugins).filter(([_, item]) => item.cmd && item.type === type.toLowerCase());
        if (cmdsInType.length > 0) {
            menuText += `╠═══「 ${func.ucword(type).toUpperCase()} 」═══\n`;
            for (const plugin of categories[type].sort((a, b) => (Array.isArray(a.cmd) ? a.cmd[0] : a.cmd).localeCompare(Array.isArray(b.cmd) ? b.cmd[0] : b.cmd))) {
                const commandName = Array.isArray(plugin.cmd) ? plugin.cmd[0] : plugin.cmd;
                menuText += `║⋄ ${m.prefix}${commandName} ${plugin.use ? `| ${plugin.use}` : ''}\n`;
            }
            menuText += `║\n`;
            displayedCategories.push(type);
        }
    }

    if (targetCategory && !displayedCategories.includes(targetCategory)) {
        await m.reply(`✗ Kategori *${targetCategory}* tidak ditemukan atau tidak memiliki command.`);
        return false;
    }

    menuText += `╚══════════════════╝\n`;

    const sendMessageModify = async (printContent) => {
        let thumbnailUrl = setting.cover;
        let thumbnailBuffer = null;
        if (thumbnailUrl) {
            try {
                thumbnailBuffer = await (await fetch(thumbnailUrl)).buffer();
            } catch (e) {
                console.error("✗ Error fetching thumbnail for sendMessageModify:", e.message);
            }
        }
        return await lulli.sendMessageModify(m.chat, printContent + '\n\n' + cfg.footer, m, {
            title: cfg.header,
            body: cfg.footer,
            thumbnail: thumbnailBuffer,
            thumbUrl: thumbnailUrl,
            largeThumb: true,
            url: setting.link,
            expiration: m.expiration
        });
    };

    await sendMessageModify(menuText);
    return true;
};

const run = async (m, lulli, { func, cfg, plugins, setting }) => {
        if (typeof setting.style === 'undefined' || setting.style === null) {
            setting.style = 1;
        }
        const currentStyleIndex = setting.style;
        const availableStylesCount = Object.keys(menuStyleTemplates).length;

        if (m.command === 'setmenu') {
            if (!m.isOwner && !m.isDevs) {
                return m.reply('✗ Perintah ini hanya bisa digunakan oleh Owner/Developer.');
            }

            if (m.args.length === 0) {
                return m.reply(`✗ Penggunaan: \`${m.prefix}setmenu [angka]\`\n\n\`\`\`Pilih gaya menu dari 1 sampai ${availableStylesCount}.\`\`\`\n\`\`\`Gaya menu saat ini: ${currentStyleIndex}.\`\`\``);
            }

            const newStyle = parseInt(m.args[0]);
            if (isNaN(newStyle) || newStyle < 1 || newStyle > availableStylesCount) {
                return m.reply(`✗ Angka gaya menu tidak valid. Pilih antara 1 sampai ${availableStylesCount}.`);
            }

            setting.style = newStyle;
            await m.reply(`✓ Gaya menu berhasil diubah ke style *${newStyle}*!`);

            const menuDisplayFunction = menuStyleTemplates[newStyle];
            if (menuDisplayFunction) {
                await menuDisplayFunction(m, lulli, { func, cfg, plugins, setting }, false, null);
            } else {
                 await m.reply(`✗ Terjadi kesalahan saat menampilkan pratinjau menu style ${newStyle}.`);
            }
            return;
        }
        
        const menuDisplayFunction = menuStyleTemplates[currentStyleIndex];
        if (!menuDisplayFunction) {
            await m.reply(`✗ Terjadi kesalahan: Gaya menu saat ini (${currentStyleIndex}) tidak ditemukan. Silakan coba \`${m.prefix}setmenu 1\` untuk mengatur ulang.`);
            return;
        }

        let isAllMenu = false;
        let targetCategory = null;

        if (m.command === 'allmenu') {
            isAllMenu = true;
        } else if (m.command === 'menu' && m.text) {
            targetCategory = m.text.trim().toLowerCase();
            if (!Object.values(plugins).some(plugin => plugin.cmd && plugin.type === targetCategory)) {
                return m.reply(`✗ Kategori *${m.text}* tidak tersedia.`);
            } else if (targetCategory === 'developer' && !m.isDevs) {
                return m.reply('✗ Menu ini hanya untuk developer.');
            }
        }

        try {
            lulli.sendReact(m.chat, '🕒', m.key);
            const success = await menuDisplayFunction(m, lulli, { func, cfg, plugins, setting }, isAllMenu, targetCategory);
            if (!success) {
                await m.reply("✗ Gagal menampilkan menu sesuai gaya yang dipilih.");
            }
        } catch (error) {
            console.error('✗ Error saat menampilkan menu:', error);
            await m.reply(cfg.mess.wrong(error.message) || `✗ Terjadi kesalahan saat memproses menu: ${error.message}`);
        }
    }
    
export default {
    run,
    cmd: ['menu', 'allmenu', 'setmenu'],
    restrict: true,
    location: 'plugins/menu.js'
};