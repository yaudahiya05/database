import mime from 'mime-types';
import FormData from 'form-data';
import filetype from 'file-type';
const {
    fromBuffer
} = filetype;
import fetch from 'node-fetch';
import axios from 'axios';
import path from 'path';
import fs from 'fs';
import {
    exec
} from 'child_process';
import {
    promisify
} from 'util';
const execPromise = promisify(exec)
async function uploadToZen(buffer) {
    try {
        let {
            ext
        } = await fromBuffer(buffer);
        const form = new FormData();
        form.append('file', buffer, `v-${Date.now()}.${ext}`);
        const res = await fetch('https://uploader.zenzxz.dpdns.org/upload', {
            method: 'POST',
            body: form,
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://uploader.zenzxz.dpdns.org',
                'Referer': 'https://uploader.zenzxz.dpdns.org/'
            }
        });
        const html = await res.text();
        const match = html.match(/href="(https?:\/\/uploader\.zenzxz\.dpdns\.org\/uploads\/[^"]+)"/);
        if (!match) throw new Error('✗ Error saat mendapatkan link dari zenzxz.');
        return {
            status: true,
            url: match[1]
        };
    } catch (err) {
        return {
            status: false,
            message: err.message
        };
    }
}
const run = async (m, lulli, {
    func,
    cfg,
    quoted
}) => {
    global.db.respon = global.db.respon || {};
    switch (m.command) {
        case 'addrespon': {
            if (!m.isOwner) return m.reply(cfg.mess.owner);
            let name;
            if (m.text) {
                name = m.text.trim().toLowerCase();
            } else {
                return m.reply(`✗ Reply stiker/audio/teks dengan caption ${m.cmd} <nama respon>`);
            }
            if (global.db.respon[name]) return m.reply('✗ Nama tersebut sudah ada di database!');
            if (quoted && (/webp|audio/.test(quoted.mimetype))) {
                const media = await quoted.download();
                const upload = await uploadToZen(media);
                if (!upload.status || !upload.url) {
                    return m.reply('✗ Gagal mengupload media, silahkan coba lagi.');
                }
                global.db.respon[name] = {
                    name: name,
                    type: /webp/.test(quoted.mimetype) ? 'sticker' : 'audio',
                    content: upload.url,
                };
                await m.reply(`✓ Sukses menambahkan respon media dengan nama *${name}* ke dalam database!`);
            } else if (quoted && m.quoted.text) {
                global.db.respon[name] = {
                    name: name,
                    type: 'text',
                    content: m.quoted.text,
                };
                await m.reply(`✓ Sukses menambahkan respon teks dengan nama *${name}* ke dalam database!`);
            } else {
                m.reply(`✗ Reply stiker/audio/teks dengan caption ${m.cmd} <nama respon>`);
            }
        }
        break;
        case 'delrespon': {
            if (!m.isOwner) return m.reply(cfg.mess.owner);
            if (!m.text) return m.reply(func.example(m.cmd, 'test'));
            const name = m.text.trim().toLowerCase();
            if (!global.db.respon[name]) return m.reply('✗ Nama tersebut tidak ada di database!');
            delete global.db.respon[name];
            await m.reply(`✓ Berhasil menghapus respon dengan nama *${name}* dari database!`);
        }
        break;
        case 'listrespon': {
            const data = Object.values(global.db.respon || {});
            if (data.length === 0) return m.reply('✦ Tidak ada data respon.');
            let caption = '✦ LIST - RESPONSE\n\n';
            caption += data.sort((a, b) => a.name.localeCompare(b.name)).map((item, index) => (index + 1) + '. ' + item.name + '\n- Type: ' + item.type).join('\n\n');
            await m.reply(caption);
        }
        break;
        case 'clearrespon': {
            if (!m.isOwner) return m.reply(cfg.mess.owner);
            const data = Object.values(global.db.respon || {});
            if (data.length === 0) return m.reply('✦ Tidak ada data respon untuk dihapus.');
            global.db.respon = {};
            await m.reply('✓ Berhasil menghapus semua respon.');
        }
        break;
    }
};
const main = async (m, lulli, {
    cfg
}) => {
    global.db.respon = global.db.respon || {};
    const responseKey = m.budy && m.budy.trim().toLowerCase();
    if (responseKey && global.db.respon[responseKey] && !m.isPrefix) {
        let data = global.db.respon[responseKey];
        if (data.type === 'sticker') {
            lulli.sendMessage(m.chat, {
                sticker: {
                    url: data.content
                }
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } else if (data.type === 'audio') {
            const tmpDir = cfg.path.trash;
            const inputPath = path.join(tmpDir, `${Date.now()}.mp3`)
            const outputPath = path.join(tmpDir, `${Date.now()}.opus`)
            const mp3Buffer = await axios.get(data.content, {
                responseType: 'arraybuffer',
                headers: {
                    'User-Agent': 'Mozilla/5.0'
                }
            })
            fs.writeFileSync(inputPath, Buffer.from(mp3Buffer.data))
            await execPromise(`ffmpeg -i "${inputPath}" -c:a libopus -b:a 48k -vbr on "${outputPath}"`)
            const buffer = fs.readFileSync(outputPath)
            lulli.sendMessage(m.chat, {
                audio: buffer,
                mimetype: 'audio/mpeg',
                ptt: true
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } else if (data.type === 'text') {
            lulli.sendMessage(m.chat, {
                text: data.content,
                mentions: lulli.ments(data.content)
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        }
    }
};
export default {
    run,
    main,
    cmd: ['addrespon', 'delrespon', 'listrespon', 'clearrespon'],
    use: 'reply sticker/audio or text',
    type: 'owner',
    location: 'plugins/owner/respon.js'
};