module.exports={cmd:["listblockcmd"],alias:["listblokcmd"],type:"owner",run:async(c,l,{setting:e})=>{if(0==e.blockcmd.length)return c.reply("Empty data.");var n="乂  *LIST BLOCK COMMANDS*\n\n",n=(n+=`Total: *${e.blockcmd.length}* commands blocked

`)+e.blockcmd.map(l=>"◦  "+(c.prefix+l)).join("\n");c.reply(n)}};