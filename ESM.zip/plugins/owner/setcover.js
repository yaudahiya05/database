import fetch from 'node-fetch';
import FormData from 'form-data';
import filetype from 'file-type';
const {
    fromBuffer
} = filetype;
async function upload(buffer) {
    try {
        let {
            ext
        } = await fromBuffer(buffer);
        const form = new FormData();
        form.append('file', buffer, `v-${Date.now()}.${ext}`);
        const res = await fetch('https://uploader.zenzxz.dpdns.org/upload', {
            method: 'POST',
            body: form,
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0',
                'Origin': 'https://uploader.zenzxz.dpdns.org',
                'Referer': 'https://uploader.zenzxz.dpdns.org/'
            }
        });
        const html = await res.text();
        const match = html.match(/href="(https?:\/\/uploader\.zenzxz\.dpdns\.org\/uploads\/[^"]+)"/);
        if (!match) throw new Error('✗ Error saat mendapatkan link dari zenzxz.');
        return {
            status: true,
            url: match[1]
        };
    } catch (e) {
        return {
            status: false,
            message: e.message
        }
    }
}
const run = async (m, lulli, {
    func,
    cfg,
    setting,
    quoted
}) => {
    let coverUrl = null;
    const potentialUrl = m.args.length > 0 ? m.args[0] : null;
    if (potentialUrl && (potentialUrl.startsWith('http://') || potentialUrl.startsWith('https://'))) {
        coverUrl = potentialUrl;
    } else if (quoted && quoted.isMedia && /image/.test(quoted.mime)) {
        let mediaBuffer = await quoted.download();
        if (!mediaBuffer) {
            return m.reply('Gagal mengunduh media yang direply.');
        }
        let result = await upload(mediaBuffer);
        if (!result || !result.status) {
            return m.reply(result?.message || '✗ Gagal mengupload gambar.');
        }
        coverUrl = result.url;
    } else {
        return m.reply('✗ Reply foto yang ingin dijadikan cover, atau masukkan URL gambar langsung setelah perintah.');
    }
    if (coverUrl) {
        setting.cover = coverUrl;
        return m.reply('✓ Cover berhasil diatur.');
    } else {
        return m.reply('✗ Gagal mendapatkan URL gambar untuk cover.');
    }
};
export default {
    run,
    cmd: 'setcover',
    alias: 'cover',
    use: 'Reply foto atau berikan URL gambar langsung', // Perbarui deskripsi penggunaan
    type: 'owner',
    owner: true,
    location: 'plugins/owner/setcover.js'
};