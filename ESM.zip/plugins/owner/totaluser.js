let run=async(e,r,{})=>{global.db.users=global.db.users||{};var s=(t=Object.values(global.db.users)).filter(e=>e.register),t=`✦ Total User: *${t.length}* User
✦ Registered: *${s.length}* User

`;t+=s.map((e,r)=>`✦ ${r+1}. @${e.jid.split("@")[0]} (Registered: ${e.register?"Yes":"No"})`).join("\n"),await e.reply(t)};export default{run:run,cmd:"totaluser",type:"owner",owner:!0,location:"plugins/owner/totaluser.js"};