import axios from 'axios';
import fs from 'node:fs';
import path from 'node:path';

async function tiktokStory(username) {
    const RAPIDAPI_KEY = process.env.RAPIDAPI_KEY || "YOUR_RAPIDAPI_KEY_HERE";
    if (RAPIDAPI_KEY === "YOUR_RAPIDAPI_KEY_HERE") {
        throw new Error("✗ RapidAPI Key belum diatur. Harap set environment variable RAPIDAPI_KEY.");
    }

    const uuid = encodeURIComponent(`@${username}`);
    try {
        const { data } = await axios.get(`https://tiktok-video-no-watermark2.p.rapidapi.com/user/posts?unique_id=${uuid}&count=1000`, {
            headers: {
                "Accept": "application/json, text/plain, */*",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
                "X-Rapidapi-Host": "tiktok-video-no-watermark2.p.rapidapi.com",
                "X-Rapidapi-Key": RAPIDAPI_KEY
            }
        });

        let result = [];
        if (data.data && Array.isArray(data.data.videos)) {
            for (let [idx, res] of data.data.videos.entries()) {
                result.push({
                    index: idx + 1,
                    video_id: res.video_id,
                    region: res.region,
                    title: res.title,
                    cover: res.cover,
                    origin_cover: res.origin_cover,
                    duration: res.duration,
                    play: res.play,
                    wmplay: res.wmplay,
                    size: res.size,
                    wm_size: res.wm_size,
                    music: res.music
                });
            }
        }
        
        return {
            status: true,
            creator: 'SuryaDev.',
            data: result
        };
    } catch (e) {
        console.error("✗ Error fetching TikTok Story:", e);
        throw {
            status: false,
            creator: 'SuryaDev.',
            message: e.response ? e.response.data : e.message
        };
    }
}

const run = async (m, lulli, { func, setting }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'babals__'));
    
    m.reply(global.mess.wait);
    
    let result;
    try {
        result = await tiktokStory(m.text);
    } catch (error) {
        return m.reply(`✗ Gagal mendapatkan story TikTok: ${error.message}`);
    }

    if (!result.status || !result.data || result.data.length === 0) {
        return m.reply('✗ Tidak ada story TikTok ditemukan untuk username ini.');
    }

    let sentVideoCount = 0;
    let captionText = '✦ TIKTOK SEARCH\n';

    const mediaDir = './media/';
    if (!fs.existsSync(mediaDir)) {
        fs.mkdirSync(mediaDir);
    }
    
    setting.videogalau = setting.videogalau || [];

    for (let data of result.data) {
        if (data.video_id) {
            captionText += `\n\n✦ ${data.index}. ${data.title}`;
            captionText += `\n- Size: ${func.formatSize(data.size)}`;
            captionText += `\n- Duration: ${data.duration}`;
            captionText += `\n- Url: ${data.play}`;

            try {
                let buffer = await func.fetchBuffer(data.play);
                
                const filePath = path.join(mediaDir, func.filename('mp4'));
                fs.writeFileSync(filePath, buffer);

                let uploaded = await func.telegraPh(filePath);
                
                fs.unlinkSync(filePath);

                if (uploaded && uploaded.url) {
                    setting.videogalau.push(uploaded.url);
                    sentVideoCount++;
                } else {
                    console.warn(`✗ Failed to upload video for TikTok story: ${data.title}`);
                }
            } catch (dlErr) {
                console.error(`✗ Error downloading or uploading TikTok story video ${data.title}:`, dlErr);
            }
        }
        await new Promise(resolve => setTimeout(resolve, 1000));
    }

    await lulli.reply(m.chat, captionText + `\n\n✓ Sukses menyimpan ${sentVideoCount} video.`, m, { expiration: m.expiration });
};

export default {
    run,
    cmd: 'tiktokstory',
    alias: 'ttstory',
    use: 'username',
    type: 'searching',
    owner: true,
    location: 'plugins/owner/tiktokstory.js'
};