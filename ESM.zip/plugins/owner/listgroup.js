import { isLidUser, jidNormalizedUser } from '@whiskeysockets/baileys';

let interactiveDatabase = {}; 
let success = 0;
let failed = 0;

const run = async (m, lulli, { cfg, func, lid }) => {
    const groupData = Object.values(await lulli.groupFetchAllParticipating().catch(() => []));
    if (groupData.length === 0) return m.reply('✗ Tidak ada grup yang ditemukan.');

    let caption = `✦ LIST - GRUP\n\n`;
    groupData.forEach((group, index) => {
        caption += `${index + 1}. ${group.subject}\n- ID: ${group.id}\n- Total peserta: ${group.participants ? Object.keys(group.participants).length : '0'}\n\n`;
    });
    
    caption += `✦ Pilihan Opsi:\n- ${m.cmd} [nomor] [opsi]\n`;
    caption += `✧ Contoh Penggunaan:\n`;
    caption += `- ${m.cmd} 1 id - menampilkan id grup.\n`;
    caption += `- ${m.cmd} 1 detail - menampilkan detail grup.\n`;
    caption += `- ${m.cmd} 1 profile - menampilkan profil grup.\n`;
    caption += `- ${m.cmd} 1 desc - menampilkan deskripsi grup.\n`;
    caption += `- ${m.cmd} 1 link - menampilkan tautan grup.\n`;
    caption += `- ${m.cmd} 1 leave - mengeluarkan bot dari grup.\n`;
    caption += `- ${m.cmd} 1 close - menutup grup.\n`;
    caption += `- ${m.cmd} 1 open - membuka grup.\n`;
    caption += `- ${m.cmd} 1 admin - menampilkan daftar admin.\n`;
    caption += `- ${m.cmd} 1 member - menampilkan daftar anggota.\n`;
    caption += `- ${m.cmd} 1 kickall - mengeluarkan semua anggota.\n`;
    
    const [numberRaw, action] = m.args;
    if (!(numberRaw && action)) return m.reply(caption);

    const number = parseInt(numberRaw);
    if (isNaN(number) || number < 1 || number > groupData.length) {
        return m.reply('✗ Nomor grup tidak valid.');
    }

    const selectedGroup = groupData[number - 1];
    const groupId = selectedGroup.id;

    const botJid = lulli.user.jid;
    lid.convertLidParticipants(selectedGroup);
    const isBotAdminInTargetGroup = selectedGroup.participants.some(p => p.id === botJid && p.admin !== null);

    switch (action.toLowerCase()) {
        case 'id':
            lulli.reply(m.chat, groupId, m, { expiration: m.expiration });
            break;

        case 'detail': {
            let detailCaption = `✦ Nama Grup: ${selectedGroup.subject}\n`;
            detailCaption += `⋄ ID Grup: ${selectedGroup.id}\n`;
            detailCaption += `⋄ Total Member: ${selectedGroup.participants.length}\n`;
            detailCaption += `⋄ Edit Setelan Grup: ${selectedGroup.restrict ? 'Hanya admin' : 'Semua peserta'}\n`;
            detailCaption += `⋄ Kirim Pesan: ${selectedGroup.announce ? 'Hanya admin' : 'Semua peserta'}\n`;
            detailCaption += `⋄ Bot Admin: ${isBotAdminInTargetGroup ? 'Ya' : 'Tidak'}\n`;
            detailCaption += `⋄ Pesan Sementara: ${selectedGroup.ephemeralDuration ? 'Aktif' : 'Mati'}`;
            if (selectedGroup.hasOwnProperty('isCommunity')) {
                detailCaption += `\n⋄ isCommunity: ${selectedGroup.isCommunity ? 'Ya' : 'Tidak'}`;
            }
            if (selectedGroup.hasOwnProperty('isCommunityAnnounce')) {
                detailCaption += `\n⋄ isCommunityAnnounce: ${selectedGroup.isCommunityAnnounce ? 'Ya' : 'Tidak'}`;
            }
            if (selectedGroup.hasOwnProperty('joinApprovalMode')) {
                detailCaption += `\n⋄ Setujui Anggota Baru: ${selectedGroup.joinApprovalMode ? 'Ya' : 'Tidak'}`;
            }
            if (selectedGroup.hasOwnProperty('memberAddMode')) {
                detailCaption += `\n⋄ Tambah anggota lain: ${selectedGroup.memberAddMode ? 'Ya' : 'Tidak'}`;
            }
            lulli.sendMessage(m.chat, {
                text: detailCaption,
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            break;
        }

        case 'profile': {
            let profile = await func.getBuffer(await lulli.profilePictureUrl(groupId, 'image').catch(() => 'https://files.catbox.moe/ifx2y7.png'));
            lulli.sendMessage(m.chat, { image: profile }, { quoted: m, ephemeralExpiration: m.expiration });
            break;
        }

        case 'desc': {
            if (!selectedGroup || !selectedGroup.desc) return m.reply('✗ Gagal mengambil deskripsi grup atau deskripsi kosong.');
            lulli.reply(m.chat, selectedGroup.desc, m, { expiration: m.expiration });
            break;
        }

        case 'link': {
            if (!isBotAdminInTargetGroup) return m.reply(cfg.mess.botAdmin);
            let code = await lulli.groupInviteCode(groupId).catch(() => '');
            if (!code) return m.reply('✗ Gagal mendapatkan link grup. Pastikan bot admin.');
            let linkCaption = `Link Group ${selectedGroup?.subject || 'Unknown Group'}\n\nhttps://chat.whatsapp.com/${code}`;
            lulli.reply(m.chat, linkCaption, m, { expiration: m.expiration });
            break;
        }

        case 'leave': {
            await lulli.reply(groupId, '✦ Saya diperintahkan untuk keluar dari grup ini. Terima kasih dan maaf atas kesalahan selama di sini.');
            await lulli.groupLeave(groupId)
                .then(() => m.reply(`✓ Berhasil keluar dari grup "${selectedGroup.subject}".`))
                .catch((e) => {
                    console.error("✗ Error leaving group:", e);
                    m.reply(`✗ Gagal keluar dari grup "${selectedGroup.subject}": ${e.message}`);
                });
            break;
        }

        case 'close': {
            if (!isBotAdminInTargetGroup) return m.reply(cfg.mess.botAdmin);
            await lulli.groupSettingUpdate(groupId, 'announcement')
                .then(() => m.reply(`✓ Grup "${selectedGroup.subject}" berhasil ditutup.`))
                .catch((e) => {
                    console.error("✗ Error closing group:", e);
                    m.reply(`✗ Gagal menutup grup "${selectedGroup.subject}": ${e.message}`);
                });
            break;
        }

        case 'open': {
            if (!isBotAdminInTargetGroup) return m.reply(cfg.mess.botAdmin);
            await lulli.groupSettingUpdate(groupId, 'not_announcement')
                .then(() => m.reply(`✓ Grup "${selectedGroup.subject}" berhasil dibuka.`))
                .catch((e) => {
                    console.error("✗ Error opening group:", e);
                    m.reply(`✗ Gagal membuka grup "${selectedGroup.subject}": ${e.message}`);
                });
            break;
        }

        case 'admin': {
            if (!selectedGroup) return m.reply('✗ Gagal mengambil daftar admin grup.');
            let adminList = selectedGroup.participants.filter(user => user.admin).map(user => user.id);
            let adminMap = adminList.map((user, index) => `${index + 1}. @${user.split('@')[0]}`).join('\n');
            let adminCaption = `✦ Daftar Admin Grup "${selectedGroup.subject}"\n\n${adminMap || 'Tidak ada admin ditemukan.'}`;
            lulli.sendMessage(m.chat, {
                text: adminCaption,
                mentions: adminList
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            break;
        }

        case 'member': {
            if (!selectedGroup) return m.reply('✗ Gagal mengambil daftar member grup.');
            let memberList = selectedGroup.participants.map((user, index) => 
                `${index + 1}. @${user.id.split('@')[0]} (${user.admin === 'superadmin' ? 'Owner' : user.admin === 'admin' ? 'Admin' : 'Member'})`
            ).join('\n');
            let memberCaption = `✦ Daftar Member Grup "${selectedGroup.subject}"\n\n${memberList || 'Tidak ada member ditemukan.'}`;
            lulli.sendMessage(m.chat, {
                text: memberCaption,
                mentions: selectedGroup.participants.map(x => x.id)
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
            break;
        }

        case 'kickall': {
            if (!isBotAdminInTargetGroup) return m.reply(cfg.mess.botAdmin);
            if (!selectedGroup) return m.reply('✗ Gagal mengambil daftar member grup.');
            let membersToKick = selectedGroup.participants.filter(user => user.admin === null && user.id !== botJid).map(user => user.id);
            if (membersToKick.length === 0) return m.reply('✦ Tidak ada member yang bisa di-kick (semuanya admin atau tidak ada member).');
            let txt = `✦ Apakah kamu yakin ingin mengeluarkan semua peserta dari grup "${selectedGroup.subject}"?\nTimeout *60* detik.\n\nketik *(Y/N)*`.trim();
            let { key: confirmKey } = await lulli.reply(m.chat, txt, m, { expiration: m.expiration });
            interactiveDatabase[m.sender] = {
                jid: m.sender,
                groupId: groupId,
                groupName: selectedGroup.subject || '-',
                key: confirmKey,
                members: membersToKick,
                timeout: setTimeout(() => {
                    lulli.reply(m.chat, '✗ Waktu habis.', m, { expiration: m.expiration });
                    lulli.sendMessage(m.chat, { delete: confirmKey });
                    delete interactiveDatabase[m.sender];
                }, 60 * 1000)
            };
            break;
        }

        default:
            lulli.reply(m.chat, `✗ Opsi "${action}" tidak valid. Pilihan Opsi: id, detail, profile, desc, link, leave, close, open, admin, member, kickall.`, m, { expiration: m.expiration });
    }
};

const main = async (m, lulli) => {
    if (m.isBot) return;
    
    if (!(m.sender in interactiveDatabase)) return;
    if (m.id === interactiveDatabase[m.sender].key.id) return;
    let { jid, groupId, groupName, key, members, timeout } = interactiveDatabase[m.sender];
    if (/^(n|no)$/i.test(m.budy.toLowerCase())) {
        clearTimeout(timeout);
        delete interactiveDatabase[jid];
        return m.reply(`✓ Kick all di grup "${groupName}" berhasil dibatalkan.`);
    }

    if (/^(y|yes)$/i.test(m.budy.toLowerCase())) {
        try {
            clearTimeout(timeout);
            await m.reply(`✦ Tunggu sebentar, mengeluarkan ${members.length} peserta...`);
            success = 0;
            failed = 0;

            for (let user of members) {
                try {
                    await lulli.groupParticipantsUpdate(groupId, [user], 'remove');
                    success++;
                    await func.delay(1000);
                } catch (error) {
                    console.error(`✗ Failed to kick ${user}:`, error);
                    failed++;
                }
            }
            delete interactiveDatabase[jid];
            m.reply(`✓ Berhasil mengeluarkan ${success} peserta di grup "${groupName}".\n- Sukses: ${success}\n- Gagal: ${failed}`);
        } catch (error) {
            console.error("✗ Error during kickall:", error);
            m.reply(`✗ Gagal mengeluarkan semua peserta: ${error.message}`);
        } finally {
            success = 0;
            failed = 0;
        }
    }
};

export default {
    run,
    main,
    cmd: 'listgroup',
    alias: ['listgrup', 'listgc'],
    type: 'owner',
    owner: true,
    location: 'plugins/owner/listgroup.js'
};