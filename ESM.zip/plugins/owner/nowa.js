import moment from"moment-timezone";let run=async(e,a,{func:t})=>{if(!e.text)return e.reply(t.example(e.cmd,"6285700408187x"));if(!e.text.includes("x"))return e.reply(`✗ Masukkan tanda x di belakang nomor.
Contoh: ${e.prefix+e.command} 6285700408187x`);await e.reply(global.mess.wait);let n=e.text.split("x")[0],r=(t=e.text).split("x").length-1,i=0;if(1==r)i=10;else if(2==r)i=100;else if(3==r)i=1e3;else{if(4!=r)return e.reply('✗ Jumlah "x" yang tidak didukung. Maksimal 4 "x".');i=1e4}let s="✦ LIST NOMOR WHATSAPP\n\nPunya Bio/status/info",o="\n\nTanpa Bio/status/info",l="\n\nTidak Terdaftar";for(let t=0;t<i;t++){var m=""+n+t.toString().padStart(r,"0"),p=m+"@s.whatsapp.net";try{var u=await a.onWhatsApp(p);if(u&&0<u.length&&u[0].exists)try{var d=await a.fetchStatus(u[0].jid);d&&d.status?s+=`
wa.me/${u[0].jid.split("@")[0]}
Biography : ${d.status}
Date : `+moment(1e3*d.setAt).tz("Asia/Jakarta").format("HH:mm:ss DD/MM/YYYY"):o+=`
wa.me/`+u[0].jid.split("@")[0]}catch(e){o+=`
wa.me/`+u[0].jid.split("@")[0]}else l+=`
`+m}catch(e){console.error(`✗ Error checking number ${m}:`,e),l+=`
`+m}}await e.reply(""+s+o+l)};export default{run:run,cmd:["nowa"],use:"number wa",type:"owner",owner:!0,location:"plugins/owner/nowa.js"};