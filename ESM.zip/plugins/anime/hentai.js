import axios from 'axios';
import * as cheerio from 'cheerio';

function hentai() {
    return new Promise(async (resolve, reject) => {
        try {
            const page = Math.floor(Math.random() * 1153);
            const { data } = await axios.get(`https://sfmcompile.club/page/${page}`);
            const $ = cheerio.load(data);
            const hasil = [];

            $('#primary > div > div > ul > li > article').each(function(a, b) {
                const title = $(b).find('header > h2').text().trim();
                const link = $(b).find('header > h2 > a').attr('href');
                const category = $(b).find('header > div.entry-before-title > span > span').text().replace('in ', '').trim();
                const shareCount = $(b).find('header > div.entry-after-title > p > span.entry-shares').text().trim();
                const viewsCount = $(b).find('header > div.entry-after-title > p > span.entry-views').text().trim();
                
                const video1 = $(b).find('source').attr('src') || $(b).find('img').attr('data-src');
                const video2 = $(b).find('video > a').attr('href') || '';

                if (title && link) {
                    hasil.push({
                        title,
                        link,
                        category,
                        share_count: shareCount,
                        views_count: viewsCount,
                        type: $(b).find('source').attr('type') || (video1?.includes('.mp4') ? 'video/mp4' : 'image/jpeg'),
                        video_1: video1,
                        video_2: video2
                    });
                }
            });
            resolve(hasil);
        } catch (e) {
            console.error('✗ Error fetching hentai data:', e.message);
            reject(new Error(`✗ Gagal mengambil data hentai: ${e.message}`));
        }
    });
}

let run = async (m, lulli) => {
    m.reply('✦ Sedang memproses, mohon tunggu...');

    try {
        const data = await hentai();
        if (!data || data.length === 0) {
            return m.reply('✗ Tidak ada video hentai yang ditemukan.');
        }

        const result = data[Math.floor(Math.random() * data.length)];
        
        let caption = `✦ H E N T A I\n\n`;
        caption += `- Judul         : *${result.title || 'N/A'}*\n`;
        caption += `- Link          : ${result.link || 'N/A'}\n`;
        caption += `- Kategori      : ${result.category || 'N/A'}\n`;
        caption += `- Jumlah Share  : ${result.share_count || 'N/A'}\n`;
        caption += `- Jumlah Dilihat: ${result.views_count || 'N/A'}\n`;
        caption += `- Tipe Media    : ${result.type || 'N/A'}`;
        
        const mediaUrl = result.video_1 || result.video_2;
        if (!mediaUrl) {
            return m.reply('✗ Tidak ada URL media yang valid ditemukan.');
        }

        const buttons = [
            ['Video Selanjutnya', m.cmd],
        ];
        
        const mediaType = result.type.includes('video') ? 'video' : 'image';
        
        await lulli.sendbut(m.chat, caption, '✦ Klik tombol untuk video selanjutnya.', buttons, m, {
            media: mediaUrl,
            expiration: m.expiration,
            mimetype: mediaType === 'video' ? 'video/mp4' : 'image/jpeg'
        });

    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Hentai:', e);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'hentai',
    type: 'nsfw',
    premium: true,
    location: 'plugins/anime/hentai.js'
};
