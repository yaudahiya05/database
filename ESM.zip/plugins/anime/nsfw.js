const nsfwEndpoints = new Map([
    ['anusview', 'https://fantox-apis.vercel.app/anusview'],
    ['barefoot', 'https://fantox-apis.vercel.app/barefoot'],
    ['beach', 'https://fantox-apis.vercel.app/beach'],
    ['bed', 'https://fantox-apis.vercel.app/bed'],
    ['bikini', 'https://fantox-apis.vercel.app/bikini'],
    ['blonde', 'https://fantox-apis.vercel.app/blonde'],
    ['bondage', 'https://fantox-apis.vercel.app/bondage'],
    ['bra', 'https://fantox-apis.vercel.app/bra'],
    ['breast', 'https://fantox-apis.vercel.app/breast'],
    ['breasthold', 'https://fantox-apis.vercel.app/breasthold'],
    ['bunnyear', 'https://fantox-apis.vercel.app/bunnyear'],
    ['bunnygirl', 'https://fantox-apis.vercel.app/bunnygirl'],
    ['catgirl', 'https://fantox-apis.vercel.app/catgirl'],
    ['chain', 'https://fantox-apis.vercel.app/chain'],
    ['close', 'https://fantox-apis.vercel.app/close'],
    ['demon', 'https://fantox-apis.vercel.app/demon'],
    ['dress', 'https://fantox-apis.vercel.app/dress'],
    ['drunk', 'https://fantox-apis.vercel.app/drunk'],
    ['fateseries', 'https://fantox-apis.vercel.app/fateseries'],
    ['fingering', 'https://fantox-apis.vercel.app/fingering'],
    ['flatchest', 'https://fantox-apis.vercel.app/flatchest'],
    ['food', 'https://fantox-apis.vercel.app/food'],
    ['gamecg', 'https://fantox-apis.vercel.app/gamecg'],
    ['genshin', 'https://fantox-apis.vercel.app/genshin'],
    ['glasses', 'https://fantox-apis.vercel.app/glasses'],
    ['greenhair', 'https://fantox-apis.vercel.app/greenhair'],
    ['gun', 'https://fantox-apis.vercel.app/gun'],
    ['headband', 'https://fantox-apis.vercel.app/headband'],
    ['headdress', 'https://fantox-apis.vercel.app/headdress'],
    ['headphone', 'https://fantox-apis.vercel.app/headphone'],
    ['hololive', 'https://fantox-apis.vercel.app/hololive'],
    ['horns', 'https://fantox-apis.vercel.app/horns'],
    ['idol', 'https://fantox-apis.vercel.app/idol'],
    ['foxgirl', 'https://fantox-apis.vercel.app/foxgirl'],
    ['maid', 'https://fantox-apis.vercel.app/maid'],
    ['nipples', 'https://fantox-apis.vercel.app/nipples'],
    ['erectnipples', 'https://fantox-apis.vercel.app/erectnipples'],
    ['nobra', 'https://fantox-apis.vercel.app/nobra'],
    ['nude', 'https://fantox-apis.vercel.app/nude'],
    ['openshirt', 'https://fantox-apis.vercel.app/openshirt'],
    ['pantypull', 'https://fantox-apis.vercel.app/pantypull'],
    ['pinkhair', 'https://fantox-apis.vercel.app/pinkhair'],
    ['ponytail', 'https://fantox-apis.vercel.app/ponytail'],
    ['schoolswimsuit', 'https://fantox-apis.vercel.app/schoolswimsuit'],
    ['seethrough', 'https://fantox-apis.vercel.app/seethrough'],
    ['sex', 'https://fantox-apis.vercel.app/sex'],
    ['sex2', 'https://fantox-apis.vercel.app/sex2'],
    ['sex3', 'https://fantox-apis.vercel.app/sex3'],
    ['shirtlift', 'https://fantox-apis.vercel.app/shirtlift'],
    ['shorts', 'https://fantox-apis.vercel.app/shorts'],
    ['spreadlegs', 'https://fantox-apis.vercel.app/spreadlegs'],
    ['spreadpussy', 'https://fantox-apis.vercel.app/spreadpussy'],
    ['stokings', 'https://fantox-apis.vercel.app/stokings'],
    ['sunglasses', 'https://fantox-apis.vercel.app/sunglasses'],
    ['swimsuit', 'https://fantox-apis.vercel.app/swimsuit'],
    ['tears', 'https://fantox-apis.vercel.app/tears'],
    ['tie', 'https://fantox-apis.vercel.app/tie'],
    ['topless', 'https://fantox-apis.vercel.app/topless'],
    ['torncloth', 'https://fantox-apis.vercel.app/torncloth'],
    ['touhou', 'https://fantox-apis.vercel.app/touhou'],
    ['tree', 'https://fantox-apis.vercel.app/tree'],
    ['twintail', 'https://fantox-apis.vercel.app/twintail'],
    ['uncensored', 'https://fantox-apis.vercel.app/uncensored'],
    ['underwear', 'https://fantox-apis.vercel.app/underwear'],
    ['uniform', 'https://fantox-apis.vercel.app/uniform'],
    ['vampire', 'https://fantox-apis.vercel.app/vampire'],
    ['weapon', 'https://fantox-apis.vercel.app/weapon'],
    ['wet', 'https://fantox-apis.vercel.app/wet'],
    ['white', 'https://fantox-apis.vercel.app/white'],
    ['whitehair', 'https://fantox-apis.vercel.app/whitehair'],
    ['wolfgirl', 'https://fantox-apis.vercel.app/wolfgirl'],
]);

let run = async (m, lulli, { func }) => {
    m.reply('✦ Sedang memproses, mohon tunggu...');

    try {
        const apiUrl = nsfwEndpoints.get(m.command);
        if (!apiUrl) {
            return m.reply('✗ Command tidak valid atau endpoint tidak ditemukan.');
        }

        const data = await func.fetchJson(apiUrl);
        
        if (!data || !data.url) {
            return m.reply('✗ Gagal mengambil gambar dari API.');
        }

        const caption = '✗ Konten NSFW. Gunakan dengan bijak.';
        
        await lulli.sendMedia(m.chat, data.url, m, {
            caption: caption,
            expiration: m.expiration,
            mimetype: 'image/jpeg'
        });

    } catch (e) {
        console.error(`✗ Terjadi kesalahan pada ${m.command} (NSFW):`, e);
        await m.reply(`✗ Terjadi kesalahan saat mengambil gambar NSFW: ${e.message}`);
    }
};

export default {
    run,
    cmd: Array.from(nsfwEndpoints.keys()),
    type: 'nsfw',
    premium: true,
    restrict: true,
    location: 'plugins/tools/nsfw.js'
};