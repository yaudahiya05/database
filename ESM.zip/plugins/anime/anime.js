const waifuApiEndpoints = new Map([
    ['waifu', 'https://waifu.pics/api/sfw/waifu'],
    ['neko', 'https://waifu.pics/api/sfw/neko'],
    ['awoo', 'https://waifu.pics/api/sfw/awoo'],
    ['megumin', 'https://waifu.pics/api/sfw/megumin'],
    ['shinobu', 'https://waifu.pics/api/sfw/shinobu'],
    ['bully', 'https://waifu.pics/api/sfw/bully'],
    ['cuddle', 'https://waifu.pics/api/sfw/cuddle'],
    ['hug', 'https://waifu.pics/api/sfw/hug'],
    ['cry', 'https://waifu.pics/api/sfw/cry'],
    ['kiss', 'https://waifu.pics/api/sfw/kiss'],
    ['lick', 'https://waifu.pics/api/sfw/lick'],
    ['pat', 'https://waifu.pics/api/sfw/pat'],
    ['bonk', 'https://waifu.pics/api/sfw/bonk'],
    ['yeet', 'https://waifu.pics/api/sfw/yeet'],
    ['trap', 'https://api.waifu.pics/nsfw/trap'],
]);

const run = async (m, lulli, { func }) => {
    m.reply('✦ Sedang memproses, mohon tunggu...');

    try {
        const apiUrl = waifuApiEndpoints.get(m.command);
        if (!apiUrl) {
            return m.reply('✗ Command tidak valid atau endpoint tidak ditemukan.');
        }

        const result = await func.fetchJson(apiUrl);
        
        if (!result || !result.url) {
            return m.reply('✗ Gagal mengambil gambar dari API.');
        }

        let caption = '✓ Dasar Wibu!!';
        if (m.command === 'trap') {
            caption = '✗ Konten NSFW. Gunakan dengan bijak.';
        }

        await lulli.sendMessage(m.chat, {
            image: { url: result.url },
            caption: caption,
            mimetype: 'image/jpeg'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

    } catch (e) {
        console.error(`✗ Terjadi kesalahan pada ${m.command} (Anime/Waifu):`, e);
        await m.reply(`✗ Terjadi kesalahan saat mengambil gambar: ${e.message}`);
    }
};

export default {
    run,
    cmd: Array.from(waifuApiEndpoints.keys()),
    type: 'anime',
    premium: true,
    limit: 5,
    location: 'plugins/tools/anime.js'
};