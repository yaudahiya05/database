import axios from"axios";import*as cheerio from"cheerio";let resepmasakan=async p=>{try{var k="https://resepkoki.id/?s="+encodeURIComponent(p),u=(await axios.get(k)).data,c=cheerio.load(u)("div.masonry-grid > div:nth-child(1) > article > div > div.archive-item-media > a").attr("href");if(!c)return{status:!1,message:"✗ Resep tidak ditemukan!"};let a=(await axios.get(c)).data,t=cheerio.load(a),i=[],s=[],e=[],n=(t("div.single-recipe-ingredients-nutritions table tbody tr").each(function(){var a=t(this).find("td:nth-child(2) span.ingredient-name").text().trim(),e=t(this).find("td:nth-child(2) span.ingredient-amount").text().trim();a&&i.push(a),e&&s.push(e)}),t("div.single-steps table tbody tr td.single-step-description div p").each(function(){var a=t(this).text().trim();a&&e.push(a)}),t("h1.post-title.entry-title").text().trim()),r=t("li.single-meta-cooking-time span").text().trim(),d=t("li.single-meta-serves span").text().trim().split(": ")[1],l=t("li.single-meta-difficulty span").text().trim().split(": ")[1],m=t("div.single-main-media img").attr("src"),h="\n";for(let a=0;a<i.length;a++)h+=`✦ ${i[a]} ${s[a]||""}
`;let o="\n";for(let a=0;a<e.length;a++)o+=`✦ Langkah ${a+1}: ${e[a]}

`;var g={creator:"Fajar Ihsana",data:{judul:n,waktu_masak:r,hasil:d,tingkat_kesulitan:l,thumb:m,bahan:h.trim(),langkah_langkah:o.trim()}};return n?{status:!0,...g}:{status:!1,message:"✗ Resep tidak ditemukan!"}}catch(p){return console.error("✗ Error resepmasakan:",p.message),{status:!1,message:"✗ Terjadi kesalahan: "+p.message}}},run=async(a,e,{func:t,cfg:i})=>{if(!a.text)return a.reply("✗ "+t.example(a.cmd,"soto ayam"));e.sendReact(a.chat,"🕒",a.key);try{var s=await resepmasakan(a.text);if(!s.status)return a.reply(""+s.message);var{judul:n,waktu_masak:r,hasil:d,tingkat_kesulitan:l,bahan:m,langkah_langkah:h,thumb:o}=s.data,p=`✦ R E S E P - M A S A K A N

`+`✦ Judul              : *${n||"N/A"}*
`+`✦ Waktu Masak        : ${r||"N/A"}
`+`✦ Hasil Porsi        : ${d||"N/A"}
`+`✦ Tingkat Kesulitan  : ${l||"N/A"}

`+`✦ *Bahan-bahan:*
${m||"Tidak ada informasi bahan."}

`+`✦ *Langkah-langkah:*
`+(h||"Tidak ada informasi langkah-langkah.");await e.sendMessageModify(a.chat,p,a,{title:"RESEP "+a.text.toUpperCase(),body:i.header,thumbnail:o?await e.resize(o,300,175):void 0,largeThumb:!0,expiration:a.expiration}),e.sendReact(a.chat,"✅",a.key)}catch(t){console.error("✗ Terjadi kesalahan pada Resep Masakan:",t),e.sendReact(a.chat,"❌",a.key),await a.reply("✗ Terjadi kesalahan: "+t.message)}};export default{run:run,cmd:"resepmasakan",alias:"resep",use:"Nama masakan",type:"searching",desc:"Mencari resep masakan dari resepkoki.id.",premium:!0,limit:!0,location:"plugins/searching/resepmasakan"};export{run};