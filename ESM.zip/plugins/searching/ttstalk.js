import*as cheerio from"cheerio";import fetch from"node-fetch";let run=async(a,e,{func:t})=>{var i=a.text?a.text.trim():"";if(!i)return a.reply(t.example(a.cmd,"suryaskylark05"));e.sendReact(a.chat,"🕒",a.key);try{var r=await stalk(i.replace("@","").toLowerCase());if(404==r.status)throw r.message;var s=r.user.verified?"✅":"",o=r.user.privateAccount?"🔒":"",n=r.user.ttSeller?"🛒":"",u=`✧ *TIKTOK STALKER*

`,u=(u=(u=(u=(u=(u=(u=(u=(u=(u=(u=(u+=`⋄ *Username:* @${r.user.uniqueId||"Tidak ditemukan"} ${s}
`)+`⋄ *Nama Tampilan:* ${r.user.nickname||"Tidak ada"}
`)+`⋄ *Bio:* ${r.user.signature||"Tidak ada bio"}
`)+`⋄ *Link di Bio:* ${r.user.bioLink?r.user.bioLink.link:"Tidak tersedia"}
`)+`⋄ *Wilayah:* ${r.user.region||"Tidak diketahui"}
`)+`⋄ *Akun Dibuat:* ${new Date(1e3*r.user.createTime).toLocaleDateString("id-ID")}
`)+`⋄ *Followers:* ${r.stats.followerCount.toLocaleString()||"0"}
`)+`⋄ *Mengikuti:* ${r.stats.followingCount.toLocaleString()||"0"}
`)+`⋄ *Total Likes:* ${r.stats.heartCount.toLocaleString()||"0"}
`)+`⋄ *Video:* ${r.stats.videoCount.toLocaleString()||"0"}
`)+`⋄ *Privat:* ${r.user.privateAccount?"Ya":"Tidak"} ${o}
`)+(`⋄ *Seller:* ${r.user.ttSeller?"Ya":"Tidak"} `+n);await e.sendMessage(a.chat,{image:{url:r.user.avatarLarger},caption:u},{quoted:a,ephemeralExpiration:a.expiration})}catch(e){console.error("✗ Error TikTok Stalk:",e),await a.reply("✗ Terjadi kesalahan: "+(e.message||e))}};async function stalk(e){try{var a,t=await(await fetch("https://tiktok.com/@"+e,{headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36"}})).text(),i=cheerio.load(t)("#__UNIVERSAL_DATA_FOR_REHYDRATION__").text();return i?(a=JSON.parse(i).__DEFAULT_SCOPE__?.["webapp.user-detail"])&&0===a.statusCode?a.userInfo:{status:404,message:"User tidak ditemukan!"}:{status:404,message:"Data tidak ditemukan! Mungkin akun privat atau kena limit."}}catch(e){return{status:404,message:e.message}}}export default{run:run,cmd:"tiktokstalk",alias:"ttstalk",use:"username",type:"searching",desc:"Mencari informasi profil TikTok seseorang.",premium:!1,limit:3,location:"plugins/searching/ttstalk.js"};