import * as cheerio from "cheerio";
import fetch from "node-fetch";

const run = async (m, lulli, { func }) => {
    // Menggunakan m.text untuk mengambil input user
    let input = m.text ? m.text.trim() : "";
    
    if (!input) return m.reply(func.example(m.cmd, 'suryaskylark05'));
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        // Membersihkan username dari spasi atau simbol @
        const username = input.replace('@', '').toLowerCase();
        let res = await stalk(username);

        if (res.status == 404) throw res.message;

        let verifiedBadge = res.user.verified ? '✅' : '';
        let privateBadge = res.user.privateAccount ? '🔒' : '';
        let sellerBadge = res.user.ttSeller ? '🛒' : '';

        let text = `✧ *TIKTOK STALKER*\n\n`
        text += `⋄ *Username:* @${res.user.uniqueId || 'Tidak ditemukan'} ${verifiedBadge}\n`
        text += `⋄ *Nama Tampilan:* ${res.user.nickname || 'Tidak ada'}\n`
        text += `⋄ *Bio:* ${res.user.signature || 'Tidak ada bio'}\n`
        text += `⋄ *Link di Bio:* ${res.user.bioLink ? res.user.bioLink.link : 'Tidak tersedia'}\n`
        text += `⋄ *Wilayah:* ${res.user.region || 'Tidak diketahui'}\n`
        text += `⋄ *Akun Dibuat:* ${new Date(res.user.createTime * 1000).toLocaleDateString('id-ID')}\n`
        text += `⋄ *Followers:* ${res.stats.followerCount.toLocaleString() || '0'}\n`
        text += `⋄ *Mengikuti:* ${res.stats.followingCount.toLocaleString() || '0'}\n`
        text += `⋄ *Total Likes:* ${res.stats.heartCount.toLocaleString() || '0'}\n`
        text += `⋄ *Video:* ${res.stats.videoCount.toLocaleString() || '0'}\n`
        text += `⋄ *Privat:* ${res.user.privateAccount ? 'Ya' : 'Tidak'} ${privateBadge}\n`
        text += `⋄ *Seller:* ${res.user.ttSeller ? 'Ya' : 'Tidak'} ${sellerBadge}`

        await lulli.sendMessage(m.chat, {
            image: { url: res.user.avatarLarger },
            caption: text
        }, { 
            quoted: m,
            ephemeralExpiration: m.expiration 
        });

    } catch (error) {
        console.error('✗ Error TikTok Stalk:', error);
        await m.reply(`✗ Terjadi kesalahan: ${error.message || error}`);
    }
};

// Fungsi Scraper Internal
async function stalk(user) {
    try {
        const url = await fetch(`https://tiktok.com/@${user}`, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
            }
        });
        const html = await url.text();
        const $ = cheerio.load(html);
        const data = $('#__UNIVERSAL_DATA_FOR_REHYDRATION__').text();
        
        if (!data) return { status: 404, message: 'Data tidak ditemukan! Mungkin akun privat atau kena limit.' };
        
        const result = JSON.parse(data);
        const userDetail = result['__DEFAULT_SCOPE__']?.['webapp.user-detail'];
        
        if (!userDetail || userDetail.statusCode !== 0) {
            return { status: 404, message: 'User tidak ditemukan!' };
        }
        
        return userDetail['userInfo'];
    } catch (err) {
        return { status: 404, message: err.message };
    }
}

export default {
    run,
    cmd: 'tiktokstalk',
    alias: 'ttstalk',
    use: 'username',
    type: 'searching',
    desc: 'Mencari informasi profil TikTok seseorang.',
    premium: false,
    limit: 3,
    location: 'plugins/searching/ttstalk.js'
};
