import fetch from"node-fetch";let formatItems=(a,t)=>{if(!t?.length)return"";let e=`
✦ ${a}
`;for(var r of t)e+=`✦ ${r.name} : ${r.quantity}
`;return e},formatWeather=a=>a?`
✦ ☀️ *Cuaca Saat Ini*
✦ Tipe : ${a.type}
✦ Aktif : `+(a.active?"[ ✓ ]":"[ ✗ ]"):"",formatWeatherHistory=a=>{if(!a?.length)return"";let t=`
✦ 🌤️ *Riwayat Cuaca*
`;for(var e of a)t+=`✦ ${e.type} (${e.active?"[ ✓ ]":"[ ✗ ]"})
`;return t},run=async(a,t)=>{t.sendReact(a.chat,"🕒",a.key);try{var e=await fetch("https://gagapi.onrender.com/alldata");if(!e.ok)throw new Error(`✗ Gagal mengambil data Grow a Garden: ${e.status} `+e.statusText);var r=await e.json(),o="✦ S T O K - G R O W - A - G A R D E N\n",o=(o=(o=(o=(o=(o=(o=(o+=`
✦ Terakhir Update : ${new Date(r.lastGlobalUpdate).toLocaleString("id-ID")}
`)+formatItems("🌱 *Stok Bibit*",r.seeds))+formatItems("⚙️ *Stok Perlengkapan*",r.gear))+formatItems("🥚 *Stok Telur*",r.eggs))+formatItems("*Stok Kosmetik*",r.cosmetics))+formatItems("*Stok Madu*",r.honey))+formatWeather(r.weather))+formatWeatherHistory(r.weatherHistory);await a.reply(o.trim()),t.sendReact(a.chat,"✅",a.key)}catch(e){console.error("✗ Terjadi kesalahan pada Grow a Garden Stalker:",e),t.sendReact(a.chat,"❌",a.key),await a.reply("✗ Gagal mengambil data Grow a Garden: "+e.message)}};export default{run:run,cmd:"growagarden",alias:"stokgag",type:"searching",desc:"Untuk melihat stok Grow a Garden.",premium:!0,location:"plugins/searching/growagarden"};export{run};