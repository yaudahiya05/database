async function run(a,e,{func:n}){if(!a.text)return a.reply(n.example(a.cmd,"nama mahasiswa"));if(e.sendReact(a.chat,"🕒",a.key),e=encodeURIComponent(a.text),!(n=await n.fetchJson("https://api.ryzendesu.vip/api/search/mahasiswa?query="+e))||n.error||n.length<1)return a.reply("✗ Data tidak ditemukan.");let s="✦ DATA MAHASISWA\n";n.forEach((a,e)=>{var{id:a,nama:n,nim:i,nama_pt:t,nama_prodi:r}=a;s+=`

${e+1}. ${a}
- Nama: ${n}
- Nim: ${i}
- PT: ${t}
- Prodi: `+r}),await a.reply(s)}export default{run:run,cmd:"mahasiswa",use:"nama mahasiswa",type:"searching",desc:"untuk mencari data mahasiswa",premium:!0,location:"plugins/searching/mahasiswa.js"};