import axios from"axios";import*as cheerio from"cheerio";let checkGmail=async l=>{try{let e=l.split("@")[0],a=(await axios.post("https://gmail-osint.activetk.jp/",new URLSearchParams({q:e,domain:"gmail.com"}),{headers:{"Content-Type":"application/x-www-form-urlencoded","User-Agent":"Postify/1.0.0"}})).data,r=cheerio.load(a)("pre").text(),t=(e,a="Tidak ada",t=!1)=>(e=(e=r.match(e))&&void 0!==e[1]?e[1].trim():a,t&&"Not found."===e?"Tidak ada":e);return{status:200,result:{email:l,photoProfile:t(/Custom profile picture !\s*=>\s*(.*)/),lastEditProfile:t(/Last profile edit : (.*)/),googleID:t(/Gaia ID : (.*)/),userTypes:t(/User types : (.*)/),googleChat:{entityType:t(/Entity Type : (.*)/),customerID:t(/Customer ID : (.*)/,"Tidak ada",!0)},googlePlus:{enterpriseUser:t(/Entreprise User : (.*)/)},mapsData:{profilePage:t(/Profile page : (.*)/)},ipAddress:r.includes("Your IP has been blocked by Google")?"Di blokir oleh Google":"Aman",calendar:r.includes("No public Google Calendar")?"Tidak ada":"Ada"}}}catch(l){return console.error("✗ Error checkGmail:",l.message),{status:404,msg:"✗ Email tidak ditemukan atau terjadi kesalahan saat pengecekan!"}}},run=async(e,a,{func:t})=>{if(!e.args[0])return e.reply("✗ "+t.example(e.cmd,"example@gmail.com"));if(!(t=e.args[0].trim()).endsWith("@gmail.com"))return e.reply("✗ Masukkan alamat email Gmail yang valid!");a.sendReact(e.chat,"🕒",e.key);try{var r=await checkGmail(t);if(404===r.status)return e.reply(""+r.msg);var l=`✦ G M A I L - C H E C K E R

`,l=(l+=`✦ Email         : *${r.result.email}*
`)+`✦ Foto Profil   : ${r.result.photoProfile}
`+`✦ Terakhir Edit : ${r.result.lastEditProfile}
`+`✦ Google ID     : ${r.result.googleID}
`+`✦ Tipe Pengguna : ${r.result.userTypes}
`+`✦ Entity Type   : ${r.result.googleChat.entityType}
`+`✦ Customer ID   : ${r.result.googleChat.customerID}
`+`✦ Pengguna Perusahaan: ${r.result.googlePlus.enterpriseUser}
`+`✦ Halaman Profil: ${r.result.mapsData.profilePage}
`+`✦ Status IP     : ${r.result.ipAddress}
`+"✦ Kalender      : "+r.result.calendar;a.reply(e.chat,l,e),a.sendReact(e.chat,"✅",e.key)}catch(t){console.error("✗ Terjadi kesalahan pada Gmail Stalk:",t),a.sendReact(e.chat,"❌",e.key),await e.reply("✗ Terjadi kesalahan: "+t.message)}};export default{run:run,cmd:"gmailstalk",alias:[],use:"email@gmail.com",type:"searching",limit:!0,location:"plugins/searching/gmailstalk"};export{run};