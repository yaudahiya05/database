import fetch from"node-fetch";let run=async(e,t,{func:r})=>{if(!e.text)return e.reply("✗ "+r.example(e.cmd,"yin"));var i=e.text.trim();t.sendReact(e.chat,"🕒",e.key);try{var n=await fetch("https://api.yanzbotz.my.id/api/cari/hero?query="+encodeURIComponent(i));if(!n.ok)throw new Error(`✗ Gagal mengambil data hero: ${n.status} `+n.statusText);var s=await n.json();if(200!==s.status)return e.reply("✗ "+(s.message||"Maaf, terjadi kesalahan saat mengambil data API."));if(!s.result)return e.reply("✗ Data hero tidak ditemukan.");var o,l=s.result,c=l.story_info_list||{},p=l.gameplay_info||{};let a=`✦ INFO HERO MOBILE LEGENDS

`;for(o in a=(a=(a=(a=(a=(a=(a+=`✦ *Informasi Umum:*
`)+`✦ Nama           : *${l.name||"-"}*
`)+`✦ Rilis          : ${l.release||"-"}
`)+`✦ Role           : ${l.role||"-"}
`)+`✦ Spesialisasi   : ${l.specialty||"-"}
`)+`✦ Lane           : ${l.lane||"-"}
`)+`✦ Harga          : ${l.price||"-"}

`+`✦ *Informasi Gameplay:*
`,p)p.hasOwnProperty(o)&&(a+=`✦ ${r.ucword(o.replace(/_/g," "))} : ${p[o]}
`);a=a+"\n"+`✦ *Informasi Cerita (Story):*
`,c.skill_resource&&(a+=`✦ Sumber Skill     : ${c.skill_resource}
`),c.damage_type&&(a+=`✦ Tipe Kerusakan   : ${c.damage_type}
`),c.basic_attack_type&&(a+=`✦ Tipe Serangan Dasar: ${c.basic_attack_type}
`),c.durability&&(a+=`✦ Daya Tahan       : ${c.durability}
`),c.offense&&(a+=`✦ Serangan         : ${c.offense}
`),c.control_effects&&(a+=`✦ Efek Kontrol     : ${c.control_effects}
`),c.difficulty&&(a+=`✦ Tingkat Kesulitan: ${c.difficulty}
`),c.alias&&(a+=`✦ Alias            : ${c.alias}
`),c.born&&(a+=`✦ Lahir            : ${c.born}
`),c.gender&&(a+=`✦ Jenis Kelamin    : ${c.gender}
`),c.species&&(a+=`✦ Spesies          : ${c.species}
`),c.weapons&&(a+=`✦ Senjata          : ${c.weapons}
`),l.desc&&(a+=`✦ Deskripsi        : ${l.desc}
`),await t.sendMedia(e.chat,l.hero_img,e,{caption:a.trim(),expiration:e.expiration,mimetype:"image/jpeg"}),t.sendReact(e.chat,"✅",e.key)}catch(a){console.error("✗ Terjadi kesalahan pada Hero ML:",a),t.sendReact(e.chat,"❌",e.key),await e.reply(`✗ Data hero *${i}* tidak ditemukan atau terjadi kesalahan: `+a.message)}};export default{run:run,cmd:"heroml",use:"Nama hero",type:"searching",limit:!0,location:"plugins/searching/heroml"};export{run};