import axios from"axios";import*as cheerio from"cheerio";let mpl={api:{base:"https://id-mpl.com",endpoint:{matchDetail:"/match-detail",schedule:"/schedule",teams:"/teams",statistics:"/statistics",news:"/news"}},headers:{"User-Agent":"Postify/1.0.0",Accept:"text/html","Accept-Language":"id-ID,id;q=0.9",Origin:"https://id-mpl.com",Referer:"https://id-mpl.com/schedule"},teams:{ALL:{value:"all",cover:null},AE:{value:131,cover:"https://wsrv.nl/?url=https://ik.imagekit.io/nloe8dhf7w/mplid/s14/teams/ae-64.png"},BTR:{value:132,cover:"https://wsrv.nl/?url=https://ik.imagekit.io/nloe8dhf7w/mplid/s14/teams/btr-64.png"},DEWA:{value:133,cover:"https://wsrv.nl/?url=https://ik.imagekit.io/nloe8dhf7w/mplid/s14/teams/dewa-64.png"},EVOS:{value:134,cover:"https://wsrv.nl/?url=https://ik.imagekit.io/nloe8dhf7w/mplid/s14/teams/evos-64.png"},GEEK:{value:135,cover:"https://wsrv.nl/?url=https://ik.imagekit.io/nloe8dhf7w/mplid/s14/teams/geek-64.png"},NAVI:{value:139,cover:"https://cdn.id-mpl.com/season15/NAVI-2.png"},ONIC:{value:138,cover:"https://cdn.id-mpl.com/data/teams/onic-b-64.png"},RRQ:{value:136,cover:"https://wsrv.nl/?url=https://ik.imagekit.io/nloe8dhf7w/mplid/s14/teams/rrq-64.png"},TLID:{value:137,cover:"https://wsrv.nl/?url=https://ik.imagekit.io/nloe8dhf7w/mplid/s14/teams/tlid-64.png"}},isValid:(e,t="string")=>{var a;return null!=e&&!!(a={string:()=>"string"==typeof e&&0<e.trim().length,number:()=>!isNaN(e)&&0<e,team:()=>"string"==typeof e&&mpl.teams[e.toUpperCase()],week:()=>!isNaN(e)&&1<=e&&e<=9})[t]&&a[t]()},matchId:e=>{var t,a;return e&&(t=e.attribs.onclick?.match(/\d+/)?.[0],a=e.attribs["data-match-id"],e=e.attribs.href?.match(/\d+/)?.[0],t||a||e)?parseInt(t||a||e):null},getSchedule:async(a=null)=>{try{if(a&&!mpl.isValid(a,"week"))return{success:!1,code:400,error:"✗ week tidak valid, pilih antara 1-9"};var s=(await axios.get(""+mpl.api.base+mpl.api.endpoint.schedule,{headers:mpl.headers})).data;if(!s)return{success:!1,code:404,error:"✗ Data Schedule tidak ditemukan"};let r=cheerio.load(s),e,t=r(".tab-linker").map((e,t)=>({weekNumber:parseInt(r(t).attr("rel")),text:r(t).text().trim(),isActive:r(t).hasClass("active")})).get();return a?(e=r(`#t-week-${a} .match.position-relative`).map((e,t)=>{var a=mpl.matchId(r(t).find(".button-watch.detail")[0]);return a?{matchId:a,date:r(t).closest(".match.date").text().trim()||"TBA",team1:{name:r(t).find(".team.team1 .name").text().trim()||"TBA",logo:r(t).find(".team.team1 .logo img").attr("src")||null,score:r(t).find(".team.team1 + .score").text().trim()||"0"},team2:{name:r(t).find(".team.team2 .name").text().trim()||"TBA",logo:r(t).find(".team.team2 .logo img").attr("src")||null,score:r(t).find(".team.team2").prev(".score").text().trim()||"0"},time:r(t).find(".time .pt-1").text().trim()||"TBA",status:{isLive:!!r(t).find(".button-watch.live").length,hasReplay:!!r(t).find(".button-watch.replay").length,link:r(t).find(".button-watch.replay").attr("href")||null},calendar:{google:r(t).find('.calendar-url a[href*="calendar.google.com"]').attr("href")||null,apple:r(t).find('.calendar-url a[href*="data:text/calendar"]').attr("href")||null}}:null}).get().filter(Boolean)).length?{success:!0,code:200,result:{weeks:t,matches:e}}:{success:!1,code:404,error:`✗ Match ID pada week ${a} tidak valid`}:{success:!0,code:200,result:{weeks:t,matches:null}}}catch(a){return{success:!1,code:a.response?.status||500,error:"✗ "+a.message}}},getMatchDetail:async e=>{try{var t,a;return mpl.isValid(e,"number")?(t=(await axios.get(""+mpl.api.base+mpl.api.endpoint.matchDetail+"/"+e,{headers:mpl.headers})).data)?{success:!0,code:200,result:{matchId:e,teams:{team1:{name:(a=cheerio.load(t))(".match-team:first-child .name").text().trim()||"TBA",logo:a(".match-team:first-child .logo img").attr("src")||null,score:a(".team.team1 + .score").text().trim()||"0"},team2:{name:a(".match-team:last-child .name").text().trim()||"TBA",logo:a(".match-team:last-child .logo img").attr("src")||null,score:a(".team.team2").prev(".score").text().trim()||"0"}},matchInfo:{date:a(".match.date").text().trim()||"TBA",time:a(".match-vs .time").text().trim()||"TBA",status:{isLive:!!a(".button-watch.live").length,hasReplay:!!a(".button-watch.replay").length,link:a(".button-watch.replay").attr("href")||null},calendar:{google:a('.calendar-url a[href*="calendar.google.com"]').attr("href")||null,apple:a('.calendar-url a[href*="data:text/calendar"]').attr("href")||null}}}}:{success:!1,code:404,error:"✗ Data tidak ditemukan"}:{success:!1,code:400,error:"✗ Match ID invalid"}}catch(e){return{success:!1,code:e.response?.status||500,result:{error:"✗ "+e.message}}}},getTeam:async a=>{try{if(!mpl.isValid(a,"team"))return{success:!1,code:400,error:"✗ team tidak valid"};var e=await mpl.getSchedule();if(!e.success)return e;var r=[];for(let t of e.result.weeks){var s=await mpl.getSchedule(t.weekNumber);s.success&&s.result.matches&&r.push(...s.result.matches.filter(e=>e.team1.name===a||e.team2.name===a).map(e=>({...e,week:t.weekNumber})))}return r.length?{success:!0,code:200,result:r}:{success:!1,code:404,error:`✗ ${a} belum ada matchnya`}}catch(e){return{success:!1,code:e.response?.status||500,error:"✗ "+e.message}}},getAllMid:async()=>{try{var e=await mpl.getSchedule();if(!e.success)return e;var a=[];for(let t of e.result.weeks){var r=await mpl.getSchedule(t.weekNumber);r.success&&r.result.matches&&a.push(...r.result.matches.filter(e=>e?.matchId).map(e=>({matchId:e.matchId,date:e.date,time:e.time,teams:e.team1.name+" vs "+e.team2.name,week:t.weekNumber,status:e.status})))}return a.length?{success:!0,code:200,result:a}:{success:!1,code:404,result:{error:"✗ Match ID tidak ditemukan"}}}catch(e){return{success:!1,code:e.response?.status||500,result:{error:"✗ "+e.message}}}}},run=async(a,r,{func:s})=>{switch(a.command){case"mpl-getteam":{if(!a.text)return a.reply("✗ "+s.example(a.cmd,"RRQ"));var t;if(!(u=Object.keys(mpl.teams)).includes(a.args[0].toUpperCase()))return a.reply(`✗ team tidak tersedia!
✦ *Daftar Tim:*
- `+u.join("\n- "));if(r.sendReact(a.chat,"🕒",a.key),!(u=await mpl.getTeam(a.args[0].toUpperCase())).success)return a.reply("✗ Something went wrong: "+u.error);let e=`✦ *TEAM ${a.args[0].toUpperCase()}*
`;for(t of u.result){var l=t.team1,i=t.team2,m=t.status;e+=`
✦ *Match ID:* ${t.matchId}
`+`✦ Date: ${t.date}
`+`✦ Time: ${t.time}
`+`✦ Week: ${t.week}
`+`✦ *TEAM 1*:
`+`✦ • Name : ${l?.name||"-"}
`+`✦ • Score : ${l?.score||"-"}
`+`✦ *TEAM 2*:
`+`✦ • Name : ${i?.name||"-"}
`+`✦ • Score : ${i?.score||"-"}
`+`✦ *STATUS*:
`+`✦ • isLive : ${m.isLive?"Yes ✓":"No ✗"}
`+`✦ • hasReplay : ${m.hasReplay?"Yes ✓":"No ✗"}
`+("✦ • Link : "+(m.link||"-")).trim()}a.reply(e),r.sendReact(a.chat,"✅",a.key)}break;case"mpl-getmatchdetail":if(!a.text)return a.reply("✗ "+s.example(a.cmd,"1234"));if(isNaN(a.args[0]))return a.reply("✗ Match ID harus berupa angka!");if(r.sendReact(a.chat,"🕒",a.key),!(u=await mpl.getMatchDetail(parseInt(a.args[0]))).success)return a.reply("✗ Something went wrong: "+u.error);var c=(u=u.result).teams.team1,n=u.teams.team2,o=(k=u.matchInfo).status,u=`✦ *MATCH DETAIL*
`+`
✦ *Match ID:* ${u.matchId}
`+`
✦ *TEAM 1*:
`+`✦ • Name : ${c?.name||"-"}
`+`✦ • Logo : ${c?.logo||"-"}
`+`✦ • Score : ${c?.score||"-"}
`+`
✦ *TEAM 2*:
`+`✦ • Name : ${n?.name||"-"}
`+`✦ • Logo : ${n?.logo||"-"}
`+`✦ • Score : ${n?.score||"-"}
`+`
✦ *MATCH INFO*:
`+`✦ • Date: ${k.date}
`+`✦ • Time: ${k.time}
`+`✦ • isLive : ${o.isLive?"Yes ✓":"No ✗"}
`+`✦ • hasReplay : ${o.hasReplay?"Yes ✓":"No ✗"}
`+("✦ • Link : "+(o.link||"-")).trim();a.reply(u),r.sendReact(a.chat,"✅",a.key);break;case"mpl-getallmid":{var d;if(r.sendReact(a.chat,"🕒",a.key),!(c=await mpl.getAllMid()).success)return a.reply("✗ Something went wrong: "+(c.result.error||c.error));let e="✦ *GET ALL MATCH ID DETAIL*\n";for(d of c.result){var h=d.status;e+=`
✦ Match ID: ${d.matchId}
`+`✦ • Date: ${d.date}
`+`✦ • Time: ${d.time}
`+`✦ • Week: ${d.week}
`+`✦ • Teams: ${d.teams}
`+`✦ • isLive : ${h.isLive?"Yes ✓":"No ✗"}
`+`✦ • hasReplay : ${h.hasReplay?"Yes ✓":"No ✗"}
`+"✦ • Link : "+(h.link||"-")}a.reply(e),r.sendReact(a.chat,"✅",a.key)}break;case"mpl-getweek":{if(!a.text)return a.reply("✗ "+s.example(a.cmd,"1"));if(isNaN(a.args[0]))return a.reply("✗ Week harus berupa angka!");if(r.sendReact(a.chat,"🕒",a.key),!(n=await mpl.getSchedule(parseInt(a.args[0]))).success)return a.reply("✗ Something went wrong: "+n.error);var p,g,{weeks:k,matches:o}=n.result;let e="✦ *WEEKS DETAIL*\n";for(p of k)e=(e+=`
✦ - Week: ${p.text}
`)+"✦ isActive: "+(p.isActive?"Yes ✓":"No ✗");e+="\n\n✦ *MATCHES DETAIL*";for(g of o){var f=g.team1,v=g.team2,w=g.status;e+=`

✦ *Match ID:* ${g.matchId}
`+`✦ Date: ${g.date}
`+`✦ Time: ${g.time}
`+`✦ Week: ${g.week}
`+`✦ *TEAM 1*:
`+`✦ • Name : ${f?.name||"-"}
`+`✦ • Score : ${f?.score||"-"}
`+`✦ *TEAM 2*:
`+`✦ • Name : ${v?.name||"-"}
`+`✦ • Score : ${v?.score||"-"}
`+`✦ *STATUS*:
`+`✦ • isLive : ${w.isLive?"Yes ✓":"No ✗"}
`+`✦ • hasReplay : ${w.hasReplay?"Yes ✓":"No ✗"}
`+"✦ • Link : "+(w.link||"-")}a.reply(e),r.sendReact(a.chat,"✅",a.key)}break;case"mpl-all":{var y,$;r.sendReact(a.chat,"🕒",a.key);let e="✦ *MPL TEAMS:*\n";for(y of Object.keys(mpl.teams).filter(e=>"ALL"!==e)){var A=mpl.teams[y];e+=`✦ - ${y}: ${A.value} ${A.cover?`(Logo: ${A.cover})`:""}
`}if(await a.reply(e.trim()),await s.delay(2e3),!(u=await mpl.getAllMid()).success)return a.reply("✗ Something went wrong while fetching all matches: "+(u.result.error||u.error));let t="\n✦ *ALL MPL MATCHES:*\n";for($ of u.result){var T=$.status;t+=`
✦ Match ID: ${$.matchId}
`+`✦ • Date: ${$.date}
`+`✦ • Time: ${$.time}
`+`✦ • Week: ${$.week}
`+`✦ • Teams: ${$.teams}
`+`✦ • isLive : ${T.isLive?"Yes ✓":"No ✗"}
`+`✦ • hasReplay : ${T.hasReplay?"Yes ✓":"No ✗"}
`+"✦ • Link : "+(T.link||"-")}await a.reply(t.trim()),r.sendReact(a.chat,"✅",a.key)}}};export default{run:run,cmd:["mpl-getteam","mpl-getallmid","mpl-getmatchdetail","mpl-getweek","mpl-all"],alias:[],use:"parameter",type:"searching",desc:"Informasi seputar MPL (Mobile Legends Professional League).",premium:!0,location:"plugins/searching/mpl"};export{run};