import axios from"axios";import*as cheerio from"cheerio";import FormData from"form-data";async function ffStalk(F){try{let e=new FormData,a=(e.append("uid",F),(await axios.post("https://tools.freefireinfo.in/profileinfo.php?success=1",e,{headers:{"content-type":"application/x-www-form-urlencoded",origin:"https://tools.freefireinfo.in",referer:"https://tools.freefireinfo.in/profileinfo.php?success=1","user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36",cookie:"_ga=GA1.1.1069461514.1740728304; __gads=ID=fa4de8c6be61d818:T=1740728303:RT=1740728303:S=ALNI_MYhU5TQnoVCO8ZG1O95QdJQc1-u1Q; __gpi=UID=0000104decca5eb5:T=1740728303:RT=1740728303:S=ALNI_MaVhADwQqMyGY78ZADfPLLbbw8zfQ; __eoi=ID=f87957be98f6348b:T=1740728303:RT=1740728303:S=AA-Afjb5ISbOLmlxgjjGBUWT3RO3; PHPSESSID=d9vet6ol1uj3frjs359to1i56v; _ga_JLWHS31Q03=GS1.1.1740728303.1.1.1740728474.0.0.0; _ga_71MLQQ24RE=GS1.1.1740728303.1.1.1740728474.57.0.1524185982; FCNEC=%5B%5B%22AKsRol9jtdxZ87hML5ighFLFnz7cP30Fki_Fu8JOnfi-SOz3P6QL33-sNGahy6Hq5X9moA6OdNMIcgFtvZZJnrPzHecI_XbfIDiQo9Nq-I1Y_PRXKDUufD0nNWLvDRQBJcdvu_bOqn2X06Njaz3k4Ml-NvsRVw21ew%3D%3D%22%5D%5D"}})).data),t=cheerio.load(a),i=t("div.result");if(i.text().includes("Invalid User ID"))throw new Error("✗ ID Free Fire tidak valid atau tidak ditemukan.");let r=i.html().split("<br>"),o=(e,a)=>(e=e.match(new RegExp(a+":\\s*(.*)")))?e[1].trim():"N/A",n=o(r[0],"Name"),s=o(r[1],"Bio"),l=o(r[2],"Like"),p=o(r[3],"Level"),d=o(r[4],"EXP"),m=o(r[5],"Region"),f=o(r[6],"Honor Score"),c=o(r[7],"BR Rank"),u=o(r[8],"BR Rank Point"),h=o(r[9],"CS Rank Point"),k=o(r[10],"Account Created"),g=o(r[11],"Last Login"),P=o(r[12],"Prefer Mode"),I=o(r[13],"Language"),R=o(r[14],"Booyah Pass Premium"),L=o(r[15],"Booyah Pass Level"),b=o(r[16],"Pet Name"),S=o(r[17],"Pet Level"),v=o(r[18],"Pet EXP"),y=o(r[19],"Star Marked"),D=o(r[20],"Selected"),$=o(r[21],"Guild"),x=[];return t(".equipped-items").find(".equipped-item").each((e,a)=>{var i=t(a).find("p").text().trim(),a=t(a).find("img").attr("src");x.push({name:i,img:a})}),{name:n,bio:s,like:l,level:p,exp:d,region:m,honorScore:f,brRank:c,brRankPoint:u,csRankPoint:h,accountCreated:k,lastLogin:g,preferMode:P,language:I,booyahPassPremium:R,booyahPassLevel:L,petInformation:{name:b,level:S,exp:v,starMarked:y,selected:D},guild:$,equippedItems:x}}catch(F){throw console.error("✗ Error ffStalk:",F.message),F}}let run=async(a,i,{func:e})=>{if(!a.text)return a.reply("✗ "+e.example(a.cmd,"12345678"));if(e=Number(a.args[0]),isNaN(e)||e<=0)return a.reply("✗ ID harus berupa angka positif.");i.sendReact(a.chat,"🕒",a.key);try{var t=await ffStalk(e),r=t.equippedItems&&0<t.equippedItems.length?t.equippedItems.map(e=>"✦ • "+e.name).join("\n"):"✦ _Tidak ada item yang terpasang._",o="✦ INFO AKUN FREE FIRE\n\n✦ *👤 Informasi Profil:*\n"+`✦ Nama         : *${t.name}*
`+`✦ Bio          : ${t.bio}
`+`✦ Suka         : ${t.like}
`+`✦ Level        : ${t.level}
`+`✦ EXP          : ${t.exp}
`+`✦ Wilayah      : ${t.region}
`+`✦ Skor Kehormatan: ${t.honorScore}
`+`✦ Peringkat BR : ${t.brRank}
`+`✦ Poin BR      : ${t.brRankPoint}
`+`✦ Poin CS      : ${t.csRankPoint}
`+`✦ Akun Dibuat  : ${t.accountCreated}
`+`✦ Login Terakhir: ${t.lastLogin}
`+`✦ Mode Favorit : ${t.preferMode}
`+`✦ Bahasa       : ${t.language}

`+`✦ *🎖️ Booyah Pass:*
`+`✦ Premium      : ${t.booyahPassPremium}
`+`✦ Level        : ${t.booyahPassLevel}

`+`✦ *🐾 Informasi Pet:*
`+`✦ Nama Pet     : ${t.petInformation.name}
`+`✦ Level Pet    : ${t.petInformation.level}
`+`✦ EXP Pet      : ${t.petInformation.exp}
`+`✦ Tanda Bintang: ${t.petInformation.starMarked}
`+`✦ Dipilih      : ${t.petInformation.selected}

`+`✦ *🎮 Item Terpasang:*
${r}

`+"✦ *Guild*: "+t.guild;await i.sendMessage(a.chat,{text:o},{quoted:a,ephemeralExpiration:a.expiration}),i.sendReact(a.chat,"✅",a.key)}catch(e){console.error("✗ Terjadi kesalahan pada FF Stalk:",e),i.sendReact(a.chat,"❌",a.key),await a.reply(`✗ Terjadi kesalahan saat mencari ID Free Fire: ${e.message}. Pastikan ID yang dimasukkan benar.`)}};export default{run:run,cmd:"ffstalk",alias:"stalkff",use:"ID Free Fire",type:"searching",limit:!0,location:"plugins/searching/ffstalk"};export{run};