let run=async(a,e,{users:r})=>{e.sendReact(a.chat,"🕒",a.key);try{var n=r.anak||0,s=r.sperma||0,t=`✦ *INFORMASI PENGGUNA*

`,t=(t+=`~ Pengguna: *${r.name.toUpperCase()}*

`)+`~ Total Anak: ${n}
`+"~ Total Sperma: "+s;await a.reply(t),e.sendReact(a.chat,"✅",a.key)}catch(r){console.error("✗ Terjadi kesalahan pada Informasi Anak/Sperma:",r),e.sendReact(a.chat,"❌",a.key),await a.reply("✗ Terjadi kesalahan: "+r.message)}};export default{run:run,cmd:"anak",alias:"sperma",type:"user",location:"plugins/user/anak.js"};