import { format as _format } from 'util'

const run = async (m, lulli, { cfg, func }) => {
  global.db = global.db || { users: {} }
  const database = global.db.users

  // --- Utility Functions ---
  const cleanJid = (input = '') => String(input).replace(/\s+/g, '').replace(/([@+-])/g, '')
  
  const formatNumber = (num) => Number(num).toLocaleString('id-ID') // Format ribuan standar Indonesia

  const getUsername = (jid) => jid.split('@')[0]

  const getPartnerJid = () => {
    let input = cleanJid(m.text)
    if (!input && m.mentionedJid?.length) return m.mentionedJid[0]
    if (!input && m.quoted?.sender) return m.quoted.sender
    if (!input) return ''
    
    return input.includes('@') ? input : input + '@s.whatsapp.net'
  }

  const initializeUser = (jid) => {
    if (!jid) return
    if (!database[jid]) {
      database[jid] = { exp: 0, partnerJid: '' }
    } else {
      database[jid].partnerJid = database[jid].partnerJid || ''
      database[jid].exp = database[jid].exp || 0
    }
  }

  const sendMessage = (content, mentions = []) => lulli.sendMessage(m.chat, { text: content, mentions: mentions }, { quoted: m, ephemeralExpiration: m.expiration })

  // --- Initialization ---
  const partnerJid = getPartnerJid()
  initializeUser(m.sender)
  if (partnerJid) initializeUser(partnerJid)

  const user = database[m.sender]

  switch (m.command) {
    case 'bersahabat': {
      if (!partnerJid) return sendMessage(`Siapa yang ingin kamu ajak berteman? Tag atau reply orangnya.`)
      if (partnerJid === m.sender) return sendMessage(`Kamu tidak bisa bersahabat dengan dirimu sendiri. 🗿`)

      const partner = database[partnerJid]

      // 1. Cek jika user sudah punya sahabat resmi
      if (user.partnerJid) {
        const currentPartner = database[user.partnerJid]
        if (currentPartner && currentPartner.partnerJid === m.sender) {
          const fine = Math.ceil(user.exp * 0.1) // Denda 10%
          user.exp -= fine
          return sendMessage(
            `Kamu sudah bersahabat dengan @${getUsername(user.partnerJid)}.\nPutus dulu jika ingin mencari sahabat baru.\n\n*Denda Penghianatan:* -${formatNumber(fine)} EXP`,
            [user.partnerJid]
          )
        }
      }

      // 2. Cek jika target sudah punya sahabat resmi dengan orang lain
      if (partner.partnerJid) {
        const partnersCurrentFriend = database[partner.partnerJid]
        if (partnersCurrentFriend && partnersCurrentFriend.partnerJid === partnerJid) {
          return sendMessage(`@${getUsername(partnerJid)} sudah memiliki sahabat. Jangan jadi orang ketiga!`, [partnerJid])
        }
      }

      // 3. Logika "Match" (Target ternyata sudah mengajak user sebelumnya)
      if (partner.partnerJid === m.sender) {
        user.partnerJid = partnerJid
        return sendMessage(`🎉 Selamat! Kamu dan @${getUsername(partnerJid)} sekarang resmi menjadi sahabat!`, [partnerJid])
      }

      // 4. Kirim Permintaan
      user.partnerJid = partnerJid
      return sendMessage(
        `Kamu mengajak @${getUsername(partnerJid)} bersahabat.\n\nTunggu dia menerima ajakanmu atau ketik *${m.prefix}terimasahabat @${getUsername(m.sender)}*`,
        [partnerJid, m.sender]
      )
    }

    case 'terimasahabat': {
      if (!partnerJid) return sendMessage(`Tag sahabat yang ingin kamu terima.`)
      if (database[partnerJid]?.partnerJid !== m.sender) {
        return sendMessage(`@${getUsername(partnerJid)} tidak sedang mengajakmu bersahabat.`, [partnerJid])
      }

      user.partnerJid = partnerJid
      return sendMessage(`🥳 Sekarang kamu dan @${getUsername(partnerJid)} resmi bersahabat!`, [partnerJid, m.sender])
    }

    case 'tolaksahabat': {
      if (!partnerJid) return sendMessage(`Tag orang yang ingin kamu tolak.`)
      if (database[partnerJid]?.partnerJid !== m.sender) return sendMessage(`Tidak ada permintaan masuk dari @${getUsername(partnerJid)}`, [partnerJid])

      database[partnerJid].partnerJid = ''
      return sendMessage(`Kamu menolak permintaan sahabat dari @${getUsername(partnerJid)} 😔`, [partnerJid])
    }

    case 'putusahabat': {
      if (!user.partnerJid) return sendMessage('Kamu sedang tidak memiliki sahabat.')

      const exPartnerJid = user.partnerJid
      user.partnerJid = ''
      
      if (database[exPartnerJid] && database[exPartnerJid].partnerJid === m.sender) {
        database[exPartnerJid].partnerJid = ''
      }

      return sendMessage(`Hubungan persahabatanmu dengan @${getUsername(exPartnerJid)} telah berakhir. 💔`, [exPartnerJid])
    }

    case 'ceksahabat': {
      const subjectJid = partnerJid || m.sender
      const subject = database[subjectJid]
      
      if (!subject?.partnerJid) {
        return sendMessage(subjectJid === m.sender ? 'Kamu belum memiliki sahabat.' : 'Dia belum memiliki sahabat.')
      }

      const currentFriendJid = subject.partnerJid
      const isOfficial = database[currentFriendJid]?.partnerJid === subjectJid

      if (isOfficial) {
        return sendMessage(`@${getUsername(subjectJid)} 🫂 @${getUsername(currentFriendJid)}\nStatus: Bersahabat Resmi`, [subjectJid, currentFriendJid])
      } else {
        return sendMessage(`@${getUsername(subjectJid)} sedang menunggu jawaban dari @${getUsername(currentFriendJid)}`, [subjectJid, currentFriendJid])
      }
    }
  }
}

export default {
  run,
  cmd: ['bersahabat', 'terimasahabat', 'tolaksahabat', 'putusahabat', 'ceksahabat'],
  type: 'fun',
  group: true,
  location: 'plugins/fun/bestie.js'
}