export const run = async (m, lulli) => {
    if (!m.quoted) {
        return m.reply('✗ Reply pesan view once VN untuk menggunakan perintah ini.');
    }

    const isViewOnceVN = m.quoted.mtype === 'audioMessage' && m.quoted.viewOnce;

    if (!isViewOnceVN) {
        return m.reply('✗ Pesan yang di-reply bukan View Once Voice Note.');
    }
    lulli.sendReact(m.chat, '🕒', m.key);
    try {
        let buffer = await m.quoted.download()
        await lulli.sendMessage(m.chat, {
            audio: buffer,
            mimetype: 'audio/mpeg',
            ptt: false
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    } catch (e) {
        console.error("✗ Error reading View Once VN:", e);
        m.reply('✗ Terjadi kesalahan saat membaca Voice Note View Once.');
    }
};

export default {
    run,
    cmd: 'readvn',
    alias: 'rvn',
    use: 'reply viewonce vn',
    type: 'convert',
    limit: true,
    location: 'plugins/convert/readvn.js'
};