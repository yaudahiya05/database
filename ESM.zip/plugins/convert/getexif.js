import webpmux from"node-webpmux";let run=async(t,e)=>{if(!t.quoted)return t.reply("✗ Reply stikernya!");if(!/sticker/.test(t.quoted.mtype))return t.reply("✗ Pesan yang di-reply bukan stiker.");try{var r=await t.quoted.download(),a=new webpmux.Image,i=(await a.load(r),JSON.parse(a.exif.toString("utf-8").slice(22))),s=`✦ *EXIF STICKER INFORMATION*

`,s=(s=(s+=`- Sticker-pack-id: ${i["sticker-pack-id"]??"-"}
`)+`- Sticker-pack-name: ${i["sticker-pack-name"]??"-"}
`)+`- Sticker-pack-publisher: ${i["sticker-pack-publisher"]??"-"}
`+("- Is-avatar-sticker: "+(0!==i["is-avatar-sticker"]?"Yes":"No"));await t.reply(s)}catch(e){console.error("✗ Error getting EXIF data from sticker:",e),await t.reply("✗ Gagal membaca EXIF data stiker: "+e.message)}};export default{run:run,cmd:"getexif",alias:"getwm",use:"reply sticker",type:"convert",limit:!0,location:"plugins/convert/getexif.js"};export{run};