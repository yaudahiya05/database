const botAdminRequiredCommands = [
    'antihacked',
    'antiporn',
    'antigsm',
    'antitoxic',
    'antilink',
    'antivirtex',
    'antibot',
    'antiluar',
    'antihidetag',
    'autokicksider',
    'antidelete',
    'antiedited',
    'verification'
];

const run = async (m, lulli, { func, cfg, groups }) => {
    groups = groups || {};
    groups[m.command] = groups[m.command] === undefined ? false : groups[m.command];

    if (botAdminRequiredCommands.includes(m.command) && !m.isBotAdmin) {
        return m.reply(cfg.mess.botAdmin);
    }

    const [action] = m.args;
    if (!action) {
        return m.reply(`✦ Current status: ${groups[m.command] ? 'active' : 'inactive'}\n\nExample: ${func.example(m.cmd, 'on / off')}`);
    }

    const option = action.toLowerCase();
    if (!/^(on|off)$/i.test(option)) {
        return m.reply(`✗ Invalid input. Use 'on' or 'off'.\nExample: ${func.example(m.cmd, 'on / off')}`);
    }

    const newStatus = option === 'on' ? true : false;
    if (groups[m.command] === newStatus) {
        return m.reply(`✗ ${func.ucword(m.command)} was already ${option === 'on' ? 'active' : 'inactive'} before.`);
    }

    groups[m.command] = newStatus;
    await m.reply(`✓ ${func.ucword(m.command)} successfully ${option === 'on' ? 'activated' : 'deactivated'}.`);
};

export default {
    run,
    cmd: [
        'welcome',
        'goodbye',
        'detect',
        'autosholat',
        ...botAdminRequiredCommands
    ],
    use: 'on / off',
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/moderation.js'
};