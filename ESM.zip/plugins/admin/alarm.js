function ensureAlarmArray(groups) {
    if (!groups.alarm || !Array.isArray(groups.alarm)) {
        groups.alarm = [];
    }
}

function isValidTime(time) {
    const timePattern = /^([01]\d|2[0-3]):([0-5]\d)$/;
    return timePattern.test(time);
}

function checkArray(arr) {
    return Array.isArray(arr) ? JSON.stringify(arr.sort()) : arr;
}

function extractNameAndTime(text) {
    const parts = text.split(' ');
    if (parts.length >= 2 && isValidTime(parts[parts.length - 1])) {
        const time = parts[parts.length - 1];
        const name = parts.slice(0, -1).join(' ');
        return { name: name.trim().toLowerCase(), time };
    }
    return { name: null, time: null };
}

const run = async (m, lulli, { func, groups }) => {
    ensureAlarmArray(groups);

    const example = `✧ Format Perintah:
- Untuk mengatur alarm, gunakan format berikut:
> ${m.prefix}setalarm name|text alarm|HH:mm|--options

✧ Daftar Opsi:
- --days 0-6 (Hari, dari Minggu (0) hingga Sabtu (6))
- --timezone Asia/Jakarta (Zona waktu yang valid)
- --tagall (Menandai semua peserta dalam pesan)
- --open (Membuka grup jika grup dalam keadaan tertutup)
- --close (Menutup grup)

✧ Contoh Penggunaan:
> ${m.prefix}setalarm pagi|Good Morning|07:00|--tagall --open --days 1,2,3

✧ Penjelasan Contoh:
Pada contoh di atas, alarm dengan nama "pagi" dan pesan "Good Morning" akan aktif pada waktu "07:00" dengan opsi sebagai berikut:
- --tagall: Pesan akan menandai semua peserta.
- --open: Grup akan dibuka jika sebelumnya dalam keadaan tertutup.
- --days 1,2,3: Alarm hanya akan aktif pada hari Senin (1), Selasa (2), dan Rabu (3).`;

    switch (m.command) {
        case 'setalarm': {
            const input = m.text.split('|').map(x => x.trim());
            if (input.length < 3) return m.reply(`✗ Format perintah salah.\n${example}`);

            const [name, textAlarm, time, ...optionsRaw] = input;
            const alarmName = name.toLowerCase();
            if (!alarmName) return m.reply('✗ Nama alarm tidak boleh kosong.');
            
            if (!isValidTime(time)) return m.reply('✗ Format waktu salah. Harus dalam format HH:mm (contoh: 07:00).');

            const alarmOptionsString = optionsRaw.join(' ');
            let parsedOptions = {
                days: null,
                timeZone: 'Asia/Jakarta',
                tagAll: false,
                announce: null,
            };

            if (alarmOptionsString) {
                const optionList = alarmOptionsString.split('--').map(x => x.trim()).filter(Boolean);
                for (const option of optionList) {
                    const [key, ...valueParts] = option.split(' ').map(x => x.trim());
                    const value = valueParts.join(' ');
                    
                    switch (key) {
                        case 'days':
                            const arrayDays = value.split(',').map(x => x.trim());
                            const uniqueDays = [...new Set(arrayDays.filter(day => !isNaN(day) && parseInt(day) >= 0 && parseInt(day) <= 6))];
                            if (uniqueDays.length === 0) return m.reply('✗ Opsi --days harus berupa angka antara 0-6, dipisahkan koma.');
                            parsedOptions.days = uniqueDays.map(Number).sort();
                            break;
                        case 'timezone':
                            const validTimezones = ['Asia/Jakarta', 'Asia/Makassar', 'Asia/Jayapura', 'America/New_York', 'Europe/Berlin'];
                            if (!validTimezones.includes(value)) {
                                return m.reply(`✗ Zona waktu tidak valid! Contoh: Asia/Jakarta. Daftar: ${validTimezones.join(', ')}`);
                            }
                            parsedOptions.timeZone = value;
                            break;
                        case 'tagall':
                            parsedOptions.tagAll = true;
                            break;
                        case 'open':
                            parsedOptions.announce = 'open';
                            break;
                        case 'close':
                            parsedOptions.announce = 'close';
                            break;
                        default:
                            return m.reply(`✗ Opsi tidak dikenal: --${key}.`);
                    }
                }
            }

            if (groups.alarm.some(a => a.time === time && checkArray(a.days) === checkArray(parsedOptions.days))) {
                return m.reply(`✗ Alarm pada waktu ${time} dengan hari yang sama sudah ada. Gunakan waktu lain atau hapus alarm tersebut terlebih dahulu.`);
            }

            const newAlarm = {
                name: alarmName,
                status: true,
                textAlarm,
                time,
                timeZone: parsedOptions.timeZone,
                days: parsedOptions.days,
                tagAll: parsedOptions.tagAll,
                announce: parsedOptions.announce,
                createdAt: Date.now()
            };
            
            const existingIndex = groups.alarm.findIndex(item => item.name === alarmName);
            if (existingIndex === -1) {
                groups.alarm.push(newAlarm);
            } else {
                groups.alarm[existingIndex] = newAlarm;
            }

            let optionsSummary = [];
            if (newAlarm.days) optionsSummary.push(`Hari: ${newAlarm.days.join(', ')}`);
            if (newAlarm.tagAll) optionsSummary.push('Tag All');
            if (newAlarm.announce) optionsSummary.push(`Announce: ${newAlarm.announce}`);
            
            await m.reply(`✓ Alarm berhasil ${existingIndex === -1 ? 'ditambahkan' : 'diperbarui'}:\n- Nama: ${name}\n- Pesan: ${textAlarm}\n- Waktu: ${time} (${newAlarm.timeZone})\n- Opsi: ${optionsSummary.length > 0 ? optionsSummary.join(', ') : '-'}`);
        }
        break;

        case 'delalarm': {
            ensureAlarmArray(groups);
            if (groups.alarm.length === 0) return m.reply('✗ Tidak ada alarm di grup ini.');
            if (!m.text) return m.reply('✗ Masukkan nama alarm yang ingin dihapus!');
            
            const alarmName = m.text.trim().toLowerCase();
            const alarmIndex = groups.alarm.findIndex(item => item.name === alarmName);
            if (alarmIndex === -1) return m.reply(`✗ Alarm dengan nama “${alarmName}“ tidak ditemukan.`);
            
            groups.alarm.splice(alarmIndex, 1);
            await m.reply(`✓ Alarm dengan nama “${alarmName}“ berhasil dihapus.`);
        }
        break;

        case 'listalarm': {
            ensureAlarmArray(groups);
            if (groups.alarm.length === 0) return m.reply('✗ Tidak ada alarm di grup ini.');
            
            let caption = '✦ *L I S T - A L A R M*\n';
            groups.alarm.forEach((item, index) => {
                let optionsList = [];
                if (item.tagAll) optionsList.push('Tag All');
                if (item.announce) optionsList.push(`Announce: ${item.announce}`);
                
                caption += `\n\n${index + 1}. Nama: ${item.name}` +
                           `\n- Status: ${item.status ? 'Aktif' : 'Non-aktif'}` +
                           `\n- Pesan: ${item.textAlarm}` +
                           `\n- Waktu: ${item.time} (${item.timeZone})` +
                           `\n- Hari: ${item.days ? item.days.map(d => ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'][d]).join(', ') : 'Setiap hari'}` +
                           `\n- Opsi: ${optionsList.length > 0 ? optionsList.join(', ') : '-'}`;
            });
            await m.reply(caption);
        }
        break;

        case 'alarm': {
            ensureAlarmArray(groups);
            if (groups.alarm.length === 0) return m.reply('✗ Tidak ada alarm di grup ini.');
            
            const [indexRaw, action] = m.args;
            if (!(indexRaw && action)) return m.reply(`✗ Format perintah salah.\n✧ Contoh: ${func.example(m.cmd, '1 on/off')}`);
            
            const index = parseInt(indexRaw) - 1;
            if (isNaN(index) || index < 0 || index >= groups.alarm.length) return m.reply('✗ Indeks alarm tidak valid!');
            
            const mode = action.toLowerCase();
            if (!/^(on|off)$/.test(mode)) return m.reply('✗ Mode tidak valid. Gunakan `on` atau `off`.');

            let alarm = groups.alarm[index];
            const newStatus = mode === 'on';
            
            if (alarm.status === newStatus) {
                return m.reply(`✗ Alarm “${alarm.name}“ sudah ${mode === 'on' ? 'aktif' : 'tidak aktif'} sebelumnya.`);
            }
            
            alarm.status = newStatus;
            await m.reply(`✓ Alarm “${alarm.name}“ berhasil di${mode === 'on' ? 'aktifkan' : 'non-aktifkan'}.`);
        }
        break;

        case 'setalarmtime': {
            ensureAlarmArray(groups);
            if (groups.alarm.length === 0) return m.reply('✗ Tidak ada alarm di grup ini.');
            
            const { name, time } = extractNameAndTime(m.text);
            if (!(name && time)) return m.reply(`✗ Format perintah salah.\n✧ Contoh: ${func.example(m.cmd, 'pagi time 08:00')}`);
            if (!isValidTime(time)) return m.reply('✗ Format waktu salah. Harus dalam format HH:mm.');
            
            let alarmData = groups.alarm.find(x => x.name === name);
            if (!alarmData) return m.reply(`✗ Alarm dengan nama “${name}“ tidak ditemukan.`);
            
            alarmData.time = time;
            await m.reply(`✓ Berhasil mengubah waktu alarm “${name}“ menjadi ${time}.`);
        }
        break;
    }
};

export default {
    run,
    cmd: [
        'setalarm',
        'delalarm',
        'listalarm',
        'alarm',
        'setalarmtime'
    ],
    use: 'options',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/alarm.js'
};
