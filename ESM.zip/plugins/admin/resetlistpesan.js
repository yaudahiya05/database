import { resetTotalChatForGroup } from '../../lib/totalchat.js';

const run = async (m, lulli, {}) => {
    await resetTotalChatForGroup(m.chat);
    
    lulli.sendReact(m.chat, '✅', m.key);
    await m.reply('✓ Group chat data successfully reset.');
};

export default {
    run,
    cmd: 'resetlistpesan',
    alias: ['resetlistchat', 'resettotalchat'],
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/group/resetlistpesan.js'
};