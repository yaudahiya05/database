const run = async (m, lulli) => {
    const { expiration } = m;
    
    let args = m.text.split('\n').map(a => a.trim()).filter(Boolean);
    
    let name = args[0];
    let values = args.slice(1);

    if (!name) return m.reply(`✗ Example: ${m.cmd} *POLL TITLE*\nOption 1\nOption 2`);
    if (values.length < 2) return m.reply('✗ Please provide at least two options for the poll.');

    let poll = {
        name: name,
        values: values,
        selectableCount: true
    };
    
    try {
        const sentPollMessage = await lulli.sendMessage(m.chat, {
            poll: poll
        }, {
            quoted: m,
            ephemeralExpiration: expiration
        });
        
        await lulli.reply(m.chat, `✓ Poll *${name}* has been created, with options: *${values.join(', ')}*`, sentPollMessage, { expiration });

    } catch (error) {
        await m.reply(`✗ Failed to create poll: ${error.message}`);
    }
};

export default {
    run,
    cmd: 'polling',
    alias: 'poll',
    use: 'poll_title\noption_1\noption_2\n...',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/polling.js'
};
