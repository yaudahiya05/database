// Variable to store giveaway participants per chat
global.giveawayParticipants = global.giveawayParticipants || {};

const run = async (m, lulli) => {
    if (m.command === 'giveaway') {
        if (!global.giveawayParticipants[m.chat]) {
            global.giveawayParticipants[m.chat] = new Set();
        }
        await m.reply(`✦ *GIVEAWAY STARTED!*\n\nType *${m.prefix}join* to participate.\n\nUse *${m.prefix}startgiveaway <number_of_winners>* to draw winners.`);
        return;
    }

    if (m.command === 'startgiveaway') {
        if (!global.giveawayParticipants[m.chat]) {
            await m.reply(`✦ Giveaway has not started. Type *${m.prefix}giveaway* to begin registration.`);
            return;
        }

        if (!m.text || isNaN(m.text) || parseInt(m.text) <= 0) {
            await m.reply(`✗ Invalid format. Use: *${m.prefix}startgiveaway <number_of_winners>* (e.g., *${m.prefix}startgiveaway 5*)`);
            return;
        }

        const numberOfWinners = parseInt(m.text);
        const participantsSet = global.giveawayParticipants[m.chat];

        if (participantsSet.size === 0) {
            await m.reply(`✗ No participants have joined this giveaway!`);
            return;
        }

        const participantsArray = Array.from(participantsSet);

        if (numberOfWinners > participantsArray.length) {
            await m.reply(`✗ The number of winners (${numberOfWinners}) cannot exceed the total number of participants (${participantsArray.length}).`);
            return;
        }

        const shuffled = participantsArray.sort(() => 0.5 - Math.random());
        const winners = shuffled.slice(0, numberOfWinners);

        const winnerMentions = winners.map(winner => `- @${winner.split('@')[0]}`).join('\n');
        await lulli.sendMessage(m.chat, {
            text: `✓ Giveaway Winners: ✓\n\n${winnerMentions}`,
            mentions: winners
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

        delete global.giveawayParticipants[m.chat];
    }
};

export default {
    run,
    cmd: ['giveaway', 'startgiveaway'],
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/giveaway.js'
};