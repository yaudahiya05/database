const run = async (m, lulli, { froms, groups }) => {
    groups.member = groups.member || [];

    if (froms) {
        const member = groups.member.find(v => v.jid === froms);
        if (!member) return m.reply('✗ Member data not found.');
        if (member.toxic === 0) return m.reply('✦ This member already has a toxic score of 0.');
        
        member.toxic = 0;
        await m.reply(`✓ Successfully reset toxic score for @${froms.split('@')[0]}.`, null, { mentions: [froms] });
    } else {
        const membersWithToxic = groups.member.filter(x => x.toxic > 0);
        if (membersWithToxic.length === 0) return m.reply('✦ No members with toxic scores.');
        
        membersWithToxic.forEach(member => member.toxic = 0);
        await m.reply(`✓ Successfully reset toxic score for *${membersWithToxic.length}* members.`);
    }
};

export default {
    run,
    cmd: 'resettoxic',
    use: 'mention or reply (optional)',
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/resettoxic.js'
};