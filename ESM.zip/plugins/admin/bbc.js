const run = async (m, lulli, { func, groups }) => {
    groups.member = groups.member || [];

    if (!m.text || isNaN(m.text)) {
        return m.reply(`✗ Invalid input.\n✦ Example: ${func.example(m.cmd, '50')}`);
    }

    const bbcAmount = Number(m.args[0]);
    if (bbcAmount <= 0) return m.reply('✗ Chat count (BBC) must be greater than 0.');
    const membersToKick = groups.member.filter(v => 
        v.chat !== undefined &&
        v.chat < bbcAmount &&
        m.members.some(groupMember => groupMember.id === v.jid)
    ).map(x => x.jid);

    if (membersToKick.length === 0) {
        return m.reply('✗ No members meet the criteria for kicking.');
    }

    await m.reply(`✦ Processing kick for ${membersToKick.length} members...`);
    const originalGoodbyeStatus = groups.goodbye;
    groups.goodbye = null;
    for (let jid of membersToKick) {
        if (jid === lulli.user.jid) continue;
        try {
            await lulli.groupParticipantsUpdate(m.chat, [jid], 'remove');
            await func.delay(3000);
        } catch (e) {
            console.error(`Failed to kick member ${jid}:`, e);
        }
    }
    groups.goodbye = originalGoodbyeStatus === null ? true : originalGoodbyeStatus;
    await m.reply(`✓ Successfully kicked ${membersToKick.length} members with chat count less than ${bbcAmount}.`);
};

export default {
    run,
    cmd: 'bbc',
    use: 'chat_count (e.g., 50)',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/bbc.js'
};