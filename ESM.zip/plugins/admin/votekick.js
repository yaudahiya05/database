let DATABASE={},run=async(e,a,{cfg:t,froms:i})=>{var s,n,r;return e.isGc?e.isBotAdmin?e.isAdmin||e.isOwner?DATABASE[e.chat]?e.reply("Masih ada sesi vote kick sebelumnya yang berjalan."):i?i===e.bot?e.reply("Tidak bisa vote kick bot sendiri."):(s=global.db.users[i])?(i=i,s=s.name||i.split("@")[0],n="@"+i.split("@")[0],r=await a.sendMessage(e.chat,{text:`Vote Kick Dimulai!

`+`Target: ${n}
`+`Apakah setuju mengeluarkan member ini dari grup?

`+`Balas pesan ini dengan angka:
`+`1 = Setuju Kick
`+`2 = Tidak Setuju

`+`Hasil akhir ditentukan suara terbanyak.
`+"*Batas waktu*: 3 menit",mentions:[i]},{ephemeralExpiration:e.expiration}),DATABASE[e.chat]={chatId:e.chat,key:r.key,target:i,targetName:s,voters:{},startTime:Date.now(),timeout:setTimeout(async()=>{await endVote(e.chat,a)},18e4)},void await a.reply(e.chat,`Vote kick untuk ${n} telah dimulai! Balas pesan vote di atas dengan *1* atau *2*.`,r,{expiration:e.expiration})):e.reply("Data user tidak ditemukan."):e.reply("Mention atau reply pesan target yang mau di-kick."):e.reply(t.mess.admin):e.reply(t.mess.botAdmin):e.reply(t.mess.group)},main=async(e,a)=>{var t,i;DATABASE[e.chat]&&e.quoted&&e.quoted.id&&(i=DATABASE[e.chat],e.quoted.id===i.key.id)&&(t=e.budy?.trim(),/^[12]$/.test(t))&&(i.voters[e.sender]={vote:t,choice:i="1"===t?"Kick":"Tidak",time:Date.now()},await a.sendMessage(e.chat,{text:`makasih @${e.sender.split("@")[0]}
kamu memilih: *${i}*`,mentions:[e.sender]},{quoted:e,ephemeralExpiration:e.expiration}),await updateVoteCount(e.chat,a))};async function updateVoteCount(e,i){var s=DATABASE[e];if(s){let a=0,t=0;Object.values(s.voters).forEach(e=>{"1"===e.vote&&a++,"2"===e.vote&&t++});var n=`Live Count:
`+`Kick (1): ${a} suara
`+`Tidak (2): ${t} suara
`+`Sisa waktu: ${Math.max(0,Math.ceil((s.startTime+18e4-Date.now())/1e3/60))} menit`;await i.sendMessage(e,{text:n,edit:s.key}).catch(()=>{})}}async function endVote(a,n){let r=DATABASE[a];if(r){clearTimeout(r.timeout);let t=0,i=0,s=[],e=(Object.entries(r.voters).forEach(([e,a])=>{"1"===a.vote&&t++,"2"===a.vote&&i++,s.push(`@${e.split("@")[0]} `+a.choice)}),`Voting selesai!

`+`Target: @${r.target.split("@")[0]}
`+`Kick: ${t} suara
`+`Tidak: ${i} suara

`+(0<s.length?`Voters:
${s.join("\n")}

`:""));t>i?(e+="Hasil: *Target DI-KICK*",setTimeout(async()=>{await n.groupParticipantsUpdate(a,[r.target],"remove").catch(e=>n.sendMessage(a,{text:"Gagal kick: "+e.message},{ephemeralExpiration:m.expiration}))},2e3)):i>t?e+="Hasil: *Target TIDAK DIKICK*":e+="Hasil: *SERI* Target tetap stay",await n.sendMessage(a,{text:e,mentions:[r.target,...Object.keys(r.voters)]}),await n.sendMessage(a,{delete:r.key}).catch(()=>{}),delete DATABASE[a]}}export default{run:run,main:main,cmd:"votekick",type:"admin",group:!0,location:"plugins/admin/votekick.js"};