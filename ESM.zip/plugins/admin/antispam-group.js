const run = async (m, lulli, { func, cfg }) => {
    global.db = global.db || {};
    global.db.groups = global.db.groups || {};
    global.db.groups[m.chat] = global.db.groups[m.chat] || {};
    let groupData = global.db.groups[m.chat];
    groupData.antispam = groupData.antispam === undefined ? false : groupData.antispam;
    if (!m.args || !m.args[0]) {
        return m.reply(`✦ Current status: ${groupData.antispam ? 'active' : 'inactive'}\n\n✦ Example: ${func.example(m.cmd, 'on / off')}`);
    }
    const option = m.args[0].toLowerCase();
    const optionList = ['on', 'off'];
    if (!optionList.includes(option)) {
        return m.reply(`✗ Invalid input. Use 'on' or 'off'.\n✦ Example: ${func.example(m.cmd, 'on / off')}`);
    }
    const newStatus = option === 'on';
    if (groupData.antispam === newStatus) {
        return m.reply(`✗ Antispam group was already ${option === 'on' ? 'active' : 'inactive'} before.`);
    }
    groupData.antispam = newStatus;
    await m.reply(`✓ Antispam group successfully ${option === 'on' ? 'activated' : 'deactivated'}.`);
};

export default {
    run,
    cmd: 'antispamgroup',
    alias: ['antispamgrup', 'antispamgc'],
    use: 'on / off',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/antispam-group.js'
};