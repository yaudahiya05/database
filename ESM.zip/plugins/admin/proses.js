const run = async (m, lulli) => {
    if (!m.quoted) {
        return await m.reply('✗ This command must be used by replying to a customer\'s message!');
    }

    try {
        const chatId = m.chat;

        const now = new Date();
        const time = now.toLocaleTimeString('en-US', {
            hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Jakarta'
        });
        const date = now.toLocaleDateString('en-US', {
            day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta'
        });

        let groupName = m.isGc ? m.groupName : 'Private Chat';
        const note = m.text.trim() || '-';
        const customerJid = m.quoted.sender;
        const notification = `
┌─「 *TRANSACTION IN PROCESS* 」
│
├ Time: \`\`\`${time} WIB\`\`\`
├ Date: \`\`\`${date}\`\`\`
├ Location: \`\`\`${groupName}\`\`\`
├ Note: \`\`\`${note}\`\`\`
│
└─「 Please Wait! 」

Hello @${customerJid.split('@')[0]}, your order is currently being processed! Please wait for further updates.`.trim();

        await lulli.sendMessage(chatId, {
            text: notification,
            mentions: [customerJid]
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

    } catch (error) {
        console.error('Error in "proses" plugin:', error);
        await lulli.sendMessage(m.chat, {
            text: '✗ An error occurred while processing the "in process" notification.'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    }
};

export default {
    run,
    cmd: 'proses',
    use: '(reply message) <note>',
    type: 'admin',
    admin: true,
    location: 'plugins/admin/proses.js'
};