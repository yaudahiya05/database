import fs from 'node:fs';

const run = async (m, lulli, { quoted }) => {
    if (!quoted || !quoted.mimetype || !/image\/(jpe?g|png)/.test(quoted.mimetype)) {
        return m.reply(`✗ Send/reply an image with the caption ${m.cmd}`);
    }

    lulli.sendReact(m.chat, '🕒', m.key);

    try {
        if (m.args[0] && /(full|panjang)/.test(m.args[0])) {
            const mediaFilePath = await lulli.downloadAndSaveMediaMessage(m);
            if (!mediaFilePath) return m.reply('✗ Failed to download image!');
            await lulli.createprofile(m.chat, mediaFilePath);
            lulli.sendReact(m.chat, '✅', m.key);
            if (mediaFilePath && fs.existsSync(mediaFilePath)) fs.unlinkSync(mediaFilePath);
        } else {
            const mediaBuffer = await quoted.download();
            await lulli.updateProfilePicture(m.chat, mediaBuffer);
            lulli.sendReact(m.chat, '✅', m.key);
        }
    } catch (e) {
        lulli.sendReact(m.chat, '❌', m.key);
        await m.reply(`✗ Failed to change group profile picture. Ensure the bot is an admin. Error: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'setppgroup',
    alias: ['setppgrup', 'setppgc'],
    use: 'reply to a photo (optional: include "full" for full-size photo)',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/setppgroup.js'
};