const run = async (m, lulli, { groups }) => {
    groups.mute = groups.mute === undefined ? false : groups.mute;

    if (/^mute$/.test(m.command)) {
        if (groups.mute) return m.reply('✗ Bot is already muted.');
        groups.mute = true;
        m.reply('✓ Bot has been muted in this group.');
    } else if (/^unmute$/.test(m.command)) {
        if (!groups.mute) return m.reply('✗ Bot is already unmuted.');
        groups.mute = false;
        m.reply('✓ Bot has been unmuted in this group.');
    }
}

export default {
    run,
    cmd: ['mute', 'unmute'],
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/mute.js'
};