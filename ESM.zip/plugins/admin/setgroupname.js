const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(`✗ Invalid input. Example: ${func.example(m.cmd, 'Awesome New Group Name!')}`);
    }

    try {
        await lulli.groupUpdateSubject(m.chat, m.text);
        await lulli.sendReact(m.chat, '✅', m.key);
    } catch (e) {
        await lulli.sendReact(m.chat, '❌', m.key);
        await m.reply(`✗ Failed to change group name. Ensure the bot is an admin. Error: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'setgroupname',
    alias: ['setgrupname', 'setgcname'],
    use: 'text',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/setgroupname.js'
};