import {
    generateWAMessage,
    STORIES_JID,
    isLidUser
} from '@whiskeysockets/baileys';

const run = async (m, lulli, { func, cfg, quoted }) => {
    const sendStatusMention = async (content, groupId, statusJidList) => {
        const media = await generateWAMessage(STORIES_JID, content, {
            upload: lulli.waUploadToServer,
        });

        const additionalNodes = [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: {
                        jid: groupId
                    },
                    content: undefined,
                }],
            }],
        }];

        await lulli.relayMessage(STORIES_JID, media.message, {
            messageId: media.key.id,
            statusJidList: statusJidList,
            additionalNodes
        });

        return await lulli.relayMessage(groupId, {
            groupStatusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: media.key,
                        type: 25,
                    },
                },
            },
        }, {
            userJid: lulli.user.jid,
            additionalNodes: [{
                tag: "meta",
                attrs: {
                    is_status_mention: "true"
                },
                content: undefined,
            }],
        });
    };

    try {
        if (!quoted || !(/audio|video|image|conversation|extendedTextMessage/.test(quoted.mtype))) {
            return m.reply('✗ Mohon balas media (audio/video/gambar) atau pesan teks yang ingin dijadikan story.');
        }
        lulli.sendReact(m.chat, '🕒', m.key);
        const caption = m.text || (m.quoted && m.quoted.text) || '';
        const groupMetadata = await lulli.groupMetadata(m.chat).catch(e => {
            console.error('✗ Gagal mendapatkan metadata grup:', e);
            return null;
        });
        if (!groupMetadata) {
            return m.reply('✗ Gagal mendapatkan data grup. Bot mungkin tidak berada di grup ini.');
        }
        const statusJidList = (groupMetadata.participants || []).map(user => isLidUser(user.id) ? user.pn : user.id);
        if (statusJidList.length === 0) {
            return m.reply('✗ Tidak ada pengguna yang ditemukan untuk ditag dalam cerita di grup ini.');
        }
        let mediaBuffer;
        if (quoted.download) {
            mediaBuffer = await quoted.download();
        }
        const content = { caption };
        if (/image\/(jpe?g|png)/i.test(quoted.mime)) {
            content.image = mediaBuffer;
        } else if (/video\/mp4/i.test(quoted.mime)) {
            content.video = mediaBuffer;
        } else if (/audio/i.test(quoted.mime)) {
            content.audio = mediaBuffer;
            content.ptt = true;
            content.mimetype = quoted.mime || 'audio/mpeg';
        } else if (/conversation|extendedTextMessage/i.test(quoted.mtype)) {
            content.text = caption;
        } else {
            return m.reply('✗ Tipe media yang dibalas tidak didukung untuk story.');
        }
        await sendStatusMention(content, m.chat, statusJidList);
        await m.reply(`✓ Berhasil mengirim cerita (story) dengan tag ke *${statusJidList.length}* pengguna di grup ini.`);
    } catch (error) {
        console.error('✗ Terjadi kesalahan pada upswtag:', error);
        await m.reply(`✗ Terjadi kesalahan saat mengirim story dengan tag: ${error.message}`);
    }
};

export default {
    run,
    cmd: 'upswtag',
    use: 'balas media/pesan teks',
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/upswtag.js'
};