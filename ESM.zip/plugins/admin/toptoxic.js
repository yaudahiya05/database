import { areJidsSameUser } from '@whiskeysockets/baileys';

function createCaption(userRank, totalUsers, topToxicUsers, maxToxic, allGroupMembers) {
    let caption = `✦ You are Top *${userRank}* Toxic out of *${totalUsers}* Users\n\n`;
    caption += topToxicUsers.slice(0, 10).map((user, index) => {
        let displayName = (global.db.users[user.jid]?.name || `(${user.jid.split('@')[0]})`).replaceAll('\n', ' ');
        const isStillInGroup = allGroupMembers.some(member => areJidsSameUser(user.jid, member.id));

        return `${index + 1}. ${isStillInGroup ? '@' + user.jid.split('@')[0] : displayName}: (${user.toxic}/${maxToxic})`;
    }).join('\n');
    return caption;
}

const run = async (m, lulli, { cfg, setting, groups }) => {
    groups.member = groups.member || [];

    const membersData = groups.member;
    if (membersData.length === 0) return m.reply('No member data in this group.');

    const currentGroupMembersData = membersData.filter(member => 
        m.members.some(groupMember => areJidsSameUser(member.jid, groupMember.id))
    ).map(member => ({
        jid: member.jid,
        toxic: member.toxic || 0
    }));

    if (currentGroupMembersData.length === 0) return m.reply('No toxic data for members in this group.');

    const topToxicUsers = currentGroupMembersData.sort((a, b) => b.toxic - a.toxic);
    const userToxicRank = topToxicUsers.findIndex(user => areJidsSameUser(user.jid, m.sender)) + 1;
    const totalCurrentUsers = currentGroupMembersData.length;
    const caption = createCaption(userToxicRank, totalCurrentUsers, topToxicUsers, setting.max_toxic || 3, m.members);
    const mentionsInCaption = topToxicUsers.slice(0, 10).map(user => user.jid);
    await lulli.sendMessage(m.chat, {
        text: caption,
        mentions: mentionsInCaption
    }, {
        quoted: m,
        ephemeralExpiration: m.expiration
    });
};

export default {
    run,
    cmd: 'toptoxic',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/toptoxic.js'
};