const run = async (m, lulli) => {
    let text = `*T A G - A L L*\n${m.text ? '\nMessage: ' + m.text + '\n' : ''}`;
    m.members.forEach(item => {
        const roleEmoji = item.admin === 'superadmin' ? '👑' : item.admin === 'admin' ? '😈' : '👤';
        text += `\n${roleEmoji} @${item.id.split('@')[0]}`;
    });
    const mentions = m.members.map(v => v.id);
    await lulli.sendMessage(m.chat, {
        text: text,
        mentions: mentions
    }, {
        quoted: null,
        ephemeralExpiration: m.expiration
    });
};

export default {
    run,
    cmd: 'tagall',
    use: 'text',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/tagall.js'
};