const run = async (m, lulli, { func, groups }) => {
    const exampleTextDefault = `*#WARNING CARD*\n──────── ୨୧ ────────\n*Violation by* : +tag\n*Rule violated* : +reason\n*Warning count* : +limit\n \n> Consequences for severe violations include blacklist / kick!!`;
    groups.warning = groups.warning || {
        text: exampleTextDefault,
        limit: 3
    };
    groups.member = groups.member || [];

    switch (m.command) {
        case 'settextwarn': {
            if (!m.text) return m.reply(`✗ Invalid input. Example: ${func.example(m.command, `${exampleTextDefault}\n\n+tag to tag user\n+reason for reason\n+limit for warning limit`)}`);
            groups.warning.text = m.text.trim();
            m.reply(`✓ Warning text successfully updated.`);
        }
        break;

        case 'setlimitwarn': {
            if (!m.args || m.args.length < 1) return m.reply(`✗ Invalid input. Example: ${func.example(m.command, '3')}`);
            let limit = parseFloat(m.args[0]);
            if (isNaN(limit) || limit <= 0) return m.reply('✗ Warning limit must be a positive number.');
            groups.warning.limit = limit;
            lulli.sendReact(m.chat, '✅', m.key);
            m.reply(`✓ Warning limit successfully set to ${limit}.`);
        }
        break;

        case 'warn': {
            let targetJid;
            let reason = 'violating rules';

            if (m.quoted && m.quoted.sender) {
                targetJid = m.quoted.sender;
                reason = m.text || reason;
            } else if (m.text) {
                let [param1, ...param2] = m.text.split(',').map(x => x.trim());
                if (m.mentionedJid && m.mentionedJid.length > 0) {
                    targetJid = m.mentionedJid[0];
                    reason = param2.join(',') || reason;
                } else {
                    targetJid = func.wa(param1);
                    reason = param2.join(',') || reason;
                }
            } else {
                return m.reply(`✗ Invalid input. Example: ${func.example(m.command, '@0,against admin')}`);
            }

            if (!targetJid || !targetJid.endsWith('@s.whatsapp.net')) return m.reply('✗ Invalid target.');
            const members = m.members.map(x => x.id);
            if (!members.includes(targetJid)) return m.reply('✗ That user is not in this group.');
            if (targetJid === lulli.user.jid || m.isAdmin || m.isOwner) {
                return m.reply('✗ Cannot give a warning to the bot, an admin, or the owner.');
            }

            let userData = groups.member.find(x => x.jid === targetJid);
            if (!userData) {
                userData = {
                    jid: targetJid,
                    lastseen: Date.now(),
                    toxic: 0,
                    chat: 0,
                    warn: 0
                };
                groups.member.push(userData);
            }
            userData.warn = (userData.warn || 0) + 1;
            let warningText = groups.warning.text
                .replace(/\+tag/g, `@${targetJid.split('@')[0]}`)
                .replace(/\+reason/g, reason)
                .replace(/\+limit/g, userData.warn);
            if (userData.warn >= groups.warning.limit) {
                warningText += `\n\n✗ @${targetJid.split('@')[0]}, you have exceeded the warning limit. Sorry, you will be removed from the group.`;
                lulli.reply(m.chat, warningText, null, {
                    mentions: [targetJid],
                    expiration: m.expiration
                });
                setTimeout(async function() {
                    if (!m.isBotAdmin) return m.reply('✗ Sorry, cannot kick the offender because the bot is not an admin.')
                    await lulli.groupParticipantsUpdate(m.chat, [targetJid], 'remove');
                }, 3000);
            } else {
                await lulli.reply(m.chat, warningText, null, {
                    mentions: [targetJid],
                    expiration: m.expiration
                });
            }
        }
        break;
    }
};

export default {
    run,
    cmd: ['warn', 'setlimitwarn', 'settextwarn'],
    use: 'parameter (e.g., @user,reason)',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/warning.js'
};