function isAlreadyResponList(key, _db) {
    return _db.some(x => x.name === key);
}

function delResponList(key, _db) {
    const index = _db.findIndex(x => x.name === key);
    if (index !== -1) {
        _db.splice(index, 1);
    }
}

const run = async (m, lulli, { func, cfg, groups }) => {
    groups.list = groups.list || [];

    switch (m.command) {
        case 'addlist': {
            if (!(m.isAdmin || m.isOwner)) return m.reply(cfg.mess.admin);
            
            let name;
            if (m.text) {
                name = m.text.trim().toLowerCase();
            } else {
                return m.reply('✗ Please enter the list name!');
            }

            if (isAlreadyResponList(name, groups.list)) return m.reply('✗ This name already exists in the database!');

            if (m.quoted && /webp|audio|image\/(jpe?g|png)/.test(m.quoted.mimetype)) {
                let media = await m.quoted.download();
                let catbox = await func.catbox(media);
                
                if (!catbox.status || !/https:\/\/files\.catbox\.moe\/[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)$/.test(catbox.url)) {
                    return m.reply('✗ Failed to upload media, please try again.');
                }
                
                let type = 'text';
                if (/webp/.test(m.quoted.mimetype)) type = 'sticker';
                else if (/audio/.test(m.quoted.mimetype)) type = 'audio';
                else if (/image/.test(m.quoted.mimetype)) type = 'image';

                groups.list.push({
                    name: name,
                    type: type,
                    content: catbox.url,
                    ...(type === 'image' ? { caption: m.quoted.caption || '' } : {})
                });
                await m.reply(`✓ Successfully added list with name *${name}* (${type}) to the database!`);

            } else if (m.quoted && m.quoted.text) {
                groups.list.push({
                    name: name,
                    type: 'text',
                    content: m.quoted.text,
                });
                await m.reply(`✓ Successfully added text list with name *${name}* to the database!`);
            } else {
                m.reply(`✗ Please reply to a sticker, audio, image, or text with caption ${m.command} <list_name>`);
            }
        }
        break;

        case 'dellist': {
            if (!(m.isAdmin || m.isOwner)) return m.reply(cfg.mess.admin);
            if (!m.text) return m.reply(func.example(m.command, 'list_name'));
            
            let name = m.text.trim().toLowerCase();
            if (!isAlreadyResponList(name, groups.list)) return m.reply('✗ This name does not exist in the database!');
            
            delResponList(name, groups.list);
            await m.reply(`✓ Successfully deleted list with name *${name}* from the database!`);
        }
        break;

        case 'list': {
            const listData = groups.list;
            if (listData.length === 0) return m.reply(cfg.mess.empty || '✦ No list messages in the database.');

            const categories = {
                "STREAMING & ENTERTAINMENT": { emoji: "🎬", keywords: ["netflix", "disney", "viu", "wetv", "iqiyi", "amazon prime", "hbo max", "moviebox", "loklok", "bstation", "gagaolala", "dramabox", "apk bioskop"] },
                "MUSIC & APPS": { emoji: "🎧", keywords: ["spotify", "youtube", "app music", "fizzo novel", "wibuku", "chatgpt", "gemini", "telegram", "zoom"] },
                "CREATIVE & EDITING TOOLS": { emoji: "🎨", keywords: ["canva", "capcut", "remini", "ibis paint", "lighroom", "am", "alight motion", "wink", "meitu", "font simbol"] },
                "GAME & TOP UP": { emoji: "💎", keywords: ["dm ff", "like mlbb", "robux gp", "pay"] },
                "PULSE & QUOTA": { emoji: "📶", keywords: ["pulsa indosat", "pulsa telkomsel", "kuota axis", "kuota byu", "kuota telkomsel", "kuota tri"] },
                "SERVICES & SOCIAL MEDIA NEEDS": { emoji: "📈", keywords: ["kebsos ig", "kebsos threads", "kebsos tt", "kebsos wa", "sewa bot", "sewa qris", "nokos", "rules nokos", "jasa bikin poster", "jasa confes", "jasa daget", "jasa edit qr", "jasa hapus bg", "jasa kenon", "jasher", "ams", "murid store"] }
            };

            let groupedItems = {};
            let uncategorized = [];

            for (const categoryName in categories) {
                groupedItems[categoryName] = [];
            }

            const sortedListData = listData.sort((a, b) => a.name.localeCompare(b.name));

            sortedListData.forEach(item => {
                let categorized = false;
                for (const categoryName in categories) {
                    if (categories[categoryName].keywords.includes(item.name.toLowerCase())) {
                        groupedItems[categoryName].push(item);
                        categorized = true;
                        break;
                    }
                }
                if (!categorized) {
                    uncategorized.push(item);
                }
            });

            if (uncategorized.length > 0) {
                groupedItems["OTHERS"] = uncategorized;
            }

            let caption = "· · ─────── · ⊱ ୨♡୧ ⊰ · ─────── · ·\n";
            caption += "˚₊‧ ୨ ୧ ‧₊˚ *MUJIB STORE LIST* ˚₊‧ ୨ ୧ ‧₊˚\n";
            caption += "· · ─────── · ⊱ ୨♡୧ ⊰ · ─────── · ·\n\n";

            for (const categoryName in groupedItems) {
                if (groupedItems[categoryName].length > 0) {
                    const categoryEmoji = categories[categoryName]?.emoji || "✨";

                    caption += `╭── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╮\n`;
                    caption += `  ${categoryEmoji} *${categoryName}*\n`;
                    caption += `╰── ⋅ ⋅ ── ✩ ── ⋅ ⋅ ──╯\n`;

                    groupedItems[categoryName].forEach(item => {
                        const itemIcon = '┆ ✦';
                        const itemType = item.type !== 'text' ? '(*' + item.type + '*)' : '';
                        caption += `${itemIcon} \`${item.name}\` ${itemType}\n`;
                    });
                    caption += '\n';
                }
            }

            caption += "──────── ⋆⋅☆⋅⋆ ────────\n";
            caption += "♡ *Happy shopping, dear!* ♡";

            lulli.reply(m.chat, caption, m, {
                expiration: m.expiration
            });
        }
        break;

        case 'clearlist': {
            if (!(m.isAdmin || m.isOwner)) return m.reply(cfg.mess.admin);
            if (groups.list.length === 0) return m.reply(cfg.mess.empty || '✦ No list messages in the database.');
            
            groups.list = [];
            m.reply('✓ Successfully cleared all lists.');
        }
        break;
    }
};

const main = async (m, lulli, { groups }) => {
    groups.list = groups.list || [];

    const responseKey = m.text && m.text.trim().toLowerCase();
    if (m.isGc && responseKey && isAlreadyResponList(responseKey, groups.list) && !m.isPrefix) {
        let data = groups.list.find(item => item.name === responseKey);
        if (!data) return;

        if (data.type === 'sticker') {
            lulli.sendMessage(m.chat, { sticker: { url: data.content } }, { quoted: m, ephemeralExpiration: m.expiration });
        } else if (data.type === 'image') {
            lulli.sendMessage(m.chat, { image: { url: data.content }, caption: data.caption || '' }, { quoted: m, ephemeralExpiration: m.expiration });
        } else if (data.type === 'audio') {
            lulli.sendMessage(m.chat, { audio: { url: data.content }, mimetype: 'audio/mpeg', ptt: false }, { quoted: m, ephemeralExpiration: m.expiration });
        } else if (data.type === 'text') {
            lulli.sendMessage(m.chat, { text: data.content, mentions: lulli.ments(data.content) }, { quoted: m, ephemeralExpiration: m.expiration });
        }
    }
};

export default {
    run,
    main,
    cmd: ['addlist', 'dellist', 'list', 'clearlist'],
    use: 'reply sticker, audio, image, or text (with list name in caption)',
    type: 'admin',
    group: true,
    location: 'plugins/admin/list.js',
};