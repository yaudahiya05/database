const run = async (m, lulli, { func }) => {
    const outsiders = m.members.filter(v =>
        v.admin === null &&
        !v.id.startsWith('62') &&
        v.id !== lulli.user.jid
    ).map(v => v.id);

    const [action] = m.args;

    if (action === '-y') {
        if (outsiders.length === 0) return m.reply('✦ This group is clean of outsiders.');

        lulli.sendReact(m.chat, '🕒', m.key);

        for (let jid of outsiders) {
            try {
                await lulli.groupParticipantsUpdate(m.chat, [jid], 'remove');
                await func.delay(2000);
            } catch (e) {
                continue;
            }
        }
        await m.reply(`✓ Successfully removed ${outsiders.length} outsiders.`);
    } else {
        if (outsiders.length === 0) return m.reply('✦ This group is clean of outsiders.');

        let caption = `✦ *${outsiders.length}* outsiders found. Send *${m.cmd} -y* to remove them.\n\n`;
        caption += outsiders.map(v => '- @' + v.replace(/@.+/, '')).join('\n');
        await lulli.reply(caption, null, { mentions: outsiders });
    }
};

export default {
    run,
    cmd: 'outsider',
    use: '-y (to kick all)',
    type: 'admin',
    admin: true,
    group: true,
    botAdmin: true,
    location: 'plugins/admin/outsider.js'
};