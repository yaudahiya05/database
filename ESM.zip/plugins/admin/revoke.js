const run = async (m, lulli, { cfg }) => {
    try {
        const inviteCode = await lulli.groupRevokeInvite(m.chat);
        await m.reply(`✓ Successfully reset the group link!\nNew link: https://chat.whatsapp.com/${inviteCode}`);
    } catch (e) {
        await m.reply(`✗ Failed to reset group link: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'revoke',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/revoke.js'
};