const run = async (m, lulli, { store, lid, cfg }) => {
    try {
        const [params] = m.args;
        let targetGroupId = params && /\d+\-\d+@g.us/.test(params) ? params : m.chat;
        
        if (typeof store.presences[targetGroupId] === 'undefined' || Object.keys(store.presences[targetGroupId]).length === 0) {
            return m.reply('No participants are currently online or presence data is unavailable.');
        }

        let onlineMembers = Object.keys(store.presences[targetGroupId]).filter(jid => store.presences[targetGroupId][jid]?.lastKnownPresence === 'available' && jid !== lulli.user.jid);
        
        if (onlineMembers.length > 0) {
            const formattedList = onlineMembers.map(jid => {
                const displayJid = (lid && lid.isLidUser(jid)) ? (lid.get(jid) || jid) : jid;
                return `- @${displayJid.replace(/@.+/, '')}`;
            }).join('\n');

            await m.reply(`✦ Online participants:\n\n${formattedList}`);
        } else {
            await m.reply('No participants are currently online.');
        }
    } catch (e) {
        await m.reply(`✗ An error occurred: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'listonline',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/listonline.js'
};