const run = async (m, lulli, { cfg }) => {
    if (!m.text && !m.quoted) {
        return m.reply('✗ Please mention or reply to the target chat.');
    }

    let targetNumberRaw;
    if (m.quoted && m.quoted.sender) {
        targetNumberRaw = m.quoted.sender.split('@')[0];
    } else if (m.text) {
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            targetNumberRaw = m.mentionedJid[0].split('@')[0];
        } else {
            targetNumberRaw = m.text.replace(/[^0-9]/g, '');
        }
    } else {
        return m.reply('✗ Invalid input format. Please enter a number, mention, or reply to a message.');
    }
    
    if (!targetNumberRaw || isNaN(targetNumberRaw)) return m.reply('✗ Invalid number.');
    if (targetNumberRaw.length < 9 || targetNumberRaw.length > 15) return m.reply('✗ Invalid number format.');
    
    const targetJid = targetNumberRaw + '@s.whatsapp.net';

    const onWaResult = await lulli.onWhatsApp(targetNumberRaw);
    if (!onWaResult || !onWaResult[0]?.exists) {
        return m.reply(`✗ The number @${targetNumberRaw} is not registered on WhatsApp!`);
    }

    if (!m.members.some(x => x.id === targetJid)) {
        return m.reply('✗ The number is not in this group.');
    }

    try {
        await lulli.groupParticipantsUpdate(m.chat, [targetJid], 'promote');
        await m.reply(`✓ Successfully promoted @${targetNumberRaw} to admin.`);
    } catch (e) {
        await m.reply(`✗ Failed to promote @${targetNumberRaw}. Error: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'promote',
    alias: 'pm',
    use: 'mention or reply',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/promote.js'
};