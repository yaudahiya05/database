const run = async (m, lulli, { func }) => {
    try {
        let profilePicUrl = await lulli.profilePictureUrl(m.chat, 'image').catch(() => 'https://telegra.ph/file/320b066dc81928b782c7b.png');
        let buffer = await func.fetchBuffer(profilePicUrl);
        await lulli.sendMessage(m.chat, {
            image: buffer,
            caption: m.m.groupName || 'Group Profile Picture'
        }, {
            quoted: m.m,
            ephemeralExpiration: m.m.expiration
        });
    } catch (error) {
        await m.reply(`✗ Failed to get group profile picture: ${error.message}`);
    }
};

export default {
    run,
    cmd: ['getppgroup', 'getppgrup', 'getppgc'],
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/getppgroup.js'
};