const run = async (m, lulli, { cfg, func }) => {
    if (!m.args || !m.args[0]) {
        return m.reply(func.example(m.cmd, 'open / close'));
    }

    const action = m.args[0].toLowerCase();

    if (/(close|tutup)/.test(action)) {
        try {
            await lulli.groupSettingUpdate(m.chat, 'announcement');
            await lulli.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } catch (err) {
            console.error("Error closing group:", err);
            await lulli.sendReact(m.chat, '❌', m.key);
        }
    } else if (/(open|buka)/.test(action)) {
        try {
            await lulli.groupSettingUpdate(m.chat, 'not_announcement');
            await lulli.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
        } catch (err) {
            console.error("Error opening group:", err);
            await lulli.sendReact(m.chat, '❌', m.key);
        }
    } else {
        m.reply(func.example(m.cmd, 'open / close'));
    }
};

export default {
    run,
    cmd: 'groupset',
    alias: ['group', 'grup', 'gc'],
    use: 'open / close',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/groupset.js'
};