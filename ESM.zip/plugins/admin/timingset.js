async function run(i,e,{func:a,groups:t}){if(t.timing&&Array.isArray(t.timing)){var[m,...r]=i.text.split(" ");switch(m){case"check":case"cek":var n=e=>{var i=t.timing.find(i=>i.event===e);return i?`- *Current status*: ${i.status?"✅":"❌"}
- *Time*: ${i.time} WIB
- *Text*: ${i.text}
`:""},n=`*List Timing Saat Ini* :
1. \`maghrib time\`
${n("maghrib_time")}
2. \`maghrib over\`
${n("maghrib_over")}
3. \`notice sleeping time\`
${n("notice_sleeping_time")}
4. \`sleeping time\`
${n("sleeping_time")}
5. \`morning time\`
`+n("morning_time");await i.reply(n);break;case"time":{if(r.length<2)return i.reply(isValidFormat(i.cmd));var[n,l]=r;if(!n||!l)return i.reply(isValidFormat(i.cmd));if(2!==l.split(":").length)return i.reply(isValidFormat(i.cmd));if(!isValidTime(l))return i.reply("Format waktu salah! gunakan format jam `00-23` dan format menit `00-60`");var[,,]=l.split(":");let e={1:"maghrib_time",2:"maghrib_over",3:"notice_sleeping_time",4:"sleeping_time",5:"morning_time"}[n];if(!["1","2","3","4","5"].includes(n))return i.reply(isValidFormat(i.cmd));t.timing.find(i=>i.event===e).time=l,await i.reply(`Costum \`time\` automatically pada \`${e.replace(/[^a-zA-Z]/gi," ")}\` berhasil diubah menjadi pukul ${l} WIB.`)}break;case"status":{if(r.length<2)return i.reply(isValidFormat(i.cmd));var[n,l]=r;if(!n||!l)return i.reply(isValidFormat(i.cmd));let e={1:"maghrib_time",2:"maghrib_over",3:"notice_sleeping_time",4:"sleeping_time",5:"morning_time"}[n];if(!["1","2","3","4","5"].includes(n))return i.reply(isValidFormat(i.cmd));if(!["on","off"].includes(l))return i.reply(""+a.example(i.cmd,"on / off"));n="on"===l;t.timing.find(i=>i.event===e).status=n,await i.reply(`Costum \`status\` automatically pada \`${e.replace(/[^a-zA-Z]/gi," ")}\` berhasil diubah menjadi `+(n?"active":"non-active"))}break;case"text":{if(r.length<2)return i.reply(isValidFormat(i.cmd));var[l,...n]=r;if(!l||!n)return i.reply(isValidFormat(i.cmd));let e={1:"maghrib_time",2:"maghrib_over",3:"notice_sleeping_time",4:"sleeping_time",5:"morning_time"}[l];if(!["1","2","3","4","5"].includes(l))return i.reply(isValidFormat(i.cmd));l=n.join(" ");t.timing.find(i=>i.event===e).text=l,await i.reply(`Costum \`text\` automatically pada \`${e.replace(/[^a-zA-Z]/gi," ")}\` berhasil diubah menjadi “${l}“`)}break;default:await i.reply(isValidFormat(i.cmd))}}else i.reply("Maaf grup ini belum terdaftar costum automatically.")}function isValidFormat(i){return`Invalid format!

*List Options* :
1. \`time\`
*Example*: _${i} time 1 17:30_
*Desc*: maka waktu pada *maghrib time* akan di setting menjadi 17:30.

2. \`status\`
*Example*: _${i} status 1 off_
*Desc*: maka status pada *maghrib time* akan di matikan.

3. \`text\`
*Example*: _${i} text 1 minimal mandi_
*Desc*: maka text pada *maghrib time* akan di ubah menjadi “minimal mandi“.

4. \`check\`
*Example*: _${i} check_
*Desc*: maka akan menampilkan costum timingset saat ini.`}function isValidTime(i){var[i,e]=i.split(":").map(Number);return 0<=i&&i<=23&&0<=e&&e<=60}module.exports={run:run,cmd:"timingset",alias:"timing-set",use:"<opsi> <event> <time>",type:"admin",admin:!0,group:!0,location:"plugins/admin/timingset.js"};