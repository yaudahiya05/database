import path from 'node:path';
import { getTotalChatInGroup, resetTotalChatForGroup } from '../../lib/totalchat.js';

function formatLocaleDate() {
    const now = new Date();
    const date = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Jakarta' }));

    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();

    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? String(hours).padStart(2, '0') : '12';

    return `${month}-${day}-${year}, ${hours}:${minutes}:${seconds} ${ampm}`;
}

function formatLocaleNumber(number) {
    if (typeof number === 'number') {
        return number.toLocaleString('en-US');
    }
    return String(number);
}

const run = async (m, lulli, { func, groups, socket }) => {
    groups.countchat = groups.countchat === undefined ? true : groups.countchat;
    groups.goodbye = groups.goodbye === undefined ? true : groups.goodbye;

    const [action] = m.args;

    if (/(on|off)$/i.test(action)) {
        const option = action.toLowerCase();
        const status = option === 'on';
        if (groups.countchat === status) {
            return m.reply(`✦ Countchat feature is already ${option === 'on' ? 'enabled' : 'disabled'}.`);
        }
        groups.countchat = status;
        await m.reply(`✓ Countchat feature successfully ${option === 'on' ? 'enabled' : 'disabled'}.`);
    } else if (/reset$/i.test(action)) {
        await resetTotalChatForGroup(m.chat);
        lulli.sendReact(m.chat, '✅', m.key);
        await m.reply('✓ Total chat data for this group has been reset.');
    } else if (/kick$/i.test(action)) {
        const botJids = [...new Set([
            lulli.user.jid,
            ...socket.getAllSockets().filter(x => x.user).map(x => x.user.jid)
        ])];

        const totalChatData = await getTotalChatInGroup(m.chat);
        const chatWithParticipants = m.members.map(participant => ({
            id: participant.id,
            chat: totalChatData[participant.id] || 0
        })).filter(x => !botJids.includes(x.id) && x.chat < 1 && x.id !== m.sender);

        const membersToKick = chatWithParticipants.map(x => x.id);
        if (membersToKick.length === 0) return m.reply('✗ No members with 0 chats can be kicked.');
        await m.reply(`✦ Processing kick for ${membersToKick.length} members with 0 chats...`);
        
        const originalGoodbyeStatus = groups.goodbye;
        groups.goodbye = null; 

        for (let jid of membersToKick) {
            try {
                await lulli.groupParticipantsUpdate(m.chat, [jid], 'remove');
                await func.delay(3000);
            } catch (e) {
                console.error(`Failed to kick member ${jid}:`, e);
            }
        }
        groups.goodbye = originalGoodbyeStatus === null ? true : originalGoodbyeStatus;
        await m.reply(`✓ Successfully kicked ${membersToKick.length} members with 0 chats.`);
    } else {
        const botJids = [...new Set([
            lulli.user.jid,
            ...socket.getAllSockets().filter(x => x.user).map(x => x.user.jid)
        ])];
        const totalChatData = await getTotalChatInGroup(m.chat);
        
        const chatWithParticipants = m.members.map(participant => ({
            id: participant.id,
            chat: totalChatData[participant.id] || 0
        })).filter(x => !botJids.includes(x.id) && x.chat > 0);

        if (chatWithParticipants.length === 0) return m.reply('✦ No chat data to display.');
        const totalChatCount = chatWithParticipants.reduce((sum, p) => sum + p.chat, 0);
        const sortedMembers = chatWithParticipants.sort((a, b) => b.chat - a.chat);
        
        let memberJids = sortedMembers.map(v => v.id);
        let memberLength = m.members.length;

        let caption = `乂  *C H A T - L I S T*\n`;
        caption += `\n📅 ${formatLocaleDate()}`;
        caption += `\n💬 ${formatLocaleNumber(totalChatCount)} Total Messages in Group`;
        caption += `\nℹ️ Information:\n`
        caption += `*${m.prefix}totalchat off* - disable countchat feature.`
        caption += `\n*${m.prefix}totalchat on* - enable countchat feature.`
        caption += `\n*${m.prefix}totalchat reset* - reset countchat data.`
        caption += `\n*${m.prefix}totalchat kick* - kick members with 0 chats.`;
        caption += `\n\n🏆 You are Top ${memberJids.indexOf(m.sender) + 1} Chat out of ${memberLength} Participants\n`;
        sortedMembers.forEach(({ id, chat }, index) => {
            caption += `\n${index + 1}. @${id.replace(/@.+/g, '')}: ${formatLocaleNumber(chat)} messages`;
        });
        await lulli.sendMessage(m.chat, {text: caption, mentions: memberJids}, { quoted: m, ephemeralExpiration: m.expiration });
    }
};

export default {
    run,
    cmd: 'listpesan',
    alias: ['totalchat', 'listtotalchat'],
    use: '[on|off|reset|kick]',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/listpesan.js'
};