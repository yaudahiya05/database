const run = async (m, lulli, {}) => {
    if (!m.quoted || !m.quoted.fakeObj) {
        return m.reply(`✗ Reply a message with the caption ${m.cmd}`);
    }
    const allMembersJids = m.members.map(v => v.id);
    await lulli.sendMessage(m.chat, {
        forward: m.quoted.fakeObj,
        mentions: allMembersJids
    }, {
        ephemeralExpiration: m.expiration
    });
};

export default {
    run,
    cmd: 'totag',
    use: 'reply chat',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/totag.js'
};