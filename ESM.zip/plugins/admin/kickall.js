let database = {};
const run = async (m, lulli, {
    func,
    cfg,
    lid
}) => {
    if (m.isGc && !m.isBotAdmin) return m.reply('✗ Bot is not an admin in this group.');
    if (m.isGc && !m.isAdmin && !m.isOwner && !m.isDevs) return m.reply('✗ You are not authorized to use this command.');
    if (m.isPc && !m.text) return m.reply('✗ Please provide the group ID.');
    let targetGroupId = m.isGc ? m.chat : m.text;
    if (!targetGroupId.endsWith('@g.us')) return m.reply('✗ Invalid group ID format.');
    const isInGroup = await lulli.groupFetchAllParticipating().then(groups => Object.keys(groups).includes(targetGroupId)).catch(() => false);
    if (!isInGroup) return m.reply('✗ The bot is not in that group.');
    let meta = await lulli.groupMetadata(targetGroupId);
    lid.convertLidParticipants(meta);
    let membersToKick = meta.participants.filter(v => v.admin == null && v.id !== lulli.user.jid).map(x => x.id);
    if (membersToKick.length === 0) return m.reply('✗ No non-admin members found to kick.');
    let confirmationText = `Are you sure you want to kick ${membersToKick.length} participants from "${meta.subject}"?\n` + `Timeout *60* seconds.\n\nType *(Y/N)*`.trim();
    let {
        key
    } = await lulli.sendMessage(m.chat, {
        text: confirmationText
    }, {
        quoted: m,
        ephemeralExpiration: m.expiration
    });
    database[m.sender] = {
        sender: m.sender,
        from: targetGroupId,
        key: key,
        members: membersToKick,
        successCount: 0,
        isRunning: false,
        isStopped: false,
        timeout: setTimeout(() => {
            if (database[m.sender] && !database[m.sender].isRunning) {
                m.reply('✗ Timeout. Kick all cancelled.');
                lulli.sendMessage(m.chat, {
                    delete: key
                });
                delete database[m.sender];
            }
        }, 60 * 1000)
    };
};
const main = async (m, lulli, {
    func
}) => {
    if (m.isBot || !database[m.sender] || !m.budy) return;
    if (database[m.sender].isRunning && /^(stop)$/i.test(m.budy)) {
        database[m.sender].isStopped = true;
        return m.reply('✦ Menunggu proses berhenti... Sisa antrean akan dibatalkan.');
    }
    if (m.key.id === database[m.sender].key.id) return
    if (/^(n|no)$/i.test(m.budy)) {
        clearTimeout(database[m.sender].timeout);
        delete database[m.sender];
        await m.reply('✗ Kick all successfully cancelled.');
    } else if (/^(y|yes)$/i.test(m.budy)) {
        let db = database[m.sender];
        clearTimeout(db.timeout);
        db.isRunning = true;
        await m.reply(`✦ Starting to kick ${db.members.length} participants...\n_Ketik *stop* untuk membatalkan di tengah jalan._`);
        try {
            for (let jid of db.members) {
                if (database[m.sender].isStopped) {
                    await m.reply(`Proses dihentikan secara paksa!\nBerhasil kick: *${db.successCount}*\nSisa antrean: *${db.members.length - db.successCount}* dibatalkan.`);
                    break;
                }
                await func.delay(1500);
                await lulli.groupParticipantsUpdate(db.from, [jid], 'remove');
                db.successCount++;
            }
        } catch (err) {
            await m.reply(`✗ Error saat proses: ${err.message}`);
        } finally {
            delete database[m.sender];
            if (!db.isStopped) {
                await m.reply(`✓ Selesai! Berhasil mengeluarkan *${db.successCount}* member.`);
            }
        }
    }
};

export default {
    run,
    main,
    cmd: 'kickall',
    type: 'developer',
    admin: true,
    group: true,
    devs: true,
    botAdmin: true,
    location: 'plugins/developer/kickall.js'
};