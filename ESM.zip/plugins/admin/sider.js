const DATABASE = new Set();

const run = async (m, lulli, { func, cfg, groups }) => {
    groups.member = groups.member || [];

    const memberIdsInGroup = m.members.map(v => v.id);
    groups.member = groups.member.filter(item => memberIdsInGroup.includes(item.jid));

    const sevenDaysInMs = 86400000 * 7;
    const now = Date.now();

    const unregisteredSiders = memberIdsInGroup.filter(jid =>
        !global.db.users[jid] &&
        !groups.member.some(member => member.jid === jid) &&
        jid !== lulli.user.jid
    );

    const inactiveSiders = groups.member.filter(data =>
        data.lastseen &&
        data.lastseen !== 0 &&
        (now - data.lastseen > sevenDaysInMs) &&
        global.db.users[data.jid] &&
        !global.db.users[data.jid].premium &&
        data.jid !== lulli.user.jid
    ).sort((a, b) => a.lastseen - b.lastseen);

    const allSidersToKick = [...new Set([...unregisteredSiders, ...inactiveSiders.map(x => x.jid)])];

    if (m.args[0] === '-y') {
        if (!m.isBotAdmin) return m.reply('✗ I am not an admin in this group for this feature.');
        
        if (allSidersToKick.length === 0) return m.reply('✦ No siders found in this group.');
        
        if (DATABASE.has(m.chat)) return m.reply('✗ There is an ongoing sider kick process. Please wait.');
        DATABASE.add(m.chat);

        const originalGoodbyeStatus = groups.goodbye;
        groups.goodbye = null; 

        try {
            await m.reply(`✦ Processing kick for ${allSidersToKick.length} siders...`);
            for (let jid of allSidersToKick) {
                await func.delay(2000);
                await lulli.groupParticipantsUpdate(m.chat, [jid], 'remove');
            }
            if (groups.goodbye === null) groups.goodbye = true;
            await m.reply(`✓ Successfully removed ${allSidersToKick.length} siders.`);
        } catch (e) {
            if (groups.goodbye === null) groups.goodbye = true;
            await m.reply(`✗ Failed to remove siders. Error: ${e.message}`);
        } finally {
            DATABASE.delete(m.chat);
        }

    } else {
        if (allSidersToKick.length === 0) return m.reply('✦ No siders found in this group.');

        let caption = `乂 *S I D E R - G R O U P*`;
        
        if (unregisteredSiders.length > 0) {
            caption += `\n\n✦ ${unregisteredSiders.length} members with no activity found.\n` + 
                       unregisteredSiders.map(v => `◦ @${v.replace(/@.+/, '')}`).join('\n');
        }
        if (inactiveSiders.length > 0) {
            caption += `\n\n✦ ${inactiveSiders.length} members who have been offline for 1 week.\n` +
                inactiveSiders.map(x => `◦ @${x.jid.replace(/@.+/, '')}\n✦ Lastseen: ${func.toDate(now - x.lastseen).split('D')[0]} days ago`).join('\n');
        }
        caption += `\n\n✦ Note: This feature will be accurate after the bot has been in the group for 1 week. Send *${m.cmd} -y* to remove them.`;
        
        await lulli.reply(m.chat, caption, m, { mentions: allSidersToKick, ephemeralExpiration: m.expiration });
    }
};

export default {
    run,
    cmd: 'sider',
    use: '-y (to kick all)',
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/sider.js'
};