const run = async (m, lulli, { groups }) => {
    groups.welcomeText = groups.welcomeText || '';
    const groupMetadata = global.db.metadata[m.chat] || {};
    const groupName = groupMetadata.subject || 'Cool Group';
    const groupDesc = 'This is the group description.';
    const example = `✦ Information:\n` +
                    `- Use +user to tag the user\n` +
                    `- Use +group to mention the group name\n` +
                    `- Use +desc to add the group description\n\n` +
                    `✦ Example usage:\n` +
                    `${m.cmd} Welcome +user to +group!\n` +
                    `Don't forget to read +desc to know the rules of this group.`;
    if (!m.text) return m.reply(example);
    groups.welcomeText = m.text.trim();
    let previewText = m.text.replace(/\+user/g, `@${m.sender.split('@')[0]}`)
                             .replace(/\+group/g, groupName)
                             .replace(/\+desc/g, groupDesc);
    await m.reply(`✓ Welcome text successfully changed to :\n${previewText}`);
};

export default {
    run,
    cmd: 'setwelcome',
    use: 'text welcome',
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/setwelcome.js'
};