const run = async (m, lulli, { cfg }) => {
    if (!m.text && !m.quoted) {
        return m.reply('✗ Mention or reply to the target chat.');
    }

    let targetNumberRaw;
    if (m.quoted && m.quoted.sender) {
        targetNumberRaw = m.quoted.sender.split('@')[0];
    } else if (m.text) {
        if (m.mentionedJid && m.mentionedJid.length > 0) {
            targetNumberRaw = m.mentionedJid[0].split('@')[0];
        } else {
            targetNumberRaw = m.text.replace(/[^0-9]/g, '');
        }
    } else {
        return m.reply('✗ Invalid input format. Enter a number, mention, or reply to a message.');
    }
    
    if (!targetNumberRaw || isNaN(targetNumberRaw)) return m.reply('✗ Invalid number.');
    if (targetNumberRaw.length < 9 || targetNumberRaw.length > 15) return m.reply('✗ Invalid format.');
    
    const targetJid = targetNumberRaw + '@s.whatsapp.net';

    const restrictedJids = [cfg.owner, lulli.user.jid, ...(global.suryadev || [])];
    if (restrictedJids.includes(targetJid)) {
        return m.reply('✗ Access denied. Cannot demote this JID.');
    }
    
    const onWaResult = await lulli.onWhatsApp(targetNumberRaw);
    if (!onWaResult || !onWaResult[0]?.exists) {
        return m.reply(`✗ Number ${targetNumberRaw} is not registered on WhatsApp!`);
    }

    if (!m.members.some(x => x.id === targetJid)) {
        return m.reply('✗ The number is not in this group.');
    }

    lulli.groupParticipantsUpdate(m.chat, [targetJid], 'demote').then(results => {
        m.reply(`✓ Successfully demoted @${targetNumberRaw} to a regular member.`);
    }).catch((e) => {
        m.reply(`✗ Failed to demote @${targetNumberRaw}. Error: ${e.message}`);
    });
}

export default {
    run,
    cmd: 'demote',
    alias: 'dm',
    use: 'mention or reply',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/demote.js'
};