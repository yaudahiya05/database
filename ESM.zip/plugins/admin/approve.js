function convertMsToDate(ms) {
    const date = new Date(ms);
    const options = {
        timeZone: 'Asia/Jakarta',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    };
    const formattedDate = date.toLocaleString('en-US', options);
    return formattedDate;
}

const run = async (m, lulli, { func }) => {
    const [value] = m.args;
    
    let approvedData = [];
    let caption = `✦ *LIST REQUEST JOIN*\n`;

    const results = await lulli.groupRequestParticipantsList(m.chat);
    
    if (results.length === 0) {
        return m.reply('✗ No pending requests.');
    }

    results.forEach((request, index) => {
        approvedData.push({
            index: index + 1,
            jid: request.phone_number,
            request_method: request.request_method,
            request_time: request.request_time
        });
        caption += `\n\n${index + 1}. @${request.phone_number.split('@')[0]}`;
        caption += `\n◦ Request method: ${request.request_method}`;
        caption += `\n◦ Time: ${convertMsToDate(request.request_time * 1000)}`;
    });

    caption += `\n\n- ${m.prefix}acc 1 to approve participant 1`;
    caption += `\n- ${m.prefix}acc all to approve all participants`;

    if (value && /^(all|semua)$/i.test(value)) {
        for (let request of results) {
            await lulli.groupRequestParticipantsUpdate(m.chat, [request.phone_number], 'approve');
            await func.delay(1000);
        }
        m.reply(`✓ Successfully approved ${results.length} participants.`);
    } else if (value && approvedData.some(x => x.index === parseInt(value))) {
        const userToApprove = approvedData[parseInt(value) - 1].jid;
        await lulli.groupRequestParticipantsUpdate(m.chat, [userToApprove], 'approve');
        m.reply(`✓ Successfully approved @${userToApprove.split('@')[0]}.`, null, { ephemeralExpiration: m.expiration, mentions: [userToApprove] });
    } else {
        await m.reply(caption, null, { mentions: approvedData.map(x => x.jid), ephemeralExpiration: m.expiration });
    }
};

export default {
    run,
    cmd: 'approve',
    alias: ['accept', 'acc'],
    use: 'all / [participant_number]',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/approve.js'
};