const run = async (m, lulli, { cfg }) => {
    try {
        let targetParticipants = [];

        if (m.quoted && /contactMessage/.test(m.quoted.mtype)) {
            const vcard = m.quoted.vcard;
            const match = vcard.match(/waid=(\d+):/);
            if (match) {
                targetParticipants.push(match[1] + '@s.whatsapp.net');
            }
        } else if (m.quoted && m.quoted.sender) {
            targetParticipants.push(m.quoted.sender);
        } else if (m.text) {
            if (m.mentionedJid && m.mentionedJid.length > 0) {
                targetParticipants.push(...m.mentionedJid.slice(0, 2));
            } else {
                const numbers = await Promise.all(m.text.split(',')
                    .map(v => v.replace(/[^0-9]/g, ''))
                    .filter(v => v.length > 4 && v.length < 20)
                    .map(async (v) => {
                        const jid = v + '@s.whatsapp.net';
                        const isOnWa = await lulli.onWhatsApp(jid);
                        return isOnWa && isOnWa[0]?.exists ? jid : null;
                    }));
                targetParticipants.push(...numbers.filter(Boolean).slice(0, 2));
            }
        } else {
            return m.reply('✗ Enter a number or reply to a target chat.');
        }

        if (targetParticipants.length === 0) {
            return m.reply('✗ No valid participants found to add.');
        }

        const results = await lulli.groupParticipantsUpdate(m.chat, targetParticipants, 'add');

        for (let i of results) {
            const targetJid = i?.content?.attrs?.phone_number || i.jid;
            const username = targetJid.split('@')[0];

            switch (i.status) {
                case '200':
                    m.reply(`✓ Successfully added @${username} to the group.`);
                    break;
                case '403':
                    await lulli.sendMessage(m.chat, {
                        text: `✦ Private. Sending group invite to @${username}.`,
                        mentions: [targetJid]
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                    await lulli.sendGroupInvite(m.chat, targetJid, {
                        inviteCode: i.content.content[0].attrs.code,
                        inviteExpiration: i.content.content[0].attrs.expiration,
                        groupName: m.groupName,
                        jpegThumbnail: await lulli.profilePictureUrl(m.chat, 'image').catch(() => 'https://telegra.ph/file/0d25a520bfa0909c74466.jpg'),
                        caption: 'You are invited to join my WhatsApp group',
                        quoted: null
                    });
                    break;
                case '409':
                    m.reply(`✗ @${username} is already in this group.`);
                    break;
                case '408':
                    m.reply(`✗ @${username} recently left this group.`);
                    break;
                case '401':
                    m.reply(`✗ Bot is blocked by @${username}.`);
                    break;
                default:
                    m.reply(`✗ Failed to add @${username}. Status: ${i.status}`);
                    break;
            }
        }
    } catch (e) {
        return m.reply(`✗ An error occurred: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'add',
    use: 'number or reply/mention',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/add.js'
};