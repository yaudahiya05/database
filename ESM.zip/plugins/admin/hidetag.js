const run = async (m, lulli, { func }) => {
    const extractJidsFromText = (input_text) => {
        const jidNumberRegex = /(^|\s|@)(\d{5,15})/g;
        let matches = [];
        let match;
        while ((match = jidNumberRegex.exec(input_text)) !== null) {
            matches.push(`${match[2]}@s.whatsapp.net`);
        }
        return matches;
    };

    if (!m.text) {
        return m.reply(`✗ Invalid input. Please provide text to hidetag. Example: ${func.example(m.command, 'Hello everyone!')}`);
    }

    const members = m.members.map(p => p.id);
    const mentionsInText = extractJidsFromText(m.text);

    const allMentions = [...mentionsInText, ...members];
    const uniqueMentions = [...new Set(allMentions)];

    await lulli.sendMessage(m.chat, {
        text: m.text,
        mentions: uniqueMentions
    }, {
        quoted: null,
        ephemeralExpiration: m.expiration
    });
};

export default {
    run,
    cmd: 'hidetag',
    alias: 'h',
    use: 'text',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/hidetag.js'
};