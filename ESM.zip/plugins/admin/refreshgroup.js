const run = async (m, lulli, {}) => {
    try {
        await lulli.chatModify({
            delete: true,
            lastMessages: [{ key: m.key, messageTimestamp: m.messageTimestamp }]
        }, m.chat);

        lulli.sendReact(m.chat, '✅', m.key);
    } catch (e) {
        lulli.sendReact(m.chat, '❌', m.key);
        await m.reply('✗ Failed to refresh group. Ensure the bot has sufficient permissions.');
    }
};

export default {
    run,
    cmd: 'refreshgroup',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/refreshgroup.js'
};