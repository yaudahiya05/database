const run = async (m, lulli, { groups }) => {
    groups.alarm = groups.alarm || [];
    if (groups.alarm.length === 0) return m.reply('No alarms in this group to reset.');
    groups.alarm = [];
    await m.reply('✓ Successfully reset all alarms in this group.');
};

export default {
    run,
    cmd: 'resetalarm',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/group/resetalarm.js'
};