const run = async (m, lulli) => {
    if (!m.quoted) {
        return await m.reply('✗ This command must be used by replying to a customer\'s message!');
    }

    try {
        const chatId = m.chat;

        const now = new Date();
        const time = now.toLocaleTimeString('en-US', {
            hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'Asia/Jakarta'
        });
        const date = now.toLocaleDateString('en-US', {
            day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Jakarta'
        });

        let groupName = m.isGc ? m.groupName : 'Private Chat';

        const note = m.text.trim() || '-';

        const customerJid = m.quoted.sender;

        const receipt = `
┌─「 ✓ *TRANSACTION COMPLETED* 」
│
├ Time: \`\`\`${time} WIB\`\`\`
├ Date: \`\`\`${date}\`\`\`
├ Location: \`\`\`${groupName}\`\`\`
├ Note: \`\`\`${note}\`\`\`
│
└─「 Thank You! 」

Hello @${customerJid.split('@')[0]}, your order has been successfully processed!`.trim();

        await lulli.sendMessage(chatId, {
            text: receipt,
            mentions: [customerJid]
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });

    } catch (error) {
        console.error('Error in "done" plugin:', error);
        await lulli.sendMessage(m.chat, {
            text: '✗ An error occurred while processing the transaction receipt.'
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    }
};

export default {
    run,
    cmd: 'done',
    use: '(reply message) <note>',
    type: 'admin',
    location: 'plugins/admin/done.js'
};