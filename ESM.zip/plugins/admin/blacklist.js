const run = async (m, lulli, { func, groups, froms }) => {
    groups.blacklist = groups.blacklist || [];

    let uniqueJids = new Set();
    groups.blacklist = groups.blacklist.filter(jid => {
        if (!uniqueJids.has(jid)) {
            uniqueJids.add(jid);
            return true;
        }
        return false;
    });

    switch (m.command) {
        case 'black':
            if (!froms) return m.reply('✗ Invalid input. Mention a member or reply to their message to add to the blacklist.');
            if (groups.blacklist.includes(froms)) return m.reply(`✗ '@${froms.split('@')[0]}' is already in the blacklist.`);
            groups.blacklist.push(froms);
            await m.reply(`✓ '@${froms.split('@')[0]}' has been added to the blacklist.`);
            break;

        case 'white':
            if (!froms) return m.reply('✗ Invalid input. Mention a member or reply to their message to remove from the blacklist.');
            const indexToRemove = groups.blacklist.indexOf(froms);
            if (indexToRemove === -1) return m.reply(`✗ '@${froms.split('@')[0]}' is not in the blacklist.`);
            groups.blacklist.splice(indexToRemove, 1);
            await m.reply(`✓ '@${froms.split('@')[0]}' has been removed from the blacklist.`);
            break;

        case 'blacklist':
            if (groups.blacklist.length === 0) return m.reply('✦ No members in the blacklist.');
            let caption = `✦ *B L A C K - L I S T*\n\nTotal: ${groups.blacklist.length}\n`;
            caption += groups.blacklist.map(jid => `- @${jid.split('@')[0]}`).join('\n');
            await m.reply(caption, null, { mentions: groups.blacklist });
            break;
    }
}

export default {
    run,
    cmd: [
        'black',
        'white',
        'blacklist'
    ],
    use: 'mention or reply',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/blacklist.js'
};