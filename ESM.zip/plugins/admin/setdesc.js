const run = async (m, lulli, { func }) => {
    if (!m.text) {
        return m.reply(`✗ Invalid input. Example: ${func.example(m.cmd, 'Awesome new group description!')}`);
    }
    try {
        await lulli.groupUpdateDescription(m.chat, m.text);
        await lulli.sendReact(m.chat, '✅', m.key);
    } catch (e) {
        await lulli.sendReact(m.chat, '❌', m.key);
        await m.reply(`✗ Failed to change group description. Ensure the bot is an admin. Error: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'setdesc',
    alias: ['setdesk', 'setdeskripsi'],
    use: 'text',
    type: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    location: 'plugins/admin/setdesc.js'
};