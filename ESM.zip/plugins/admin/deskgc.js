const run = async (m, lulli) => {
    const desc = `${m.metadata?.desc || ''}`;
    
    if (desc) {
        await m.reply(desc);
    } else {
        await m.reply('✗ This group does not have a description.');
    }
};

export default {
    run,
    cmd: 'deskgc',
    alias: 'descgc',
    type: 'admin',
    group: true,
    admin: true,
    location: 'plugins/admin/deskgc.js'
};