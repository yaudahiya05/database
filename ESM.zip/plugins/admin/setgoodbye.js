const run = async (m, lulli, { func, groups }) => {
    groups.goodbyeText = groups.goodbyeText || '';
    const groupMetadata = await lulli.groupMetadata(m.chat).catch(() => ({}));
    const groupName = groupMetadata.subject || 'Cool Group';
    const groupDesc = groupMetadata.desc || 'Group description.';
    const exampleGoodbyeText = groups.goodbyeText || `Goodbye +user from +group.`;
    if (!m.text) return m.reply(`✗ Invalid input. Example: ${func.example(m.command, `${exampleGoodbyeText}\n\n+user to tag user\n+group for group name\n+desc for group description`)}`);
    groups.goodbyeText = m.text.trim();
    let previewText = m.text.replace(/\+user/g, `@${m.sender.split('@')[0]}`)
                             .replace(/\+group/g, groupName)
                             .replace(/\+desc/g, groupDesc);
    await m.reply(`✓ Goodbye text successfully changed to :\n${previewText}`);
};

export default {
    run,
    cmd: 'setgoodbye',
    alias: 'setbye',
    use: 'text goodbye',
    type: 'admin',
    admin: true,
    group: true,
    location: 'plugins/admin/setgoodbye.js'
};