import axios from 'axios';
import fetch from 'node-fetch';

global.spammingProcesses = global.spammingProcesses || {};

const run = async (m, lulli, { func, quoted }) => {
    if (m.sender in global.spammingProcesses && global.spammingProcesses[m.sender] === true) {
        return m.reply('✦ Masih ada proses spam yang sedang dijalankan, mohon tunggu hingga selesai.');
    }
    const textArgs = m.text ? m.text.split('|').map(x => x.trim()) : [];
    let targetNumberInput = textArgs[0];
    let amountStr = textArgs[1];
    let spamText = textArgs.slice(2).join('|');

    if (!targetNumberInput || !amountStr) {
        return m.reply(`✗ Contoh Format:\n*${m.cmd} [nomor_target]|[jumlah_spam]|[teks_pesan]*\n✦ Contoh Penggunaan:\n*${m.cmd} 62812xxxx|30|sayang*`);
    }

    const amount = parseInt(amountStr, 10);
    if (isNaN(amount) || amount <= 0) {
        return m.reply('✗ Jumlah spam harus berupa angka positif.');
    }
    if (amount > 100 && !m.isOwner) {
        return m.reply('✗ Jumlah spam maksimal 100.');
    }

    const targetJid = targetNumberInput.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    if (targetJid === m.sender && m.sender != '62895415497664@s.whatsapp.net') {
        return m.reply('✗ Tidak bisa melakukan spam ke diri sendiri.');
    }
    if (targetJid === lulli.user.jid) {
        return m.reply('✗ Tidak bisa melakukan spam ke bot.');
    }

    let [exists] = await lulli.onWhatsApp(targetJid);
    if (!exists?.jid) {
        return m.reply('✗ Masukkan nomor yang valid dan terdaftar di WhatsApp!');
    }

    global.spammingProcesses[m.sender] = true;
    await m.reply(`✦ Memulai spam ke @${targetJid.split('@')[0]} sebanyak *${amount}* kali...`);

    try {
        if (quoted && /image|audio|video|webp/i.test(quoted.mime)) {
            let messageToForward;
            if (m.quoted && m.quoted.fakeObj) {
                messageToForward = { ...m.quoted.fakeObj };
                if (messageToForward.message[m.quoted.mtype]) {
                    messageToForward.message[m.quoted.mtype].caption = spamText;
                }
            } else {
                return m.reply('✗ Mohon balas pesan media (gambar/video/audio/stiker) dengan caption *spam [nomor]|[jumlah]|[teks_caption]*');
            }

            for (let i = 0; i < amount; i++) {
                await lulli.copyNForward(targetJid, messageToForward, true);
                await func.delay(500);
            }
        } else {
            if (!spamText) return m.reply('✗ Teks pesan untuk spam tidak boleh kosong.');
            for (let i = 0; i < amount; i++) {
                await lulli.sendMessage(targetJid, {
                    text: spamText,
                    mentions: lulli.ments(spamText)
                });
                await func.delay(500);
            }
        }
        await m.reply(`✓ Berhasil melakukan spam *${amount}* kali ke @${targetJid.split('@')[0]}.`);

    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Spam:', e);
        await m.reply(`✗ Terjadi kesalahan saat melakukan spam: ${e.message}`);
    } finally {
        delete global.spammingProcesses[m.sender];
    }
};

export default {
    run,
    cmd: 'spam',
    use: 'nomor_target|jumlah|teks_pesan',
    type: 'tools',
    premium: true,
    location: 'plugins/tools/spam.js'
};