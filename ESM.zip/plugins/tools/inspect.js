import moment from"moment-timezone";let run=async(t,e,{func:i,cfg:n})=>{if(!t.text)return t.reply(i.example(t.cmd,"https://chat.whatsapp.com/codeInvite"));if(!t.text.includes("chat.whatsapp.com"))return t.reply("✗ Link tidak valid. Pastikan itu adalah link grup WhatsApp.");e.sendReact(t.chat,"🕒",t.key);var[,r]=t.text.match(/chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i)||[];if(!r)return t.reply("✗ Tidak dapat menemukan kode undangan grup dari link yang diberikan.");try{var s=await e.groupQueryInvite(r);if(!s)return t.reply(i.jsonFormat(s)||"✗ Gagal mendapatkan metadata grup. Mungkin link tidak valid atau grup tidak ditemukan.");let a="✦ *GROUP INSPECTOR*\n\n";a=(a+=`✧ ID Grup: *${s.id||"-"}*
`)+`✧ Nama Grup: *${s.subject||"-"}*
`,s.subjectOwner&&(a+=`✧ Update Nama Oleh: *@${s.subjectOwner.split("@")[0]}*
`),a=(a=(a=(a+=`✧ Update Nama Pada: *${moment(1e3*s.subjectTime).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss")||"-"}*
`)+`✧ Dibuat Oleh: *${s.owner?"@"+s.owner.split("@")[0]:s.id.match("-")?"@"+s.id.split("-")[0]:"Tidak Diketahui"}*
`)+`✧ Dibuat Pada: *${moment(1e3*s.creation).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss")||"-"}*
`)+`✧ Jumlah Anggota: *${s.size||"0"}*
`,s.descOwner&&(a+=`✧ Update Desc Oleh: *@${s.descOwner.split("@")[0]}*
`),a=(a=(a=(a=(a+=`✧ Update Desc Pada: *${moment(1e3*s.descTime).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss")||"-"}*
`)+`✧ ID Deskripsi: *${s.descId||"-"}*
`+`✧ Deskripsi:
`)+`\`\`\`
${s.desc||"Tidak ada deskripsi."}
\`\`\`
`)+`✧ Teman yang ikut bergabung (${s.participants?s.participants.length:0}):
`)+(s.participants&&0<s.participants.length?s.participants.map((a,t)=>++t+". @"+a.jid.split("@")[0]).join("\n"):"  Tidak ada anggota yang diketahui."),await t.reply(a.trim())}catch(a){console.error("✗ Terjadi kesalahan pada Group Inspector:",a),await t.reply(n.mess.wrong(a.message)||"✗ Terjadi kesalahan: "+a.message)}};export default{run:run,cmd:"inspect",use:"link group",type:"tools",desc:"melihat detail informasi dari sebuah grup WhatsApp melalui link undangannya.",premium:!0,limit:!0,location:"plugins/tools/inspect.js"};export{run};