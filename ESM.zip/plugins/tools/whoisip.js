import axios from"axios";let run=async(a,e,{func:t,cfg:i})=>{if(!a.text)return a.reply(t.example(a.cmd,"144.0.283.11"));e.sendReact(a.chat,"🕒",a.key);var o=a.text.trim();if(!/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(o))return a.reply("✗ Format IP Address tidak valid. Contoh: `192.168.1.1`");try{var r=await t.fetchJson(`https://ipwho.is/${o}?lang=id-ID`);if(!r||!r.success)return a.reply("✗ Gagal mengambil informasi IP: "+(r?.message||"Data tidak ditemukan."));var{ip:n,type:s,continent:d,country:l,country_code:c,region:p,city:m,calling_code:u,capital:g,borders:$,flag:h,connection:y,latitude:I,longitude:P}=r,w=(I&&P&&(await e.sendMessage(a.chat,{location:{degreesLatitude:parseFloat(I),degreesLongitude:parseFloat(P),name:`IP From ${l} `+h.emoji,address:m+`, ${p}, `+l}}),await t.delay(1e3)),"✦ *I P - C H E C K E R*\n\n"),w=(w=(w=(w=(w=(w=(w=(w+=`✧ IP: *${n}*
`)+`✧ Tipe IP: *${s}*
`+`✧ Benua: *${d}*
`)+`✧ Negara: *${l}* (${c}) ${h.emoji}
`)+`✧ Ibukota: *${g}*
`+`✧ Wilayah: *${p}*
`)+`✧ Kota: *${m}*
`+`✧ Kode Telepon: *+${u}*
`)+`✧ Perbatasan: *${$||"Tidak Ada"}*
`+`✧ Pemilik IP: *${y?.org||"-"}*
`)+`✧ Provider: *${y?.isp||"-"}*
`)+`✧ Domain: *${y?.domain||"-"}*
`;await a.reply(w.trim())}catch(e){console.error("✗ Terjadi kesalahan pada IP WHOIS:",e),await a.reply("✗ Terjadi kesalahan: "+i.mess.wrong(e.message))}};export default{run:run,cmd:"whoisip",alias:["ipwhois","ipwho"],use:"alamat IP (contoh: 8.8.8.8)",type:"tools",premium:!0,location:"plugins/tools/whoisip.js"};