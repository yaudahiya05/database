import moment from"moment-timezone";function formatMicrosecondTimestamp(a){return a?(a=parseInt(a,10)/1e3,moment(a).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss")):"-"}function formatSecondTimestamp(a){return a?(a=1e3*parseInt(a,10),moment(a).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss")):"-"}let run=async(a,e,{func:t,cfg:i})=>{if(!a.text)return a.reply(t.example(a.cmd,"https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601"));if(!a.text.includes("whatsapp.com/channel"))return a.reply("✗ Link tidak valid. Pastikan itu adalah link channel WhatsApp.");var[,n]=a.text.match(/whatsapp\.com\/channel\/([0-9A-Za-z]{20,24})/i)||[];if(!n)return a.reply("✗ Tidak dapat menemukan kode channel dari link yang diberikan.");e.sendReact(a.chat,"🕒",a.key);try{var r,s=await e.newsletterMetadata("invite",n);if(!s||!s.id)return r="object"==typeof s&&null!==s?JSON.stringify(s,null,2):s,a.reply(`✗ Gagal mendapatkan metadata channel. Mungkin link tidak valid atau channel tidak ditemukan.
Debug Info: `+(r||"Tidak ada info debug."));var{id:m,state:o,thread_metadata:d}=s,c=d?.name?.text,l=d?.name?.update_time,p=d?.creation_time,u=d?.subscribers_count,k=o?.type,h=d?.settings?.reaction_codes,f=d?.verification,y=d?.description?.text,g=d?.description?.update_time,T=(T=(T=(T=(T=(T=(T=(T="✦ *CHANNEL INSPECTOR*\n\n")+`✧ ID Channel: *${m||"-"}*
`+`✧ Nama Channel: *${c||"-"}*
`)+`✧ Update Nama: *${formatMicrosecondTimestamp(l)}*
`)+`✧ Dibuat Pada: *${formatSecondTimestamp(p)}*
`+`✧ Jumlah Pengikut: *${u||"0"}*
`)+`✧ Status: *${t.ucword(k)||"-"}*
`)+`✧ Kode Reaksi: *${h&&Array.isArray(h)&&0<h.length?h.map(a=>a.code||a.id||"").filter(Boolean).join(", "):"-"}*
`+`✧ Verifikasi: *${"VERIFIED"===f?"Terverifikasi":"Tidak Terverifikasi"}*
`)+`✧ Update Deskripsi: *${formatMicrosecondTimestamp(g)}*
`)+`✧ Deskripsi:
`+`\`\`\`
${y||"Tidak ada deskripsi."}
\`\`\`
`;await a.reply(T.trim())}catch(e){console.error("✗ Terjadi kesalahan pada Channel Inspector:",e),await a.reply(i.mess.wrong(e.message)||"✗ Terjadi kesalahan: "+e.message)}};export default{run:run,cmd:"inspectch",use:"link saluran",type:"tools",desc:"melihat detail informasi dari sebuah channel WhatsApp.",premium:!0,location:"plugins/tools/inspectch.js"};