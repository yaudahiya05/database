let newsletterCheckSessions={},run=async(e,n)=>{newsletterCheckSessions[e.sender]=Date.now(),await e.reply("✦ *CEK ID CHANNEL*\n\n_Silahkan teruskan pesan (forward message) dari channel yang ingin Anda cek ID-nya._")},main=async(e,n)=>{var s,a;e.sender in newsletterCheckSessions&&Date.now()-newsletterCheckSessions[e.sender]<36e5&&(s=e.msg?.contextInfo?.forwardedNewsletterMessageInfo)&&(a=`✦ *INFO - CHANNEL*

`,a=(a+=`- ID Channel: *${s.newsletterJid}*
`)+`- Nama Channel: *${s.newsletterName||"Tidak Diketahui"}*
`,await e.reply(a.trim()),delete newsletterCheckSessions[e.sender])};export default{run:run,main:main,cmd:"cekidch",alias:"getidch",type:"tools",limit:!0,location:"plugins/tools/cekidch.js"};