function getDevice(id) {
    const device = id.length > 21 ? 'Android' : id.substring(0, 2) === '3A' ? 'IOS' : 'WhatsApp Web';
    return device;
}

export const run = async (m, lulli) => {
    lulli.sendReact(m.chat, '🕒', m.key);

    if (!m.quoted) {
        lulli.sendReact(m.chat, '❌', m.key);
        return m.reply('✗ Balas pesan target untuk mengecek jenis perangkatnya.');
    }

    try {
        let id = m.quoted.id;
        const deviceType = getDevice(id);

        let caption = '「 *DEVICE DETECTOR* 」\n';
        caption += `Device Type: *${deviceType}*`;

        await m.reply(caption.trim());
        lulli.sendReact(m.chat, '✅', m.key);
    } catch (e) {
        console.error('✗ Terjadi kesalahan pada Device Detector:', e);
        lulli.sendReact(m.chat, '❌', m.key);
        await m.reply(`✗ Terjadi kesalahan: ${e.message}`);
    }
};

export default {
    run,
    cmd: 'cekdevice',
    alias: 'device',
    use: 'balas chat target',
    type: 'tools',
    desc: 'mengecek jenis perangkat (platform) dari pengirim pesan yang dibalas.',
    premium: false,
    location: 'plugins/tools/device.js'
};