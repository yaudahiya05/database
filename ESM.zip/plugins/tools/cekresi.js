import axios from"axios";let run=async(s,i,{})=>{let[r,t]=s.args,e=["shopee-express","ninja","lion-parcel","pos-indonesia","tiki","acommerce","gtl-goto-logistics","paxel","sap-express","indah-logistik-cargo","lazada-express-lex","lazada-logistics","janio-asia","jet-express","pcp-express","pt-ncs","nss-express","grab-express","rcl-red-carpet-logistics","qrim-express","ark-xpress","standard-express-lwe","luar-negeri-bea-cukai","jnt","jne","sicepat","anteraja"],n="╭─「 *LIST - EKSPEDISI* 」\n";if(e.forEach((e,a)=>{n+=`◈ ${a+1}. ${e}
`}),n+="╰─────────────────",!r||!t)return s.reply(`✗ Masukkan nomer resi dan ekspedisi-nya.

~ Contoh: *${s.cmd}* <nomer_resi> <ekspedisi>

`+n);if(!e.includes(t.toLowerCase()))return s.reply(`✗ Ekspedisi *${t}* tidak valid.

`+n);try{var o=(await axios.get(`https://lacakin.vercel.app/api/cekresi?noresi=${encodeURIComponent(r)}&ekspedisi=`+encodeURIComponent(t))).data;if(!o.success||!o.data)return s.reply("✗ "+(o.message||"Data tidak ditemukan atau terjadi kesalahan."));let e=o.data,a="╭─「 *S T A T U S - R E S I* 」\n│\n";if(a=(a=(a=(a=(a=(a=(a+=`◈ Ekspedisi: *${e.ekspedisi}*
`)+`◈ No Resi: *${e.resi}*
`)+`◈ Status: *${e.status}*
`)+`◈ Tanggal Kirim: ${e.tanggalKirim||"-"}
`)+`◈ CS Hotline: ${e.customerService||"-"}
`+`│
`)+`◎ Posisi Terakhir:
~ ${e.lastPosition||"-"}
`)+`│
`+`» *Riwayat Pengiriman:*
`,e.history?.length)for(var l of e.history.slice(0,10))a=(a+=`~ 🕒 ${l.tanggal||"-"}
`)+`~ 📍 ${l.keterangan||"-"}

`;else a+="» _Riwayat tidak ditemukan._\n\n";a=a+`🔗 *Link Pelacakan:* ${e.shareLink||"Tidak Tersedia"}
`+"╰─────────────────",await s.reply(a.trim()),i.sendReact(s.chat,"✅",s.key)}catch(e){console.error("✗ Terjadi kesalahan pada Cek Resi:",e),i.sendReact(s.chat,"❌",s.key),await s.reply("✗ Terjadi kesalahan saat melacak resi: "+(e.message||"Data tersebut tidak dapat ditemukan."))}};export default{run:run,cmd:"cekresi",use:"<nomer_resi> <ekspedisi>",type:"tools",location:"plugins/tools/cekresi.js"};