import fetch from"node-fetch";let run=async(a,e)=>{if(!a.text)return a.reply("✗ Mohon masukkan nama kota/desa.");e.sendReact(a.chat,"🕒",a.key);try{var t=encodeURIComponent(a.text.trim()),i=await(await fetch("https://api.diioffc.web.id/api/tools/cekcuaca?query="+t)).json();if(!i.status||!i.result)return a.reply("✗ "+(i.message||"Tidak ditemukan data cuaca untuk kota/desa tersebut."));var n=i.result,m="✦ *C E K - C U A C A*\n\n",m=(m=(m=(m=(m=(m=(m=(m+=`✧ Nama Lokasi: *${n.name||"-"}*
`)+`✧ Zona Waktu: ${n.timezone||"-"}
`+`✧ Deskripsi: ${n.weather?.[0]?.description||"-"}
`)+`✧ Suhu: *${n.main?.temp||"-"}°C*
`)+`✧ Suhu Minimum: ${n.main?.temp_min||"-"}°C
`)+`✧ Suhu Maksimum: ${n.main?.temp_max||"-"}°C
`)+`✧ Tekanan Udara: ${n.main?.pressure||"-"} hPa
`)+`✧ Kelembapan: ${n.main?.humidity||"-"}%
`)+`✧ Kecepatan Angin: ${n.wind?.speed||"-"} m/s

`;await e.sendMessage(a.chat,{image:{url:"https://tse4.mm.bing.net/th?id=OIP.XC9RLrV4cN8oAQCFcvkvwgHaEJ&pid=Api&P=0&h=180"},caption:m.trim(),mimetype:"image/jpeg"},{quoted:a,ephemeralExpiration:a.expiration})}catch(e){console.error("✗ Terjadi kesalahan pada Cek Cuaca:",e),await a.reply("✗ Terjadi kesalahan: "+(e.message||"Tidak ditemukan data cuaca."))}};export default{run:run,cmd:"cekcuaca",alias:"cca",use:"nama kota/desa",type:"tools",limit:5,location:"plugins/tools/cekcuaca.js"};