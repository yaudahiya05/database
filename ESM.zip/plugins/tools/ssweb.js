let run=async(e,a,{func:n,cfg:t})=>{var[i,s]=e.args;if(!i||!s)return e.reply(`✗ Penggunaan tidak tepat.

✦ Contoh:
*${e.cmd} hp https://example.com*

✦ List Tipe:
- hp
- pc
- tab`);if(i=i.toLowerCase(),!["hp","pc","tab"].includes(i))return e.reply("✗ Tipe screenshot tidak valid.\n\n✦ Pilih dari:\n- hp\n- pc\n- tab\n\n✦ Contoh: *${m.cmd} hp https://example.com*");let r;"hp"===i?r="phone&dimension=480x800":"pc"===i?r="desktop&dimension=1024x768":"tab"===i&&(r="tablet&dimension=800x1280");var p=n.pickRandom(["f57572","f45b80"]);if(!n.isUrl(s))return e.reply("✗ URL yang diberikan tidak valid. Pastikan itu adalah alamat website yang benar.");e.reply("✦ Sedang memproses, mohon tunggu...");try{var o=`https://api.screenshotmachine.com/?key=${p}&url=${encodeURIComponent(s)}&device=${r}&format=png&cacheLimit=0&delay=200`;await a.sendMessage(e.chat,{image:{url:o},caption:`✦ *S S W E B - R E S U L T*

✧ URL: *${s}*
✧ Tipe: *${i.toUpperCase()}*
✧ API Key: *${p}* (Digunakan)

`},{quoted:e,ephemeralExpiration:e.expiration})}catch(a){console.error("✗ Terjadi kesalahan pada Screenshot Web:",a),await e.reply(t.mess.wrong(a.message)||"✗ Terjadi kesalahan saat mengambil screenshot: "+a.message)}};export default{run:run,cmd:"ssweb",use:"<type> <url>",type:"tools",limit:3,premium:!1,location:"plugins/tools/ssweb.js"};