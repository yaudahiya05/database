let run=async(e,a,{func:t})=>{let c;switch(1<=e.args.length?c=e.args.slice(0).join(" "):e.quoted&&e.quoted.text&&(c=e.quoted.text),e.command){case"encode":if(!c)return a.sendReact(e.chat,"❌",e.key),e.reply(t.example(e.cmd,"yaudah iya"));a.sendReact(e.chat,"🕒",e.key);var d=c.trim(),n=Array.from(d).map(e=>"\\u"+e.charCodeAt(0).toString(16).padStart(4,"0")).join("");await e.reply(`*UNICODE ENCODER*

✧ Teks Asli: *${d}*
✧ Hasil Encode : \`\`\`${n}\`\`\``),a.sendReact(e.chat,"✅",e.key);break;case"decode":return c?(a.sendReact(e.chat,"🕒",e.key),/^(\\[uU][0-9a-fA-F]{4})+$/.test(c.trim())?(d=unescape(c.trim().replace(/\\u/g,"%u")),await e.reply(`*UNICODE DECODER*

✧ Teks Encode: \`\`\`${c.trim()}\`\`\`
✧ Hasil Decode : *${d}*`),void a.sendReact(e.chat,"✅",e.key)):(a.sendReact(e.chat,"❌",e.key),e.reply("✗ String yang dimasukkan bukan format Unicode escape yang valid."))):(a.sendReact(e.chat,"❌",e.key),e.reply(t.example(e.cmd,"\\u0079\\u0061\\u0075\\u0064\\u0061\\u0068\\u0020\\u0069\\u0079\\u0061")))}};export default{run:run,cmd:["encode","decode"],use:"text",type:"tools",desc:"mengubah teks ke/dari format Unicode escape.",premium:!1,location:"plugins/tools/encode.js"};