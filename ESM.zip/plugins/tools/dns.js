import axios from"axios";import dns from"dns";let run=async(r,s,{func:a,cfg:e})=>{let n;switch(1<=r.args.length?n=r.args.slice(0).join(" "):r.quoted&&r.quoted.text&&(n=r.quoted.text),r.command){case"ceksubdo":{if(!n)return s.sendReact(r.chat,"❌",r.key),r.reply(`✗ Input domain web!

Contoh :
${r.cmd} google.com`);if(n&&!a.isUrl(n))return s.sendReact(r.chat,"❌",r.key),r.reply(e.mess.error.url||"✗ Format URL tidak valid.");let t=n.replace(/^https?:\/\//,"");s.sendReact(r.chat,"🕒",r.key);try{var i,c,d,o=(await axios.get(`https://crt.sh/?q=${t}&output=json`,{headers:{"Content-Type":"application/json"}})).data;if(!Array.isArray(o)||0===o.length)return s.sendReact(r.chat,"❌",r.key),r.reply("✗ Data subdomain tidak ditemukan.");let e="╭─「 ✦ *SUBDOMAIN - CHECK* 」\n",a=[];for(i of o)i.name_value.split("\n").map(e=>a.push(e));if(0===(l=[...new Set(a.filter(e=>!e.startsWith("*")&&e!==t))]).length)return s.sendReact(r.chat,"❌",r.key),r.reply(`✗ Tidak ada subdomain yang ditemukan untuk *${t}*.`);for(c of l){e=e+`✧ Subdomain: *${c}*
`+`✧ DNS:
`;for(d of await dns.promises.resolve4(c).catch(()=>["-"]))e+=`  - ${d}
`;e+="────────────────\n"}e+="╰───────────────────",await r.reply(e),s.sendReact(r.chat,"✅",r.key)}catch(n){console.error("✗ Error Cek Subdomain:",n),s.sendReact(r.chat,"❌",r.key),await r.reply("✗ Terjadi kesalahan saat cek subdomain: "+n.message)}break}case"sendngl":if(!r.text||!r.text.includes("https://ngl.link/"))return s.sendReact(r.chat,"❌",r.key),r.reply(a.example(r.cmd,"https://ngl.link/denakhtar1 hallo"));var[o,...l]=r.text.split(" ");if(!(o&&0<l.length))return s.sendReact(r.chat,"❌",r.key),r.reply(a.example(r.cmd,"https://ngl.link/denakhtar1 hallo"));s.sendReact(r.chat,"🕒",r.key),o=o.split("https://ngl.link/")[1],l=l.join(" ");try{var t=await axios.post("https://ngl.link/api/submit",`username=${o}&question=${l}&deviceId=18d7b980-ac6a-4878-906e-087dfec6ea1b&gameSlug=&referrer=`),u="╭─「 ✦ *NGL - MESSAGE* 」\n"+`✧ Status: *Pesan terkirim!* 
`+`✧ Target User: *${o}*
`+`✧ ID Pesan: *${t.data.questionId}*
`+`✧ Region: *${t.data.userRegion}*
│
`+"╰───────────────────";await r.reply(u),s.sendReact(r.chat,"✅",r.key)}catch(n){console.error("✗ Error Send NGL:",n),s.sendReact(r.chat,"❌",r.key),await r.reply("✗ Gagal mengirim pesan NGL: "+n.message)}break;case"cekdns":if(!n)return s.sendReact(r.chat,"❌",r.key),r.reply(`✗ Input domain web!

Contoh :
${r.cmd} google.com`);if(n&&!a.isUrl(n))return s.sendReact(r.chat,"❌",r.key),r.reply(e.mess.error.url||"✗ Format URL tidak valid.");s.sendReact(r.chat,"🕒",r.key),l=n.replace(/^https?:\/\//,"");try{var p,k=await a.fetchJson(`https://www.virustotal.com/api/v3/domains/${l}/subdomains?limit=100`,{method:"GET",headers:{accept:"application/json","x-apikey":"d8d56420a997b7372501df999e2fa9b6226c5864ccf509bf142c9f618fdca90c"}});if(!k||!Array.isArray(k.data)||0===k.data.length)return s.sendReact(r.chat,"❌",r.key),r.reply("✗ Data DNS tidak ditemukan untuk domain ini.");let e="╭─「 ✦ *DOMAIN - DNS - CHECKER* 」\n│\n";for(p of k.data){if(e=(e+=`✧ Subdomain: *${p.id}*
`)+`✧ Tipe: *${p.type}*
`+`✧ DNS Records:
`,p.attributes.last_dns_records&&Array.isArray(p.attributes.last_dns_records))for(var y of p.attributes.last_dns_records)e=(e=(e+=`  - Tipe Record: ${y.type}
`)+`    TTL: ${y.ttl}
`)+`    Value: ${y.value}

`;else e+=`  - Tidak ada record DNS yang ditemukan.

`;e+="─────────────────\n"}e+="╰───────────────────",await r.reply(e),s.sendReact(r.chat,"✅",r.key)}catch(n){console.error("✗ Error Cek DNS:",n),s.sendReact(r.chat,"❌",r.key),await r.reply(e.mess.wrong(n.message)||"✗ Terjadi kesalahan saat cek DNS: "+n.message)}break;case"scanurl":if(!n)return s.sendReact(r.chat,"❌",r.key),r.reply(`✗ Input domain web!

Contoh :
${r.cmd} google.com`);if(n&&!a.isUrl(n))return s.sendReact(r.chat,"❌",r.key),r.reply(e.mess.error.url||"✗ Format URL tidak valid.");s.sendReact(r.chat,"🕒",r.key),o=n.replace(/^https?:\/\//,"");try{var h,m,g=await axios.get("https://urlscan.io/api/v1/search/?q="+o);if(!g.data||!Array.isArray(g.data.results)||0===g.data.results.length)return s.sendReact(r.chat,"❌",r.key),r.reply("✗ Tidak ada hasil scan URL yang ditemukan atau URL tidak aktif.");if(g.data.total<=1)return s.sendReact(r.chat,"❌",r.key),r.reply("✗ Masukkan URL yang valid/aktif.");let e="╭─「 ✦ *URL - SCAN - REPORT* 」\n";for([h,m]of g.data.results.entries())e=(e=(e=(e=(e=(e=(e+=`✧ Scan #${h+1}
`)+`  - Visibilitas: *${m.task.visibility||"-"}*
`)+`  - Metode: *${m.task.method||"-"}*
`)+`  - Negara: *${m.page.country||"-"}*
`)+`  - IP: *${m.page.ip||"-"}*
`)+`  - URL: *${m.page.url||"-"}*
`)+`  - Sub Domain: *${m.page.ptr||"-"}*
`+"──────────────────\n";await r.reply(e),s.sendReact(r.chat,"✅",r.key)}catch(n){console.error("✗ Error Scan URL:",n),s.sendReact(r.chat,"❌",r.key),await r.reply("✗ Terjadi kesalahan saat scan URL: "+n.message)}}};export default{run:run,cmd:["ceksubdo","sendngl","cekdns","scanurl"],use:"url",type:"tools",desc:"berbagai alat untuk mengecek informasi domain dan URL.",devs:!0,location:"plugins/tools/dns.js"};export{run};