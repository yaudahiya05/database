let run=async(a,n,{})=>{var o=a.text||a.quoted?.text||"",o=parseFloat(o.replace(/[^0-9.]/g,""));if(!o||isNaN(o))return a.reply(`Masukkan angka yang ingin dikonversi.
Contoh: ${a.prefix}convkoin 39534`);var t=Math.floor(o/20.77),i=(i=(i=`*KONVERSI KOIN*

`)+`Input: ${o.toLocaleString("id-ID")}
`+`Pembagi: 20.77
`)+`Hasil: *${t.toLocaleString("id-ID")}*`;await a.reply(i)};export default{run:run,cmd:"convkoin",alias:["ck","koin"],use:"<angka>",type:"tools",limit:!0,location:"plugins/tools/coinconverter.js"};