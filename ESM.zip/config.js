import path from 'path';
import * as baileys from '@whiskeysockets/baileys'; 
import pkg from './package.json' with { type: 'json' };

const configuration = {
    // nomor owner
    owner: replacement('6285126904781'),
    // nama owner
    ownerName: 'SuryaDev',
    // nomor pengembang buat akses fitur developer
    devs: [
        '62895415497664',
        '6285700408187',
        '6289504842184',
        '6285126904781',
    ].map(replacement),
    // nama bot lu
    botName: 'Lulli Bot',
    // copyright pada beberapa fitur
    copyright: 'Copyright © 2025 SuryaDev',
    // header pada beberapa fitur
    header: `© lulli-bot v${pkg.version}`,
    // footer pada beberapa fitur
    footer: 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ʙʏ sᴜʀʏᴀ',
    // ram maksimal untuk auto restart / gb
    max_ram: 3,
    // blacklist nomor dengan kode negara tersebut
    blocks: ['91', '92', '212'],
    // multi prefix default
    prefixes: /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.,©^]/i,
    // qris url di beberapa fitur seperti donate, buyprem dan sewabot
    qrisUrl: 'https://telegra.ph/file/080cbdedf32c6c84ff435.jpg',
    // audio url yang ada di menu
    audioUrl: 'https://cdn.filestackcontent.com/2r7cSUozTQ2tTS15NfFj',
    // apikey fitur quickchat
    quoteApi: 'https://qc.botcahx.eu.org/generate',
    // url database mongodb (daftar di https://www.mongodb.com/)
    mongoUrl: '',
    // setting cooldown
    cooldown: {
        // cooldown anti spam / detik
        antispam: 10,
        // cooldown command / milidetik
        command: 5000,
    },
    // setting id group dan saluran
    id: {
        // id group (cara ambil: ketik .listgc lalu pilih grup yang di ambil id nya contoh: .listgc 9 id)
        group: '120363264558127828@g.us',
        // id channel (cara ambil: invite bot menjadi admin channel lalu balas pesan undangan dengan perintah .getnewsletter
        newsletter: '120363261409301854@newsletter'
    },
    link: {
        group: 'https://chat.whatsapp.com/BgrnHVRRpRaJKHN7AxGYEa',
        channel: 'https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601'
    },
    // setting pairing code
    pairing: {
        status: true, // ubah false jika ingin menggunakan qr
        number: '6285602467071' // ubah jadi nomor bot lu
    },
    // setting configuration baileys
    baileys: {
        module: baileys, // baileys module
        session: 'session', // session name
        button: true,
        online: false, // online setiap terhubung
        version: [2, 3000, 1033105955],
        browser: ['Ubuntu', 'Chrome', '22.04.4'],
        options: {}
    },
    // setting configuration panel api
    panelApi: {
        domain: '',
        apikey: '',
        capikey: '',
        eggs: '15'
    },
    spam: {
        limit: 3, // batas pesan dianggap spam
        cooldown: 10, // waktu cooldown dalam detik
        warning: 3, // jumlah maksimum peringatan sebelum tindakan diambil
        action: 'BOTH', // tindakan setelah warning terpenuhi (KICK, BLOCK, BOTH)
    },
    // setting path location
    path: {
        system: path.resolve('system'),
        lib: path.resolve('lib'),
        logs: path.resolve('logs'),
        media: path.resolve('media'),
        trash: path.resolve('sampah'),
        jadibot: path.resolve('jadibot'),
    },
    // emoji di auto react story
    emoticon: [
        "🙂‍↔", "💫", "✨",
        "💥", "🌹", "🤍",
        "😹", "🥰", "🤗",
        "😊", "🥳", "😍",
        "💌", "💐", "🦋",
        "🖤", "💗", "😻",
        "🫶🏻", "👏🏻", "💋",
        "🫰🏻", "😎", "🙂‍↕",
        "🤩", "😀", "😇",
        "🌚", "💖", "🌝",
        "🥀", "🗿", "🔥",
        "❤️", "👀", "😌",
        "🌟", "🥳", "🤡"
    ],
    paymentMethods: [
        {
            status: true,
            name: 'QRIS',
            src: 'https://telegra.ph/file/91ec74ba6a45936c0c127.jpg',
            username: 'jabalsurya',
            an: 'SURYA SHOP',
            desc: '_QRIS adalah metode pembayaran otomatis. *Cukup scan dan bayar*. Akun (DANA/OVO/GOPAY/SHOPEEPAY/BANK) tidak perlu premium untuk menggunakan QRIS._'
        },
        {
            name: 'DANA',
            src: '0895415497664',
            an: 'ASM××××'
        },
        {
            name: 'OVO',
            src: '0895415497664',
            an: 'JAB×× SUR××'
        },
        {
            name: 'GOPAY',
            src: '0895415497664',
            an: 'JAB×× SUR××'
        },
        {
            name: 'SHOPEE PAY',
            src: '0895415497664',
            an: 'JAB×× SUR××'
        }
    ],
    packagePanel: [{
            id: 1,
            name: '1GB',
            memory: '1024',
            disk: '1024',
            cpu: '30',
            duration: '30 day',
            price: 3000,
            // normal_price: 3000
        },
        {
            id: 2,
            name: '2GB',
            memory: '2024',
            disk: '2024',
            cpu: '50',
            duration: '30 day',
            price: 5000,
            // normal_price: 5000
        },
        {
            id: 3,
            name: '3GB',
            memory: '3024',
            disk: '3024',
            cpu: '75',
            duration: '30 day',
            price: 7000,
            // normal_price: 7000
        },
        {
            id: 4,
            name: '4GB',
            memory: '4024',
            disk: '4024',
            cpu: '100',
            duration: '30 day',
            price: 9000,
            // normal_price: 9000
        },
        {
            id: 5,
            name: '5GB',
            memory: '5024',
            disk: '5024',
            cpu: '125',
            duration: '30 day',
            price: 11000,
            // normal_price: 11000
        },
        {
            id: 6,
            name: '6GB',
            memory: '6024',
            disk: '6024',
            cpu: '150',
            duration: '30 day',
            price: 13000,
            // normal_price: 13000
        },
        {
            id: 7,
            name: '7GB',
            memory: '7024',
            disk: '7024',
            cpu: '175',
            duration: '30 day',
            price: 15000,
            // normal_price: 15000
        },
        {
            id: 8,
            name: 'UNLI',
            memory: '0',
            disk: '0',
            cpu: '0',
            duration: '30 day',
            price: 17000,
            // normal_price: 20000
        }
    ],
    packageSewabot: [{
            name: 'SEWA 1',
            duration: '7 day',
            price: 5000,
            normal_price: 7000
        },
        {
            name: 'SEWA 2',
            duration: '15 day',
            price: 10000,
            normal_price: 15000
        },
        {
            name: 'SEWA 3',
            duration: '30 day',
            price: 15000,
            normal_price: 25000
        },
        {
            name: 'SEWA 4',
            duration: '60 day',
            price: 30000,
            normal_price: 40000
        },
        {
            name: 'SEWA 5',
            duration: '90 day',
            price: 45000,
            normal_price: 60000
        },
        {
            name: 'SEWA 6',
            duration: '150 day',
            price: 75000,
            normal_price: 100000
        },
        {
            name: 'SEWA 7',
            duration: '365 day',
            price: 185000,
            normal_price: 200000
        },
    ],
    packagePremium: [{
            id: 'P1',
            name: 'PREMIUM 1',
            duration: '7 day',
            price: 3500,
            normal_price: 5000,
        },
        {
            id: 'P2',
            name: 'PREMIUM 2',
            duration: '15 day',
            price: 7500,
            normal_price: 10000,
        },
        {
            id: 'P3',
            name: 'PREMIUM 3',
            duration: '30 day',
            price: 15000,
            normal_price: 20000,
        },
        {
            id: 'P4',
            name: 'PREMIUM 4',
            duration: '60 day',
            price: 30000,
            normal_price: 35000,
        },
        {
            id: 'P5',
            name: 'PREMIUM 5',
            duration: '90 day',
            price: 45000,
            normal_price: 50000
        }
    ],
    // setting messages
    mess: {
        wait: '✦ Processed . . .',
        ok: '✓ Successfully.',
        limit: '✗ Limitmu abis. mau unlimited limit? upgrade ke premium, ketik .buyprem',
        premium: '✗ Fitur ini hanya untuk pengguna premium. beli premium biar bisa akses fitur ini, ketik .buyprem',
        jadibot: '✗ Fitur ini hanya untuk pengguna jadibot.',
        owner: '✗ This feature is only for owners.',
        devs: '✗ This feature is only for developers.',
        group: '✗ Fitur ini hanya akan berfungsi dalam grup.',
        private: '✗ Gunakan fitur ini dalam obrolan pribadi.',
        admin: '✗ Fitur ini hanya untuk admin grup.',
        botAdmin: '✗ Fitur ini akan berfungsi saat bot menjadi admin.',
        game: '✗ Bermain game di chat pribadi hanya untuk pengguna premium, upgrade ke premium dengan ketik .buyprem',
        error: {
            url: '✗ URL tidak valid!',
            api: '✗ Maaf terjadi kesalahan!'
        },
        block: {
            owner: '✗ Fitur ini diblokir oleh owner!',
            system: '✗ Fitur ini diblokir oleh sistem karena terjadi kesalahan!'
        },
        query: '✦ Enter search text',
        search: '✦ Searching . . .',
        empty: '✦ Data kosong.',
        wrong: (error) => `✗ Something went wrong: ${error}`,
        antispam: '✗ kamu terdeteksi spam, harap jeda selama *@cooldown detik*, ini peringatan ke-@warning dari @maxwarning',
        antispam2: '✗ @sender telah diblokir karena melakukan spam secara berulang. hubungi owner jika ingin membuka blokir.',
        verify: '✗ Nomor kamu belum diverifikasi, kirim aja `@command` buat verifikasi! 😉',
        notverified: '✗ Your number is not verified, send *@command* for verification.',
        restrict: '✗ Kamu udah melanggar *Syarat & Ketentuan* bot dengan pakai kata yang dilarang. Jadi, kamu dilarang pakai bot selama @menit menit.',
        banned2: '✗ Maaf, kamu lagi di-banned. Berakhir: *@expire* 😅',
        cooldown: '✗ Command sedang cooldown. Mohon tunggu @detik detik.',
        groupmode: '✗ Gabung yuk ke room chat bot supaya kamu bisa pakai botnya! Klik link ini: @link\n- Jangan lupa follow saluran kami: https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601 Terima kasih! 😊',
        payment: {
            qris: `✦ PAYMENT QRIS\n\n- Atas Nama: @an\n- Username Orkut: @username\n- Harga: @price\n\nCara Pembayaran:\n1. Buka aplikasi mobile banking/e-wallet yang mendukung QRIS\n2. Pilih menu pembayaran QR/Scan QR Code\n3. Arahkan kamera ke QR Code di atas\n4. Konfirmasi pembayaran\n\nPembelian hanya berlaku selama 10 menit. Segera selesaikan pembayaran sebelum waktu habis. Jika sudah, harap kirimkan bukti foto dengan caption \`BUKTI\` untuk dikonfirmasi oleh owner.`,
            ewallet: `✦ PAYMENT @ewallet\n \n- Nomor: @nomor\n- Atas Nama: @an\n- Harga: @price\n\nPembelian hanya berlaku selama 10 menit. Segera selesaikan pembayaran sebelum waktu habis. Jika sudah, harap kirimkan bukti foto dengan caption \`BUKTI\` untuk dikonfirmasi oleh owner.`
        }
    }
};

function replacement(id) {
    return id.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
}

export default configuration;